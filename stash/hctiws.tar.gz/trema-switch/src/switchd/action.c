/*
 * Author: Yasunobu Chiba
 *
 * Copyright (C) 2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include <assert.h>
#include "action.h"
#include "switch_config.h"
#include "switch_port.h"


typedef struct {
  const buffer *frame;
  uint16_t in_port;
} flooding_data;


static void
flooding_walker( switch_port *port, void *user_data ) {
  assert( port != NULL );
  assert( port->device != NULL );
  assert( user_data != NULL );

  flooding_data *fd = user_data;

  if ( port->port_no == fd->in_port || port->device->status.up == false ) {
    return;
  }

  if ( fd->frame == NULL ) {
    error( "Failed to send an Ethernet frame because frame is NULL." );
    return;
  }
  if ( fd->frame->length + ETH_FCS_LENGTH <  ETH_MINIMUM_LENGTH ) {
    error( "Failed to send an Ethernet frame due to too short frame ( length = %u ).",
           fd->frame->length );
    return;
  }

  info( "Sending a frame ( frame = %p, length = %u ) to port %u (%s).",
        fd->frame, fd->frame->length, port->port_no, port->device->name );
  send_frame( port->device, duplicate_buffer( fd->frame ) );
}


static void
execute_action_output( const buffer *frame, uint16_t in_port, struct ofp_action_output *action ) {
  assert( frame != NULL );
  assert( frame->length > 0 );

  switch ( action->port ) {
  case OFPP_IN_PORT:
  {
    debug( "Sending a frame to in_port ( frame = %p, length = %u, in_port = %u ).",
           frame, frame->length, in_port );
    switch_port *port = lookup_switch_port( in_port );
    if ( port != NULL && port->device != NULL ) {
      send_frame( port->device, duplicate_buffer( frame ) );
    }
    else {
      error( "Failed to find a switch port from input port number ( in_port = %u ).", in_port );
    }
  }
  break;

  case OFPP_TABLE:
  {
    warn( "OFPP_TABLE is not implemented yet." );
  }
  break;

  case OFPP_NORMAL:
  {
    warn( "OFPP_NORMAL is not implemented ( frame = %p, length = %u, in_port = %u ).",
          frame, frame->length, in_port );
  }
  break;

  case OFPP_FLOOD:
  case OFPP_ALL:
  {
    debug( "Flooding a frame ( frame = %p, length = %u, in_port = %u ).", frame, frame->length, in_port );
    flooding_data fd = { frame, in_port };
    foreach_switch_port( flooding_walker, &fd );
  }
  break;

  case OFPP_CONTROLLER:
  {
    debug( "Sending a frame to controller ( frame = %p, length = %u, in_port = %u ).",
           frame, frame->length, in_port );

    buffer *pin = NULL;
    if ( config.miss_send_len >= frame->length ) {
      pin = create_packet_in( get_transaction_id(), UINT32_MAX, ( uint16_t ) frame->length,
                              in_port, OFPR_ACTION, frame );
    }
    else {
      buffer *truncated = alloc_buffer_with_length( config.miss_send_len );
      void *p = append_back_buffer( truncated, config.miss_send_len );
      memcpy( p, frame->data, config.miss_send_len );
      pin = create_packet_in( get_transaction_id(), UINT32_MAX, ( uint16_t ) frame->length,
                              in_port, OFPR_ACTION, truncated );
      free_buffer( truncated );
    }
    send_openflow_message( pin );
    free_buffer( pin );      
  }
  break;

  case OFPP_LOCAL:
  {
    warn( "OFPP_LOCAL is not implemented ( frame = %p, length = %u, in_port = %u ).",
          frame, frame->length, in_port );
  }
  break;

  case OFPP_NONE:
  {
    debug( "Discarding a frame explicitly with OFPP_NONE ( frame = %p, length = %u, in_port = %u ).",
           frame, frame->length, in_port );
  }
  break;

  default:
  {
    switch_port *port = lookup_switch_port( action->port );
    if ( port != NULL && port->device != NULL ) {
      info( "Sending a frame ( length = %u ) to %u (%s).", frame->length, port->port_no, port->device->name );
      send_frame( port->device, duplicate_buffer( frame ) );
    }
    else {
      error( "Invalid switch port number ( %#x ).", action->port );
    }
  }
  break;
  }
}


static void
execute_action( const buffer *frame, uint16_t in_port, struct ofp_action_header *ah ) {
  switch ( ah->type ) {
  case OFPAT_OUTPUT:
  {
    execute_action_output( frame, in_port, ( struct ofp_action_output * ) ah );
  }
  break;
  case OFPAT_SET_VLAN_VID:
  case OFPAT_SET_VLAN_PCP:
  case OFPAT_STRIP_VLAN:
  case OFPAT_SET_DL_SRC:
  case OFPAT_SET_DL_DST:
  case OFPAT_SET_NW_SRC:
  case OFPAT_SET_NW_DST:
  case OFPAT_SET_NW_TOS:
  case OFPAT_SET_TP_SRC:
  case OFPAT_SET_TP_DST:
  case OFPAT_ENQUEUE:
  case OFPAT_VENDOR:
  {
    warn( "Not implemented yet ( type = %#x ).", ah->type );
  }
  break;
  default:
  {
    error( "Undefined action type ( type = %#x ).", ah->type );
  }
  break;
  }
}


void
execute_actions( const buffer *frame, uint16_t in_port, const openflow_actions *actions ) {
  assert( frame != NULL );
  assert( frame->length > 0 );
  assert( actions != NULL );
  assert( actions->n_actions > 0 );

  list_element *action = actions->list;
  while ( action != NULL ) {
    struct ofp_action_header *ah = action->data;
    execute_action( frame, in_port, ah );
    action = action->next;
  }
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
