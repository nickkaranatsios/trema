/*
 * Author: Yasunobu Chiba
 *
 * Copyright (C) 2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include <arpa/inet.h>
#include <assert.h>
#include <errno.h>
#include <linux/ethtool.h>
#include <linux/if_ether.h>
#include <linux/if_packet.h>
#include <linux/sockios.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include "chibach.h"
#include "ether_device.h"


static void
up( ether_device *device ) {
  int fd = socket( AF_INET, SOCK_DGRAM, 0 );

  struct ifreq ifr;
  memset( &ifr, 0, sizeof( ifr ) );
  strncpy( ifr.ifr_name, device->name, IFNAMSIZ );
  ifr.ifr_name[ IFNAMSIZ - 1 ] = '\0';

  int ret = ioctl( fd, SIOCGIFFLAGS, &ifr );
  if ( ret == -1 ) {
    error( "Failed to get interface flags ( name = %s, ret = %d, errno = %s [%d] ).",
           ifr.ifr_name, ret, strerror( errno ), errno );
    return;
  }

  ifr.ifr_flags |= IFF_UP | IFF_RUNNING;
  ret = ioctl( fd, SIOCSIFFLAGS, &ifr );
  if ( ret == -1 ) {
    error( "Failed to set interface flags ( name = %s, flags = %#x, ret = %d, errno = %s [%d] ).",
           ifr.ifr_name, ifr.ifr_flags, ret, strerror( errno ), errno );
    return;
  }

  close( fd );
}


static uint32_t
make_current_ofp_port_features( uint32_t speed, uint8_t duplex, uint8_t port, uint8_t autoneg,
                                uint32_t rx_pause, uint32_t tx_pause ) {
  uint32_t ofp_features = 0;

  if ( speed == SPEED_10 && duplex == DUPLEX_HALF ) {
    ofp_features |= OFPPF_10MB_HD;
  }
  if ( speed == SPEED_10 && duplex == DUPLEX_FULL ) {
    ofp_features |= OFPPF_10MB_FD;
  }
  if ( speed == SPEED_100 && duplex == DUPLEX_HALF ) {
    ofp_features |= OFPPF_100MB_HD;
  }
  if ( speed == SPEED_100 && duplex == DUPLEX_FULL ) {
    ofp_features |= OFPPF_100MB_FD;
  }
  if ( speed == SPEED_1000 && duplex == DUPLEX_HALF ) {
    ofp_features |= OFPPF_1GB_HD;
  }
  if ( speed == SPEED_1000 && duplex == DUPLEX_FULL ) {
    ofp_features |= OFPPF_1GB_FD;
  }
  if ( speed == SPEED_10000 ) {
    ofp_features |= OFPPF_10GB_FD;
  }
  if ( port == PORT_TP || port == PORT_AUI || port == PORT_BNC ) {
    ofp_features |= OFPPF_COPPER;
  }
  if ( port == PORT_FIBRE ) {
    ofp_features |= OFPPF_FIBER;
  }
  if ( autoneg == AUTONEG_ENABLE ) {
    ofp_features |= OFPPF_AUTONEG;
  }
  if ( rx_pause & tx_pause ) {
    ofp_features |= OFPPF_PAUSE;
  }
  else if ( rx_pause | tx_pause ) {
    ofp_features |= OFPPF_PAUSE_ASYM;
  }

  return ofp_features;
}


static uint32_t
make_supported_ofp_port_features( uint32_t features ) {
  uint32_t ofp_features = 0;

  if ( features & SUPPORTED_10baseT_Half ) {
    ofp_features |= OFPPF_10MB_HD;
  }
  if ( features & SUPPORTED_10baseT_Full ) {
    ofp_features |= OFPPF_10MB_FD;
  }
  if ( features & SUPPORTED_100baseT_Half ) {
    ofp_features |= OFPPF_100MB_HD;
  }
  if ( features & SUPPORTED_100baseT_Full ) {
    ofp_features |= OFPPF_100MB_FD;
  }
  if ( features & SUPPORTED_1000baseT_Half ) {
    ofp_features |= OFPPF_1GB_HD;
  }
  if ( features & ( SUPPORTED_1000baseT_Full | SUPPORTED_1000baseKX_Full ) ) {
    ofp_features |= OFPPF_1GB_FD;
  }
  if ( features & ( SUPPORTED_10000baseT_Full | SUPPORTED_10000baseKX4_Full | SUPPORTED_10000baseKR_Full ) ) {
    ofp_features |= OFPPF_10GB_FD;
  }
  if ( features & ( SUPPORTED_TP | SUPPORTED_AUI | SUPPORTED_BNC ) ) {
    ofp_features |= OFPPF_COPPER;
  }
  if ( features & SUPPORTED_FIBRE ) {
    ofp_features |= OFPPF_FIBER;
  }
  if ( features & SUPPORTED_Autoneg ) {
    ofp_features |= OFPPF_AUTONEG;
  }
  if ( features & SUPPORTED_Pause ) {
    ofp_features |= OFPPF_PAUSE;
  }
  if ( features & SUPPORTED_Asym_Pause ) {
    ofp_features |= OFPPF_PAUSE_ASYM;
  }

  return ofp_features;
}


bool
update_link_status( ether_device *device ) {
  assert( device != NULL );
  assert( strlen( device->name ) > 0 );

  int fd = socket( PF_INET, SOCK_DGRAM, 0 );
  if ( fd < 0 ) {
    error( "Failed to open a socket ( ret = %d, errno = %s [%d] ).",
           fd, strerror( errno ), errno );
    return false;
  }

  struct ifreq ifr;
  memset( &ifr, 0, sizeof( ifr ) );
  strncpy( ifr.ifr_name, device->name, IFNAMSIZ );
  ifr.ifr_name[ IFNAMSIZ - 1 ] = '\0';

  struct ethtool_value ev;
  ev.cmd = ETHTOOL_GLINK;
  ifr.ifr_data = ( char * ) &ev;
  int ret = ioctl( fd, SIOCETHTOOL, &ifr );
  if ( ret == -1 ) {
    error( "Failed to retrieve link status of %s ( ret = %d, error = %s [%d] ).",
           device->name, ret, strerror( errno ), errno );
    close( fd );
    return false;
  }
  if ( ev.data > 0 ) {
    device->status.up = true;
  }
  else {
    device->status.up = false;
  }

  struct ethtool_cmd ec;
  ec.cmd = ETHTOOL_GSET;
  ifr.ifr_data = ( char * ) &ec;
  ret = ioctl( fd, SIOCETHTOOL, &ifr );
  if ( ret == -1 ) {
    error( "Failed to retrieve statuses of %s ( ret = %d, error = %s [%d] ).",
           device->name, ret, strerror( errno ), errno );
    close( fd );
    return false;
  }

  struct ethtool_pauseparam ep;
  ep.cmd = ETHTOOL_GPAUSEPARAM;
  ifr.ifr_data = ( char * ) &ep;
  ret = ioctl( fd, SIOCETHTOOL, &ifr );
  if ( ret == -1 ) {
    error( "Failed to retrieve pause parameters of %s ( ret = %d, error = %s [%d] ).",
           device->name, ret, strerror( errno ), errno );
    close( fd );
    return false;
  }

  close( fd );

  device->status.curr = make_current_ofp_port_features( ethtool_cmd_speed( &ec ), ec.duplex, ec.port,
                                                        ec.autoneg, ep.rx_pause, ep.tx_pause );
  device->status.advertised = make_supported_ofp_port_features( ec.advertising );
  device->status.supported = make_supported_ofp_port_features( ec.supported );
  device->status.peer = device->status.curr; // FIMXE: how to know the correct value?

  return true;
}


static void
enable_promiscuous( ether_device *device ) {
  int fd = socket( AF_INET, SOCK_DGRAM, 0 );

  struct ifreq ifr;
  memset( &ifr, 0, sizeof( ifr ) );
  strncpy( ifr.ifr_name, device->name, IFNAMSIZ );
  ifr.ifr_name[ IFNAMSIZ - 1 ] = '\0';

  int ret = ioctl( fd, SIOCGIFFLAGS, &ifr );
  if ( ret == -1 ) {
    error( "Failed to get interface flags ( name = %s, ret = %d, errno = %s [%d] ).",
           ifr.ifr_name, ret, strerror( errno ), errno );
    return;
  }

  ifr.ifr_flags |= IFF_PROMISC;
  ret = ioctl( fd, SIOCSIFFLAGS, &ifr );
  if ( ret == -1 ) {
    error( "Failed to set interface flags ( name = %s, flags = %#x, ret = %d, errno = %s [%d] ).",
           ifr.ifr_name, ifr.ifr_flags, ret, strerror( errno ), errno );
    return;
  }

  close( fd );
}


static void
disable_promiscuous( ether_device *device ) {
  int fd = socket( AF_INET, SOCK_DGRAM, 0 );

  struct ifreq ifr;
  memset( &ifr, 0, sizeof( ifr ) );
  strncpy( ifr.ifr_name, device->name, IFNAMSIZ );
  ifr.ifr_name[ IFNAMSIZ - 1 ] = '\0';

  int ret = ioctl( fd, SIOCGIFFLAGS, &ifr );
  if ( ret == -1 ) {
    error( "Failed to get interface flags ( name = %s, ret = %d, errno = %s [%d] ).",
           ifr.ifr_name, ret, strerror( errno ), errno );
    return;
  }

  ifr.ifr_flags &= ~IFF_PROMISC;
  ret = ioctl( fd, SIOCSIFFLAGS, &ifr );
  if ( ret == -1 ) {
    error( "Failed to set interface flags ( name = %s, flags = %#x, ret = %d, errno = %s [%d] ).",
           ifr.ifr_name, ifr.ifr_flags, ret, strerror( errno ), errno );
    return;
  }

  close( fd );
}


static void
handle_received_frames( ether_device *device ) {
  while ( device->recv_queue->length > 0 ) {
    buffer *frame = dequeue_message( device->recv_queue );
    if ( device->received_callback != NULL ) {
      device->received_callback( frame, device->received_user_data );
    }
  }
}


static void
recv_frame( int fd, void *user_data ) {
  UNUSED( fd );

  ether_device *device = user_data;
  assert( device != NULL );

  // all queued messages should be processed before receiving new messages from remote
  if ( device->recv_queue->length > 0 ) {
    return;
  }

  static char recv_buf[ 1522 ];

  while ( 1 ) {
    ssize_t length = recv( device->fd, recv_buf, sizeof( recv_buf ), MSG_DONTWAIT );
    assert( length != 0 );
    if ( length < 0 ) {
      if ( errno == EINTR || errno == EAGAIN || errno == EWOULDBLOCK ) {
        break;
      }
      error( "Receive error ( errno = %s [%d] ).", strerror( errno ), errno );
      return;
    }

    buffer *frame = alloc_buffer_with_length( ( size_t ) length );
    void *p = append_back_buffer( frame, ( size_t ) length );
    memcpy( p, recv_buf, ( size_t ) length );
    enqueue_message( device->recv_queue, frame );
  }

  handle_received_frames( device );
}


static void
flush_send_queue( int fd, void *user_data ) {
  UNUSED( fd );

  ether_device *device = user_data;
  assert( device != NULL );

  debug( "Flushing send queue ( name = %s, queue length = %d ).", device->name, device->send_queue->length );

  set_writable( device->fd, false );

  struct sockaddr_ll sll;
  memset( &sll, 0, sizeof( sll ) );
  sll.sll_ifindex = device->ifindex;

  buffer *buf = NULL;
  while ( ( buf = peek_message( device->send_queue ) ) != NULL ) {
    ssize_t length = sendto( device->fd, buf->data, buf->length, MSG_DONTWAIT,
                             ( struct sockaddr * ) &sll, sizeof( sll ) );
    if ( length < 0 ) {
      if ( errno == EINTR || errno == EAGAIN || errno == EWOULDBLOCK ) {
        set_writable( device->fd, true );
        return;
      }
      error( "Failed to send a message to ethernet device ( name = %s, errno = %s [%d] ).",
             device->name, strerror( errno ), errno );
      return;
    }
    if ( ( size_t ) length < buf->length ) {
      remove_front_buffer( buf, ( size_t ) length );
      set_writable( device->fd, true );
      return;
    }

    buf = dequeue_message( device->send_queue );
    free_buffer( buf );
  }
}


ether_device *
create_ether_device( const char *name ) {
  assert( strlen( name ) > 0 );

  int nfd = socket( PF_INET, SOCK_DGRAM, 0 );
  if ( nfd < 0 ) {
    error( "Failed to open a socket ( ret = %d, errno = %s [%d] ).",
           nfd, strerror( errno ), errno );
    return NULL;
  }

  struct ifreq ifr;
  memset( &ifr, 0, sizeof( ifr ) );
  strncpy( ifr.ifr_name, name, IFNAMSIZ );
  ifr.ifr_name[ IFNAMSIZ - 1 ] = '\0';
  int ret = ioctl( nfd, SIOCGIFINDEX, &ifr );
  if ( ret == -1 ) {
    error( "Failed to retrieve an interface index of %s ( ret = %d, errno = %s [%d] ).",
           name, ret, strerror( errno ), errno );
    close( nfd );
    return NULL;
  }
  int ifindex = ifr.ifr_ifindex;

  ret = ioctl( nfd, SIOCGIFHWADDR, &ifr );
  if ( ret == -1 ) {
    error( "Failed to retrieve hardware address of %s ( ret = %d, error = %s [%d] ).",
           name, ret, strerror( errno ), errno );
    close( nfd );
    return NULL;
  }

  close( nfd );

  int fd = socket( PF_PACKET, SOCK_RAW, htons( ETH_P_ALL ) );
  if ( fd < 0 ) {
    error( "Failed to open a socket ( ret = %d, errno = %s [%d] ).",
           fd, strerror( errno ), errno );
    return NULL;
  }

  struct sockaddr_ll sll;
  memset( &sll, 0, sizeof( sll ) );
  sll.sll_family = AF_PACKET;
  sll.sll_protocol = htons( ETH_P_ALL );
  sll.sll_ifindex = ifindex;
  ret = bind( fd, ( struct sockaddr * ) &sll, sizeof( sll ) );
  if ( ret < 0 ) {
    error( "Failed to bind ( fd = %d, ret = %d, errno = %s [%d] ).",
           fd, ret, strerror( errno ), errno );
    close( fd );
    return NULL;
  }

  while ( 1 ) {
    char buf;
    ssize_t length = recv( fd, &buf, 1, MSG_DONTWAIT );
    if ( length <= 0 ) {
      break;
    }
  }

  ether_device *device = xmalloc( sizeof( ether_device ) );
  memset( device, 0, sizeof( ether_device ) );
  strncpy( device->name, name, IFNAMSIZ );
  device->name[ IFNAMSIZ - 1 ] = '\0';
  device->fd = fd;
  device->ifindex = ifindex;
  memcpy( device->hw_addr, ifr.ifr_hwaddr.sa_data, ETH_ADDRLEN );
  device->send_queue = create_message_queue();
  device->recv_queue = create_message_queue();

  set_fd_handler( fd, recv_frame, device, flush_send_queue, device );
  set_readable( fd, true );

  enable_promiscuous( device );
  up( device );
  update_link_status( device );

  return device;
}


void
delete_ether_device( ether_device *device ) {
  assert( device != NULL );
 
  if ( device->fd >= 0 ) {
    set_readable( device->fd, false );
    if ( device->send_queue->length > 0 ) {
      set_writable( device->fd, false );
    }
    delete_fd_handler( device->fd );
    close( device->fd );
  }

  disable_promiscuous( device );

  delete_message_queue( device->send_queue );
  delete_message_queue( device->recv_queue );

  xfree( device );
}


bool
send_frame( ether_device *device, buffer *frame ) {
  assert( device != NULL );
  assert( device->send_queue != NULL );
  assert( frame != NULL );
  assert( frame->length > 0 );

  bool ret = enqueue_message( device->send_queue, frame );
  if ( ret == false ) {
    return false;
  }

  if ( device->send_queue->length > 0 && device->fd >= 0 ) {
    set_writable( device->fd, true );
  }

  return true;
}


bool
set_frame_received_handler( ether_device *device, frame_received_handler callback, void *user_data ) {
  assert( device != NULL );
  assert( callback != NULL );

  device->received_callback = callback;
  device->received_user_data = user_data;

  return true;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
