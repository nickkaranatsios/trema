/*
 * Functions for sending/receving Ethernet frames with raw socket interface.
 *
 * Author: Yasunobu Chiba
 *
 * Copyright (C) 2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#ifndef ETHER_DEVICE_H
#define ETHER_DEVICE_H


#include <net/if.h>
#include "chibach.h"


typedef void ( *frame_received_handler )( buffer *frame, void *user_data );


typedef struct {
  char name[ IFNAMSIZ ];
  int ifindex;
  uint8_t hw_addr[ ETH_ADDRLEN ];
  struct {
    bool up;
    uint32_t curr;
    uint32_t advertised;
    uint32_t supported;
    uint32_t peer;
  } status;
  int fd;
  message_queue *send_queue;
  message_queue *recv_queue;
  frame_received_handler received_callback;
  void *received_user_data;
} ether_device;



ether_device *create_ether_device( const char *name );
void delete_ether_device( ether_device *device );
bool send_frame( ether_device *device, buffer *frame );
bool set_frame_received_handler( ether_device *device, frame_received_handler callback, void *user_data );
bool update_link_status( ether_device *device );


#endif // ETHER_DEVICE_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
