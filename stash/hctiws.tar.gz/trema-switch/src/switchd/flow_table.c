/*
 * Author: Yasunobu Chiba
 *
 * Copyright (C) 2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include <assert.h>
#include <errno.h>
#include <string.h>
#include "common.h"
#include "flow_table.h"


flow_entry*
alloc_flow_entry( struct ofp_match match, const openflow_actions *actions, uint16_t priority,
                  uint16_t flags, uint64_t cookie, uint16_t idle_timeout, uint16_t hard_timeout ) {
  flow_entry *entry = xmalloc( sizeof( flow_entry ) );
  memset( entry, 0, sizeof( flow_entry ) );

  entry->match = match;
  entry->actions = copy_actions( actions );
  entry->priority = priority;
  entry->flags = flags;
  entry->cookie = cookie;
  entry->idle_timeout = idle_timeout;
  entry->hard_timeout = hard_timeout;
  entry->packet_count = 0;
  entry->byte_count = 0;

  bool ret = now( &entry->created_at );
  if ( ret == false ) {
    xfree( entry );
    return NULL;
  }

  entry->last_seen = entry->created_at;

  return entry;
}


void
free_flow_entry( flow_entry *entry ) {
  assert( entry != NULL );

  if ( entry->actions != NULL ) {
    delete_actions( entry->actions );
  }
  xfree( entry );
}


flow_entry*
lookup_flow_entry( struct ofp_match match ) {
  return lookup_match_entry( match );
}


flow_entry*
lookup_flow_entry_strict( struct ofp_match match, uint16_t priority ) {
  return lookup_match_strict_entry( match, priority );
}


bool
add_flow_entry( flow_entry *entry ) {
  assert( entry != NULL );

  return insert_match_entry( entry->match, entry->priority, entry );
}


bool
update_flow_entry( flow_entry *entry ) {
  assert( entry != NULL );

  return update_match_entry( entry->match, entry->priority, entry );
}


bool
delete_flow_entry( flow_entry *entry ) {
  assert( entry != NULL );

  flow_entry *deleted = delete_match_entry( entry->match, entry->priority );

  return ( deleted != NULL ) ? true : false;
}


typedef struct {
  foreach_flow_entry_handler callback;
  void *user_data;
} foreach_flow_entry_data;


static void
foreach_flow_entry_walker( struct ofp_match match, uint16_t priority, void *data, void *user_data ) {
  UNUSED( match );
  UNUSED( priority );

  foreach_flow_entry_data *param = user_data;
  param->callback( data, param->user_data );
}


void
foreach_flow_entry( foreach_flow_entry_handler callback, void *user_data ) {
  foreach_flow_entry_data param = { callback, user_data };
  foreach_match_table( foreach_flow_entry_walker, &param );
}


openflow_actions*
copy_actions( const openflow_actions *actions ) {
  assert( actions != NULL );

  openflow_actions *copied = create_actions();
  copied->n_actions = actions->n_actions;
  list_element *action = actions->list;
  while( action != NULL ) {
    size_t action_length = ( ( struct ofp_action_header * ) action->data )->len;
    struct ofp_action_header *ah = xmalloc( action_length );
    memcpy( ah, action->data, action_length );
    append_to_tail( &copied->list, ah );
    action = action->next;
  }

  return copied;
}


static void
send_flow_removed( flow_entry *entry, uint8_t reason ) {
  assert( entry != NULL );

  struct timespec duration = { 0, 0 };
  now( &duration );
  SUB_TIMESPEC( &duration, &entry->created_at, &duration );

  buffer *flow_removed = create_flow_removed( get_transaction_id(), entry->match, entry->cookie,
                                              entry->priority, reason,
                                              ( uint32_t ) duration.tv_sec, ( uint32_t ) duration.tv_nsec,
                                              entry->idle_timeout, entry->packet_count, entry->byte_count );
  send_openflow_message( flow_removed );
  free_buffer( flow_removed );
}


static void
age_flow_entries_walker( flow_entry *entry, void *user_data ) {
  const struct timespec *current_time = user_data;
  struct timespec diff = { 0, 0 };
  if ( entry->hard_timeout > 0 ) {
    SUB_TIMESPEC( current_time, &entry->created_at, &diff );
    if ( diff.tv_sec >= entry->hard_timeout ) {
      delete_flow_entry( entry );
      if ( ( entry->flags & OFPFF_SEND_FLOW_REM ) != 0 ) {
        send_flow_removed( entry, OFPRR_HARD_TIMEOUT );
      }
      free_flow_entry( entry );
    }
  }

  if ( entry->idle_timeout > 0 ) {
    SUB_TIMESPEC( current_time, &entry->last_seen, &diff );
    if ( diff.tv_sec >= entry->idle_timeout ) {
      delete_flow_entry( entry );
      if ( ( entry->flags & OFPFF_SEND_FLOW_REM ) != 0 ) {
        send_flow_removed( entry, OFPRR_IDLE_TIMEOUT );
      }
      free_flow_entry( entry );
    }
  }
}


static void
age_flow_entries( void *user_data ) {
  UNUSED( user_data );
  struct timespec current_time;
  now( &current_time );
  foreach_flow_entry( age_flow_entries_walker, &current_time );
}



void
init_flow_table() {
  init_match_table();
  add_periodic_event_callback( 1, age_flow_entries, NULL );  
}


void
finalize_flow_table() {
  finalize_match_table();
  delete_periodic_event_callback( age_flow_entries );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
