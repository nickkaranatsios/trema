/*
 * Flow table implementation.
 *
 * Author: Yasunobu Chiba
 *
 * Copyright (C) 2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#ifndef FLOW_TABLE_H
#define FLOW_TABLE_H


#include <time.h>
#include "chibach.h"


typedef struct {
  struct ofp_match match;
  openflow_actions *actions;
  uint16_t priority;
  uint16_t flags;
  uint64_t cookie;
  uint16_t idle_timeout;
  uint16_t hard_timeout;
  uint64_t packet_count;
  uint64_t byte_count;
  struct timespec created_at;
  struct timespec last_seen;
} flow_entry;

typedef void ( *foreach_flow_entry_handler )( flow_entry *entry, void *user_data );


flow_entry* alloc_flow_entry( struct ofp_match match, const openflow_actions *actions, uint16_t priority,
                              uint16_t flags, uint64_t cookie, uint16_t idle_timeout, uint16_t hard_timeout );
void free_flow_entry( flow_entry *entry );
flow_entry* lookup_flow_entry( struct ofp_match match );
flow_entry* lookup_flow_entry_strict( struct ofp_match match, uint16_t priority );
bool add_flow_entry( flow_entry *entry );
bool update_flow_entry( flow_entry *entry );
bool delete_flow_entry( flow_entry *entry );
void foreach_flow_entry( foreach_flow_entry_handler callback, void *user_data );
openflow_actions* copy_actions( const openflow_actions *actions );
void init_flow_table( void );
void finalize_flow_table( void );


#endif // FLOW_TABLE_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
