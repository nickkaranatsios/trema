/*
 * Author: Yasunobu Chiba
 *
 * Copyright (C) 2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include <errno.h>
#include <inttypes.h>
#include <stdio.h>
#include <string.h>
#include <sys/utsname.h>
#include "chibach.h"
#include "switch_config.h"


switch_config config = {
  "Trema Project", // mfr_desc
  "Chibach", // *default* hw_desc
  "Trema-based OpenFlow Switch", // sw_desc
  "0", // serial_num
  "Trema-based OpenFlow Datapath", // dp_desc
  0, // datapath_id
  0, // n_buffers
  1, // n_tables
  OFPC_ARP_MATCH_IP, // capabilities
  1 << OFPAT_OUTPUT, // actions
  0, // flags
  65535, // miss_send_len
};


void
init_switch_config() {
  struct utsname buf;
  int ret = uname( &buf );
  if ( ret < 0 ) {
    error( "Failed to retrieve system information ( errno = %s [%d] ).",
           strerror( errno ), errno );
    return;
  }

  snprintf( config.hw_desc, DESC_STR_LEN, "%s %s %s %s %s",
            buf.sysname, buf.nodename, buf.release, buf.version, buf.machine );
  config.hw_desc[ DESC_STR_LEN - 1 ] = '\0';
  info( "hw_desc is set to '%s'.", config.hw_desc );

  snprintf( config.sw_desc, DESC_STR_LEN, "%s", get_chibach_name() );
  config.sw_desc[ DESC_STR_LEN - 1 ] = '\0';
  info( "sw_desc is set to '%s'.", config.sw_desc );

  config.datapath_id = get_datapath_id();
  info( "datapath_id is set to %#" PRIx64 ".", config.datapath_id );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
