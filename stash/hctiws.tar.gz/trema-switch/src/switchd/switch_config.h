/*
 * Utilities for managing switch-wide configuration.
 *
 * Author: Yasunobu Chiba
 *
 * Copyright (C) 2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#ifndef SWITCH_CONFIG_H
#define SWITCH_CONFIG_H


#include "chibach.h"


typedef struct {
  const char mfr_desc[ DESC_STR_LEN ];
  char hw_desc[ DESC_STR_LEN ];
  char sw_desc[ DESC_STR_LEN ];
  const char serial_num[ SERIAL_NUM_LEN ];
  const char dp_desc[ DESC_STR_LEN ];
  uint64_t datapath_id;
  const uint32_t n_buffers;
  const uint8_t n_tables;
  const uint32_t capabilities;
  const uint32_t actions;
  uint16_t flags;
  uint16_t miss_send_len;
} switch_config;


extern switch_config config;


void init_switch_config( void );


#endif // SWITCH_CONFIG_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
