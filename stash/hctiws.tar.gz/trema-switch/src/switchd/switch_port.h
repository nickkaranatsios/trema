/*
 * Functions for managing switch ports.
 *
 * Author: Yasunobu Chiba
 *
 * Copyright (C) 2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#ifndef SWITCH_PORT_H
#define SWITCH_PORT_H


#include "chibach.h"
#include "ether_device.h"


typedef struct {
  uint16_t port_no;
  struct {
    uint32_t state;
    uint32_t config;
    uint32_t curr;
    uint32_t advertised;
    uint32_t supported;
    uint32_t peer;
  } status;
  ether_device *device;
} switch_port;

typedef void ( *switch_port_walker )( switch_port *port, void *user_data );


void init_switch_port( void );
void finalize_switch_port( void );
switch_port* lookup_switch_port( uint16_t port_no );
void foreach_switch_port( switch_port_walker callback, void *user_data );
switch_port* add_switch_port( const char *interface );
bool update_switch_port_status( switch_port *port );
void switch_port_to_ofp_phy_port( struct ofp_phy_port *phy_port, const switch_port *port );


#endif // SWITCH_PORT_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
