/*
 * Author: Yasunobu Chiba
 *
 * Copyright (C) 2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include <assert.h>
#include <inttypes.h>
#include <getopt.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#include "action.h"
#include "chibach.h"
#include "common.h"
#include "ether_device.h"
#include "flow_table.h"
#include "switch_config.h"
#include "switch_port.h"


static bool controller_ready = false;


static void
check_switch_port_status_walker( switch_port *port, void *user_data ) {
  UNUSED( user_data );
  bool updated = update_switch_port_status( port );
  if ( updated ) {
    uint8_t reason = OFPPR_MODIFY;
    struct ofp_phy_port desc;
    memset( &desc, 0, sizeof( struct ofp_phy_port ) );
    switch_port_to_ofp_phy_port( &desc, port );
    buffer *port_status = create_port_status( get_transaction_id(), reason, desc );
    send_openflow_message( port_status );
    free_buffer( port_status );
  }
}


static void
check_switch_port_status( void *user_data ) {
  UNUSED( user_data );
  foreach_switch_port( check_switch_port_status_walker, NULL );
}


static void
handle_hello( uint32_t transaction_id, uint8_t version, void *user_data ) {
  info( "Hello received ( transaction_id = %#x, version = %#x, user_data = %p ).",
        transaction_id, version, user_data );
}


static void
handle_echo_request( uint32_t transaction_id, const buffer *body, void *user_data ) {
  info( "Echo request received ( transaction_id = %#x, body = %p, user_data = %p ).",
        transaction_id, body, user_data );

  buffer *reply = create_echo_reply( transaction_id, body );
  send_openflow_message( reply );
  free_buffer( reply );
}


static void
create_phy_ports_walker( switch_port *port, void *user_data ) {
  assert( port != NULL );
  assert( user_data != NULL );

  struct ofp_phy_port *phy_port = xmalloc( sizeof( struct ofp_phy_port ) );
  memset( phy_port, 0, sizeof( struct ofp_phy_port ) );

  update_switch_port_status( port );
  switch_port_to_ofp_phy_port( phy_port, port );
  append_to_tail( user_data, phy_port );
}


static void
create_phy_ports( list_element **list ) {
  create_list( list );
  foreach_switch_port( create_phy_ports_walker, list );
}


static void
delete_phy_ports( list_element *list ) {
  assert( list != NULL );

  list_element *e = list;
  while ( e != NULL ) {
    xfree( e->data );
    e = e->next;
  }

  delete_list( list );
}


static void
handle_features_request( uint32_t transaction_id, void *user_data ) {
  info( "Features request received ( transaction_id = %#x, user_data = %p ).",
        transaction_id, user_data );

  info( "Sending a features reply message." );

  list_element *ports = NULL;
  create_phy_ports( &ports );
  buffer *features_reply = create_features_reply( get_transaction_id(), config.datapath_id,
                                                  config.n_buffers, config.n_tables,
                                                  config.capabilities, config.actions, ports );
  send_openflow_message( features_reply );
  free_buffer( features_reply );
  if ( ports != NULL ) {
    delete_phy_ports( ports );
  }

  add_periodic_event_callback( 1, check_switch_port_status, NULL );

  controller_ready = true;
}


static void
handle_set_config( uint32_t transaction_id, uint16_t flags, uint16_t miss_send_len, void *user_data ) {
  info( "Set config received ( transaction_id = %#x, flags = %#x, miss_send_len = %u, user_data = %p ).",
        transaction_id, flags, miss_send_len, user_data );

  if ( config.miss_send_len != miss_send_len ) {
    info( "miss_send_len is updated ( %u -> %u ).", config.miss_send_len, miss_send_len );
    config.miss_send_len = miss_send_len;
  }
  if ( config.flags != flags ) {
    info( "Config flags are updated ( %#x -> %#x ).", config.flags, flags );
    config.flags = flags;
  }
}


static void
send_flow_removed( flow_entry *entry ) {
  assert( entry != NULL );

  struct timespec duration = { 0, 0 };
  now( &duration );
  SUB_TIMESPEC( &duration, &entry->created_at, &duration );

  buffer *flow_removed = create_flow_removed( get_transaction_id(), entry->match, entry->cookie,
                                              entry->priority, OFPRR_DELETE,
                                              ( uint32_t ) duration.tv_sec, ( uint32_t ) duration.tv_nsec,
                                              entry->idle_timeout, entry->packet_count, entry->byte_count );
  send_openflow_message( flow_removed );
  free_buffer( flow_removed );
}


static void
send_error( uint32_t transaction_id, uint16_t type, uint16_t code, const buffer *original_message ) {
  buffer *err = create_error( transaction_id, type, code, original_message );
  send_openflow_message( err );
  free_buffer( err );
}


static void
handle_flow_mod_add( uint32_t transaction_id, struct ofp_match match, uint64_t cookie,
                     uint16_t idle_timeout, uint16_t hard_timeout, uint16_t priority, uint32_t buffer_id,
                     uint16_t out_port, uint16_t flags, const openflow_actions *actions, void *user_data ) {
  UNUSED( transaction_id );
  UNUSED( out_port );
  UNUSED( user_data );

  if ( buffer_id != UINT32_MAX ) {
    warn( "Invalid buffer id ( %#x ). Frame buffering is not supported.", buffer_id );
  }
  flow_entry *entry = lookup_flow_entry_strict( match, priority );
  if ( entry != NULL ) {
    if ( entry->actions != NULL ) {
      delete_actions( entry->actions );
    }
    entry->actions = copy_actions( actions );
    entry->idle_timeout = idle_timeout;
    entry->hard_timeout = hard_timeout;
    entry->flags = flags;
    entry->cookie = cookie;
    update_flow_entry( entry );
  }
  else {
    entry = alloc_flow_entry( match, actions, priority, flags, cookie, idle_timeout, hard_timeout );
    add_flow_entry( entry );
  }
}


static void
handle_flow_mod_modify( uint32_t transaction_id, struct ofp_match match, uint64_t cookie,
                        uint16_t idle_timeout, uint16_t hard_timeout, uint16_t priority, uint32_t buffer_id,
                        uint16_t out_port, uint16_t flags, const openflow_actions *actions, void *user_data,
                        bool strict ) {
  UNUSED( transaction_id );
  UNUSED( buffer_id );
  UNUSED( out_port );
  UNUSED( user_data );

  flow_entry *entry = NULL;
  if ( strict ) {
    entry = lookup_flow_entry_strict( match, priority );
    if ( entry != NULL ) {
      if ( entry->actions != NULL ) {
        delete_actions( entry->actions );
      }
      entry->actions = copy_actions( actions );
      entry->idle_timeout = idle_timeout;
      entry->hard_timeout = hard_timeout;
      entry->flags = flags;
      entry->cookie = cookie;
      update_flow_entry( entry );
    }
  }
  else {
    // TODO: implement here
  }
}


static bool
delete_flow_entry_with_outport( flow_entry *entry, uint16_t out_port ) {
  assert( entry != NULL );

  bool ok = false;

  if ( out_port == OFPP_NONE ) {
    ok = true;
  }
  else {
    if ( entry->actions != NULL ) {
      for ( list_element *e = entry->actions->list; e != NULL; e = e->next ) {
        struct ofp_action_output *ao = e->data;
        if ( ao->type == OFPAT_OUTPUT && ao->port == out_port ) {
          ok = true;
        }
      }
    }
  }

  if ( ok ) {
    delete_flow_entry( entry );
    if ( ( entry->flags & OFPFF_SEND_FLOW_REM ) != 0 ) {
      send_flow_removed( entry );
    }
    free_flow_entry( entry );
  }

  return ok;
}


static void
handle_flow_mod_delete( uint32_t transaction_id, struct ofp_match match, uint64_t cookie,
                        uint16_t idle_timeout, uint16_t hard_timeout, uint16_t priority, uint32_t buffer_id,
                        uint16_t out_port, uint16_t flags, const openflow_actions *actions, void *user_data,
                        bool strict ) {
  UNUSED( transaction_id );
  UNUSED( cookie );
  UNUSED( idle_timeout );
  UNUSED( hard_timeout );
  UNUSED( buffer_id );
  UNUSED( out_port );
  UNUSED( flags );
  UNUSED( actions );
  UNUSED( user_data );

  flow_entry *entry = NULL;
  if ( strict ) {
    entry = lookup_flow_entry_strict( match, priority );
    if ( entry != NULL ) {
      delete_flow_entry_with_outport( entry, out_port );
    }
  }
  else {
    // TODO: implement here
  }
}


static void
handle_flow_mod( uint32_t transaction_id, struct ofp_match match, uint64_t cookie, uint16_t command,
                 uint16_t idle_timeout, uint16_t hard_timeout, uint16_t priority, uint32_t buffer_id,
                 uint16_t out_port, uint16_t flags, const openflow_actions *actions, void *user_data ) {
  char match_str[ 256 ];
  match_to_string( &match, match_str, sizeof( match_str ) );
  info( "Flow modification received ( transaction_id = %#x, match = [%s], cookie = %#" PRIx64 ", "
        "command = %#x, idle_timeout = %u, hard_timeout = %u, priority = %u, buffer_id = %#x, "
        "out_port = %u, flags = %#x, actions = %p, user_data = %p ).",
        transaction_id, match_str, cookie, command, idle_timeout, hard_timeout, priority, buffer_id,
        out_port, flags, actions, user_data );

  switch ( command ) {
  case OFPFC_ADD:
  {
    handle_flow_mod_add( transaction_id, match, cookie, idle_timeout, hard_timeout, priority,
                         buffer_id, out_port, flags, actions, user_data );
  }
  break;

  case OFPFC_MODIFY:
  {
    handle_flow_mod_modify( transaction_id, match, cookie, idle_timeout, hard_timeout, priority,
                            buffer_id, out_port, flags, actions, user_data, false );
  }
  break;

  case OFPFC_MODIFY_STRICT:
  {
    handle_flow_mod_modify( transaction_id, match, cookie, idle_timeout, hard_timeout, priority,
                            buffer_id, out_port, flags, actions, user_data, true );
  }
  break;

  case OFPFC_DELETE:
  {
    handle_flow_mod_delete( transaction_id, match, cookie, idle_timeout, hard_timeout, priority,
                            buffer_id, out_port, flags, actions, user_data, false );
  }
  break;

  case OFPFC_DELETE_STRICT:
  {
    handle_flow_mod_delete( transaction_id, match, cookie, idle_timeout, hard_timeout, priority,
                            buffer_id, out_port, flags, actions, user_data, true );
  }
  break;

  default:
    error( "Undefined flow modification command ( command = %#x ).", command );
    send_error( transaction_id, OFPET_FLOW_MOD_FAILED, OFPFMFC_BAD_COMMAND, NULL ); // FIXME: it should have body
  }
}


static void
handle_packet_out( uint32_t transaction_id, uint32_t buffer_id, uint16_t in_port,
                   const openflow_actions *actions, const buffer *data, void *user_data ) {
  info( "Packet-out received ( transaction_id = %#x, buffer_id = %#x, in_port = %u, "
        "actions = %p, data = %p, user_data = %p ).",
        transaction_id, buffer_id, in_port, actions, data, user_data );

  if ( actions != NULL && actions->n_actions > 0 ) {
    execute_actions( data, in_port, actions );
  }
}


static void
handle_desc_stats_request( uint32_t transaction_id, const buffer *body ) {
  UNUSED( body );

  buffer *reply = create_desc_stats_reply( transaction_id, 0, config.mfr_desc, config.hw_desc, config.sw_desc,
                                           config.serial_num, config.dp_desc );
  send_openflow_message( reply );
  free_buffer( reply );
}


static void
handle_stats_request( uint32_t transaction_id, uint16_t type, uint16_t flags, const buffer *body, void *user_data ) {
  UNUSED( flags );
  UNUSED( user_data );

  switch ( type ) {
  case OFPST_DESC:
  {
    handle_desc_stats_request( transaction_id, body );
  }
  break;
  
  case OFPST_FLOW:
  case OFPST_AGGREGATE:
  case OFPST_TABLE:
  case OFPST_PORT:
  case OFPST_QUEUE:
  case OFPST_VENDOR:
  {
    warn( "Unsupoprted stats type ( type = %#x ).", type );
    send_error( transaction_id, OFPET_BAD_REQUEST, OFPBRC_BAD_STAT, body );
  }
  break;

  default:
  {
    error( "Undefined stats type ( type = %#x ).", type );
    send_error( transaction_id, OFPET_BAD_REQUEST, OFPBRC_BAD_STAT, body );
  }
  break;
  }


}


static void
handle_controller_connected( void *user_data ) {
  info( "Connected ( user_data = %p ).", user_data );

  set_hello_handler( handle_hello, NULL );
  set_echo_request_handler( handle_echo_request, NULL );
  set_features_request_handler( handle_features_request, NULL );
  set_set_config_handler( handle_set_config, NULL );
  set_flow_mod_handler( handle_flow_mod, NULL );
  set_packet_out_handler( handle_packet_out, NULL );
  set_stats_request_handler( handle_stats_request, NULL );

  info( "Sending a hello message." );
  buffer *hello = create_hello( get_transaction_id() );
  send_openflow_message( hello );
  free_buffer( hello );
}


static void
handle_controller_disconnected( void *user_data ) {
  info( "Disconnected ( user_data = %p ).", user_data );

  controller_ready = false;

  // clear handlers
  openflow_event_handlers handlers;
  memset( &handlers, 0, sizeof( handlers ) );
  set_openflow_event_handlers( handlers );
  set_controller_connected_handler( handle_controller_connected, NULL );
  set_controller_disconnected_handler( handle_controller_disconnected, NULL );

  delete_periodic_event_callback( check_switch_port_status );
}


static void
recv_frame( buffer *frame, void *user_data ) {
  assert( frame != NULL );
  assert( frame->length > 0 );

  switch_port *port = user_data;

  info( "Received a frame ( length = %u ) on port %u (%s).", frame->length, port->port_no, port->device->name );

  if ( !controller_ready ) {
    free_buffer( frame );
    return;
  }

  bool ret = parse_packet( frame );
  if ( ret == false ) {
    warn( "Failed to parse an Ethernet frame. Discarding it." );
    free_buffer( frame );
    return;
  }

  struct ofp_match match;
  set_match_from_packet( &match, port->port_no, 0, frame );
  flow_entry *entry = lookup_flow_entry( match );
  if ( entry != NULL ) {
    entry->packet_count++;
    entry->byte_count += frame->length;
    now( &entry->last_seen );
    if ( entry->actions != NULL ) {
      execute_actions( frame, port->port_no, entry->actions );
    }
  }
  else {
    uint16_t frame_length = ( uint16_t ) frame->length;
    if ( config.miss_send_len < frame->length ) {
      buffer *truncated = alloc_buffer_with_length( config.miss_send_len );
      void *p = append_back_buffer( truncated, config.miss_send_len );
      memcpy( p, frame->data, config.miss_send_len );
      free_buffer( frame );
      frame = truncated;
    }
    buffer *pin = create_packet_in( get_transaction_id(), UINT32_MAX, frame_length,
                                    port->port_no, OFPR_NO_MATCH, frame );
    send_openflow_message( pin );
    free_buffer( pin );
  }

  free_buffer( frame );
}


void
usage() {
  printf(
    "Usage: %s [OPTION]...\n"
    "\n"
    "  -i, --datapath_id=DATAPATH_ID set datapath id\n"
    "  -c, --controller=IP_ADDR      set controller host\n"
    "  -p, --port=TCP_PORT           set controller TCP port\n"
    "  -e, --eth_ports=ETH_DEVICES   set switch ports\n"
    "  -d, --daemonize               run in the background\n"
    "  -l, --logging_level=LEVEL     set logging level\n"
    "  -h, --help                    display this help and exit\n",
    get_chibach_name()
  );
}


static struct option long_options[] = {
  { "eth_ports", required_argument, NULL, 'e' },
  { NULL, 0, NULL, 0 },
};

static char short_options[] = "e:";


static void
add_ether_port( const char *eth_port ) {
  info( "Adding an Ethernet port as a switch port ( %s ).", eth_port );
  switch_port *port = add_switch_port( eth_port );
  set_frame_received_handler( port->device, recv_frame, port );
}


static void
add_ether_ports( int *argc, char ***argv ) {
  assert( argc != NULL );
  assert( argv != NULL );

  int argc_tmp = *argc;
  char *new_argv[ *argc ];

  for ( int i = 0; i < *argc; ++i ) {
    new_argv[ i ] = ( *argv )[ i ];
  }

  for ( ;; ) {
    opterr = 0;
    int c = getopt_long( *argc, *argv, short_options, long_options, NULL );

    if ( c == -1 ) {
      break;
    }

    switch ( c ) {
      case 'e':
        if ( optarg != NULL ) {
          char *save_ptr = NULL;
          char *p = strtok_r( optarg, ",", &save_ptr );
          while( p != NULL ) {
            add_ether_port( p );
            p = strtok_r( NULL, ",", &save_ptr );
          }
        }
        break;
      default:
        continue;
    }

    if ( optarg == NULL || strchr( new_argv[ optind - 1 ], '=' ) != NULL ) {
      argc_tmp -= 1;
      new_argv[ optind - 1 ] = NULL;
    }
    else {
      argc_tmp -= 2;
      new_argv[ optind - 1 ] = NULL;
      new_argv[ optind - 2 ] = NULL;
    }
  }

  for ( int i = 0, j = 0; i < *argc; ++i ) {
    if ( new_argv[ i ] != NULL ) {
      ( *argv )[ j ] = new_argv[ i ];
      j++;
    }
  }
  if ( argc_tmp < *argc ) {
    ( *argv )[ argc_tmp ] = NULL;
  }
  *argc = argc_tmp;

  optind = 0;
  opterr = 1;
}


int
main( int argc, char *argv[] ) {
  if ( geteuid() != 0 ) {
    fprintf( stderr, "%s must be run with root privilege.\n", argv[ 0 ] );
    return -1;
  }

  init_chibach( &argc, &argv );

  init_switch_config();
  init_flow_table();

  init_switch_port();
  add_ether_ports( &argc, &argv );

  set_controller_connected_handler( handle_controller_connected, NULL );
  set_controller_disconnected_handler( handle_controller_disconnected, NULL );

  start_chibach();

  finalize_flow_table();
  finalize_switch_port();

  return 0;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
