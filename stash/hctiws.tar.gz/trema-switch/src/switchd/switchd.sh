#! /bin/sh
#
# Copyright (C) 2012 NEC Corporation
#

CHIBACH_HOME=`pwd`
LOG_DIR=$CHIBACH_HOME/tmp/log
PID_DIR=$CHIBACH_HOME/tmp/pid

SWITCHD=$CHIBACH_HOME/switchd
SWITCHD_OPTS="-i 0xcafe -e eth2,eth3"
SWITCHD_PID=$PID_DIR/switchd.pid

prepare()
{
    export CHIBACH_HOME
    if [ ! -d "$LOG_DIR" ]; then
	mkdir -p $LOG_DIR
    fi
    if [ ! -d "$PID_DIR" ]; then
	mkdir -p $PID_DIR
    fi
}

start()
{
    prepare
    $SWITCHD $SWITCHD_OPTS
}

stop()
{
    prepare
    kill `cat $SWITCHD_PID`
}

usage()
{
    echo "Usage: ./switchd.sh {start|stop|restart}"
    exit
}

case "$1" in
    start)
        start
        ;;
    stop)
        stop
        ;;
    restart)
	stop
	start
        ;;
    *)
        usage
        ;;
esac
