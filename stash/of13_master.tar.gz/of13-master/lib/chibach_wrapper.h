/*
 * Wraps 3rd party functions for unit testing.
 *
 * Author: Yasuhito Takamiya <yasuhito@gmail.com>, Yasunobu Chiba
 *
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#ifndef CHIBACH_WRAPPER_H
#define CHIBACH_WRAPPER_H


#include <stdarg.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>


extern int ( *chibach_fprintf )( FILE *stream, const char *format, ... );
extern int ( *chibach_vprintf )( const char *format, va_list ap );
extern int ( *chibach_vasprintf )( char **strp, const char *fmt, va_list ap );

extern void * ( *chibach_malloc )( size_t size );
extern void * ( *chibach_calloc )( size_t nmemb, size_t size );
extern void ( *chibach_free )( void *ptr );

extern void ( *chibach_abort )( void );

extern int ( *chibach_unlink ) ( const char *pathname );

extern pid_t ( *chibach_getpid )( void );


#endif // CHIBACH_WRAPPER_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
