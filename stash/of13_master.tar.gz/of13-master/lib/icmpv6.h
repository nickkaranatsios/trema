/*
 * ICMP header definitions
 *
 * Author: Kazuya Suzuki
 *
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#ifndef ICMPV6_H
#define ICMPV6_H


typedef struct icmpv6_header {
  uint8_t type;
  uint8_t code;
  uint16_t csum;
} icmpv6_header_t;


#define ICMPV6_TYPE_ECHOREP 0
#define ICMPV6_TYPE_UNREACH 1
#define ICMPV6_TYPE_TIMEEXCEED 3
#define ICMPV6_TYPE_PARAMPROBLEM 4
//#define ICMPV6_TYPE_SOURCEQUENCH 4
//#define ICMPV6_TYPE_REDIRECT 5
//#define ICMPV6_TYPE_ECHOREQ 8
//#define ICMPV6_TYPE_ROUTERADV 9
//#define ICMPV6_TYPE_ROUTERSOL 10

#define ICMPV6_TYPE_ECHO_REQUEST 128
#define ICMPV6_TYPE_ECHO_REPLY 129
#define ICMPV6_TYPE_MULTICAST_LISTENER_QUERY 130
#define ICMPV6_TYPE_MULTICAST_LISTENER_REPORT 131
#define ICMPV6_TYPE_MULTICAST_LISTENER_DONE 132
#define ICMPV6_TYPE_ROUTER_SOLICITATION 133
#define ICMPV6_TYPE_ROUTER_ADVERTISEMENT 134
#define ICMPV6_TYPE_NEIGHBOR_SOLICITATION 135
#define ICMPV6_TYPE_NEIGHBOR_ADVERTISEMENT 136
#define ICMPV6_TYPE_REDIRECT_MESSEAGE 137
#define ICMPV6_TYPE_ROUTER_RENUMBERING 138
#define ICMPV6_TYPE_ICMP_NODE_INFORMATION_QUERY 139
#define ICMPV6_TYPE_ICMP_NODE_INFORMATION_RESPONSE 140
#define ICMPV6_TYPE_INVERSE_ND_SOLICITATION 141
#define ICMPV6_TYPE_INVERSE_ND_ADVERTISEMENT_MESSAGE 142

// ICMP codes for Destination Unreachable
#define ICMPV6_CODE_NETUNREACH 0
#define ICMPV6_CODE_PROTOUNREACH 1
#define ICMPV6_CODE_HOSTUNREACH 3
#define ICMPV6_CODE_PORTUNREACH 4
//#define ICMPV6_CODE_FRAGNEED 4
//#define ICMPV6_CODE_SRCROUTEFAIL 5
//#define ICMPV6_CODE_ADMINPROHIBIT 13

// ICMP codes for Time Exceeded
#define ICMPV6_CODE_TIMETOLIVE 0
#define ICMPV6_CODE_FRAGREASM 1

// ICMP codes for Parameter Problem
#define ICMPV6_CODE_HEADER_ERROR 0
#define ICMPV6_CODE_PRECEDENCE_HEADER_ERROR 1
#define ICMPV6_CODE_IPV6_OPTION_ERROR 1

#define ICMPV6_ND_LINK_LAYER_ADDRESS_TYPE(_header) *(((uint8_t *)(_header )) + 24)
#define ICMPV6_ND_SOURCE_LINK_LAYER_ADDRESS 1
#define ICMPV6_ND_TARGET_LINK_LAYER_ADDRESS 2

#endif // ICMPV6_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
