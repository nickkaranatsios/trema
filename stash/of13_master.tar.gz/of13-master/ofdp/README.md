#
# Copyright (C) 2012 NEC Corporation
# NEC Confidential
#

OpenFlow 1.3.0 DataPath Library  
================

OpenFlow 1.3.0 DataPath Library is a OpenFlow DataPath Library.
This Library supports only version 1.3.0. Version 1.0.0 does *not* support.
 

Supported
--------

 - This Library does *not* support following optional items:

	[4.5]Reserved ports: LOCAL, NORMAL, FLOOD
	[5.6.1]Group Types: Fast failover
	[5.7]Meter Table
	[5.7.1]Meter Bands
	[5.8]Counters: Per Queue, Per Meter, Per Meter Band
	[5.9]Instructions: Meter
	[5.12]Actions: Set-Queue, Push-Tag/Pop-Tag(push-PBB)
	[A.2.3.7] Flow Match Fields: OFPXMT_OFB_IN_PHY_PORT,
										OFPXMT_OFB_SCTP_SRC,
										OFPXMT_OFB_SCTP_DST,
										OFPXMT_OFB_TUNNEL_ID
	[A.2.3.8] Experimenter Flow Match Fields
	
 - This Library has restrictions. Following items is not supported. 
	
 	[5.1]Pipeline Processing: OpenFlow-hybrid
	[A.1.1 OpenFlow Header] OFPT_SET_CONFIG, OFPMP_TABLE_FEATURES(SET), ofp_table_mod(SET), ofp_group_features(SET)
	[A.4.3.2]Switch Configurations: OFPC_FRAG_NORMAL, OFPC_FRAG_REASM, OFPC_FRAG_MASK
	[A.2.3.7] Flow Match Fields: Tunnel-ID
	
	
 - [5.12]Actions: Set-Fields supports the almost same items as [A.2.3.7] Flow Match Fields. But, following items does *not* support.

	OFPXMT_OFB_IN_PORT(Switch input port.)
	OFPXMT_OFB_METADATA(Metadata passed between tables.)
	OFPXMT_OFB_PBB_ISID(PBB I-SID)
	OFPXMT_OFB_IPV6_EXTHDR(IPv6 Extension Header pseudo-field)

 - [5.12]Actions: Push-Tag does *not* support already capsulated frame. 


Getting Started
---------------

Make the Library at the command prompt:

    $ cd ${LIBRARY_HOME}/lib; make;


Executing user
--------------

It is necessary to execute this library by root. 


Supported Platforms
-------------------

OpenFlow 1.3.0 DataPath Library has been tested ONLY on the following environments:

* Ubuntu 12.04 (i386/amd64, Desktop Edition)
* Debian GNU/Linux 6.0 (i386/amd64)

It may also run on other GNU/Linux distributions but is not tested and
NOT SUPPORTED at this moment.


License
-------

Trema is released under the GNU General Public License version 2.0:

* http://www.gnu.org/licenses/gpl-2.0.html
