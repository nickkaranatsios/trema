/*
 * Functions for Openflow datapath library common.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include "ofdp_common.h"


const uint32_t OFP_NO_BUFFER = UINT_MAX;


#define STRERROR_BUF_SIZE       1024


/**
 * get now time to timespec
 *
 * param set timespec
 * return success/failed
 */
bool
now( struct timespec *tp ) {
  int ret = clock_gettime( CLOCK_MONOTONIC, tp );

  if ( ret < 0 ) {
    char buf[ STRERROR_BUF_SIZE ];

    error( "Failed to retrieve current time ( %s [%d] ).", strerror_r( errno, buf, STRERROR_BUF_SIZE ),
      errno );
    return false;
  }

  return true;
}


/**
 * get difference timespec
 *
 * param start time
 * param end time
 * param set difference time
 * return nothing
 */
void
timespec_diff( struct timespec start, struct timespec end, struct timespec *diff ) {
  if ( ( end.tv_nsec - start.tv_nsec ) < 0 ) {
      ( *diff ).tv_sec = end.tv_sec - start.tv_sec - 1;
      ( *diff ).tv_nsec = 1000000000 + end.tv_nsec - start.tv_nsec;
  }
  else {
      ( *diff ).tv_sec = end.tv_sec - start.tv_sec;
      ( *diff ).tv_nsec = end.tv_nsec - start.tv_nsec;
  }
  return;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
