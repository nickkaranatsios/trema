/*
 * Functions for Openflow spcification structure wrapper.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */

#ifndef OPENFLOW_WRAPPER_H
#define OPENFLOW_WRAPPER_H

#include "../../lib/openflow.h"


extern const uint32_t OFP_NO_BUFFER;
typedef enum {
  ofp_error_type_unkown = ~0,
  ofp_error_code_unkown = ~0
} ofp_error_unkown;


typedef enum ofp_port_no ofp_port_no;
typedef enum ofp_type ofp_type;
typedef enum ofp_config_flags ofp_config_flags;
typedef enum ofp_capabilities ofp_capabilities;
typedef enum ofp_port_config ofp_port_config;
typedef enum ofp_port_state ofp_port_state;
typedef enum ofp_port_features ofp_port_features;
typedef enum ofp_port_reason ofp_port_reason;
typedef enum ofp_match_type ofp_match_type;
typedef enum ofp_oxm_class ofp_oxm_class;
typedef enum oxm_ofb_match_fields oxm_ofb_match_fields;
typedef enum ofp_vlan_id ofp_vlan_id;
typedef enum ofp_ipv6exthdr_flags ofp_ipv6exthdr_flags;
typedef enum ofp_packet_in_reason ofp_packet_in_reason;
typedef enum ofp_action_type ofp_action_type;
typedef enum ofp_controller_max_len ofp_controller_max_len;
typedef enum ofp_flow_mod_command ofp_flow_mod_command;
typedef enum ofp_flow_mod_flags ofp_flow_mod_flags;
typedef enum ofp_flow_removed_reason ofp_flow_removed_reason;
typedef enum ofp_error_type ofp_error_type;
typedef enum ofp_hello_failed_code ofp_hello_failed_code;
typedef enum ofp_bad_request_code ofp_bad_request_code;
typedef enum ofp_bad_action_code ofp_bad_action_code;
typedef enum ofp_flow_mod_failed_code ofp_flow_mod_failed_code;
typedef enum ofp_port_mod_failed_code ofp_port_mod_failed_code;
typedef enum ofp_queue_op_failed_code ofp_queue_op_failed_code;
typedef enum ofp_bad_instruction_code ofp_bad_instruction_code;
typedef enum ofp_bad_match_code ofp_bad_match_code;
typedef enum ofp_group_mod_failed_code ofp_group_mod_failed_code;
typedef enum ofp_table_mod_failed_code ofp_table_mod_failed_code;
typedef enum ofp_switch_config_failed_code ofp_switch_config_failed_code;
typedef enum ofp_role_request_failed_code ofp_role_request_failed_code;
typedef enum ofp_meter_mod_failed_code ofp_meter_mod_failed_code;
typedef enum ofp_table_features_failed_code ofp_table_features_failed_code;
typedef enum ofp_multipart_types ofp_multipart_types;
typedef enum ofp_multipart_request_flags ofp_multipart_request_flags;
typedef enum ofp_multipart_reply_flags ofp_multipart_reply_flags;
typedef enum ofp_queue_properties ofp_queue_properties;
typedef enum ofp_instruction_type ofp_instruction_type;
typedef enum ofp_table ofp_table;
typedef enum ofp_group_mod_command ofp_group_mod_command;
typedef enum ofp_group_type ofp_group_type;
typedef enum ofp_meter ofp_meter;
typedef enum ofp_meter_mod_command ofp_meter_mod_command;
typedef enum ofp_meter_flags ofp_meter_flags;
typedef enum ofp_meter_band_type ofp_meter_band_type;
typedef enum ofp_table_feature_prop_type ofp_table_feature_prop_type;
typedef enum ofp_group_capabilities ofp_group_capabilities;
typedef enum ofp_controller_role ofp_controller_role;


typedef struct ofp_header ofp_header;
typedef struct ofp_switch_config ofp_switch_config;
typedef struct ofp_port ofp_port;
typedef struct ofp_switch_features ofp_switch_features;
typedef struct ofp_port_status ofp_port_status;
typedef struct ofp_port_mod ofp_port_mod;
typedef struct ofp_match ofp_match;
typedef struct ofp_oxm_experimenter_header ofp_oxm_experimenter_header;
typedef struct ofp_packet_in ofp_packet_in;
typedef struct ofp_action_output ofp_action_output;
typedef struct ofp_action_group ofp_action_group;
typedef struct ofp_action_set_queue ofp_action_set_queue;
typedef struct ofp_action_mpls_ttl ofp_action_mpls_ttl;
typedef struct ofp_action_nw_ttl ofp_action_nw_ttl;
typedef struct ofp_action_push ofp_action_push;
typedef struct ofp_action_pop_mpls ofp_action_pop_mpls;
typedef struct ofp_action_set_field ofp_action_set_field;
typedef struct ofp_action_experimenter_header ofp_action_experimenter_header;
typedef struct ofp_action_header ofp_action_header;
typedef struct ofp_packet_out ofp_packet_out;
typedef struct ofp_flow_mod ofp_flow_mod;
typedef struct ofp_flow_removed ofp_flow_removed;
typedef struct ofp_error_experimenter_msg ofp_error_experimenter_msg;
typedef struct ofp_error_msg ofp_error_msg;
typedef struct ofp_multipart_request ofp_multipart_request;
typedef struct ofp_multipart_reply ofp_multipart_reply;
typedef struct ofp_desc ofp_desc;
typedef struct ofp_flow_stats_request ofp_flow_stats_request;
typedef struct ofp_flow_stats ofp_flow_stats;
typedef struct ofp_aggregate_stats_request ofp_aggregate_stats_request;
typedef struct ofp_aggregate_stats_reply ofp_aggregate_stats_reply;
typedef struct ofp_table_stats ofp_table_stats;
typedef struct ofp_port_stats_request ofp_port_stats_request;
typedef struct ofp_port_stats ofp_port_stats;
typedef struct ofp_experimenter_header ofp_experimenter_header;
typedef struct ofp_queue_prop_header ofp_queue_prop_header;
typedef struct ofp_queue_prop_min_rate ofp_queue_prop_min_rate;
typedef struct ofp_queue_prop_max_rate ofp_queue_prop_max_rate;
typedef struct ofp_packet_queue ofp_packet_queue;
typedef struct ofp_queue_get_config_request ofp_queue_get_config_request;
typedef struct ofp_queue_get_config_reply ofp_queue_get_config_reply;
typedef struct ofp_queue_prop_experimenter ofp_queue_prop_experimenter;
typedef struct ofp_queue_stats_request ofp_queue_stats_request;
typedef struct ofp_queue_stats ofp_queue_stats;
typedef struct ofp_instruction_goto_table ofp_instruction_goto_table;
typedef struct ofp_instruction_write_metadata ofp_instruction_write_metadata;
typedef struct ofp_instruction_actions ofp_instruction_actions;
typedef struct ofp_instruction_meter ofp_instruction_meter;
typedef struct ofp_table_mod ofp_table_mod;
typedef struct ofp_bucket ofp_bucket;
typedef struct ofp_group_mod ofp_group_mod;
typedef struct ofp_meter_band_header ofp_meter_band_header;
typedef struct ofp_meter_mod ofp_meter_mod;
typedef struct ofp_meter_band_drop ofp_meter_band_drop;
typedef struct ofp_meter_band_dscp_remark ofp_meter_band_dscp_remark;
typedef struct ofp_meter_band_experimenter ofp_meter_band_experimenter;
typedef struct ofp_table_features ofp_table_features;
typedef struct ofp_table_feature_prop_instructions ofp_table_feature_prop_instructions;
typedef struct ofp_table_feature_prop_next_tables ofp_table_feature_prop_next_tables;
typedef struct ofp_table_feature_prop_actions ofp_table_feature_prop_actions;
typedef struct ofp_table_feature_prop_oxm ofp_table_feature_prop_oxm;
typedef struct ofp_group_stats_request ofp_group_stats_request;
typedef struct ofp_bucket_counter ofp_bucket_counter;
typedef struct ofp_group_stats ofp_group_stats;
typedef struct ofp_group_desc_stats ofp_group_desc_stats;
typedef struct ofp_group_features ofp_group_features;
typedef struct ofp_meter_multipart_request ofp_meter_multipart_request;
typedef struct ofp_meter_band_stats ofp_meter_band_stats;
typedef struct ofp_meter_stats ofp_meter_stats;
typedef struct ofp_meter_config ofp_meter_config;
typedef struct ofp_meter_features ofp_meter_features;
typedef struct ofp_role_request ofp_role_request;
typedef struct ofp_async_config ofp_async_config;
typedef struct ofp_experimenter_multipart_header ofp_experimenter_multipart_header;


#endif  // OPENFLOW_WRAPPER_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
