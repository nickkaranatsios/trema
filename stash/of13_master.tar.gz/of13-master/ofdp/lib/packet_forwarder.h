/*
 * Functions for Openflow pipeline processing forwarder.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef PACKET_FORWARDER_H
#define PACKET_FORWARDER_H


#include "ofdp_common.h"
#include "buffer.h"
#include "switch_port.h"
#include "linked_list.h"


// Structure of packet forwarder queue
typedef struct {
  switch_port *port;
  buffer *buf;
} packet_forewarder_queue_entry;

typedef struct {
  list_element *recv_data_head;
} packet_forewarder_queue;


// List of public library function
OFDPE init_packet_forwarder( void );
OFDPE finalize_packet_forwarder( void );
OFDPE accept_recv_data( switch_port *port, buffer *buf );
OFDPE enqueue_head_recv_data( switch_port *port, buffer *buf );


#endif  // PACKET_FORWARDER_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
