/*
 * Functions for maching packet to flow entry.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef PACKET_MATCHER_H
#define PACKET_MATCHER_H


#include "packet_info.h"
#include "table_manager.h"


bool match_packet2match_match( const match *packet, match *p_match );
bool match_packet_match( packet_info *packet, match *p_match );
bool match_match_match( match *x, match *y );
bool compare_match_match( match *x, match *y );
OFDPE initialize_packet_matcher( void );
OFDPE finalize_packet_matcher( void );
flow_entry *(*match_entry_fetcher)( buffer *parsed_buffer, uint8_t table_id );


#endif // PACKET_MATCHER_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
