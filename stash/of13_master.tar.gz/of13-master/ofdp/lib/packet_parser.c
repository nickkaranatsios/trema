/*
 * Functions for parse packet from received data.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include "ofdp_common.h"
#include "packet_parser.h"

/**
 * Initialize Packet Parser
 * return OFDPE Information
 */
OFDPE
init_packet_parser( void ) {
  return OFDPE_SUCCESS;
}


/**
 * finalize Packet Parser
 * return OFDPE Information
 */
OFDPE
finalize_packet_parser( void ) {
  return OFDPE_SUCCESS;
}

/**
 * Parse packet
 * @param packet_datagram pointer for packet datagram
 * return
 */
bool
parse_packet( buffer *packet_datagram ) {
  assert( packet_datagram != NULL );
  bool retval;

  retval = parse_packet_datagram( packet_datagram );
  return retval;
  //  if ( retval != true ) {
  //    return OFDPE_FAILED;
  //  }
  //  parsed_packet = (packet_info * )packet_datagram->user_data;
  //  memcpy( parsed_packet, packet_datagram->user_data, sizeof( packet_info ) );

  //  parsed_packet->buffer = packet_datagram;

  //  return OFDPE_SUCCESS;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
