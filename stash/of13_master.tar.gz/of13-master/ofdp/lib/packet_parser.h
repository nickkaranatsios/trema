/*
 * Functions for parse packet from received data.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef PACKET_PARSER_H
#define PACKET_PARSER_H


#include "openflow.h"
#include "packet_info.h"
#include "ofdp_error.h"


OFDPE init_packet_parser( void );
OFDPE finalize_packet_parser( void );
bool parse_packet( buffer *packet_datagram );


#endif // PACKET_PARSER_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
