/*
 * Functions for managing flow entry action buckets.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef TABLE_MANAGER_ACTION_BUCKET_H
#define TABLE_MANAGER_ACTION_BUCKET_H


#include "ofdp_common.h"
#include "doubly_linked_list.h"
#include "table_manager_action.h"

// -- Action Bucket
typedef struct bucket {
  uint16_t weight;
  uint16_t watch_port;
  uint32_t watch_group;
  uint64_t packet_count;
  uint64_t byte_count;
  action_list *actions;
} bucket;


bucket *create_action_bucket( const uint16_t weight, const uint16_t watch_port, const uint32_t watch_group, void *actions );
void delete_action_bucket( bucket **p_bucket );


// -- Action Bucket List
typedef struct bucket_dlist_element {
  bucket *node;
  struct bucket_dlist_element *prev;
  struct bucket_dlist_element *next;
} bucket_list;


void delete_action_bucket_list( bucket_list **list );
OFDPE append_action_bucket( bucket_list *list, bucket *p_bucket );
OFDPE remove_action_bucket( bucket_list *list, bucket *p_bucket );
uint32_t get_bucket_count( bucket_list *list );
#define create_action_bucket_list() ( bucket_list * ) ( create_dlist() )


#endif // TABLE_MANAGER_ACTION_BUCKET_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
