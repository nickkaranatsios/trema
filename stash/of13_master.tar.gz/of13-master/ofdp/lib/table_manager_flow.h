/*
 * Functions for managing flow entries.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef TABLE_MANAGER_FLOW_H
#define TABLE_MANAGER_FLOW_H


#include "ofdp_common.h"
#include "table_manager_instruction.h"
#include "table_manager_match.h"
#include "hash_table.h"
#include "linked_list.h"


typedef struct _instructions_capabilities {
  bool meter;
  bool apply_actions;
  bool clear_actions;
  bool write_actions;
  bool write_metadata;
  bool goto_table;
} instructions_capabilities;


typedef struct _actions_capabilities {
  bool output;
  bool set_queue;
  bool drop;
  bool group;
  bool push_vlan;
  bool pop_vlan;
  bool push_mpls;
  bool pop_mpls;
  bool push_pbb;
  bool pop_pbb;
} actions_capabilities;


typedef struct _match_capabilities {
  bool in_port;
  bool in_phy_port;
  bool metadata;
  bool eth_dst;
  bool eth_src;
  bool eth_type;
  bool vlan_vid;
  bool vlan_pcp;
  bool ip_dscp;
  bool ip_ecn;
  bool ip_proto;
  bool ipv4_src;
  bool ipv4_dst;
  bool tcp_src;
  bool tcp_dst;
  bool udp_src;
  bool udp_dst;
  bool sctp_src;
  bool sctp_dst;
  bool icmpv4_type;
  bool icmpv4_code;
  bool arp_op;
  bool arp_spa;
  bool arp_tpa;
  bool arp_sha;
  bool arp_tha;
  bool ipv6_src;
  bool ipv6_dst;
  bool ipv6_flabel;
  bool icmpv6_type;
  bool icmpv6_code;
  bool ipv6_nd_target;
  bool ipv6_nd_sll;
  bool ipv6_nd_tll;
  bool mpls_label;
  bool mpls_tc;
  bool mpls_bos;
  bool pbb_isid;
  bool tunnel_id;
  bool ipv6_exthdr;
} match_capabilities;


typedef struct _table_features {
  uint8_t table_id;
  char name[ OFP_MAX_TABLE_NAME_LEN ];
  uint64_t metadata_match;
  uint64_t metadata_write;
  uint32_t config;
  uint32_t max_entries;
  instructions_capabilities instructions;
  instructions_capabilities instructions_miss;
  uint8_t min_next_table_ids;
  uint8_t min_next_table_ids_miss;
  actions_capabilities write_actions;
  actions_capabilities write_actions_miss;
  actions_capabilities apply_actions;
  actions_capabilities apply_actions_miss;
  match_capabilities matches;
  match_capabilities wildcards;
  match_capabilities write_setfield;
  match_capabilities write_setfield_miss;
  match_capabilities apply_setfield;
  match_capabilities apply_setfield_miss;
} table_features;


typedef struct _flow_entry {
  uint8_t table_id;
  uint32_t duration_sec;
  uint32_t duration_nsec;
  uint16_t priority;
  uint16_t idle_timeout;
  uint16_t hard_timeout;
  uint16_t flags;
  uint64_t cookie;
  uint64_t packet_count;
  uint64_t byte_count;
  match *p_match;
  instruction_list *instructions;
  struct timespec created_at;
  struct timespec last_seen;
} flow_entry;


typedef struct flow_stats {
  uint16_t length;
  uint8_t table_id;
  uint8_t pad;
  uint32_t duration_sec;
  uint32_t duration_nsec;
  uint16_t priority;
  uint16_t idle_timeout;
  uint16_t hard_timeout;
  uint16_t flags;
  uint64_t cookie;
  uint64_t packet_count;
  uint64_t byte_count;
  match *p_match;
} flow_stats;


typedef void ( *flow_entry_handler )( flow_entry *entry, void *user_data, uint8_t table_id );
flow_entry *create_flow_entry( match *p_match, instruction_list *instructions,
  const uint16_t priority, const uint16_t idle_timeout, const uint16_t hard_timeout,
  const uint16_t flags, const uint64_t cookie );
void delete_flow_entry( flow_entry **entry );
OFDPE append_flow_entry( const uint8_t table_id, flow_entry *entry );
flow_entry *lookup_flow_entry( const uint8_t table_id, match *p_match );
flow_entry *lookup_flow_entry_strict( const uint8_t table_id, match *p_match, uint16_t priority );
OFDPE update_flow_entry( const uint8_t table_id, flow_entry *entry );
OFDPE remove_flow_entry( const uint8_t table_id, flow_entry *entry );
void foreach_flow_entry( const uint8_t table_id, flow_entry_handler callback,  void *user_data );
void remove_timeout_flow_entry( const uint8_t table_id );


typedef struct _flow_table_element {
  flow_entry *data;
  struct _flow_table_element *prev;
  struct _flow_table_element *next;
} flow_table_list;


typedef struct _flow_table_stats {
  uint32_t active_count;
  uint64_t lookup_count;
  uint64_t matched_count;
} flow_table_stats;


typedef struct _flow_table {
  bool valid;
  flow_table_list *entry;
  hash_table *exact_table;
  list_element *wildcards_table;
  flow_table_stats counters;
  table_features features;
} flow_table;


OFDPE init_flow_table( const uint8_t table_id );
OFDPE finalize_flow_table( const uint8_t table_id );

// API for Counters
typedef struct _flow_stats_request {
  uint8_t table_id;
  uint32_t out_port;
  uint32_t out_group;
  uint64_t cookie;
  uint64_t cookie_mask;
  match *p_match;
} flow_stats_request;


uint32_t flow_table_active_count_inc( const uint8_t table_id );
uint32_t flow_table_active_count_dec( const uint8_t table_id );
uint32_t flow_table_get_active_count( const uint8_t table_id );
uint64_t flow_table_lookup_count_inc( const uint8_t table_id );
uint64_t flow_table_get_lookup_count( const uint8_t table_id );
uint64_t flow_table_matched_count_inc( const uint8_t table_id );
uint64_t flow_table_get_matched_count( const uint8_t table_id );
OFDPE get_statistics_table( ofp_table_stats **statistics, const uint8_t num );
OFDPE get_statistics_flow( const flow_stats_request request, flow_stats **statistics, uint32_t *num );
void dump_flow_table_stats( ofp_table_stats *stats );
void dump_flow_stats( flow_stats *stats );


// API for get Flow Table Pointer
flow_table *_get_flow_table( const uint8_t table_id );


#endif // TABLE_MANAGER_FLOW_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
