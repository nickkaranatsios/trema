/*
 * Functions for managing flow entry match fields.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef TABLE_MANAGER_MATCH_H
#define TABLE_MANAGER_MATCH_H


#include "ofdp_common.h"
#include "ether.h"
#include "ipv6.h"
#include "packet_info.h"


typedef struct _match8 {
  uint8_t value;
  uint8_t mask;
  bool valid;
} match8;


typedef struct _match16 {
  uint16_t value;
  uint16_t mask;
  bool valid;
} match16;


typedef struct _match32 {
  uint32_t value;
  uint32_t mask;
  bool valid;
} match32;


typedef struct _match64 {
  uint64_t value;
  uint64_t mask;
  bool valid;
} match64;


typedef struct _match {
  match16 arp_op;
  match8 arp_sha[ ETH_ADDRLEN ];
  match32 arp_spa;
  match8 arp_tha[ ETH_ADDRLEN ];
  match32 arp_tpa;
  match8 eth_dst[ ETH_ADDRLEN ];
  match8 eth_src[ ETH_ADDRLEN ];
  match16 eth_type;

  match8 icmpv4_code;
  match8 icmpv4_type;
  match8 icmpv6_code;
  match8 icmpv6_type;

  match32 in_phy_port;
  match32 in_port;
  match8 ip_dscp;
  match8 ip_ecn;
  match8 ip_proto;

  match32 ipv4_dst;
  match32 ipv4_src;

  match8 ipv6_src[ IPV6_ADDRLEN ];
  match8 ipv6_dst[ IPV6_ADDRLEN ];
  match16 ipv6_exthdr;
  match32 ipv6_flabel;

  match8 ipv6_nd_sll[ IPV6_LINK_LAYER_LEN ];
  match8 ipv6_nd_target[ IPV6_ADDRLEN ];
  match8 ipv6_nd_tll[ IPV6_LINK_LAYER_LEN ];

  match64 metadata;
  match8 mpls_bos;

  match32 mpls_label;
  match8 mpls_tc;
  match16 sctp_dst;
  match16 sctp_src;
  match16 tcp_dst;
  match16 tcp_src;

  match64 tunnel_id;

  match16 udp_dst;
  match16 udp_src;
  match8 vlan_pcp;

  match16 vlan_vid;
} match;


extern const uint8_t NULL_VALUE8;
extern const uint16_t NULL_VALUE16;
extern const uint32_t NULL_VALUE32;
extern const uint64_t NULL_VALUE64;


match *init_match( void );
void delete_match( match **p_match );
bool validate_match( match *p_match );


#endif // TABLE_MANAGER_MATCH_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
