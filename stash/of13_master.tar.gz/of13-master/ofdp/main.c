/*
 * Functions for OpenFlow main process.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <stdbool.h>
#include <unistd.h>
#include "main.h"
#include "table_pattern.h"
#include "lib/ofdp.h"
#include "controller_manager.h"
#include "action_executor.h"
#include "ether.h"
#include "log.h"
#include "wrapper.h"
#include "timer.h"


#define PROG_SUCCESS 0
#define PROG_FAIL -1


void
dump_frame( void *data, size_t size ) {
  uint8_t *tmp = ( uint8_t * ) data;
  char buf[ 1024 ];
  int index = 0;

  debug( "- %p -------------------", tmp );

  for ( size_t i = 0; i < size; i++ ) {
    if ( i % 16 == 0 ) {
      index += sprintf( &( buf[ index ] ), "= %p =  ", &tmp[ i ] );
    }

    index += sprintf( &( buf[ index ] ), "%02x ", tmp[ i ] );

    if ( i % 16 == 15 ) {
      debug( buf );
      index = 0;
    }
  }

  if ( index != 0 ) {
    debug( buf );
  }
}


static void
packet_in_handler( void *notify_parameter ) {
  notify_parameter_packet_in *parameter = ( notify_parameter_packet_in * ) notify_parameter;

  debug( "packet_in_handler. reason=%d", parameter->reason );
  switch ( parameter->reason ) {
  case OFPR_NO_MATCH:
    debug( "notified OFPR_NO_MATCH. " );
    break;

  case OFPR_ACTION:
    debug( "notified OFPR_ACTION." );
    debug( "buffer_id=%u, table_id=%u, cookie=%u", parameter->buffer_id, parameter->table_id, parameter->cookie );
    break;

  case OFPR_INVALID_TTL:
    debug( "notified OFPR_INVALID_TTL. " );
    debug( "buffer_id=%u, table_id=%u, cookie=%u", parameter->buffer_id, parameter->table_id, parameter->cookie );
    break;

  default:
    break;
  }

  dump_frame( parameter->packet->data, parameter->packet->length );
  free_buffer( parameter->packet );
  xfree( notify_parameter );

  return;
}


static void
packet_in_handler_to_packet_out( void *notify_parameter ) {
  notify_parameter_packet_in *original_parameter = ( notify_parameter_packet_in * ) notify_parameter;

  switch ( original_parameter->reason ) {
  case OFPR_ACTION:
  {
    action_list *alist = init_action_list();
    append_action( alist, create_action_output( 4, 1500 ) );
    debug( "notified OFPR_ACTION." );
    debug( "buffer_id=%u, table_id=%u, cookie=%u", original_parameter->buffer_id, original_parameter->table_id, original_parameter->cookie );
    debug( "execute packet out." );

    pthread_t thread;
    memset( &thread, 0, sizeof( thread ) );
    pthread_create( &thread, NULL, (void * (*)(void *))execute_action_packet_out, original_parameter );
    finalize_action_list( &alist );
    break;
  }

  default:
    packet_in_handler( notify_parameter );
    break;
  }

  return;
}


static void
flow_removed_handler( void *notify_parameter ) {
  notify_parameter_flow_removed *parameter = ( notify_parameter_flow_removed * ) notify_parameter;

  debug( "[flow_removed_handler]" );
  debug( "cookie = %u, priority = %u, reason = %u", parameter->cookie, parameter->priority, parameter->reason );
  debug( "table_id = %u, duration_sec = %u, duration_nsec = %u", parameter->table_id, parameter->duration_sec, parameter->duration_nsec );
  debug( "idle_timeout = %u, hard_timeout = %u, packet_count = %u, byte_count = %u",
    parameter->idle_timeout,
    parameter->hard_timeout,
    parameter->packet_count,
    parameter->byte_count );
  xfree( notify_parameter );
  return;
}


static void
port_status_handler( void *notify_parameter ) {
  notify_parameter_port_status *parameter = ( notify_parameter_port_status * ) notify_parameter;

  debug( "[port_status_handler]" );
  debug( "reason = %u", parameter->reason );
  debug( "[ofp_port]" );
  debug( "\t.port_no = %u, .state = %u, .config = %u", parameter->desc.port_no, parameter->desc.state, parameter->desc.config );
  debug( "\t.curr = %u, .curr_speed = %u, .advertised = %u", parameter->desc.curr, parameter->desc.curr_speed, parameter->desc.advertised );
  debug( "\t.supported = %u, .max_speed = %u, .peer = %u", parameter->desc.supported, parameter->desc.max_speed, parameter->desc.peer );
  debug( "\t.hw_addr = %x:%x:%x:%x:%x:%x",
    parameter->desc.hw_addr[ 0 ],
    parameter->desc.hw_addr[ 1 ],
    parameter->desc.hw_addr[ 2 ],
    parameter->desc.hw_addr[ 3 ],
    parameter->desc.hw_addr[ 4 ],
    parameter->desc.hw_addr[ 5 ] );
  xfree( notify_parameter );
  return;
}


static void
error_handler( void *notify_parameter ) {
  notify_parameter_error *parameter = ( notify_parameter_error * ) notify_parameter;

  debug( "[error_handler]" );
  debug( "error_code = %u", parameter->error_code );
  if ( parameter->packet != NULL ) {
    dump_frame( parameter->packet->data, parameter->packet->length );
    if ( parameter->packet->user_data != NULL ) {
      free_packet_info( parameter->packet );
    }
    free_buffer( parameter->packet );
  }
  xfree( notify_parameter );
  return;
}


static void
usage( char *program_name ) {
  printf(
    "Usage: %s [OPTION]...\n"
    "\n"
    "  -l <LEVEL>\n"
    "         set logging level\n"
    "  -d\n"
    "         run in the background\n"
    "  -p <DEVICE_NAME1>[:<PORT_NO1>[,<DEVICE_NAME2>...]]]\n"
    "         set openflow datapath device\n"
    "  -t <PATTERN_NO>\n"
    "         set flow table pattern\n",
    program_name
    );

  return;
}


static list_element *
analyze_argument_device_option( char *optarg ) {
  list_element *head = NULL;

  char *save_ptr = NULL;
  char *p = strtok_r( optarg, ",", &save_ptr );

  for (;; ) {
    if ( p == NULL ) {
      break;
    }

    char *p_port = NULL;
    char *p_dev = strtok_r( p, ":", &p_port );

    argument_device_info *dev_info = ( argument_device_info * ) xcalloc( 1, sizeof( argument_device_info ) );
    strncpy( dev_info->device_name, p_dev, IFNAMSIZ - 1 );
    if ( p_port != NULL ) {
      dev_info->port_no = (uint16_t) atoi( p_port );
    }
    else {
      dev_info->port_no = 0;
    }

    append_to_tail( &head, dev_info );

    p = strtok_r( NULL, ",", &save_ptr );
  }

  return head;
}


static bool
analyze_argument( int argc, char **argv, command_argument *arg_data ) {
  memset( arg_data, 0, sizeof( command_argument ) );

  arg_data->program_name = strdup( basename( argv[ 0 ] ) );
  arg_data->loglevel = strdup( LOG_LEVEL );
  arg_data->devices_info = NULL;
  arg_data->is_daemon = false;
  arg_data->table_pattern_no = 0;

  static const char optstring[] = "l:dp:t:";

  for (;; ) {
    int opt = getopt( argc, argv, optstring );
    if ( opt == -1 ) {
      break;
    }

    switch ( opt ) {
    case 'l':
      if ( arg_data->loglevel != NULL ) {
        xfree( arg_data->loglevel );
      }
      arg_data->loglevel = strdup( optarg );
      break;

    case 'd':
      arg_data->is_daemon = true;
      break;

    case 'p':
      arg_data->devices_info = analyze_argument_device_option( optarg );
      break;

    case 't':
      arg_data->table_pattern_no = (uint16_t) atoi( optarg );
      break;

    default:
      usage( arg_data->program_name );
      return false;
    }
  }

  if ( arg_data->devices_info == NULL ) {
    usage( arg_data->program_name );
    return false;
  }

  return true;
}


static void
free_argument( command_argument *arg_data ) {
  if ( arg_data->program_name != NULL ) {
    xfree( arg_data->program_name );
  }
  if ( arg_data->loglevel != NULL ) {
    xfree( arg_data->loglevel );
  }
  if ( arg_data->devices_info != NULL ) {
    for ( list_element *node = arg_data->devices_info; node != NULL; node = node->next ) {
      xfree( node->data );
    }
    delete_list( arg_data->devices_info );
  }
}


static void
stop_ofdplib( void ) {
  OFDPE ret = OFDPE_SUCCESS;

  ret = stop_datapath();
  if ( ret != OFDPE_SUCCESS ) {
    error( "stop_datapath failed." );
    return;
  }

  return;
}


static void
set_exit_sighandler( void ) {
  struct sigaction signal_exit;

  memset( &signal_exit, 0, sizeof( struct sigaction ) );
  signal_exit.sa_handler = ( void * ) stop_ofdplib;
  sigaction( SIGINT, &signal_exit, NULL );
  sigaction( SIGTERM, &signal_exit, NULL );
}


static void
set_ignore_sighandler( void ) {
  struct sigaction signal_ignore;

  memset( &signal_ignore, 0, sizeof( struct sigaction ) );
  signal_ignore.sa_handler = SIG_IGN;
  sigaction( SIGPIPE, &signal_ignore, NULL );
}


static bool
set_sighandler( void ) {
  set_exit_sighandler();
  set_ignore_sighandler();

  return true;
}


static bool
add_ether_devices( list_element *devices_list_head ) {
  OFDPE ret = OFDPE_SUCCESS;
  list_element *p;

  for ( p = devices_list_head; p != NULL; p = p->next ) {
    argument_device_info *dev = p->data;
    ret = add_port( dev->port_no, dev->device_name );
    //    ret = init_device( ( argument_device_info * ) p->data );
    if ( ret != OFDPE_SUCCESS ) {
      warn( "add_port failed." );
      return false;
    }
  }

  return true;
}


#ifdef UNIT_TESTING
static void
test_argument() {
  int argc = 0;
  char **argv = NULL;
  command_argument cmd_arg;

  /*
          // case 1
          argc = 3;
          argv = xcalloc(argc, sizeof(char*));
          argv[0] = strdup("test_main");
          argv[1] = strdup("-l");
          argv[2] = strdup("error");
          analyze_argument(argc, argv, &cmd_arg);
          xfree(argv[0]);
          xfree(argv[1]);
          xfree(argv[2]);
          xfree(argv);

          // case 2
          argc = 2;
          argv = xcalloc(argc, sizeof(char*));
          argv[0] = strdup("test_main");
          argv[1] = strdup("-d");
          analyze_argument(argc, argv, &cmd_arg);
          xfree(argv[0]);
          xfree(argv[1]);
          xfree(argv);

          // case 3
          argc = 3;
          argv = xcalloc(argc, sizeof(char*));
          argv[0] = strdup("test_main");
          argv[1] = strdup("-p");
          argv[2] = strdup("eth0");
          analyze_argument(argc, argv, &cmd_arg);
          xfree(argv[0]);
          xfree(argv[1]);
          xfree(argv[2]);
          xfree(argv);

          // case 4
          argc = 3;
          argv = xcalloc(argc, sizeof(char*));
          argv[0] = strdup("test_main");
          argv[1] = strdup("-p");
          argv[2] = strdup("eth0:1");
          analyze_argument(argc, argv, &cmd_arg);
          xfree(argv[0]);
          xfree(argv[1]);
          xfree(argv[2]);
          xfree(argv);

          // case 5
          argc = 3;
          argv = xcalloc(argc, sizeof(char*));
          argv[0] = strdup("test_main");
          argv[1] = strdup("-p");
          argv[2] = strdup("eth0:1,eth1");
          analyze_argument(argc, argv, &cmd_arg);
          xfree(argv[0]);
          xfree(argv[1]);
          xfree(argv[2]);
          xfree(argv);

          // case 6
          argc = 3;
          argv = xcalloc(argc, sizeof(char*));
          argv[0] = strdup("test_main");
          argv[1] = strdup("-p");
          argv[2] = strdup("eth0:1,eth1:2");
          analyze_argument(argc, argv, &cmd_arg);
          xfree(argv[0]);
          xfree(argv[1]);
          xfree(argv[2]);
          xfree(argv);

          // case 7
          argc = 3;
          argv = xcalloc(argc, sizeof(char*));
          argv[0] = strdup("test_main");
          argv[1] = strdup("-t");
          argv[2] = strdup("1");
          analyze_argument(argc, argv, &cmd_arg);
          xfree(argv[0]);
          xfree(argv[1]);
          xfree(argv[2]);
          xfree(argv);
  */

  // case 8
  argc = 2;
  argv = xcalloc( argc, sizeof( char * ) );
  argv[ 0 ] = strdup( "test_main" );
  argv[ 1 ] = strdup( "-h" );
  analyze_argument( argc, argv, &cmd_arg );
  xfree( argv[ 0 ] );
  xfree( argv[ 1 ] );
  xfree( argv );

  /*
*/
  return;
}


#endif  // UNIT_TESTING


static void
senario_test_03( void *user_data ) {
  UNUSED( user_data );

  info( "call senario_test_03()." );

  register_table_pattern_03_2();
  delete_timer_event( senario_test_03, NULL );

  return;
}


static void
senario_test_04( void *user_data ) {
  UNUSED( user_data );

  info( "call senario_test_04()." );

  register_table_pattern_04_2();
  delete_timer_event( senario_test_04, NULL );

  return;
}


static void
senario_test_07( void *user_data ) {
  UNUSED( user_data );

  info( "call senario_test_07()." );

  register_table_pattern_07_2();
  delete_timer_event( senario_test_07, NULL );

  return;
}


static void
senario_test_08( void *user_data ) {
  UNUSED( user_data );

  info( "call senario_test_08()." );

  register_table_pattern_08_2();
  delete_timer_event( senario_test_08, NULL );

  return;
}


static void
senario_test_13( void *user_data ) {
  UNUSED( user_data );

  info( "call senario_test_13()." );

  register_table_pattern_13_2();
  delete_timer_event( senario_test_13, NULL );

  return;
}


static void
senario_test_13_2( void *user_data ) {
  UNUSED( user_data );

  info( "call senario_test_13_2()." );

  register_table_pattern_13_3();
  delete_timer_event( senario_test_13_2, NULL );

  return;
}


static void
senario_test_14( void *user_data ) {
  UNUSED( user_data );

  info( "call senario_test_14()." );

  register_table_pattern_14_2();
  delete_timer_event( senario_test_14, NULL );

  return;
}


static void
senario_test_15( void *user_data ) {
  UNUSED( user_data );

  info( "call senario_test_15()." );

  register_table_pattern_15_2();
  delete_timer_event( senario_test_15, NULL );

  return;
}


static void
senario_test_16_add_2_1( void *user_data ) {
  UNUSED( user_data );

  info( "call senario_test_16_add_2_1()." );

  register_table_pattern_continuation_test_add_2_1();

  return;
}


static void
senario_test_16_add_port3( void *user_data ) {
  UNUSED( user_data );

  info( "call senario_test_16_add_port3()." );

  register_table_pattern_continuation_test_add_port3();

  return;
}


static void
senario_test_16_delete_port3( void *user_data ) {
  UNUSED( user_data );

  info( "call senario_test_16_delete_port3()." );

  register_table_pattern_continuation_test_delete_port3();

  return;
}


static void
senario_test_16_delete_port3_first( void *user_data ) {
  UNUSED( user_data );

  info( "call senario_test_16_delete_port3_first()." );

  register_table_pattern_continuation_test_delete_port3();
  delete_timer_event( senario_test_16_delete_port3_first, NULL );
  add_periodic_event_callback( 2 * HOUR, senario_test_16_delete_port3, NULL );

  return;
}


static void
dump_stats( void *user_data ) {
  UNUSED( user_data );

  OFDPE ret = OFDPE_SUCCESS;
  const uint8_t max_table_id = 1;
  const uint8_t max_group_id = 1;

  // port stats
  ofp_port_stats *port_stats;
  int num_port_stats;
  ret = get_device_statistics( OFPP_ALL, &port_stats, &num_port_stats );
  if ( ret == OFDPE_SUCCESS ) {
    for ( int i = 0; i < num_port_stats; i++ ) {
      dump_port_stats( &( port_stats[ i ] ) );
    }
    xfree( port_stats );
  }
  else {
    error( "get_device_statistics() error." );
  }

  // flow table stats
  ofp_table_stats *table_stats;
  for ( uint8_t table_id = 0; table_id <= max_table_id; table_id++ ) {
    ret = get_statistics_table( &table_stats, table_id );
    if ( ret == OFDPE_SUCCESS ) {
      dump_flow_table_stats( table_stats );
      xfree( table_stats );
    }
    else {
      error( "dump_flow_table_stats(%d) error.", table_id );
    }
  }

  // flow stats
  flow_stats *flow_stat;
  flow_stats_request request;
  request.cookie = 0;
  request.cookie_mask = 0;
  request.out_group = 0;
  request.out_port = 0;
  request.p_match = NULL;
  request.table_id = 0;

  uint32_t num_flow_stats;
  for ( uint8_t table_id = 0; table_id <= max_table_id; table_id++ ) {
    request.table_id = table_id;
    request.out_port = OFPP_ANY;
    ret = get_statistics_flow( request, &flow_stat, &num_flow_stats );
    if ( ret == OFDPE_SUCCESS ) {
      for ( uint64_t i = 0; i < num_flow_stats; i++ ) {
        dump_flow_stats( &( flow_stat[ i ] ) );
      }
      xfree( flow_stat );
    }
    else {
      error( "dump_flow_stats(%d) error.", table_id );
    }
  }

  // group stats
  ofp_group_stats *group_stats;
  uint32_t num_group_stats;
  for ( uint8_t group_id = 0; group_id <= max_group_id; group_id++ ) {
    ret = get_statistics_group( group_id, &group_stats, &num_group_stats );
    if ( ret == OFDPE_SUCCESS ) {
      dump_group_stats( group_stats );
//      xfree( group_stats->bucket_stats );
      xfree( group_stats );
    }
    else {
      error( "dump_group_stats(%d) error.", group_id );
    }
  }
//  group features
  ofp_group_features features;
  ret = get_group_features( &features );
  if ( ret == OFDPE_SUCCESS ) {
    dump_group_features( &features );
  }
  else {
    error( "dump_group_desc_stats error.");
  }
  //  get_group_desc_status
  group_desc_stats *group_desc_status;
  uint16_t num_group_desc_stats = 0;
  ret = get_group_desc_status( &group_desc_status, &num_group_desc_stats );
  if ( ret == OFDPE_SUCCESS ) {
      for( uint16_t i = 0; i < num_group_desc_stats ; i++ ){
          dump_group_desc_status( group_desc_status, i );
      }
    xfree( group_desc_status );
  }
  else {
    error( "dump_group_desc_stats error.");
  }
}


static void
dump_config() {
  ofp_switch_features switch_features;
  memset( &switch_features, 0, sizeof( switch_features ) );
  get_switch_features( &switch_features );
  dump_switch_features( &switch_features );

  ofp_switch_config switch_config;
  memset( &switch_config, 0, sizeof( switch_config ) );
  get_switch_config( &switch_config );
  dump_switch_config( &switch_config );

  table_features *t_features;
  get_table_features( 0, &t_features );
  dump_table_features( t_features );
  xfree( t_features );
  get_table_features( 1, &t_features );
  dump_table_features( t_features );
  xfree( t_features );

  ofp_table_mod *t_mod;
  get_table_configuration( 0, &t_mod );
  dump_table_configuration( t_mod );
  xfree( t_mod );
  get_table_configuration( 1, &t_mod );
  dump_table_configuration( t_mod );
  xfree( t_mod );

}


static void
set_notify_handler() {
  register_notify_handler_to_controller( NOTIFY_TYPE_PACKET_IN, packet_in_handler );
  register_notify_handler_to_controller( NOTIFY_TYPE_FLOW_REMOVED, flow_removed_handler );
  register_notify_handler_to_controller( NOTIFY_TYPE_PORT_STATUS, port_status_handler );
  register_notify_handler_to_controller( NOTIFY_TYPE_ERROR, error_handler );
  return;
}


static OFDPE
start_main( uint32_t senario_no ) {
  OFDPE ret = OFDPE_SUCCESS;

  set_notify_handler();

  if ( senario_no == 1 ) {
    add_periodic_event_callback( 60, dump_config, NULL );
  }
  else if ( senario_no == 3 ) {
    add_periodic_event_callback( 30, senario_test_03, NULL );
  }
  else if ( senario_no == 4 ) {
    add_periodic_event_callback( 30, senario_test_04, NULL );
    register_notify_handler_to_controller( NOTIFY_TYPE_PACKET_IN, packet_in_handler_to_packet_out );
  }
  else if ( senario_no == 7 ) {
    add_periodic_event_callback( 30, senario_test_07, NULL );
  }
  else if ( senario_no == 8 ) {
    add_periodic_event_callback( 30, senario_test_08, NULL );
  }
  else if ( senario_no == 13 ) {
    add_periodic_event_callback( 30, senario_test_13, NULL );
    add_periodic_event_callback( 60, senario_test_13_2, NULL );
  }
  else if ( senario_no == 14 ) {
    add_periodic_event_callback( 30, senario_test_14, NULL );
  }
  else if ( senario_no == 15 ) {
    add_periodic_event_callback( 30, senario_test_15, NULL );
  }
  else if ( senario_no == 16 ) {
    add_periodic_event_callback( 10 * MINUTS, senario_test_16_add_2_1, NULL );
    add_periodic_event_callback( 2 * HOUR, senario_test_16_add_port3, NULL );
    add_periodic_event_callback( 1 * HOUR, senario_test_16_delete_port3_first, NULL );
  }

  if ( senario_no == 16 ) {
    add_periodic_event_callback( 5 * MINUTS, dump_stats, NULL );
  }
  else {
    add_periodic_event_callback( 10, dump_stats, NULL );
  }

  ret = start_datapath();

  return ret;
}


int
main( int argc, char **argv ) {
  command_argument arg_data;

  if ( geteuid() != 0 ) {
    fprintf( stderr, "need for root user.\n" );
    return PROG_FAIL;
  }

#ifdef UNIT_TESTING
  test_argument();
  return PROG_SUCCESS;

#endif  // UNIT_TESTING

  if ( !analyze_argument( argc, argv, &arg_data ) ) {
    fprintf( stderr, "analyze_arg failed.\n" );
    return PROG_FAIL;
  }

  ofdp_library_argument lib_arg;
  set_ofdp_library_argument( &lib_arg,
    arg_data.program_name, arg_data.loglevel, arg_data.devices_info, arg_data.is_daemon,
    SWITCH_MTU, NUM_POOL, NUM_CONTROLLER_BUFFER, SELECT_TIMEOUT_USEC, MAX_SEND_QUEUE, MAX_RECV_QUEUE, DATAPATH_ID );

  if ( !set_sighandler() ) {
    fprintf( stderr, "set_sighandler failed.\n" );
    return PROG_FAIL;
  }

  OFDPE ret = OFDPE_SUCCESS;

  ret = init_datapath( &lib_arg );
  if ( ret != OFDPE_SUCCESS ) {
    fprintf( stderr, "init_datapath failed.\n" );
    return PROG_FAIL;
  }

  add_ether_devices( lib_arg.devices_info );

  register_table_pattern( arg_data.table_pattern_no );

  ret = start_main( arg_data.table_pattern_no );
  if ( ret != OFDPE_SUCCESS ) {
    error( "start_datapath failed." );
    return PROG_FAIL;
  }

  ret = finalize_datapath();
  if ( ret != OFDPE_SUCCESS ) {
    error( "finalize_datapath failed." );
    return ret;
  }

  free_argument( &arg_data );

  return PROG_SUCCESS;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
