/*
 * Functions for OpenFlow main process.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef MAIN_H
#define MAIN_H


#include <stdint.h>
#include "port_manager.h"
#include "linked_list.h"


// Define of changable parameters
const char LOG_LEVEL[] = "info";
const size_t SWITCH_MTU = 1500;
const uint32_t NUM_POOL = 1000;
const uint32_t NUM_CONTROLLER_BUFFER = 100;
const size_t MAX_SEND_QUEUE = 400;      // NUM_POOL - (NUM_POOL - NUM_CONTROLLER_BUFFER) * x
const size_t MAX_RECV_QUEUE = 400;      // NUM_POOL - (NUM_POOL - NUM_CONTROLLER_BUFFER) * x
const uint32_t SELECT_TIMEOUT_USEC = 100000;
const uint64_t DATAPATH_ID = 1;


// Structure of command line arguments
typedef struct {
  char *program_name;
  char *loglevel;
  list_element *devices_info;       // data is argument_device_info
  uint32_t table_pattern_no;
  bool is_daemon;
} command_argument;


#endif  // MAIN_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
