/*
 * Functions for register OpenFlow table pattern.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include "table_pattern.h"
#include "table_manager.h"
#include "port_manager.h"
#include "controller_manager.h"


static void
register_table_pattern_01() {
  instruction_list *instructions = NULL;
  action *act = NULL;
  action_list *alist = NULL;
  match *p_match;
  flow_entry *entry;

  // flow table 0
  instructions = init_instruction_list();

  alist = init_action_list();

  act = create_action_push_mpls( 0x8847 );
  append_action( alist, act );

  append_instruction( instructions, create_instruction_write_actions( alist ) );

  append_instruction( instructions, create_instruction_goto_table( 1 ) );

  p_match = init_match();
  p_match->udp_dst.value = 9999;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.valid = true;
  p_match->eth_type.value = 0x0800;


  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 0, entry );


  // flow table 1
  instructions = init_instruction_list();

  append_instruction( instructions, create_instruction_clear_actions() );

  alist = init_action_list();

  p_match = init_match();
  p_match->eth_dst[ 0 ].value = 0x01;
  p_match->eth_dst[ 0 ].valid = true;
  p_match->eth_dst[ 1 ].value = 0x02;
  p_match->eth_dst[ 1 ].valid = true;
  p_match->eth_dst[ 2 ].value = 0x03;
  p_match->eth_dst[ 2 ].valid = true;
  p_match->eth_dst[ 3 ].value = 0x04;
  p_match->eth_dst[ 3 ].valid = true;
  p_match->eth_dst[ 4 ].value = 0x05;
  p_match->eth_dst[ 4 ].valid = true;
  p_match->eth_dst[ 5 ].value = 0x06;
  p_match->eth_dst[ 5 ].valid = true;
  act = create_action_set_field( p_match );
  append_action( alist, act );

  act = create_action_set_ipv4_ttl( 100 );
  append_action( alist, act );

  act = create_action_push_vlan( 0x8100 );
  append_action( alist, act );

  act = create_action_output( 1, 1500 );
  append_action( alist, act );

  append_instruction( instructions, create_instruction_write_actions( alist ) );

  p_match = init_match();
  p_match->udp_dst.value = 9999;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 1, entry );
}


static void
register_table_pattern_02() {
  instruction_list *instructions = NULL;
  action *act = NULL;
  action_list *alist = NULL;
  match *p_match;
  flow_entry *entry;


  // flow table 0
  instructions = init_instruction_list();

  append_instruction( instructions, create_instruction_write_metadata( 123, 123 ) );

  append_instruction( instructions, create_instruction_goto_table( 1 ) );

  p_match = init_match();
  p_match->tcp_dst.value = 1234;
  p_match->tcp_dst.valid = true;
  p_match->ip_proto.value = 6;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 0, entry );


  // flow table 1
  instructions = init_instruction_list();

  alist = init_action_list();

  act = create_action_push_mpls( 0x8847 );
  append_action( alist, act );

  act = create_action_set_mpls_ttl( 100 );
  append_action( alist, act );

  act = create_action_output( 2, 1500 );
  append_action( alist, act );

  append_instruction( instructions, create_instruction_apply_actions( alist ) );

  p_match = init_match();
  p_match->tcp_dst.value = 1234;
  p_match->tcp_dst.valid = true;
  p_match->metadata.value = 123;
  p_match->metadata.mask = 123;
  p_match->metadata.valid = true;
  p_match->ip_proto.value = 6;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 1, entry );
}


static void
register_table_pattern_03() {
  instruction_list *instructions = NULL;
  action *act = NULL;
  action_list *alist = NULL;
  match *p_match;
  flow_entry *entry;


  // flow table 0
  instructions = init_instruction_list();

  alist = init_action_list();

  act = create_action_output( 2, 1500 );
  append_action( alist, act );

  append_instruction( instructions, create_instruction_write_actions( alist ) );

  p_match = init_match();
  p_match->udp_dst.value = 9999;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 0, entry );
}


void
register_table_pattern_03_2() {
  instruction_list *instructions = NULL;
  action *act = NULL;
  action_list *alist = NULL;
  match *p_match;
  flow_entry *entry;


  // remove
  p_match = init_match();
  p_match->udp_dst.value = 9999;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = lookup_flow_entry( 0, p_match );
  remove_flow_entry( 0, entry );

  // flow table 0
  instructions = init_instruction_list();

  alist = init_action_list();

  act = create_action_pop_mpls( 0x8847 );
  append_action( alist, act );

  act = create_action_copy_ttl_in();
  append_action( alist, act );

  act = create_action_output( OFPP_ALL, 1500 );
  append_action( alist, act );

  append_instruction( instructions, create_instruction_write_actions( alist ) );

  p_match = init_match();
  p_match->udp_dst.value = 9999;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 0, entry );
}


static void
register_table_pattern_04() {
  instruction_list *instructions = NULL;
  action *act = NULL;
  action_list *alist = NULL;
  match *p_match;
  flow_entry *entry;


  // flow table 0
  instructions = init_instruction_list();

  alist = init_action_list();

  act = create_action_output( 2, 1500 );
  append_action( alist, act );

  append_instruction( instructions, create_instruction_write_actions( alist ) );

  p_match = init_match();
  p_match->udp_dst.value = 9999;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 0, entry );
}


void
register_table_pattern_04_2() {
  instruction_list *instructions = NULL;
  action *act = NULL;
  action_list *alist = NULL;
  match *p_match;
  flow_entry *entry;


  // remove
  p_match = init_match();
  p_match->udp_dst.value = 9999;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = lookup_flow_entry( 0, p_match );
  remove_flow_entry( 0, entry );

  // flow table 0
  instructions = init_instruction_list();

  alist = init_action_list();

  act = create_action_pop_vlan();
  append_action( alist, act );

  act = create_action_decr_ipv4_ttl();
  append_action( alist, act );

  act = create_action_output( OFPP_CONTROLLER, 1500 );
  append_action( alist, act );

  append_instruction( instructions, create_instruction_write_actions( alist ) );

  p_match = init_match();
  p_match->udp_dst.value = 9999;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 0, entry );
}


static void
register_table_pattern_05() {
  instruction_list *instructions = NULL;
  action *act = NULL;
  action_list *alist = NULL;
  match *p_match;
  flow_entry *entry;


  // flow table 0
  instructions = init_instruction_list();

  alist = init_action_list();

  p_match = init_match();
  p_match->udp_dst.value = 9696;
  p_match->udp_dst.valid = true;
  act = create_action_set_field( p_match );
  append_action( alist, act );

  act = create_action_output( OFPP_TABLE, 1500 );
  append_action( alist, act );

  append_instruction( instructions, create_instruction_write_actions( alist ) );

  p_match = init_match();
  p_match->udp_dst.value = 9999;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 0, entry );


  instructions = init_instruction_list();

  alist = init_action_list();

  act = create_action_decr_mpls_ttl();
  append_action( alist, act );

  act = create_action_output( OFPP_IN_PORT, 1500 );
  append_action( alist, act );

  append_instruction( instructions, create_instruction_write_actions( alist ) );

  p_match = init_match();
  p_match->udp_dst.value = 9696;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 0, entry );
}


static void
register_table_pattern_06() {
  instruction_list *instructions = NULL;
  action *act = NULL;
  action_list *alist = NULL;
  match *p_match;
  flow_entry *entry;


  // flow table 0
  instructions = init_instruction_list();

  alist = init_action_list();

  act = create_action_copy_ttl_out();
  append_action( alist, act );

  act = create_action_output( OFPP_ANY, 1500 );
  append_action( alist, act );

  append_instruction( instructions, create_instruction_write_actions( alist ) );

  p_match = init_match();
  p_match->udp_dst.value = 9999;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 0, entry );
}


static void
register_table_pattern_07() {
  instruction_list *instructions = NULL;
  action *act = NULL;
  action_list *alist = NULL;
  match *p_match;
  bucket_list *blist = NULL;
  bucket *p_bucket;
  group_entry *gentry = NULL;
  flow_entry *entry;


  // group table 0
  blist = create_action_bucket_list();
  alist = init_action_list();
  act = create_action_output( 1, 1500 );
  append_action( alist, act );
  p_bucket = create_action_bucket( 1, 1, 1, alist );
  append_action_bucket( blist, p_bucket );

  alist = init_action_list();
  act = create_action_output( 3, 1500 );
  append_action( alist, act );
  p_bucket = create_action_bucket( 1, 1, 1, alist );
  append_action_bucket( blist, p_bucket );

  alist = init_action_list();
  act = create_action_output( 4, 1500 );
  append_action( alist, act );
  p_bucket = create_action_bucket( 1, 1, 1, alist );
  append_action_bucket( blist, p_bucket );

  alist = init_action_list();
  act = create_action_output( 2, 1500 );
  append_action( alist, act );
  p_bucket = create_action_bucket( 1, 1, 1, alist );
  append_action_bucket( blist, p_bucket );

  alist = init_action_list();
  act = create_action_output( 5, 1500 );
  append_action( alist, act );
  p_bucket = create_action_bucket( 1, 1, 1, alist );
  append_action_bucket( blist, p_bucket );

  gentry = create_group_entry( OFPGT_ALL, blist );
  append_group_entry( gentry );


  // flow table 0
  instructions = init_instruction_list();

  alist = init_action_list();
  act = create_action_group( 0 );
  append_action( alist, act );
  append_instruction( instructions, create_instruction_apply_actions( alist ) );

  p_match = init_match();
  p_match->udp_dst.value = 9999;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 0, entry );
}


void
register_table_pattern_07_2() {
  update_port_config(5, OFPPC_NO_FWD, OFPPC_NO_FWD);
}


static void
register_table_pattern_08() {
  instruction_list *instructions = NULL;
  action *act = NULL;
  action_list *alist = NULL;
  match *p_match;
  bucket_list *blist = NULL;
  bucket *p_bucket;
  group_entry *gentry = NULL;
  flow_entry *entry;


  // group table 0
  blist = create_action_bucket_list();
  alist = init_action_list();
  act = create_action_output( 1, 1500 );
  append_action( alist, act );
  p_bucket = create_action_bucket( 1, 1, 1, alist );
  append_action_bucket( blist, p_bucket );

  alist = init_action_list();
  act = create_action_output( 2, 1500 );
  append_action( alist, act );
  p_bucket = create_action_bucket( 1, 1, 1, alist );
  append_action_bucket( blist, p_bucket );

  alist = init_action_list();
  act = create_action_output( 3, 1500 );
  append_action( alist, act );
  p_bucket = create_action_bucket( 1, 1, 1, alist );
  append_action_bucket( blist, p_bucket );

  gentry = create_group_entry( OFPGT_ALL, blist );
  append_group_entry( gentry );


  // flow table 0
  instructions = init_instruction_list();

  alist = init_action_list();
  act = create_action_group( 0 );
  append_action( alist, act );
  append_instruction( instructions, create_instruction_apply_actions( alist ) );

  p_match = init_match();
  p_match->udp_dst.value = 9999;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 0, entry );
}


void
register_table_pattern_08_2() {
  instruction_list *instructions = NULL;
  action *act = NULL;
  action_list *alist = NULL;
  match *p_match;
  bucket_list *blist = NULL;
  bucket *p_bucket;
  group_entry *gentry = NULL;
  flow_entry *entry;


  // remove
  p_match = init_match();
  p_match->udp_dst.value = 9999;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = lookup_flow_entry( 0, p_match );
  remove_flow_entry( 0, entry );

  remove_group_entry( 0 );


  // group table 0
  blist = create_action_bucket_list();
  alist = init_action_list();
  act = create_action_output( 1, 1500 );
  append_action( alist, act );
  p_bucket = create_action_bucket( 1, 1, 1, alist );
  append_action_bucket( blist, p_bucket );

  alist = init_action_list();
  act = create_action_output( 2, 1500 );
  append_action( alist, act );
  p_bucket = create_action_bucket( 1, 1, 1, alist );
  append_action_bucket( blist, p_bucket );

  alist = init_action_list();
  act = create_action_output( 3, 1500 );
  append_action( alist, act );
  p_bucket = create_action_bucket( 1, 1, 1, alist );
  append_action_bucket( blist, p_bucket );

  gentry = create_group_entry( OFPGT_SELECT, blist );
  append_group_entry( gentry );


  // flow table 0
  instructions = init_instruction_list();

  alist = init_action_list();
  act = create_action_group( 0 );
  append_action( alist, act );
  append_instruction( instructions, create_instruction_apply_actions( alist ) );

  p_match = init_match();
  p_match->udp_dst.value = 9999;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 0, entry );
}


static void
register_table_pattern_09() {
  instruction_list *instructions = NULL;
  action *act = NULL;
  action_list *alist = NULL;
  match *p_match;
  bucket_list *blist = NULL;
  bucket *p_bucket;
  group_entry *gentry = NULL;
  flow_entry *entry;


  // group table 0
  blist = create_action_bucket_list();
  alist = init_action_list();
  act = create_action_output( 1, 1500 );
  append_action( alist, act );
  p_bucket = create_action_bucket( 1, 1, 1, alist );
  append_action_bucket( blist, p_bucket );

  alist = init_action_list();
  act = create_action_output( 2, 1500 );
  append_action( alist, act );
  p_bucket = create_action_bucket( 1, 1, 1, alist );
  append_action_bucket( blist, p_bucket );

  alist = init_action_list();
  act = create_action_output( 3, 1500 );
  append_action( alist, act );
  p_bucket = create_action_bucket( 1, 1, 1, alist );
  append_action_bucket( blist, p_bucket );

  gentry = create_group_entry( OFPGT_INDIRECT, blist );
  append_group_entry( gentry );


  // flow table 0
  instructions = init_instruction_list();

  alist = init_action_list();
  act = create_action_group( 0 );
  append_action( alist, act );
  append_instruction( instructions, create_instruction_apply_actions( alist ) );

  p_match = init_match();
  p_match->udp_dst.value = 9999;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 0, entry );
}


static void
register_table_pattern_10() {
  // no register pattern
}


static void
register_table_pattern_11() {
  instruction_list *instructions = NULL;
  action *act = NULL;
  action_list *alist = NULL;
  match *p_match;
  flow_entry *entry;


  // flow table 0
  instructions = init_instruction_list();

  alist = init_action_list();

  act = create_action_output( 3, 1500 );
  append_action( alist, act );

  append_instruction( instructions, create_instruction_apply_actions( alist ) );

  p_match = init_match();
  p_match->udp_dst.value = 9999;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 1 * MINUTS, 0, OFPFF_SEND_FLOW_REM, 0 );
  append_flow_entry( 0, entry );
}


static void
register_table_pattern_12() {
  instruction_list *instructions = NULL;
  action *act = NULL;
  action_list *alist = NULL;
  match *p_match;
  flow_entry *entry;


  // flow table 0
  instructions = init_instruction_list();

  alist = init_action_list();

  act = create_action_output( 3, 1500 );
  append_action( alist, act );

  append_instruction( instructions, create_instruction_apply_actions( alist ) );

  p_match = init_match();
  p_match->udp_dst.value = 9999;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 1 * MINUTS, OFPFF_SEND_FLOW_REM, 0 );
  append_flow_entry( 0, entry );
}


static void
register_table_pattern_13() {
  // no register pattern
}


void
register_table_pattern_13_2() {
  add_port( 4, "eth0" );
}


void
register_table_pattern_13_3() {
  instruction_list *instructions = NULL;
  action *act = NULL;
  action_list *alist = NULL;
  match *p_match;
  flow_entry *entry;


  // flow table 0
  instructions = init_instruction_list();

  alist = init_action_list();

  act = create_action_output( 4, 1500 );
  append_action( alist, act );

  append_instruction( instructions, create_instruction_write_actions( alist ) );

  p_match = init_match();
  p_match->udp_dst.value = 9999;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 0, entry );
}


static void
register_table_pattern_14() {
  instruction_list *instructions = NULL;
  action *act = NULL;
  action_list *alist = NULL;
  match *p_match;
  flow_entry *entry;


  // flow table 0
  instructions = init_instruction_list();

  alist = init_action_list();

  act = create_action_output( 2, 1500 );
  append_action( alist, act );

  append_instruction( instructions, create_instruction_write_actions( alist ) );

  p_match = init_match();
  p_match->udp_dst.value = 9999;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 0, entry );
}


void
register_table_pattern_14_2() {
  delete_port( 2 );
}


static void
register_table_pattern_15() {
  // no register pattern
}


void
register_table_pattern_15_2() {
  add_port( 99, "eth99" );
}


static void
register_table_pattern_17() {
  instruction_list *instructions = NULL;
  action *act = NULL;
  action_list *alist = NULL;
  match *p_match;
  flow_entry *entry;


  // flow table 0
  instructions = init_instruction_list();

  append_instruction( instructions, create_instruction_write_metadata( 123, 123 ) );

  append_instruction( instructions, create_instruction_goto_table( 1 ) );

  p_match = init_match();
  p_match->udp_dst.value = 9999;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.valid = true;
  p_match->eth_type.value = 0x0800;


  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 0, entry );


  // flow table 1
  instructions = init_instruction_list();

  alist = init_action_list();

  p_match = init_match();
  p_match->udp_dst.value = 9999;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.valid = true;
  p_match->eth_type.value = 0x0800;
  p_match->ipv4_dst.valid = true;
  p_match->ipv4_dst.value = 0xC0A80101;
  p_match->ipv4_src.valid = true;
  p_match->ipv4_src.value = 0xC0A80110;
  p_match->eth_src[ 0 ].value = 0xff;
  p_match->eth_src[ 1 ].value = 0xff;
  p_match->eth_src[ 2 ].value = 0xff;
  p_match->eth_src[ 3 ].value = 0xff;
  p_match->eth_src[ 4 ].value = 0xff;
  p_match->eth_src[ 5 ].value = 0xff;
  p_match->eth_src[ 0 ].valid = true;
  p_match->eth_dst[ 0 ].value = 0xff;
  p_match->eth_dst[ 1 ].value = 0xff;
  p_match->eth_dst[ 2 ].value = 0xff;
  p_match->eth_dst[ 3 ].value = 0xff;
  p_match->eth_dst[ 4 ].value = 0xff;
  p_match->eth_dst[ 5 ].value = 0xff;
  p_match->eth_dst[ 0 ].valid = true;

  act = create_action_set_field( p_match );
  append_action( alist, act );

  act = create_action_push_mpls( 0x8847 );
  append_action( alist, act );

  act = create_action_set_mpls_ttl( 100 );
  append_action( alist, act );

  act = create_action_output( 1, 1500 );
  append_action( alist, act );

  append_instruction( instructions, create_instruction_apply_actions( alist ) );

  p_match = init_match();
  p_match->metadata.value = 123;
  p_match->metadata.mask = 123;
  p_match->metadata.valid = true;
  p_match->udp_dst.value = 9999;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.valid = true;
  p_match->eth_type.value = 0x0800;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 1, entry );
}


void
register_table_pattern_continuation_test_add_2_1() {
  instruction_list *instructions = NULL;
  action *act = NULL;
  action_list *alist = NULL;
  match *p_match;
  flow_entry *entry;


  // match 2-1
  instructions = init_instruction_list();

  alist = init_action_list();

  act = create_action_output( 2, 1500 );
  append_action( alist, act );

  append_instruction( instructions, create_instruction_write_actions( alist ) );

  p_match = init_match();
  p_match->udp_dst.value = 1234;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 5 * MINUTS, OFPFF_SEND_FLOW_REM, 0 );
  append_flow_entry( 0, entry );
}


void
register_table_pattern_continuation_test_update_2_2() {
  match *p_match;
  flow_entry *entry;


  // find 2-1
  p_match = init_match();
  p_match->udp_dst.value = 1234;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = lookup_flow_entry( 0, p_match );

  // update 2-2
  entry->hard_timeout = 5 * MINUTS;
  update_flow_entry( 0, entry );
}


void
register_table_pattern_continuation_test_add_port3() {
  add_port( 3, "eth3" );
}


void
register_table_pattern_continuation_test_delete_port3() {
  delete_port( 3 );
}


static void
register_table_pattern_continuation_test() {
  instruction_list *instructions = NULL;
  action *act = NULL;
  action_list *alist = NULL;
  match *p_match;
  flow_entry *entry;


  // match 1
  instructions = init_instruction_list();

  alist = init_action_list();

  p_match = init_match();
  p_match->ipv4_src.value = 0x11223344;
  p_match->ipv4_src.valid = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;
  act = create_action_set_field( p_match );
  append_action( alist, act );

  act = create_action_output( 2, 1500 );
  append_action( alist, act );

  append_instruction( instructions, create_instruction_write_actions( alist ) );

  p_match = init_match();
  p_match->udp_dst.value = 1233;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 0, entry );

  // match 2-1
  register_table_pattern_continuation_test_add_2_1();

  // match 3
  instructions = init_instruction_list();

  alist = init_action_list();

  p_match = init_match();
  p_match->ipv4_src.value = 0x11223344;
  p_match->ipv4_src.valid = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;
  act = create_action_set_field( p_match );
  append_action( alist, act );

  act = create_action_output( 2, 1500 );
  append_action( alist, act );

  append_instruction( instructions, create_instruction_write_actions( alist ) );

  p_match = init_match();
  p_match->udp_dst.value = 1235;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 0, entry );

  // match 4
  instructions = init_instruction_list();

  alist = init_action_list();

  p_match = init_match();
  p_match->ipv4_src.value = 0x11223344;
  p_match->ipv4_src.valid = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;
  act = create_action_set_field( p_match );
  append_action( alist, act );

  act = create_action_output( 2, 1500 );
  append_action( alist, act );

  append_instruction( instructions, create_instruction_write_actions( alist ) );

  p_match = init_match();
  p_match->udp_dst.value = 9998;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 0, entry );

  // match 5
  instructions = init_instruction_list();

  alist = init_action_list();

  act = create_action_output( 3, 1500 );
  append_action( alist, act );

  append_instruction( instructions, create_instruction_write_actions( alist ) );

  p_match = init_match();
  p_match->udp_dst.value = 9999;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 0, entry );

  // match 6
  instructions = init_instruction_list();

  alist = init_action_list();

  p_match = init_match();
  p_match->ipv4_src.value = 0x11223344;
  p_match->ipv4_src.valid = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;
  act = create_action_set_field( p_match );
  append_action( alist, act );

  act = create_action_output( 2, 1500 );
  append_action( alist, act );

  append_instruction( instructions, create_instruction_write_actions( alist ) );

  p_match = init_match();
  p_match->udp_dst.value = 10000;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 0, entry );
}


static match *
init_match_linklayer_address() {
  match *p_match = init_match();

  for ( uint8_t i = 0; i < OFP_ETH_ALEN; i++ ) {
    p_match->eth_src[ i ].valid = true;
    p_match->eth_src[ i ].value = i;
  }

  return p_match;
}


static void
register_default_table_pattern() {
  match *p_match = NULL;
  action *act = NULL;
  action_list *alist = NULL;
  instruction_list *instructions = NULL;
  flow_entry *entry = NULL;

  // flow table 0, entry 0 [udp 9998]
  p_match = init_match_linklayer_address();

  act = create_action_set_field( p_match );

  alist = init_action_list();
  append_action( alist, act );

  instructions = init_instruction_list();
  append_instruction( instructions, create_instruction_write_actions( alist ) );

  p_match = init_match();
  p_match->udp_dst.value = 9998;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 0, entry );


  // flow table 0, entry 1 [udp 10000]
  p_match = init_match_linklayer_address();

  act = create_action_set_field( p_match );

  alist = init_action_list();
  append_action( alist, act );

  instructions = init_instruction_list();
  append_instruction( instructions, create_instruction_write_actions( alist ) );

  p_match = init_match();
  p_match->udp_dst.value = 10000;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 0, entry );


  // flow table 0, entry 2 [udp 1234]
  p_match = init_match_linklayer_address();

  act = create_action_set_field( p_match );

  alist = init_action_list();
  append_action( alist, act );

  instructions = init_instruction_list();
  append_instruction( instructions, create_instruction_write_actions( alist ) );

  p_match = init_match();
  p_match->udp_dst.value = 1234;
  p_match->udp_dst.valid = true;
  p_match->ip_proto.value = 17;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 0, entry );


  // flow table 0, entry 3 [tcp 1233]
  p_match = init_match_linklayer_address();

  act = create_action_set_field( p_match );

  alist = init_action_list();
  append_action( alist, act );

  instructions = init_instruction_list();
  append_instruction( instructions, create_instruction_write_actions( alist ) );

  p_match = init_match();
  p_match->tcp_dst.value = 1233;
  p_match->tcp_dst.valid = true;
  p_match->ip_proto.value = 6;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 0, entry );


  // flow table 0, entry 4 [tcp 1235]
  p_match = init_match_linklayer_address();

  act = create_action_set_field( p_match );

  alist = init_action_list();
  append_action( alist, act );

  instructions = init_instruction_list();
  append_instruction( instructions, create_instruction_write_actions( alist ) );

  p_match = init_match();
  p_match->tcp_dst.value = 1235;
  p_match->tcp_dst.valid = true;
  p_match->ip_proto.value = 6;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 0, entry );


  // flow table 0, entry 5 [tcp 9999]
  p_match = init_match_linklayer_address();

  act = create_action_set_field( p_match );

  alist = init_action_list();
  append_action( alist, act );

  instructions = init_instruction_list();
  append_instruction( instructions, create_instruction_write_actions( alist ) );

  p_match = init_match();
  p_match->tcp_dst.value = 9999;
  p_match->tcp_dst.valid = true;
  p_match->ip_proto.value = 6;
  p_match->ip_proto.valid  = true;
  p_match->eth_type.value = 0x0800;
  p_match->eth_type.valid = true;

  entry = create_flow_entry( p_match, instructions, 1, 0, 0, 0, 0 );
  append_flow_entry( 0, entry );
}


bool
register_table_pattern( unsigned int table_pattern_no ) {
  void ( *regist_pattern[] )( ) = {
    NULL,
    register_table_pattern_01,
    register_table_pattern_02,
    register_table_pattern_03,
    register_table_pattern_04,
    register_table_pattern_05,
    register_table_pattern_06,
    register_table_pattern_07,
    register_table_pattern_08,
    register_table_pattern_09,
    register_table_pattern_10,
    register_table_pattern_11,
    register_table_pattern_12,
    register_table_pattern_13,
    register_table_pattern_14,
    register_table_pattern_15,
    register_table_pattern_continuation_test,
    register_table_pattern_17,
  };

  if ( table_pattern_no < sizeof( regist_pattern ) / sizeof( regist_pattern[ 0 ] ) ) {
    info( "table pattern no = %d", table_pattern_no );
    if ( regist_pattern[ table_pattern_no ] != NULL ) {
      regist_pattern[ table_pattern_no ]();
    }
  }
  else {
    error( "Illigal table pattern no = %d", table_pattern_no );
    return false;
  }

  if ( table_pattern_no != 16 ) {
    register_default_table_pattern();
  }

  return true;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
