/*
 * Functions for register OpenFlow table pattern.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef TABLE_PATTERN_H
#define TABLE_PATTERN_H


#include "bool.h"


#define MINUTS  60
#define HOUR    ( 60 * MINUTS )


// List of public library function
bool register_table_pattern( unsigned int table_pattern_no );
void register_table_pattern_03_2();
void register_table_pattern_04_2();
void register_table_pattern_07_2();
void register_table_pattern_08_2();
void register_table_pattern_13_2();
void register_table_pattern_13_3();
void register_table_pattern_14_2();
void register_table_pattern_15_2();
void register_table_pattern_continuation_test_add_2_1();
void register_table_pattern_continuation_test_update_2_2();
void register_table_pattern_continuation_test_add_port3();
void register_table_pattern_continuation_test_delete_port3();


#endif  // TABLE_PATTERN_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
