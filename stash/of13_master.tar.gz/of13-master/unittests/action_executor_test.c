
#include <assert.h>
#include <netinet/ip.h>
#include <stdio.h>
#include <string.h>
#include "checks.h"
#include "cmockery_trema.h"
#include "utility.h"
#include "wrapper.h"
#include "linked_list.h"
#include "doubly_linked_list.h"
#include "mutex_lock.h"
#include "test_mocks.h"
#include "test_util.h"
#include "trema_wrapper.h"
#include "action_executor.h"
#include "port_manager.h"
#include "table_manager.h"
#include "packet_parser.h"
#include "controller_manager.h"
#include "buffer.h"
#include "ether.h"
#include "ipv4.h"
#include "ipv6.h"
#include "icmp.h"
#include "tcp.h"
#include "udp.h"

#include "openflow.h"

/******************************************************************************
 * Mocks.
 ******************************************************************************/

static void ( *original_die )( const char *format, ... );
static bool ( *original_is_device_linkup )( const uint32_t port_no );
static OFDPE ( *original_execute_action_list )( action_list *p_action_list, buffer *frame );
OFDPE ( *original_send_data )( const uint32_t port_no, buffer *send_buffer );

static bool ret_mock_is_device_linkup[] = {true, true, true, true, true};
static int called_mock_is_device_linkup = 0;
static bool
mock_is_device_linkup( const uint32_t port_no ) {
  return ret_mock_is_device_linkup[called_mock_is_device_linkup++];
}

static int called_mock_send_data = 0;
static OFDPE
mock_send_data( const uint32_t port_no, buffer *send_buffer ) {
  called_mock_send_data++;
  return OFDPE_SUCCESS;
}

static int called_mock_execute_action_list = 0;
static OFDPE
mock_execute_action_list( action_list *p_action_list, buffer *frame ) {
  called_mock_execute_action_list++;
  return OFDPE_SUCCESS;
}

static int called_mock_handler_notify_to_controller = 0;
void
mock_handler_notify_to_controller ( void *notify_parameter ) {
  called_mock_handler_notify_to_controller ++;
  return;
}

void
dump(void *data, size_t size) {
    uint8_t* tmp = (uint8_t *)data;
  printf("- %p -------------------\n", tmp);
  for(size_t i = 0; i < size; i++) {
    if(i % 16 == 0) printf("= %p =  ", &tmp[i]);
    printf("%02x ", tmp[i]);
    if(i % 16 == 15) printf("\n");
  }
}

static void
dumpe(void *data) {
  uint8_t* tmp = (uint8_t *)data;
  printf("- ethr %p -------------------\n", tmp);
  printf("%02x:%02x:%02x:%02x:%02x:%02x\n",
          tmp[0], tmp[1], tmp[2], tmp[3], tmp[4], tmp[5]);
}

static void
dumpi4(void *data) {
  uint8_t* tmp = (uint8_t *)data;
  printf("- ipv4 %p -------------------\n", tmp);
  printf("%02x.%02x.%02x.%02x\n", tmp[0], tmp[1], tmp[2], tmp[3]);
}

static void
dumpi6(void *data) {
  uint8_t* tmp = (uint8_t *)data;
  printf("- ipv6 %p -------------------\n", tmp);
  printf("%02x:%02x:%02x:%02x:%02x:%02x:%02x:%02x:"
         "%02x:%02x:%02x:%02x:%02x:%02x:%02x:%02x\n",
          tmp[0], tmp[1], tmp[2], tmp[3], tmp[4], tmp[5], tmp[6], tmp[7],
          tmp[8], tmp[9], tmp[10], tmp[11], tmp[12], tmp[13], tmp[14], tmp[15]);
}

/******************************************************************************
 * static finction extern
 ******************************************************************************/
extern void set_ipv4_checksum(ipv4_header_t *header);
extern void set_ipv4_udp_checksum(ipv4_header_t *ipv4_header, udp_header_t *udp_header, void* payload);
extern void set_ipv6_udp_checksum(ipv6_header_t *ipv6_header, udp_header_t *udp_header, void* payload);
extern void set_ipv4_tcp_checksum(ipv4_header_t *ipv4_header, tcp_header_t *tcp_header, void* payload, size_t payload_length);
extern void set_ipv6_tcp_checksum(ipv6_header_t *ipv6_header, tcp_header_t *tcp_header, void* payload, size_t payload_length);
extern void set_icmpv4_checksum(icmp_header_t *header, size_t length);
extern void set_icmpv6_checksum(ipv6_header_t *ipv6_header, icmp_header_t *icmp_header, size_t length);

extern packet_info* get_packet_info_data( const buffer *frame );
extern void set_address( void *dst, match8 value[], size_t size );
extern void set_dl_address( void *dst, match8 value[] );
extern void set_ipv6_address( void *dst, match8 value[] );

extern bool set_dl_dst( buffer *frame, match8 value[] );
extern bool set_dl_src( buffer *frame, match8 value[]  );
extern bool set_dl_type( buffer *frame, uint16_t value );
extern bool set_vlan_vid( buffer *frame, uint16_t value );
extern bool set_vlan_pcp( buffer *frame, uint8_t value );
extern bool set_nw_dscp( buffer *frame, uint8_t value );
extern bool set_nw_ecn( buffer *frame, uint8_t value );
extern bool set_ip_proto( buffer *frame, uint8_t value );
extern bool set_ipv4_src( buffer *frame, uint32_t value );
extern bool set_ipv4_dst( buffer *frame, uint32_t value );
extern bool set_tcp_src( buffer *frame, uint16_t value );
extern bool set_tcp_dst( buffer *frame, uint16_t value );
extern bool set_udp_src( buffer *frame, uint16_t value );
extern bool set_udp_dst( buffer *frame, uint16_t value );
extern bool set_icmpv4_type( buffer *frame, uint8_t value );
extern bool set_icmpv4_code( buffer *frame, uint8_t value );
extern bool set_arp_op( buffer *frame, uint16_t value );
extern bool set_arp_spa( buffer *frame, uint32_t value );
extern bool set_arp_tpa( buffer *frame, uint32_t value );
extern bool set_arp_sha( buffer *frame, match8 value[] );
extern bool set_arp_tha( buffer *frame, match8 value[] );
extern bool set_ipv6_src( buffer *frame, match8 value[] );
extern bool set_ipv6_dst( buffer *frame, match8 value[] );
extern bool set_ipv6_flabel( buffer *frame, uint32_t value );
extern bool set_icmpv6_type( buffer *frame, uint8_t value );
extern bool set_icmpv6_code( buffer *frame, uint8_t value );
extern bool set_ipv6_nd_target( buffer *frame, match8 value[] );
extern bool set_ipv6_nd_sll( buffer *frame, match8 value[] );
extern bool set_ipv6_nd_tll( buffer *frame, match8 value[] );
extern bool set_mpls_label( buffer *frame, uint32_t value );
extern bool set_mpls_tc( buffer *frame, uint8_t value );
extern bool set_mpls_bos( buffer *frame, uint8_t value );

extern void push_linklayer_tag( buffer *frame, void* head, size_t tag_size );
extern void pop_linklayer_tag( buffer *frame, void* head, size_t tag_size );
extern void push_vlan_tag( buffer *frame, void* head );
extern void pop_vlan_tag( buffer *frame, void* head );
extern void push_mpls_tag( buffer *frame, void* head );
extern void pop_mpls_tag( buffer *frame, void* head );

extern bool decrement_ttl(uint8_t *ttl);

extern bool execute_action_copy_ttl_in( buffer *frame, action *copy_ttl_in );
extern bool execute_action_pop_mpls( buffer *frame, action *pop_mpls );
extern bool execute_action_pop_vlan( buffer *frame, action *pop_vlan );
extern bool execute_action_push_mpls( buffer *frame, action *push_mpls );
extern bool execute_action_push_vlan( buffer *frame, action *push_vlan );
extern bool execute_action_copy_ttl_out( buffer *frame, action *copy_ttl_out );
extern bool execute_action_dec_mpls_ttl( buffer *frame, action *dec_mpls_ttl );
extern bool execute_action_dec_nw_ttl( buffer *frame, action *dec_nw_ttl );
extern bool execute_action_set_mpls_ttl( buffer *frame, action *set_mpls_ttl );
extern bool execute_action_set_nw_ttl( buffer *frame, action *set_nw_ttl );
extern bool execute_action_set_field( buffer *frame, action *set_field );
extern bool execute_action_group( buffer *frame, action *group );
extern bool execute_action_output( buffer *frame, action *output );

extern bool check_backet(action_list *acions);
extern bool execute_group_all(buffer *frame, bucket_list *buckets );
extern bool execute_group_select( buffer *frame, bucket_list *buckets );
extern bool execute_group_indirect( buffer *frame, action_list* actions );

/******************************************************************************
 * Setup and teardown.
 ******************************************************************************/



static void
action_executor_setup() {
	original_die = die;
	die = mock_die;

	original_is_device_linkup = is_device_linkup;
	is_device_linkup = mock_is_device_linkup;

	original_send_data = send_data;
  send_data = mock_send_data;
	init_packet_buffer_pool(1024, 1024 * 9);
	init_controller_manager(10);

	for(size_t i = 0; i < sizeof(ret_mock_is_device_linkup)/sizeof(ret_mock_is_device_linkup[0]); i++) {
	  ret_mock_is_device_linkup[i] = true;
	}
	called_mock_is_device_linkup = 0;
	called_mock_execute_action_list = 0;
	called_mock_send_data = 0;
	called_mock_handler_notify_to_controller = 0;

	init_group_table();
}


static void
action_executor_teardown() {
  die = original_die;
  is_device_linkup = original_is_device_linkup;
  send_data = original_send_data;

  finalize_packet_buffer_pool();
  finalize_controller_manager();
  finalize_group_table();
}


static match8*
get_test_match8(size_t size) {
  match8 * match8 = xmalloc(sizeof(match8) * size);
  for(size_t i = 0; i < size; i++) {
    match8[i].value = i;
    }
  return match8;
}


/******************************************************************************
 * Tests.
 ******************************************************************************/

static void
test_set_ipv4_checksum() {
//set_ipv4_checksum(ipv4_header_t *header)
  buffer *frame = copy_packet_to_buffer("./test_packets/udp.cap");
  parse_packet(frame);
  set_ipv4_checksum(((packet_info *)(frame->user_data))->l3_header);

  free_buffer(frame);
}

static void
test_set_ipv4_udp_checksum() {
  buffer *frame = copy_packet_to_buffer("./test_packets/udp.cap");
  parse_packet(frame);

  set_ipv4_udp_checksum(((packet_info *)(frame->user_data))->l3_header,
                        ((packet_info *)(frame->user_data))->l4_header,
                        ((packet_info *)(frame->user_data))->l4_payload);

  udp_header_t *udp_header = (udp_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t) + sizeof(ipv4_header_t));

  assert_true(htons(0x04a1) == udp_header->csum);

  free_buffer(frame);
}
static void
test_set_ipv6_udp_checksum() {
//set_ipv6_udp_checksum(ipv6_header_t *ipv6_header, udp_header_t *udp_header, void* payload);

  buffer *frame = copy_packet_to_buffer("./test_packets/ipv6_udp2.cap");
  parse_packet(frame);

  set_ipv6_udp_checksum(((packet_info *)(frame->user_data))->l3_header,
                        ((packet_info *)(frame->user_data))->l4_header,
                        ((packet_info *)(frame->user_data))->l4_payload);

  udp_header_t *udp_header = (udp_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t) + sizeof(ipv6_header_t));
  assert_true(htons(0xb759) == udp_header->csum);

  free_buffer(frame);
}


static void
test_set_ipv4_tcp_checksum() {
  buffer *frame = copy_packet_to_buffer("./test_packets/tcp.cap");
  parse_packet(frame);

  set_ipv4_tcp_checksum(((packet_info *)(frame->user_data))->l3_header,
                        ((packet_info *)(frame->user_data))->l4_header,
                        ((packet_info *)(frame->user_data))->l4_payload,
                        ((packet_info *)(frame->user_data))->l4_payload_length);

  tcp_header_t *tcp_header = (tcp_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t) + sizeof(ipv4_header_t));
  assert_true(htons(0xfb05) == tcp_header->csum);

  free_buffer(frame);
}


static void
test_set_ipv6_tcp_checksum() {
  buffer *frame = copy_packet_to_buffer("./test_packets/ipv6_tcp.cap");
  parse_packet(frame);

  set_ipv6_tcp_checksum(((packet_info *)(frame->user_data))->l3_header,
                        ((packet_info *)(frame->user_data))->l4_header,
                        ((packet_info *)(frame->user_data))->l4_payload,
                        ((packet_info *)(frame->user_data))->l4_payload_length);

  tcp_header_t *tcp_header = (tcp_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t) + sizeof(ipv6_header_t));
  assert_true(htons(0x27e4) == tcp_header->csum);

  free_buffer(frame);
}


static void
test_set_icmpv4_checksum() {
//set_icmp_checksum(icmp_header_t *header, size_t length);
  buffer *frame = copy_packet_to_buffer("./test_packets/icmp_echo_rep.cap");
  parse_packet(frame);

  set_icmpv4_checksum(((packet_info *)(frame->user_data))->l4_header ,
                    ((packet_info *)(frame->user_data))->l4_payload_length);

  icmp_header_t *icmp_header = (icmp_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t) + sizeof(ipv4_header_t));
  assert_true(htons(0x46a9) == icmp_header->csum);
  free_buffer(frame);
}


static void
test_set_icmpv6_checksum() {
//set_icmp_checksum(icmp_header_t *header, size_t length);
  buffer *frame = copy_packet_to_buffer("./test_packets/ipv6_icmp.cap");
  parse_packet(frame);

  set_icmpv6_checksum(((packet_info *)(frame->user_data))->l3_header,
                      ((packet_info *)(frame->user_data))->l4_header ,
                      ((packet_info *)(frame->user_data))->l4_payload_length);

  icmp_header_t *icmp_header = (icmp_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t) + sizeof(ipv6_header_t));
  assert_true(htons(0x7bc0) == icmp_header->csum);
  free_buffer(frame);
}


static void
test_get_packet_info_data() {

  buffer *frame = alloc_buffer();
  packet_info *packet = xmalloc(sizeof(packet_info));
  packet_info *ret = NULL;
  frame->user_data = packet;

  ret = get_packet_info_data( frame );
  assert_true(ret == packet);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}


static void
test_set_address() {
  uint8_t dst[10];
  match8 *match = get_test_match8(10);
  for(size_t i = 0; i < sizeof(dst)/sizeof(dst[0]); i++) {
    dst[i] = 99;
    match[i].value = i;
    }

  set_address( &dst[0],  match, 10 );

  for(size_t i = 0; i < sizeof(dst)/sizeof(dst[0]); i++) {
    assert_int_equal(i, dst[i]);
    }

  xfree(match);
}


static void
test_set_dl_address() {
  uint8_t dst[6];
  match8 *match = get_test_match8(6);

  for(size_t i = 0; i < sizeof(dst)/sizeof(dst[0]); i++) {
      dst[i] = 99;
    }

  set_dl_address( &dst[0],  match);

  for(size_t i = 0; i < sizeof(dst)/sizeof(dst[0]); i++) {
    assert_int_equal(i, dst[i]);
    }

  xfree(match);
}


static void
test_set_ipv6_address() {
  uint8_t dst[16];
  match8 *match = get_test_match8(16);

  for(size_t i = 0; i < sizeof(dst)/sizeof(dst[0]); i++) {
      dst[i] = 99;
    }

  set_ipv6_address( &dst[0],  match);

  for(size_t i = 0; i < sizeof(dst)/sizeof(dst[0]); i++) {
    assert_int_equal(i, dst[i]);
    }

  xfree(match);
}


static void
test_set_dl_dst() {
  buffer *frame = copy_packet_to_buffer("./test_packets/icmp_echo_rep.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  match8 *value = get_test_match8(6);

  packet->l2_header = frame->data;
  packet->format = 0;
  frame->user_data = packet;

  assert_true(set_dl_dst( frame, value ));
  assert_int_equal(0x8c, ((ether_header_t*)frame->data)->macda[0]);
  assert_int_equal(0x89, ((ether_header_t*)frame->data)->macda[1]);
  assert_int_equal(0xa5, ((ether_header_t*)frame->data)->macda[2]);
  assert_int_equal(0x16, ((ether_header_t*)frame->data)->macda[3]);
  assert_int_equal(0x22, ((ether_header_t*)frame->data)->macda[4]);
  assert_int_equal(0x09, ((ether_header_t*)frame->data)->macda[5]);

  packet->format = packet->format | ETH_DIX;

  assert_true(set_dl_dst( frame, value ));
  assert_int_equal(0, ((ether_header_t*)frame->data)->macda[0]);
  assert_int_equal(1, ((ether_header_t*)frame->data)->macda[1]);
  assert_int_equal(2, ((ether_header_t*)frame->data)->macda[2]);
  assert_int_equal(3, ((ether_header_t*)frame->data)->macda[3]);
  assert_int_equal(4, ((ether_header_t*)frame->data)->macda[4]);
  assert_int_equal(5, ((ether_header_t*)frame->data)->macda[5]);

  xfree(value);
  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_dl_src() {
  buffer *frame = copy_packet_to_buffer("./test_packets/icmp_echo_rep.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  match8 *value = get_test_match8(6);

  packet->l2_header = frame->data;
  packet->format = 0;
  frame->user_data = packet;

  assert_true(set_dl_src( frame, value ));
  assert_int_equal(0x8c, ((ether_header_t*)frame->data)->macsa[0]);
  assert_int_equal(0x89, ((ether_header_t*)frame->data)->macsa[1]);
  assert_int_equal(0xa5, ((ether_header_t*)frame->data)->macsa[2]);
  assert_int_equal(0x15, ((ether_header_t*)frame->data)->macsa[3]);
  assert_int_equal(0x84, ((ether_header_t*)frame->data)->macsa[4]);
  assert_int_equal(0xcb, ((ether_header_t*)frame->data)->macsa[5]);

  packet->format = packet->format | ETH_DIX;

  assert_true(set_dl_src( frame, value ));
  assert_int_equal(0x00, ((ether_header_t*)frame->data)->macsa[0]);
  assert_int_equal(0x01, ((ether_header_t*)frame->data)->macsa[1]);
  assert_int_equal(0x02, ((ether_header_t*)frame->data)->macsa[2]);
  assert_int_equal(0x03, ((ether_header_t*)frame->data)->macsa[3]);
  assert_int_equal(0x04, ((ether_header_t*)frame->data)->macsa[4]);
  assert_int_equal(0x05, ((ether_header_t*)frame->data)->macsa[5]);

  xfree(value);
  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_dl_type() {
  buffer *frame = copy_packet_to_buffer("./test_packets/icmp_echo_rep.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  uint16_t value = 0x0100;

  packet->l2_header = frame->data;
  packet->format = 0;
  frame->user_data = packet;

  assert_true(set_dl_type( frame, value ));
  assert_int_equal(htons(0x0800), ((ether_header_t*)frame->data)->type);

  packet->format = packet->format | ETH_DIX;

  assert_true(set_dl_type( frame, value ));
  assert_int_equal(htons(0x0100), ((ether_header_t*)frame->data)->type);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_vlan_vid() {
  buffer *frame = copy_packet_to_buffer("./test_packets/vlan_1.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  uint16_t value = 0x0300;

  vlantag_header_t* vlan_header = (vlantag_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t));

  packet->l2_vlan_header = vlan_header;
  vlan_header->tci = 0xFFFF;
  packet->format = 0;
  frame->user_data = packet;


  assert_true(set_vlan_vid( frame, value ));
  assert_int_equal(htons(0xFFFF), vlan_header->tci);

  packet->format = packet->format | ETH_8021Q;

  assert_true(set_vlan_vid( frame, value ));

  assert_int_equal(htons(0xF003), vlan_header->tci);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_vlan_pcp() {
  buffer *frame = copy_packet_to_buffer("./test_packets/vlan_1.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  uint8_t value = 0x00;

  vlantag_header_t* vlan_header = (vlantag_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t));

  packet->l2_vlan_header = vlan_header;
  vlan_header->tci = 0xFFFF;
  packet->format = 0;
  frame->user_data = packet;


  assert_true(set_vlan_pcp( frame, value ));
  assert_int_equal(htons(0xFFFF), vlan_header->tci);

  packet->format = packet->format | ETH_8021Q;

  assert_true(set_vlan_pcp( frame, value ));

  assert_int_equal(htons(0x1fff), vlan_header->tci);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_nw_tos() {
  buffer *frame = copy_packet_to_buffer("./test_packets/udp.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  uint8_t value = 0x01;

  ipv4_header_t* header = (ipv4_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t));

  packet->l3_header = header;
  packet->format = 0;
  frame->user_data = packet;

  assert_true(set_nw_dscp( frame, value ));
  assert_int_equal(0x00, header->tos);

  packet->format = packet->format | NW_IPV4;

  assert_true(set_nw_dscp( frame, value ));
  assert_int_equal(0x04, header->tos);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_nw_ecn() {
  buffer *frame = copy_packet_to_buffer("./test_packets/udp.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  uint8_t value = 0x01;

  ipv4_header_t* header = (ipv4_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t));

  packet->l3_header = header;
  packet->format = 0;
  frame->user_data = packet;

  assert_true(set_nw_ecn( frame, value ));
  assert_int_equal(0x00, header->tos);

  packet->format = packet->format | NW_IPV4;

  assert_true(set_nw_ecn( frame, value ));
  assert_int_equal(0x01, header->tos);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_ip_proto() {
  buffer *frame = copy_packet_to_buffer("./test_packets/udp.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  uint8_t value = 0x01;

  ipv4_header_t* header = (ipv4_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t));

  packet->l3_header = header;
  packet->format = 0;
  frame->user_data = packet;

  assert_true(set_ip_proto( frame, value ));
  assert_int_equal(0x11, header->protocol);

  packet->format = packet->format | NW_IPV4;

  assert_true(set_ip_proto( frame, value ));
  assert_int_equal(0x01, header->protocol);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_ipv4_src() {
  buffer *frame = copy_packet_to_buffer("./test_packets/udp.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  uint32_t value = 0x00000001;

  ipv4_header_t* header = (ipv4_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t));

  packet->l3_header = header;
  packet->format = 0;
  frame->user_data = packet;

  assert_true(set_ipv4_src( frame, value ));
  assert_int_equal(htonl(0x0a3835af), header->saddr);

  packet->format = packet->format | NW_IPV4;

  assert_true(set_ipv4_src( frame, value ));
  assert_int_equal(htonl(0x00000001), header->saddr);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_ipv4_dst() {
  buffer *frame = copy_packet_to_buffer("./test_packets/udp.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  uint32_t value = 0x00000001;

  ipv4_header_t* header = (ipv4_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t));

  packet->l3_header = header;
  packet->format = 0;
  frame->user_data = packet;

  assert_true(set_ipv4_dst( frame, value ));
  assert_int_equal(htonl(0x0a3837ff), header->daddr);

  packet->format = packet->format | NW_IPV4;

  assert_true(set_ipv4_dst( frame, value ));
  assert_int_equal(htonl(0x00000001), header->daddr);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_tcp_src() {
  buffer *frame = copy_packet_to_buffer("./test_packets/tcp.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  uint16_t value = 0x0001;

  tcp_header_t* header = (tcp_header_t *)((uint8_t *)frame->data + (sizeof(ether_header_t) + sizeof(ipv4_header_t)));

  packet->l4_header = header;
  packet->format = 0;
  frame->user_data = packet;

  assert_true(set_tcp_src( frame, value ));
  assert_int_equal(htons(0x0050), header->src_port);

  parse_packet(frame);
  assert_true(set_tcp_src( frame, value ));
  assert_int_equal(htons(0x0001), header->src_port);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_tcp_dst() {
  buffer *frame = copy_packet_to_buffer("./test_packets/tcp.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  uint16_t value = 0x0001;

  tcp_header_t* header = (tcp_header_t *)((uint8_t *)frame->data + (sizeof(ether_header_t) + sizeof(ipv4_header_t)));

  packet->l4_header = header;
  packet->format = 0;
  frame->user_data = packet;

  assert_true(set_tcp_dst( frame, value ));
  assert_int_equal(htons(0xad49), header->dst_port);

  parse_packet(frame);
  assert_true(set_tcp_dst( frame, value ));
  assert_int_equal(htons(0x0001), header->dst_port);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_udp_src() {
  buffer *frame = copy_packet_to_buffer("./test_packets/udp.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  uint16_t value = 0x0001;

  udp_header_t* header = (udp_header_t *)((uint8_t *)frame->data + (sizeof(ether_header_t) + sizeof(ipv4_header_t)));

  packet->l4_header = header;
  packet->format = 0;
  frame->user_data = packet;

  assert_true(set_udp_src( frame, value ));
  assert_int_equal(htons(0xf0b0), header->src_port);

  parse_packet(frame);
  assert_true(set_udp_src( frame, value ));
  assert_int_equal(htons(0x0001), header->src_port);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_udp_dst() {
  buffer *frame = copy_packet_to_buffer("./test_packets/udp.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  uint16_t value = 0x0001;

  udp_header_t* header = (udp_header_t *)((uint8_t *)frame->data + (sizeof(ether_header_t) + sizeof(ipv4_header_t)));

  packet->l4_header = header;
  packet->format = 0;
  frame->user_data = packet;

  assert_true(set_udp_dst( frame, value ));
  assert_int_equal(htons(0x5bcb), header->dst_port);

  parse_packet(frame);
  assert_true(set_udp_dst( frame, value ));
  assert_int_equal(htons(0x0001), header->dst_port);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_icmpv4_type() {
  buffer *frame = copy_packet_to_buffer("./test_packets/icmp_echo_rep.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  uint8_t value = 0x01;

  icmp_header_t* header = (icmp_header_t *)((uint8_t *)frame->data + (sizeof(ether_header_t) + sizeof(ipv4_header_t)));

  packet->l4_header = header;
  packet->format = 0;
  frame->user_data = packet;

  assert_true(set_icmpv4_type( frame, value ));
  assert_int_equal(0x00, header->type);

  parse_packet(frame);
  assert_true(set_icmpv4_type( frame, value ));
  assert_int_equal(0x01, header->type);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_icmpv4_code() {
  buffer *frame = copy_packet_to_buffer("./test_packets/icmp_echo_rep.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  uint8_t value = 0x02;

  icmp_header_t* header = (icmp_header_t *)((uint8_t *)frame->data + (sizeof(ether_header_t) + sizeof(ipv4_header_t)));

  packet->l4_header = header;
  packet->format = 0;
  frame->user_data = packet;

  assert_true(set_icmpv4_code( frame, value ));
  assert_int_equal(0x00, header->code);

  parse_packet(frame);
  assert_true(set_icmpv4_code( frame, value ));
  assert_int_equal(0x02, header->code);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_arp_op() {
  buffer *frame = copy_packet_to_buffer("./test_packets/arp_rep.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  uint16_t value = 0x0001;

  arp_header_t* header = (arp_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t));

  packet->l3_header = header;
  packet->format = 0;
  frame->user_data = packet;

  assert_true(set_arp_op( frame, value ));
  assert_int_equal(htons(0x0002), header->ar_op);

  packet->format = packet->format | NW_ARP;

  assert_true(set_arp_op( frame, value ));
  assert_int_equal(htons(0x0001), header->ar_op);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_arp_spa() {
  buffer *frame = copy_packet_to_buffer("./test_packets/arp_rep.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  uint32_t value = 0x00000001;

  arp_header_t* header = (arp_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t));

  packet->l3_header = header;
  packet->format = 0;
  frame->user_data = packet;

  assert_true(set_arp_spa( frame, value ));
  assert_int_equal(htonl(0xc0a8642b), header->sip);

  packet->format = packet->format | NW_ARP;

  assert_true(set_arp_spa( frame, value ));
  assert_int_equal(htonl(0x00000001), header->sip);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_arp_tpa() {
  buffer *frame = copy_packet_to_buffer("./test_packets/arp_rep.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  uint32_t value = 0x00000001;

  arp_header_t* header = (arp_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t));

  packet->l3_header = header;
  packet->format = 0;
  frame->user_data = packet;

  assert_true(set_arp_tpa( frame, value ));
  assert_int_equal(htonl(0xc0a8642c), header->tip);

  packet->format = packet->format | NW_ARP;

  assert_true(set_arp_tpa( frame, value ));
  assert_int_equal(htonl(0x00000001), header->tip);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_arp_sha() {
  buffer *frame = copy_packet_to_buffer("./test_packets/arp_rep.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  match8 *value = get_test_match8(6);

  arp_header_t* header = (arp_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t));

  packet->l3_header = header;
  packet->format = 0;
  frame->user_data = packet;

  assert_true(set_arp_sha( frame, value ));
  assert_int_equal(0x8c, header->sha[0]);
  assert_int_equal(0x89, header->sha[1]);
  assert_int_equal(0xa5, header->sha[2]);
  assert_int_equal(0x15, header->sha[3]);
  assert_int_equal(0x84, header->sha[4]);
  assert_int_equal(0xcb, header->sha[5]);

  packet->format = packet->format | NW_ARP;

  assert_true(set_arp_sha( frame, value ));
  assert_int_equal(0x00, header->sha[0]);
  assert_int_equal(0x01, header->sha[1]);
  assert_int_equal(0x02, header->sha[2]);
  assert_int_equal(0x03, header->sha[3]);
  assert_int_equal(0x04, header->sha[4]);
  assert_int_equal(0x05, header->sha[5]);

  xfree(value);
  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_arp_tha() {
  buffer *frame = copy_packet_to_buffer("./test_packets/arp_rep.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  match8 *value = get_test_match8(6);

  arp_header_t* header = (arp_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t));

  packet->l3_header = header;
  packet->format = 0;
  frame->user_data = packet;

  assert_true(set_arp_tha( frame, value ));
  assert_int_equal(0x8c, header->tha[0]);
  assert_int_equal(0x89, header->tha[1]);
  assert_int_equal(0xa5, header->tha[2]);
  assert_int_equal(0x16, header->tha[3]);
  assert_int_equal(0x22, header->tha[4]);
  assert_int_equal(0x09, header->tha[5]);

  packet->format = packet->format | NW_ARP;

  assert_true(set_arp_tha( frame, value ));
  assert_int_equal(0x00, header->tha[0]);
  assert_int_equal(0x01, header->tha[1]);
  assert_int_equal(0x02, header->tha[2]);
  assert_int_equal(0x03, header->tha[3]);
  assert_int_equal(0x04, header->tha[4]);
  assert_int_equal(0x05, header->tha[5]);

  xfree(value);
  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_ipv6_src() {
  buffer *frame = copy_packet_to_buffer("./test_packets/ipv6_tcp.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  match8 *value = get_test_match8(16);

  ipv6_header_t* header = (ipv6_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t));

  packet->l3_header = header;
  packet->format = 0;
  frame->user_data = packet;

  assert_true(set_ipv6_src( frame, value ));
  assert_int_equal(0x20, header->saddr[0]);
  assert_int_equal(0x01, header->saddr[1]);
  assert_int_equal(0x00, header->saddr[2]);
  assert_int_equal(0x00, header->saddr[3]);
  assert_int_equal(0x00, header->saddr[4]);
  assert_int_equal(0x00, header->saddr[5]);
  assert_int_equal(0x00, header->saddr[6]);
  assert_int_equal(0x00, header->saddr[7]);
  assert_int_equal(0x00, header->saddr[8]);
  assert_int_equal(0x00, header->saddr[9]);
  assert_int_equal(0x00, header->saddr[10]);
  assert_int_equal(0x00, header->saddr[11]);
  assert_int_equal(0x00, header->saddr[12]);
  assert_int_equal(0x00, header->saddr[13]);
  assert_int_equal(0x00, header->saddr[14]);
  assert_int_equal(0x01, header->saddr[15]);

  packet->format = packet->format | NW_IPV6;

  assert_true(set_ipv6_src( frame, value ));
  assert_int_equal(0x00, header->saddr[0]);
  assert_int_equal(0x01, header->saddr[1]);
  assert_int_equal(0x02, header->saddr[2]);
  assert_int_equal(0x03, header->saddr[3]);
  assert_int_equal(0x04, header->saddr[4]);
  assert_int_equal(0x05, header->saddr[5]);
  assert_int_equal(0x06, header->saddr[6]);
  assert_int_equal(0x07, header->saddr[7]);
  assert_int_equal(0x08, header->saddr[8]);
  assert_int_equal(0x09, header->saddr[9]);
  assert_int_equal(0x0a, header->saddr[10]);
  assert_int_equal(0x0b, header->saddr[11]);
  assert_int_equal(0x0c, header->saddr[12]);
  assert_int_equal(0x0d, header->saddr[13]);
  assert_int_equal(0x0e, header->saddr[14]);
  assert_int_equal(0x0f, header->saddr[15]);

  xfree(value);
  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_ipv6_dst() {
  buffer *frame = copy_packet_to_buffer("./test_packets/ipv6_tcp.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  match8 *value = get_test_match8(16);

  ipv6_header_t* header = (ipv6_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t));

  packet->l3_header = header;
  packet->format = 0;
  frame->user_data = packet;

  assert_true(set_ipv6_dst( frame, value ));
  assert_int_equal(0x20, header->daddr[0]);
  assert_int_equal(0x01, header->daddr[1]);
  assert_int_equal(0x00, header->daddr[2]);
  assert_int_equal(0x00, header->daddr[3]);
  assert_int_equal(0x00, header->daddr[4]);
  assert_int_equal(0x00, header->daddr[5]);
  assert_int_equal(0x00, header->daddr[6]);
  assert_int_equal(0x00, header->daddr[7]);
  assert_int_equal(0x00, header->daddr[8]);
  assert_int_equal(0x00, header->daddr[9]);
  assert_int_equal(0x00, header->daddr[10]);
  assert_int_equal(0x00, header->daddr[11]);
  assert_int_equal(0x00, header->daddr[12]);
  assert_int_equal(0x00, header->daddr[13]);
  assert_int_equal(0x00, header->daddr[14]);
  assert_int_equal(0x02, header->daddr[15]);

  packet->format = packet->format | NW_IPV6;

  assert_true(set_ipv6_dst( frame, value ));
  assert_int_equal(0x00, header->daddr[0]);
  assert_int_equal(0x01, header->daddr[1]);
  assert_int_equal(0x02, header->daddr[2]);
  assert_int_equal(0x03, header->daddr[3]);
  assert_int_equal(0x04, header->daddr[4]);
  assert_int_equal(0x05, header->daddr[5]);
  assert_int_equal(0x06, header->daddr[6]);
  assert_int_equal(0x07, header->daddr[7]);
  assert_int_equal(0x08, header->daddr[8]);
  assert_int_equal(0x09, header->daddr[9]);
  assert_int_equal(0x0a, header->daddr[10]);
  assert_int_equal(0x0b, header->daddr[11]);
  assert_int_equal(0x0c, header->daddr[12]);
  assert_int_equal(0x0d, header->daddr[13]);
  assert_int_equal(0x0e, header->daddr[14]);
  assert_int_equal(0x0f, header->daddr[15]);

  xfree(value);
  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_ipv6_flabel() {
  buffer *frame = copy_packet_to_buffer("./test_packets/ipv6_tcp.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  uint32_t value = 0x00000001;

  ipv6_header_t* header = (ipv6_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t));

  packet->l3_header = header;
  packet->format = 0;
  frame->user_data = packet;

  assert_true(set_ipv6_flabel( frame, value ));
  assert_int_equal(htonl(0x60000000), header->hdrctl);

  packet->format = packet->format | NW_IPV6;

  assert_true(set_ipv6_flabel( frame, value ));
  assert_int_equal(htonl(0x60000001), header->hdrctl);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_icmpv6_type() {
  buffer *frame = copy_packet_to_buffer("./test_packets/ipv6_icmp.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  uint8_t value = 0x01;

  icmp_header_t* header = (icmp_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t) + sizeof(ipv6_header_t));

  packet->l4_header = header;
  packet->format = 0;
  frame->user_data = packet;

  assert_true(set_icmpv6_type( frame, value ));
  assert_int_equal(0x08, header->type);

  parse_packet(frame);
  assert_true(set_icmpv6_type( frame, value ));
  assert_int_equal(0x01, header->type);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_icmpv6_code() {
  buffer *frame = copy_packet_to_buffer("./test_packets/ipv6_icmp.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  uint8_t value = 0x01;

  icmp_header_t* header = (icmp_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t) + sizeof(ipv6_header_t));

  packet->l4_header = header;
  packet->format = 0;
  frame->user_data = packet;

  assert_true(set_icmpv6_code( frame, value ));
  assert_int_equal(0x00, header->code);

  parse_packet(frame);
  assert_true(set_icmpv6_code( frame, value ));
  assert_int_equal(0x01, header->code);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_ipv6_nd_target() {
  buffer *frame = copy_packet_to_buffer("./test_packets/v6_icmp_nd_sll.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  match8 *value = get_test_match8(16);

  icmp_header_t* header = (icmp_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t) + sizeof(ipv6_header_t));

  packet->l3_payload = header;
  packet->format = 0;
  packet->icmpv6_type = 0;
  frame->user_data = packet;

  assert_true(set_ipv6_nd_target( frame, value ));
  uint8_t *ipv6addr = (uint8_t *)header + 8;
  assert_int_equal(0xfe, ipv6addr[0]);
  assert_int_equal(0x80, ipv6addr[1]);
  assert_int_equal(0x00, ipv6addr[2]);
  assert_int_equal(0x00, ipv6addr[3]);
  assert_int_equal(0x00, ipv6addr[4]);
  assert_int_equal(0x00, ipv6addr[5]);
  assert_int_equal(0x00, ipv6addr[6]);
  assert_int_equal(0x00, ipv6addr[7]);
  assert_int_equal(0x02, ipv6addr[8]);
  assert_int_equal(0x60, ipv6addr[9]);
  assert_int_equal(0x97, ipv6addr[10]);
  assert_int_equal(0xff, ipv6addr[11]);
  assert_int_equal(0xfe, ipv6addr[12]);
  assert_int_equal(0x07, ipv6addr[13]);
  assert_int_equal(0x69, ipv6addr[14]);
  assert_int_equal(0xea, ipv6addr[15]);

  packet->format = packet->format | NW_ICMPV6;
  packet->icmpv6_type = 0;

  assert_true(set_ipv6_nd_target( frame, value ));
  assert_int_equal(0xfe, ipv6addr[0]);
  assert_int_equal(0x80, ipv6addr[1]);
  assert_int_equal(0x00, ipv6addr[2]);
  assert_int_equal(0x00, ipv6addr[3]);
  assert_int_equal(0x00, ipv6addr[4]);
  assert_int_equal(0x00, ipv6addr[5]);
  assert_int_equal(0x00, ipv6addr[6]);
  assert_int_equal(0x00, ipv6addr[7]);
  assert_int_equal(0x02, ipv6addr[8]);
  assert_int_equal(0x60, ipv6addr[9]);
  assert_int_equal(0x97, ipv6addr[10]);
  assert_int_equal(0xff, ipv6addr[11]);
  assert_int_equal(0xfe, ipv6addr[12]);
  assert_int_equal(0x07, ipv6addr[13]);
  assert_int_equal(0x69, ipv6addr[14]);
  assert_int_equal(0xea, ipv6addr[15]);

  packet->format = packet->format | NW_ICMPV6;
  packet->icmpv6_type = ICMPV6_TYPE_NEIGHBOR_SOLICITATION;

  assert_true(set_ipv6_nd_target( frame, value ));
  assert_int_equal(0x00, ipv6addr[0]);
  assert_int_equal(0x01, ipv6addr[1]);
  assert_int_equal(0x02, ipv6addr[2]);
  assert_int_equal(0x03, ipv6addr[3]);
  assert_int_equal(0x04, ipv6addr[4]);
  assert_int_equal(0x05, ipv6addr[5]);
  assert_int_equal(0x06, ipv6addr[6]);
  assert_int_equal(0x07, ipv6addr[7]);
  assert_int_equal(0x08, ipv6addr[8]);
  assert_int_equal(0x09, ipv6addr[9]);
  assert_int_equal(0x0a, ipv6addr[10]);
  assert_int_equal(0x0b, ipv6addr[11]);
  assert_int_equal(0x0c, ipv6addr[12]);
  assert_int_equal(0x0d, ipv6addr[13]);
  assert_int_equal(0x0e, ipv6addr[14]);
  assert_int_equal(0x0f, ipv6addr[15]);

  xfree(value);
  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_ipv6_nd_sll() {
  buffer *frame = copy_packet_to_buffer("./test_packets/v6_icmp_nd_sll.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  match8 *value = get_test_match8(6);

  icmp_header_t* header = (icmp_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t) + sizeof(ipv6_header_t));

  packet->l3_payload = header;
  packet->format = 0;
  packet->icmpv6_type = 0;
  frame->user_data = packet;

  assert_true(set_ipv6_nd_sll( frame, value ));
  uint8_t *link_layer_address = (uint8_t *)header + 26;
  assert_int_equal(0x00, link_layer_address[0]);
  assert_int_equal(0x00, link_layer_address[1]);
  assert_int_equal(0x86, link_layer_address[2]);
  assert_int_equal(0x05, link_layer_address[3]);
  assert_int_equal(0x80, link_layer_address[4]);
  assert_int_equal(0xda, link_layer_address[5]);

  packet->format = packet->format | NW_ICMPV6;
  packet->icmpv6_type = 0;

  assert_true(set_ipv6_nd_sll( frame, value ));
  assert_int_equal(0x00, link_layer_address[0]);
  assert_int_equal(0x00, link_layer_address[1]);
  assert_int_equal(0x86, link_layer_address[2]);
  assert_int_equal(0x05, link_layer_address[3]);
  assert_int_equal(0x80, link_layer_address[4]);
  assert_int_equal(0xda, link_layer_address[5]);

  packet->format = packet->format | NW_ICMPV6;
  packet->icmpv6_type = ICMPV6_TYPE_NEIGHBOR_SOLICITATION;

  assert_true(set_ipv6_nd_sll( frame, value ));
  assert_int_equal(0x00, link_layer_address[0]);
  assert_int_equal(0x01, link_layer_address[1]);
  assert_int_equal(0x02, link_layer_address[2]);
  assert_int_equal(0x03, link_layer_address[3]);
  assert_int_equal(0x04, link_layer_address[4]);
  assert_int_equal(0x05, link_layer_address[5]);

  xfree(value);
  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_ipv6_nd_tll() {
  buffer *frame = copy_packet_to_buffer("./test_packets/v6_icmp_nd_tll2.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  match8 *value = get_test_match8(6);

  icmp_header_t* header = (icmp_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t) + sizeof(ipv6_header_t));

  packet->l3_payload = header;
  packet->format = 0;
  packet->icmpv6_type = 0;
  frame->user_data = packet;

  assert_true(set_ipv6_nd_tll( frame, value ));
  uint8_t *link_layer_address = (uint8_t *)header + 26;
  assert_int_equal(0x00, link_layer_address[0]);
  assert_int_equal(0x00, link_layer_address[1]);
  assert_int_equal(0x86, link_layer_address[2]);
  assert_int_equal(0x05, link_layer_address[3]);
  assert_int_equal(0x80, link_layer_address[4]);
  assert_int_equal(0xda, link_layer_address[5]);

  packet->format = packet->format | NW_ICMPV6;
  packet->icmpv6_type = 0;

  assert_true(set_ipv6_nd_tll( frame, value ));
  assert_int_equal(0x00, link_layer_address[0]);
  assert_int_equal(0x00, link_layer_address[1]);
  assert_int_equal(0x86, link_layer_address[2]);
  assert_int_equal(0x05, link_layer_address[3]);
  assert_int_equal(0x80, link_layer_address[4]);
  assert_int_equal(0xda, link_layer_address[5]);

  packet->format = packet->format | NW_ICMPV6;
  packet->icmpv6_type = ICMPV6_TYPE_NEIGHBOR_ADVERTISEMENT;

  assert_true(set_ipv6_nd_tll( frame, value ));
  assert_int_equal(0x00, link_layer_address[0]);
  assert_int_equal(0x01, link_layer_address[1]);
  assert_int_equal(0x02, link_layer_address[2]);
  assert_int_equal(0x03, link_layer_address[3]);
  assert_int_equal(0x04, link_layer_address[4]);
  assert_int_equal(0x05, link_layer_address[5]);

  xfree(value);
  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_mpls_label() {
  buffer *frame = copy_packet_to_buffer("./test_packets/mpls_8847.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  uint32_t value = 0x01;

  uint32_t* header = (uint32_t *)((uint8_t *)frame->data + sizeof(ether_header_t));
  *header = 0xffffffff;

  packet->l2_mpls_header = header;
  packet->format = 0;
  frame->user_data = packet;

  assert_true(set_mpls_label( frame, value ));
  uint8_t *label = (uint8_t *)header;
  assert_int_equal(0xff, label[0]);
  assert_int_equal(0xff, label[1]);
  assert_int_equal(0xff, label[2]);
  assert_int_equal(0xff, label[3]);

  packet->format = packet->format | ETH_MPLS;

  assert_true(set_mpls_label( frame, value ));
  assert_int_equal(0x00, label[0]);
  assert_int_equal(0x00, label[1]);
  assert_int_equal(0x1f, label[2]);
  assert_int_equal(0xff, label[3]);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_mpls_tc() {
  buffer *frame = copy_packet_to_buffer("./test_packets/mpls_8847.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  uint8_t value = 0x01;

  uint32_t* header = (uint32_t *)((uint8_t *)frame->data + sizeof(ether_header_t));
  *header = 0xFFFFFFFF;

  packet->l2_mpls_header = header;
  packet->format = 0;
  frame->user_data = packet;

  assert_true(set_mpls_tc( frame, value ));
  uint8_t *label = (uint8_t *)header;
  assert_int_equal(0xff, label[0]);
  assert_int_equal(0xff, label[1]);
  assert_int_equal(0xff, label[2]);
  assert_int_equal(0xff, label[3]);

  packet->format = packet->format | ETH_MPLS;

  assert_true(set_mpls_tc( frame, value ));
  assert_int_equal(0xff, label[0]);
  assert_int_equal(0xff, label[1]);
  assert_int_equal(0xf3, label[2]);
  assert_int_equal(0xff, label[3]);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_set_mpls_bos() {
  buffer *frame = copy_packet_to_buffer("./test_packets/mpls_8847.cap");
  packet_info *packet = xcalloc(1, sizeof(packet_info));
  uint8_t value = 0x01;

  uint32_t* header = (uint32_t *)((uint8_t *)frame->data + sizeof(ether_header_t));
  *header = 0x00000000;

  packet->l2_mpls_header = header;
  packet->format = 0;
  frame->user_data = packet;

  assert_true(set_mpls_bos( frame, value ));
  uint8_t *label = (uint8_t *)header;
  assert_int_equal(0x00, label[0]);
  assert_int_equal(0x00, label[1]);
  assert_int_equal(0x00, label[2]);
  assert_int_equal(0x00, label[3]);

  packet->format = packet->format | ETH_MPLS;

  assert_true(set_mpls_bos( frame, value ));
  assert_int_equal(0x00, label[0]);
  assert_int_equal(0x00, label[1]);
  assert_int_equal(0x01, label[2]);
  assert_int_equal(0x00, label[3]);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}


static void
test_push_linklayer_tag() {
  size_t tag_size = 8;
  buffer *frame = alloc_buffer_with_length(64);
  frame->length = sizeof(ether_header_t);
  memset(frame->data, 0xff, 64);
  uint8_t *data = (uint8_t *)frame->data + sizeof(ether_header_t);

  push_linklayer_tag( frame, data, tag_size );

  assert_int_equal(sizeof(ether_header_t) + tag_size, frame->length);
  assert_int_equal(0, data[0]);
  assert_int_equal(0, data[1]);
  assert_int_equal(0, data[2]);
  assert_int_equal(0, data[3]);
  assert_int_equal(0, data[4]);
  assert_int_equal(0, data[5]);
  assert_int_equal(0, data[6]);
  assert_int_equal(0, data[7]);

  free_buffer(frame);
}

static void
test_pop_linklayer_tag() {
  size_t tag_size = 8;
  buffer *frame = alloc_buffer_with_length(64);
  frame->length = sizeof(ether_header_t) + tag_size + tag_size;
  memset(frame->data, 0xff, 64);
  memset((uint8_t *)frame->data + sizeof(ether_header_t), 0x00, tag_size);

  pop_linklayer_tag( frame, (uint8_t *)frame->data + sizeof(ether_header_t), tag_size );

  assert_int_equal(sizeof(ether_header_t) + tag_size, frame->length);

  uint8_t *data = (uint8_t *)frame->data + sizeof(ether_header_t);
  assert_int_equal(0xff, data[0]);
  assert_int_equal(0xff, data[1]);
  assert_int_equal(0xff, data[2]);
  assert_int_equal(0xff, data[3]);
  assert_int_equal(0xff, data[4]);
  assert_int_equal(0xff, data[5]);
  assert_int_equal(0xff, data[6]);
  assert_int_equal(0xff, data[7]);

  free_buffer(frame);
}

static void
test_push_vlan_tag() {
  buffer *frame = alloc_buffer_with_length(64);
  frame->length = sizeof(ether_header_t);
  memset(frame->data, 0xff, 64);
  uint8_t *data = (uint8_t *)frame->data + sizeof(ether_header_t);

  push_vlan_tag( frame, data );

  assert_int_equal(sizeof(ether_header_t) + sizeof(vlantag_header_t), frame->length);
  for(size_t i = 0; i < sizeof(vlantag_header_t); i++) {
    assert_int_equal(0x00, data[i]);
    }

  free_buffer(frame);
}

static void
test_pop_vlan_tag() {
  buffer *frame = alloc_buffer_with_length(64);
  frame->length = sizeof(ether_header_t) + sizeof(vlantag_header_t) + 1;
  memset(frame->data, 0xff, 64);
  memset((uint8_t *)frame->data + sizeof(ether_header_t), 0x00, sizeof(vlantag_header_t));
  uint8_t *data = (uint8_t *)frame->data + sizeof(ether_header_t);

  pop_vlan_tag( frame, data );

  assert_int_equal(sizeof(ether_header_t) + 1, frame->length);
  assert_int_equal(0xff, data[0]);
  assert_int_equal(0x00, data[1]);

  free_buffer(frame);
}

static void
test_push_mpls_tag() {
  buffer *frame = copy_packet_to_buffer("./test_packets/tcp.cap");
  frame->length = sizeof(ether_header_t);
  memset(frame->data, 0xff, 64);
  uint8_t *data = (uint8_t *)frame->data + sizeof(ether_header_t);

  push_mpls_tag( frame, data );

  assert_int_equal(sizeof(ether_header_t) + sizeof(uint32_t), frame->length);
  for(size_t i = 0; i < sizeof(uint32_t); i++) {
    assert_int_equal(0x00, data[i]);
    }

  free_buffer(frame);
}

static void
test_pop_mpls_tag() {
  buffer *frame = alloc_buffer_with_length(64);
  frame->length = sizeof(ether_header_t) + sizeof(uint32_t) + 1;
  memset(frame->data, 0xff, 64);
  memset((uint8_t *)frame->data + sizeof(ether_header_t), 0x00, sizeof(uint32_t));
  uint8_t *data = (uint8_t *)frame->data + sizeof(ether_header_t);

  pop_mpls_tag( frame, data );
  assert_int_equal(sizeof(ether_header_t) + 1, frame->length);
  assert_int_equal(0xff, data[0]);
  assert_int_equal(0x00, data[1]);

  free_buffer(frame);
}


static void
test_decrement_ttl() {

  uint8_t ttl = 1;
  assert_true(decrement_ttl(&ttl));
  assert_int_equal(0, ttl);
  assert_false(decrement_ttl(&ttl));
  assert_int_equal(0, ttl);
}


static void
test_execute_action_copy_ttl_in() {
  buffer *frame = copy_packet_to_buffer("./test_packets/mpls_8847.cap");
  ipv4_header_t *ipv4_header = (ipv4_header_t *)(((uint8_t *)frame->data) + sizeof(ether_header_t) + sizeof(uint32_t));
  ipv4_header->ttl = 0x01;

  packet_info *packet = xcalloc(1, sizeof(packet_info));
  packet->format = 0;
  frame->user_data = packet;
  action copy_ttl_in;

//  packet->format = packet->format;
  assert_true(execute_action_copy_ttl_in( frame, &copy_ttl_in ));
  assert_true(0x01 == ipv4_header->ttl);

  packet->format = packet->format | ETH_MPLS;
  assert_true(execute_action_copy_ttl_in( frame, &copy_ttl_in ));
  assert_true(0x01 == ipv4_header->ttl);

  parse_packet(frame);

  assert_true(execute_action_copy_ttl_in( frame, &copy_ttl_in ));
  assert_true(0xff == ipv4_header->ttl);

  xfree(packet);
  free_buffer(frame);
}


static void
test_execute_action_pop_mpls() {
  buffer *frame = alloc_buffer_with_length(64);
  frame->length = sizeof(ether_header_t) + sizeof(uint32_t) + 1;
  memset(frame->data, 0xff, 64);
  memset((uint8_t *)frame->data + sizeof(ether_header_t), 0x00, sizeof(uint32_t));

  packet_info *packet = xcalloc(1, sizeof(packet_info));
  packet->format = 0;
  packet->l2_mpls_header = (uint8_t *)frame->data + sizeof(ether_header_t);
  frame->user_data = packet;

  action action;

  assert_true(execute_action_pop_mpls( frame, &action ));
  uint8_t *data = (uint8_t *)frame->data + sizeof(ether_header_t);
  assert_int_equal(0x00, data[0]);
  assert_int_equal(0x00, data[1]);

  packet->format = packet->format | ETH_MPLS;
  assert_true(execute_action_pop_mpls( frame, &action ));
  assert_int_equal(0xff, data[0]);
  assert_int_equal(0x00, data[1]);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}


static void
test_execute_action_pop_vlan() {
  buffer *frame = alloc_buffer_with_length(64);
  frame->length = sizeof(ether_header_t) + sizeof(vlantag_header_t) + 1;
  memset(frame->data, 0xff, 64);
  memset((uint8_t *)frame->data + sizeof(ether_header_t), 0x00, sizeof(vlantag_header_t));

  packet_info *packet = xcalloc(1, sizeof(packet_info));
  packet->l2_vlan_header = (uint8_t *)frame->data + sizeof(ether_header_t);
  packet->format = 0;
  frame->user_data = packet;

  action action;

  assert_true(execute_action_pop_vlan( frame, &action ));
  uint8_t *data = (uint8_t *)frame->data + sizeof(ether_header_t);
  assert_int_equal(0x00, data[0]);
  assert_int_equal(0x00, data[1]);

  packet->format = packet->format | ETH_8021Q;
  assert_true(execute_action_pop_vlan( frame, &action ));
  assert_int_equal(0xff, data[0]);
  assert_int_equal(0x00, data[1]);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}


static void
test_execute_action_push_mpls() {
  buffer *frame = copy_packet_to_buffer("./test_packets/udp.cap");

  packet_info *packet = xcalloc(1, sizeof(packet_info));
  packet->format = 0;
  packet->l2_mpls_header = (uint8_t *)frame->data + sizeof(ether_header_t);
  frame->user_data = packet;

  action action;

  packet->format = packet->format | ETH_MPLS;
  assert_true(execute_action_push_mpls( frame, &action ));

  uint32_t *mpls = (uint32_t *)(((uint8_t *)frame->data) + sizeof(ether_header_t));
  assert_true(*mpls == htonl(0x00000100));

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}


static void
test_execute_action_push_vlan() {
  buffer *frame = copy_packet_to_buffer("./test_packets/udp.cap");

  packet_info *packet = xcalloc(1, sizeof(packet_info));
  packet->format = 0;
  packet->l2_vlan_header = (uint8_t *)frame->data + sizeof(ether_header_t);
  frame->user_data = packet;

  action action;

  packet->format = packet->format | ETH_8021Q;
  assert_true(execute_action_push_vlan( frame, &action ));
  vlantag_header_t *vlan_header = (vlantag_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t));
  assert_true(vlan_header->tci == 0);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}


static void
test_execute_action_copy_ttl_out() {
  buffer *frame = copy_packet_to_buffer("./test_packets/mpls_8847.cap");
  ipv4_header_t *ipv4_header = (ipv4_header_t *)(((uint8_t *)frame->data) + sizeof(ether_header_t) + sizeof(uint32_t));
  ipv4_header->ttl = 0x01;

  packet_info *packet = xcalloc(1, sizeof(packet_info));
  packet->format = 0;
  frame->user_data = packet;
  action copy_ttl_in;

//  packet->format = packet->format;
  assert_true(execute_action_copy_ttl_out( frame, &copy_ttl_in ));
  assert_true(0x01 == ipv4_header->ttl);

  packet->format = packet->format | ETH_MPLS;
  assert_true(execute_action_copy_ttl_out( frame, &copy_ttl_in ));
  assert_true(0x01 == ipv4_header->ttl);

  parse_packet(frame);

  assert_true(execute_action_copy_ttl_out( frame, &copy_ttl_in ));
  uint8_t *mpls_ttl = (((uint8_t *)frame->data) + sizeof(ether_header_t)  + 3);
  assert_true(0x01 == *mpls_ttl);

  xfree(packet);
  free_buffer(frame);
}


static void
test_execute_action_dec_mpls_ttl() {
  buffer *frame = alloc_buffer_with_length(64);
  frame->length = sizeof(ether_header_t);
  memset(frame->data, 0xff, 64);

  packet_info *packet = xcalloc(1, sizeof(packet_info));
  packet->format = 0;
  packet->l2_mpls_header = (uint8_t *)frame->data + sizeof(ether_header_t);
  frame->user_data = packet;

  action action;
  flow_entry entry;
  action.entry = &entry;
  match match;
  entry.p_match = &match;

  assert_true(execute_action_dec_mpls_ttl( frame, &action ));
  uint8_t *ttl = (uint8_t *)frame->data + sizeof(ether_header_t) + 3;
  assert_true(0xff == *ttl);

  packet->format = packet->format | ETH_MPLS;
  assert_true(execute_action_dec_mpls_ttl( frame, &action ));
  assert_true(0xfe == *ttl);

  register_notify_handler_to_controller(NOTIFY_TYPE_PACKET_IN ,mock_handler_notify_to_controller);
  *ttl = 0;
  packet->format = packet->format | ETH_MPLS;
  packet->l2_mpls_header = (uint8_t *)frame->data + sizeof(ether_header_t);
  assert_true(execute_action_dec_mpls_ttl( frame, &action ));
  assert_true(1 == called_mock_handler_notify_to_controller);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}


static void
test_execute_action_dec_nw_ttl_ipv4() {
  buffer *frame = alloc_buffer_with_length(64);
  frame->length = sizeof(ether_header_t);
  memset(frame->data, 0xff, 64);

  packet_info *packet = xcalloc(1, sizeof(packet_info));
  packet->format = 0;
  packet->l3_header = (uint8_t *)frame->data + sizeof(ether_header_t);
  frame->user_data = packet;

  action action;
  flow_entry entry;
  action.entry = &entry;
  match match;
  entry.p_match = &match;

  assert_true(execute_action_dec_nw_ttl( frame, &action ));
  ipv4_header_t *v4header = (ipv4_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t));
  assert_true(0xff == v4header->ttl);

  packet->format = packet->format | NW_IPV4;
  assert_true(execute_action_dec_nw_ttl( frame, &action ));
  assert_true(0xfe == v4header->ttl);

  register_notify_handler_to_controller(NOTIFY_TYPE_PACKET_IN ,mock_handler_notify_to_controller);
  v4header->ttl = 0;
  packet->format = packet->format | NW_IPV4;
  packet->l3_header = (uint8_t *)frame->data + sizeof(ether_header_t);
  assert_true(execute_action_dec_nw_ttl( frame, &action ));
  assert_true(1 == called_mock_handler_notify_to_controller);
  assert_true(0x0 == v4header->ttl);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_execute_action_dec_nw_ttl_ipv6() {
  buffer *frame = alloc_buffer_with_length(64);
  frame->length = sizeof(ether_header_t);
  memset(frame->data, 0xff, 64);

  packet_info *packet = xcalloc(1, sizeof(packet_info));
  packet->format = 0;
  packet->l3_header = (uint8_t *)frame->data + sizeof(ether_header_t);
  frame->user_data = packet;

  action action;
  flow_entry entry;
  action.entry = &entry;
  match match;
  entry.p_match = &match;

  assert_true(execute_action_dec_nw_ttl( frame, &action ));
  ipv6_header_t *v6header = (ipv6_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t));
  assert_true(0xff == v6header->hoplimit);

  packet->format =  NW_IPV6;
  assert_true(execute_action_dec_nw_ttl( frame, &action ));
  assert_true(0xfe == v6header->hoplimit);

  register_notify_handler_to_controller(NOTIFY_TYPE_PACKET_IN ,mock_handler_notify_to_controller);
  v6header->hoplimit = 0;
  packet->format = packet->format | NW_IPV6;
  packet->l3_header = (uint8_t *)frame->data + sizeof(ether_header_t);
  assert_true(execute_action_dec_nw_ttl( frame, &action ));
  assert_true(1 == called_mock_handler_notify_to_controller);
  assert_true(0x0 == v6header->hoplimit);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}


static void
test_execute_action_set_mpls_ttl() {
  buffer *frame = alloc_buffer_with_length(64);
  frame->length = sizeof(ether_header_t);
  memset(frame->data, 0xff, 64);

  packet_info *packet = xcalloc(1, sizeof(packet_info));
  packet->format = 0;
  packet->l2_mpls_header = (uint8_t *)frame->data + sizeof(ether_header_t);
  frame->user_data = packet;

  action action;
  action.mpls_ttl = 1;

  assert_true(execute_action_set_mpls_ttl( frame, &action ));
  uint8_t *ttl = (uint8_t *)frame->data + sizeof(ether_header_t) + 3;
  assert_true(0xff == *ttl);

  packet->format = packet->format | ETH_MPLS;
  assert_true(execute_action_set_mpls_ttl( frame, &action ));
  assert_true(0x01 == *ttl);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}


static void
test_execute_action_set_nw_ttl_ipv4() {
  buffer *frame = alloc_buffer_with_length(64);
  frame->length = sizeof(ether_header_t);
  memset(frame->data, 0xff, 64);

  packet_info *packet = xcalloc(1, sizeof(packet_info));
  packet->format = 0;
  packet->l3_header = (uint8_t *)frame->data + sizeof(ether_header_t);
  frame->user_data = packet;

  action action;
  action.nw_ttl = 1;

  assert_true(execute_action_set_nw_ttl( frame, &action ));
  ipv4_header_t *v4header = (ipv4_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t));
  assert_true(0xff == v4header->ttl);

  packet->format = packet->format | NW_IPV4;
  assert_true(execute_action_set_nw_ttl( frame, &action ));
  assert_true(0x01 == v4header->ttl);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}

static void
test_execute_action_set_nw_ttl_ipv6() {
  buffer *frame = alloc_buffer_with_length(64);
  frame->length = sizeof(ether_header_t);
  memset(frame->data, 0xff, 64);

  packet_info *packet = xcalloc(1, sizeof(packet_info));
  packet->format = 0;
  packet->l3_header = (uint8_t *)frame->data + sizeof(ether_header_t);
  frame->user_data = packet;

  action action;
  action.nw_ttl = 1;

  assert_true(execute_action_set_nw_ttl( frame, &action ));
  ipv6_header_t *v6header = (ipv6_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t));
  assert_true(0xff == v6header->hoplimit);

  packet->format =  NW_IPV6;
  assert_true(execute_action_set_nw_ttl( frame, &action ));
  assert_true(0x01 == v6header->hoplimit);

  frame->user_data = NULL;
  xfree(packet);
  free_buffer(frame);
}


static void
test_execute_action_set_field_ether() {
  buffer *frame = copy_packet_to_buffer("./test_packets/arp_rep.cap");
  parse_packet(frame);

  match *match = init_match();
  action *action = create_action_set_field(match);

  match->eth_type.valid = true;
  match->eth_type.value = 1;

  match->eth_src[0].valid = true;
  match->eth_src[0].value = 0x00;
  match->eth_src[1].value = 0x01;
  match->eth_src[2].value = 0x02;
  match->eth_src[3].value = 0x03;
  match->eth_src[4].value = 0x04;
  match->eth_src[5].value = 0x05;

  match->eth_dst[0].valid = true;
  match->eth_dst[0].value = 0x06;
  match->eth_dst[1].value = 0x07;
  match->eth_dst[2].value = 0x08;
  match->eth_dst[3].value = 0x09;
  match->eth_dst[4].value = 0x0a;
  match->eth_dst[5].value = 0x0b;

  assert_true(execute_action_set_field(frame, action));

  ether_header_t *ether = (ether_header_t *)frame->data;

  assert_true(ether->type == htons(0x0001));
  assert_true(ether->macsa[0] == 0x00);
  assert_true(ether->macsa[1] == 0x01);
  assert_true(ether->macsa[2] == 0x02);
  assert_true(ether->macsa[3] == 0x03);
  assert_true(ether->macsa[4] == 0x04);
  assert_true(ether->macsa[5] == 0x05);
  assert_true(ether->macda[0] == 0x06);
  assert_true(ether->macda[1] == 0x07);
  assert_true(ether->macda[2] == 0x08);
  assert_true(ether->macda[3] == 0x09);
  assert_true(ether->macda[4] == 0x0a);
  assert_true(ether->macda[5] == 0x0b);

  xfree(frame->user_data);
  frame->user_data = NULL;
  free_buffer(frame);
  delete_action(&action);
}


static void
test_execute_action_set_field_arp() {
  buffer *frame = copy_packet_to_buffer("./test_packets/arp_rep.cap");
  parse_packet(frame);

  match *match = init_match();
  action *action = create_action_set_field(match);

  assert_true(execute_action_set_field(frame, action));

  match->arp_op.valid = true;
  match->arp_op.value = 1;

  match->arp_sha[0].valid = true;
  match->arp_sha[0].value = 0x00;
  match->arp_sha[1].value = 0x01;
  match->arp_sha[2].value = 0x02;
  match->arp_sha[3].value = 0x03;
  match->arp_sha[4].value = 0x04;
  match->arp_sha[5].value = 0x05;

  match->arp_tha[0].valid = true;
  match->arp_tha[0].value = 0x06;
  match->arp_tha[1].value = 0x07;
  match->arp_tha[2].value = 0x08;
  match->arp_tha[3].value = 0x09;
  match->arp_tha[4].value = 0x0a;
  match->arp_tha[5].value = 0x0b;

  match->arp_spa.valid = true;
  match->arp_spa.value = 0x11121314;

  match->arp_tpa.valid = true;
  match->arp_tpa.value = 0x15161718;

  assert_true(execute_action_set_field(frame, action));

  arp_header_t *arp = (arp_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t));

  assert_true(arp->ar_op == htons(0x0001));
  assert_true(arp->sha[0] == 0x00);
  assert_true(arp->sha[1] == 0x01);
  assert_true(arp->sha[2] == 0x02);
  assert_true(arp->sha[3] == 0x03);
  assert_true(arp->sha[4] == 0x04);
  assert_true(arp->sha[5] == 0x05);
  assert_true(arp->tha[0] == 0x06);
  assert_true(arp->tha[1] == 0x07);
  assert_true(arp->tha[2] == 0x08);
  assert_true(arp->tha[3] == 0x09);
  assert_true(arp->tha[4] == 0x0a);
  assert_true(arp->tha[5] == 0x0b);
  assert_true(arp->sip == htonl(0x11121314));
  assert_true(arp->tip == htonl(0x15161718));

  xfree(frame->user_data);
  frame->user_data = NULL;
  free_buffer(frame);
  delete_action(&action);
}

static void
test_execute_action_set_field_vlan() {
  buffer *frame = copy_packet_to_buffer("./test_packets/vlan_1.cap");
  parse_packet(frame);

  match *match = init_match();
  action *action = create_action_set_field(match);

  match->vlan_pcp.valid = true;
  match->vlan_pcp.value = 1;
  match->vlan_vid.valid = true;
  match->vlan_vid.value = 7;

  assert_true(execute_action_set_field(frame, action));

  vlantag_header_t *vlan = (vlantag_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t));
  assert_true(vlan->tci == htons(0x2700));

  xfree(frame->user_data);
  frame->user_data = NULL;
  free_buffer(frame);
  delete_action(&action);
}


static void
test_execute_action_set_field_ipv4() {
  buffer *frame = copy_packet_to_buffer("./test_packets/icmp_echo_rep.cap");
  parse_packet(frame);

  match *match = init_match();
  action *action = create_action_set_field(match);

  match->ip_dscp.valid = true;
  match->ip_dscp.value = 1;
  match->ip_ecn.valid = true;
  match->ip_ecn.value = 2;
  match->ip_proto.valid = true;
  match->ip_proto.value = 3;
  match->ipv4_dst.valid = true;
  match->ipv4_dst.value = 0x01020304;
  match->ipv4_src.valid = true;
  match->ipv4_src.value = 0x05060708;

  assert_true(execute_action_set_field(frame, action));

  ipv4_header_t *ipv4 = (ipv4_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t));
  assert_true(ipv4->tos == 0x06);
  assert_true(ipv4->protocol == 0x03);
  assert_true(ipv4->daddr == htonl(0x01020304));
  assert_true(ipv4->saddr == htonl(0x05060708));


  xfree(frame->user_data);
  frame->user_data = NULL;
  free_buffer(frame);
  delete_action(&action);
}


static void
test_execute_action_set_field_ipv6() {
  buffer *frame = copy_packet_to_buffer("./test_packets/ipv6_icmp.cap");
  parse_packet(frame);

  match *match = init_match();
  action *action = create_action_set_field(match);

  match->ipv6_flabel.valid = true;
  match->ipv6_flabel.value = 0x01020304;
  match->ipv6_dst[0].valid = true;
  match->ipv6_dst[0].value = 0x00;
  match->ipv6_dst[1].value = 0x01;
  match->ipv6_dst[2].value = 0x02;
  match->ipv6_dst[3].value = 0x03;
  match->ipv6_dst[4].value = 0x04;
  match->ipv6_dst[5].value = 0x05;
  match->ipv6_dst[6].value = 0x06;
  match->ipv6_dst[7].value = 0x07;
  match->ipv6_dst[8].value = 0x08;
  match->ipv6_dst[9].value = 0x09;
  match->ipv6_dst[10].value = 0x0a;
  match->ipv6_dst[11].value = 0x0b;
  match->ipv6_dst[12].value = 0x0c;
  match->ipv6_dst[13].value = 0x0d;
  match->ipv6_dst[14].value = 0x0e;
  match->ipv6_dst[15].value = 0x0f;
  match->ipv6_src[0].valid = true;
  match->ipv6_src[0].value = 0x10;
  match->ipv6_src[1].value = 0x11;
  match->ipv6_src[2].value = 0x12;
  match->ipv6_src[3].value = 0x13;
  match->ipv6_src[4].value = 0x14;
  match->ipv6_src[5].value = 0x15;
  match->ipv6_src[6].value = 0x16;
  match->ipv6_src[7].value = 0x17;
  match->ipv6_src[8].value = 0x18;
  match->ipv6_src[9].value = 0x19;
  match->ipv6_src[10].value = 0x1a;
  match->ipv6_src[11].value = 0x1b;
  match->ipv6_src[12].value = 0x1c;
  match->ipv6_src[13].value = 0x1d;
  match->ipv6_src[14].value = 0x1e;
  match->ipv6_src[15].value = 0x1f;

  assert_true(execute_action_set_field(frame, action));

  ipv6_header_t *ipv6 = (ipv6_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t));
  assert_true(ipv6->hdrctl == htonl(0x60020304));
  assert_true(ipv6->daddr[0] == 0x00);
  assert_true(ipv6->daddr[1] == 0x01);
  assert_true(ipv6->daddr[2] == 0x02);
  assert_true(ipv6->daddr[3] == 0x03);
  assert_true(ipv6->daddr[4] == 0x04);
  assert_true(ipv6->daddr[5] == 0x05);
  assert_true(ipv6->daddr[6] == 0x06);
  assert_true(ipv6->daddr[7] == 0x07);
  assert_true(ipv6->daddr[8] == 0x08);
  assert_true(ipv6->daddr[9] == 0x09);
  assert_true(ipv6->daddr[10] == 0x0a);
  assert_true(ipv6->daddr[11] == 0x0b);
  assert_true(ipv6->daddr[12] == 0x0c);
  assert_true(ipv6->daddr[13] == 0x0d);
  assert_true(ipv6->daddr[14] == 0x0e);
  assert_true(ipv6->daddr[15] == 0x0f);
  assert_true(ipv6->saddr[0] == 0x10);
  assert_true(ipv6->saddr[1] == 0x11);
  assert_true(ipv6->saddr[2] == 0x12);
  assert_true(ipv6->saddr[3] == 0x13);
  assert_true(ipv6->saddr[4] == 0x14);
  assert_true(ipv6->saddr[5] == 0x15);
  assert_true(ipv6->saddr[6] == 0x16);
  assert_true(ipv6->saddr[7] == 0x17);
  assert_true(ipv6->saddr[8] == 0x18);
  assert_true(ipv6->saddr[9] == 0x19);
  assert_true(ipv6->saddr[10] == 0x1a);
  assert_true(ipv6->saddr[11] == 0x1b);
  assert_true(ipv6->saddr[12] == 0x1c);
  assert_true(ipv6->saddr[13] == 0x1d);
  assert_true(ipv6->saddr[14] == 0x1e);
  assert_true(ipv6->saddr[15] == 0x1f);

  xfree(frame->user_data);
  frame->user_data = NULL;
  free_buffer(frame);
  delete_action(&action);
}


static void
test_execute_action_set_field_icmpv4() {
  buffer *frame = copy_packet_to_buffer("./test_packets/icmp_echo_rep.cap");
  parse_packet(frame);

  match *match = init_match();
  action *action = create_action_set_field(match);
  match->icmpv4_code.valid = true;
  match->icmpv4_code.value = 1;
  match->icmpv4_type.valid = true;
  match->icmpv4_type.value = 2;

  assert_true(execute_action_set_field(frame, action));

  icmp_header_t *icmpv4 = (icmp_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t) + sizeof(ipv4_header_t));
  assert_true(icmpv4->code == 0x01);
  assert_true(icmpv4->type == 0x02);

  xfree(frame->user_data);
  frame->user_data = NULL;
  free_buffer(frame);
  delete_action(&action);
}


static void
test_execute_action_set_field_icmpv6() {
  buffer *frame = copy_packet_to_buffer("./test_packets/v6_icmp_nd_sll.cap");
  parse_packet(frame);

  match *match = init_match();
  action *action = create_action_set_field(match);
  match->icmpv6_code.valid = true;
  match->icmpv6_code.value = 0x01;
  match->icmpv6_type.valid= true;
  match->icmpv6_type.value = 0x02;

  assert_true(execute_action_set_field(frame, action));

  icmpv6_header_t *icmpv6 = (icmpv6_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t) + sizeof(ipv6_header_t));
  assert_true(icmpv6->code == 0x01);
  assert_true(icmpv6->type == 0x02);

  xfree(frame->user_data);
  frame->user_data = NULL;
  free_buffer(frame);
  delete_action(&action);
}


static void
test_execute_action_set_field_icmpv6_nd_sll() {
  buffer *frame = copy_packet_to_buffer("./test_packets/v6_icmp_nd_sll.cap");
  parse_packet(frame);

  match *match = init_match();
  action *action = create_action_set_field(match);
  match->ipv6_nd_target[0].valid = true;
  match->ipv6_nd_target[0].value = 0x00;
  match->ipv6_nd_target[1].value = 0x01;
  match->ipv6_nd_target[2].value = 0x02;
  match->ipv6_nd_target[3].value = 0x03;
  match->ipv6_nd_target[4].value = 0x04;
  match->ipv6_nd_target[5].value = 0x05;
  match->ipv6_nd_target[6].value = 0x06;
  match->ipv6_nd_target[7].value = 0x07;
  match->ipv6_nd_target[8].value = 0x08;
  match->ipv6_nd_target[9].value = 0x09;
  match->ipv6_nd_target[10].value = 0x0a;
  match->ipv6_nd_target[11].value = 0x0b;
  match->ipv6_nd_target[12].value = 0x0c;
  match->ipv6_nd_target[13].value = 0x0d;
  match->ipv6_nd_target[14].value = 0x0e;
  match->ipv6_nd_target[15].value = 0x0f;

  match->ipv6_nd_sll[0].valid = true;
  match->ipv6_nd_sll[0].value = 0x10;
  match->ipv6_nd_sll[1].value = 0x11;
  match->ipv6_nd_sll[2].value = 0x12;
  match->ipv6_nd_sll[3].value = 0x13;
  match->ipv6_nd_sll[4].value = 0x14;
  match->ipv6_nd_sll[5].value = 0x15;

  assert_true(execute_action_set_field(frame, action));

  uint8_t *target = (uint8_t *)frame->data + sizeof(ether_header_t) + sizeof(ipv6_header_t)+ sizeof(icmpv6_header_t) + 4;
  assert_true(target[0] == 0x00);
  assert_true(target[1] == 0x01);
  assert_true(target[2] == 0x02);
  assert_true(target[3] == 0x03);
  assert_true(target[4] == 0x04);
  assert_true(target[5] == 0x05);
  assert_true(target[6] == 0x06);
  assert_true(target[7] == 0x07);
  assert_true(target[8] == 0x08);
  assert_true(target[9] == 0x09);
  assert_true(target[10] == 0x0a);
  assert_true(target[11] == 0x0b);
  assert_true(target[12] == 0x0c);
  assert_true(target[13] == 0x0d);
  assert_true(target[14] == 0x0e);
  assert_true(target[15] == 0x0f);
  uint8_t *sll = target + 16 + 2;
  assert_true(sll[0] == 0x10);
  assert_true(sll[1] == 0x11);
  assert_true(sll[2] == 0x12);
  assert_true(sll[3] == 0x13);
  assert_true(sll[4] == 0x14);
  assert_true(sll[5] == 0x15);

  xfree(frame->user_data);
  frame->user_data = NULL;
  free_buffer(frame);
  delete_action(&action);
}


static void
test_execute_action_set_field_icmpv6_nd_tll() {
  buffer *frame = copy_packet_to_buffer("./test_packets/v6_icmp_nd_tll2.cap");
  parse_packet(frame);

  match *match = init_match();
  action *action = create_action_set_field(match);

  match->ipv6_nd_tll[0].valid = true;
  match->ipv6_nd_tll[0].value = 0x10;
  match->ipv6_nd_tll[1].value = 0x11;
  match->ipv6_nd_tll[2].value = 0x12;
  match->ipv6_nd_tll[3].value = 0x13;
  match->ipv6_nd_tll[4].value = 0x14;
  match->ipv6_nd_tll[5].value = 0x15;

  assert_true(execute_action_set_field(frame, action));

  uint8_t *target = (uint8_t *)frame->data + sizeof(ether_header_t) + sizeof(ipv6_header_t)+ sizeof(icmpv6_header_t) + 4;
  uint8_t *tll = target + 16 + 2;
  assert_true(tll[0] == 0x10);
  assert_true(tll[1] == 0x11);
  assert_true(tll[2] == 0x12);
  assert_true(tll[3] == 0x13);
  assert_true(tll[4] == 0x14);
  assert_true(tll[5] == 0x15);

  xfree(frame->user_data);
  frame->user_data = NULL;
  free_buffer(frame);
  delete_action(&action);
}


static void
test_execute_action_set_field_udp() {
  buffer *frame = copy_packet_to_buffer("./test_packets/udp.cap");
  parse_packet(frame);

  match *match = init_match();
  action *action = create_action_set_field(match);
  match->udp_dst.valid = true;
  match->udp_dst.value = 0x0001;
  match->udp_src.valid = true;
  match->udp_src.value = 0x0002;

  assert_true(execute_action_set_field(frame, action));

  udp_header_t *udp = (udp_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t) + sizeof(ipv4_header_t));
  assert_true(udp->dst_port == htons(0x0001));
  assert_true(udp->src_port == htons(0x0002));

  xfree(frame->user_data);
  frame->user_data = NULL;
  free_buffer(frame);
  delete_action(&action);
}


static void
test_execute_action_set_field_tcp() {
  buffer *frame = copy_packet_to_buffer("./test_packets/tcp.cap");
  parse_packet(frame);

  match *match = init_match();
  action *action = create_action_set_field(match);
  match->tcp_dst.valid = true;
  match->tcp_dst.value = 0x0001;
  match->tcp_src.valid = true;
  match->tcp_src.value = 0x0002;

  assert_true(execute_action_set_field(frame, action));

  udp_header_t *tcp = (udp_header_t *)((uint8_t *)frame->data + sizeof(ether_header_t) + sizeof(ipv4_header_t));
  assert_true(tcp->dst_port == htons(0x0001));
  assert_true(tcp->src_port == htons(0x0002));

  xfree(frame->user_data);
  frame->user_data = NULL;
  free_buffer(frame);
  delete_action(&action);
}


static void
test_execute_action_set_field_mpls() {
  buffer *frame = copy_packet_to_buffer("./test_packets/mpls_8847.cap");
  parse_packet(frame);


  match *match = init_match();
  action *action = create_action_set_field(match);
  match->mpls_bos.valid = true;
  match->mpls_bos.value = 0x00;
  match->mpls_tc.valid = true;
  match->mpls_tc.value = 0x01;
  match->mpls_label.valid = true;
  match->mpls_label.value = 0x01020304;

  assert_true(execute_action_set_field(frame, action));

  uint32_t *mpls = (uint32_t *)((uint8_t *)frame->data + sizeof(ether_header_t));
  assert_true(*mpls == htonl(0x203042ff));

  xfree(frame->user_data);
  frame->user_data = NULL;
  free_buffer(frame);
  delete_action(&action);
}


static void
test_execute_action_group_all() {
//execute_action_group( buffer *frame, action *group, flow_entry *_flow_entry )
  original_execute_action_list = execute_action_list;
  execute_action_list = mock_execute_action_list;


  action_list *actions1 = init_action_list();
  action *action1 = create_action_decr_ipv4_ttl();
  action *action2 = create_action_decr_ipv4_ttl();
  append_action(actions1, action1);
  append_action(actions1, action2);
  bucket *bucket1 = create_action_bucket(1, 2, 3, actions1);

  action_list *actions2 = init_action_list();
  action *action3 = create_action_decr_ipv4_ttl();
  action *action4 = create_action_decr_ipv4_ttl();
  append_action(actions2, action3);
  append_action(actions2, action4);
  bucket *bucket2 = create_action_bucket(1, 2, 3, actions2);

  bucket_list *buckets = create_action_bucket_list();
  append_action_bucket(buckets, bucket1);
  append_action_bucket(buckets, bucket2);

  group_entry *group = create_group_entry(OFPGT_ALL, buckets);

  append_group_entry(group);

  buffer *frame = copy_packet_to_buffer("./test_packets/udp.cap");
  action *action_group = create_action_group(0);

  assert_true(execute_action_group(frame, action_group ));
  assert_int_equal(2, called_mock_execute_action_list);

  free_buffer(frame);

  execute_action_list = original_execute_action_list;
}


static void
test_execute_action_group_select() {
//execute_action_group( buffer *frame, action *group, flow_entry *_flow_entry )
  original_execute_action_list = execute_action_list;
  execute_action_list = mock_execute_action_list;

  action_list *actions1 = init_action_list();
  action *action1 = create_action_decr_ipv4_ttl();
  action *action2 = create_action_decr_ipv4_ttl();
  append_action(actions1, action1);
  append_action(actions1, action2);
  bucket *bucket1 = create_action_bucket(1, 2, 3, actions1);

  action_list *actions2 = init_action_list();
  action *action3 = create_action_decr_ipv4_ttl();
  action *action4 = create_action_decr_ipv4_ttl();
  append_action(actions2, action3);
  append_action(actions2, action4);
  bucket *bucket2 = create_action_bucket(1, 2, 3, actions2);

  bucket_list *buckets = create_action_bucket_list();
  append_action_bucket(buckets, bucket1);
  append_action_bucket(buckets, bucket2);

  group_entry *group = create_group_entry(OFPGT_SELECT, buckets);

  append_group_entry(group);

  buffer *frame = copy_packet_to_buffer("./test_packets/udp.cap");
  action *action_group = create_action_group(0);

  assert_true(execute_action_group(frame, action_group ));
  assert_int_equal(1, called_mock_execute_action_list);

  free_buffer(frame);

  execute_action_list = original_execute_action_list;
}


static void
test_execute_action_group_indirect() {

  original_execute_action_list = execute_action_list;
  execute_action_list = mock_execute_action_list;

  action_list *actions1 = init_action_list();
  action *action1 = create_action_decr_ipv4_ttl();
  action *action2 = create_action_decr_ipv4_ttl();
  append_action(actions1, action1);
  append_action(actions1, action2);
  bucket *bucket1 = create_action_bucket(1, 2, 3, actions1);

  action_list *actions2 = init_action_list();
  action *action3 = create_action_decr_ipv4_ttl();
  action *action4 = create_action_decr_ipv4_ttl();
  append_action(actions2, action3);
  append_action(actions2, action4);
  bucket *bucket2 = create_action_bucket(1, 2, 3, actions2);

  bucket_list *buckets = create_action_bucket_list();
  append_action_bucket(buckets, bucket1);
  append_action_bucket(buckets, bucket2);

  group_entry *group = create_group_entry(OFPGT_INDIRECT, buckets);

  append_group_entry(group);

  buffer *frame = copy_packet_to_buffer("./test_packets/udp.cap");
  action *action_group = create_action_group(0);

  assert_true(execute_action_group(frame, action_group ));
  assert_int_equal(1, called_mock_execute_action_list);

  free_buffer(frame);
  execute_action_list = original_execute_action_list;
}


static void
test_execute_action_output() {
  buffer *frame = copy_packet_to_buffer("./test_packets/udp.cap");

  action output;
  output.port = 1;

  assert_true(execute_action_output(frame, &output));
  assert_int_equal(1, called_mock_send_data);

  free_buffer(frame);
}







static void
test_init_action_executor() {
  assert_true(init_action_executor() == OFDPE_SUCCESS);
}

static void
test_finalize_action_executor() {
  assert_true(finalize_action_executor() == OFDPE_SUCCESS);
}


static void
test_execute_action_list_1() {
  buffer *frame = copy_packet_to_buffer("./test_packets/udp.cap");
  parse_packet(frame);

  action_list *actions = init_action_list();
  action *set_ttl = create_action_set_ipv4_ttl(3);
  action *push_vlan = create_action_push_vlan(4);
  match *match = init_match();
  match->eth_type.valid = true;
  match->eth_type.value = 0x0102;
  action *set_field = create_action_set_field(match);
  action *output = create_action_output(1, 2);
  append_action(actions, set_ttl);
  append_action(actions, push_vlan);
  append_action(actions, set_field);
  append_action(actions, output);

  assert_true(execute_action_list( actions, frame) == OFDPE_SUCCESS);

  ether_header_t *ether_header = (ether_header_t *)frame->data;
  assert_true(ether_header->type == htons(0x0102));

  vlantag_header_t *vlan_header = (vlantag_header_t *)(((uint8_t *)ether_header) + sizeof(ether_header_t));
  assert_true(vlan_header->tci == htons(0x0000));

  ipv4_header_t *ipv4_header =  (ipv4_header_t *)(((uint8_t *)vlan_header) + sizeof(vlantag_header_t));
  assert_true(ipv4_header->ttl == 3);

  assert_int_equal(1, called_mock_send_data);

  finalize_action_list(&actions);
  free_buffer(frame);
}


static void
test_execute_action_list_2() {
  buffer *frame = copy_packet_to_buffer("./test_packets/udp.cap");
  parse_packet(frame);

  action_list *actions = init_action_list();
  action *decr_ttl = create_action_decr_ipv4_ttl();
  action *push_mpls = create_action_push_mpls(4);
  append_action(actions, decr_ttl);
  append_action(actions, push_mpls);

  assert_true(execute_action_list( actions, frame) == OFDPE_SUCCESS);

  ether_header_t *ether_header = (ether_header_t *)frame->data;
  uint32_t *mpls = (uint32_t *)(((uint8_t *)ether_header) + sizeof(ether_header_t));
  assert_true(*mpls == htonl(0x00000100));

  ipv4_header_t *ipv4_header =  (ipv4_header_t *)(((uint8_t *)ether_header) + sizeof(ether_header_t) + sizeof(uint32_t));

  assert_true(ipv4_header->ttl == 0x7f);

  assert_int_equal(0, called_mock_send_data);

  finalize_action_list(&actions);
  free_buffer(frame);
}


static void
test_execute_action_list_3() {
  buffer *frame = copy_packet_to_buffer("./test_packets/vlan_1.cap");
  parse_packet(frame);

  action_list *actions = init_action_list();
  action *pop_vlan = create_action_pop_vlan();
  append_action(actions, pop_vlan);

  assert_true(execute_action_list( actions, frame) == OFDPE_SUCCESS);

  ether_header_t *ether_header = (ether_header_t *)frame->data;
  ipv4_header_t *ipv4_header =  (ipv4_header_t *)(((uint8_t *)ether_header) + sizeof(ether_header_t));

  assert_true(ipv4_header->version == 4);

  assert_int_equal(0, called_mock_send_data);

  finalize_action_list(&actions);
  free_buffer(frame);
}


static void
test_execute_action_list_4() {
  buffer *frame = copy_packet_to_buffer("./test_packets/mpls_8847.cap");
  parse_packet(frame);

  action_list *actions = init_action_list();
  action *pop_mpls = create_action_pop_mpls(1);
  append_action(actions, pop_mpls);

  assert_true(execute_action_list( actions, frame) == OFDPE_SUCCESS);

  ether_header_t *ether_header = (ether_header_t *)frame->data;
  ipv4_header_t *ipv4_header =  (ipv4_header_t *)(((uint8_t *)ether_header) + sizeof(ether_header_t));

  assert_true(ipv4_header->version == 4);

  assert_int_equal(0, called_mock_send_data);

  finalize_action_list(&actions);
  free_buffer(frame);
}


static void
test_execute_action_list_5() {
  buffer *frame = copy_packet_to_buffer("./test_packets/mpls_8847.cap");
  parse_packet(frame);

  action_list *actions = init_action_list();
  action *decr_mpls = create_action_decr_mpls_ttl();
  append_action(actions, decr_mpls);

  assert_true(execute_action_list( actions, frame) == OFDPE_SUCCESS);

  ether_header_t *ether_header = (ether_header_t *)frame->data;
  uint32_t *mpls = (uint32_t *)(((uint8_t *)ether_header) + sizeof(ether_header_t));

  assert_true(*mpls == htonl(0x0001d1fe));

  assert_int_equal(0, called_mock_send_data);

  finalize_action_list(&actions);
  free_buffer(frame);
}


static void
test_execute_action_list_6() {
  buffer *frame = copy_packet_to_buffer("./test_packets/mpls_8847.cap");
  parse_packet(frame);

  action_list *actions = init_action_list();
  action *set_mpls_ttl = create_action_set_mpls_ttl(0x23);
  append_action(actions, set_mpls_ttl);

  assert_true(execute_action_list( actions, frame) == OFDPE_SUCCESS);

  ether_header_t *ether_header = (ether_header_t *)frame->data;
  uint32_t *mpls = (uint32_t *)(((uint8_t *)ether_header) + sizeof(ether_header_t));
  assert_true(*mpls == htonl(0x0001d123));

  assert_int_equal(0, called_mock_send_data);

  finalize_action_list(&actions);
  free_buffer(frame);
}


static void
test_execute_action_list_7() {

  action_list *actions = init_action_list();
  action *action1 = create_action_decr_ipv4_ttl();
  action *action2 = create_action_decr_ipv4_ttl();
  append_action(actions, action1);
  append_action(actions, action2);
  bucket *bucket = create_action_bucket(1, 2, 3, actions);

  bucket_list *buckets = create_action_bucket_list();
  append_action_bucket(buckets, bucket);

  group_entry *group = create_group_entry(OFPGT_INDIRECT, buckets);

  append_group_entry(group);

  buffer *frame = copy_packet_to_buffer("./test_packets/udp.cap");
  parse_packet(frame);

  action_list *action_l = init_action_list();
  action *action_group = create_action_group(0x00);
  append_action(action_l, action_group);

  assert_true(execute_action_list( action_l, frame) == OFDPE_SUCCESS);

  ether_header_t *ether_header = (ether_header_t *)frame->data;
  ipv4_header_t *ipv4_header =  (ipv4_header_t *)(((uint8_t *)ether_header) + sizeof(ether_header_t));

  assert_true(ipv4_header->ttl == 0x7e);

  assert_int_equal(0, called_mock_send_data);
  finalize_action_list(&action_l);
  free_buffer(frame);
}


static void
test_execute_action_set_1() {

  buffer *frame = copy_packet_to_buffer("./test_packets/udp.cap");
  parse_packet(frame);

  action *set_ttl = create_action_set_ipv4_ttl(3);
  action *push_vlan = create_action_push_vlan(4);
  push_vlan->ethertype = ETH_ETHTYPE_TPID;
  match *match = init_match();
  match->ipv4_dst.valid = true;
  match->ipv4_dst.value = htonl(0x01020304);
  action *set_field = create_action_set_field(match);
  action *output = create_action_output(1, 2);

  action_set action_set;
  memset(&action_set, 0, sizeof(action_set));
  action_set.set_nw_ttl = set_ttl;
  action_set.push_vlan = push_vlan;
  action_set.set_field = set_field;
  action_set.output = output;

  assert_true(execute_action_set( &action_set, frame) == OFDPE_SUCCESS);

  ether_header_t *ether_header = (ether_header_t *)frame->data;

  vlantag_header_t *vlan_header = (vlantag_header_t *)(((uint8_t *)ether_header) + sizeof(ether_header_t));
  assert_true(vlan_header->tci == htons(0x0000));

  ipv4_header_t *ipv4_header =  (ipv4_header_t *)(((uint8_t *)vlan_header) + sizeof(vlantag_header_t));
  assert_true(ipv4_header->ttl == 3);
  assert_true(ipv4_header->daddr == 0x01020304);

  assert_int_equal(1, called_mock_send_data);

  free_buffer(frame);
}


static void
test_execute_action_set_2() {

  buffer *frame = copy_packet_to_buffer("./test_packets/udp.cap");
  parse_packet(frame);

  action *decr_ttl = create_action_decr_ipv4_ttl();
  action *push_mpls = create_action_push_mpls(4);
  push_mpls->ethertype = ETH_ETHTYPE_MPLS;

  action_set action_set;
  memset(&action_set, 0, sizeof(action_set));
  action_set.dec_nw_ttl = decr_ttl;
  action_set.push_mpls = push_mpls;

  assert_true(execute_action_set( &action_set, frame) == OFDPE_SUCCESS);

  ether_header_t *ether_header = (ether_header_t *)frame->data;
  uint32_t *mpls = (uint32_t *)(((uint8_t *)ether_header) + sizeof(ether_header_t));
  assert_true(*mpls == htonl(0x00000100));

  ipv4_header_t *ipv4_header =  (ipv4_header_t *)(((uint8_t *)ether_header) + sizeof(ether_header_t) + sizeof(uint32_t));

  assert_true(ipv4_header->ttl == 0x7f);

  assert_int_equal(0, called_mock_send_data);

  free_buffer(frame);
}


static void
test_execute_action_set_3() {
  buffer *frame = copy_packet_to_buffer("./test_packets/vlan_1.cap");
  parse_packet(frame);

  action *pop_vlan = create_action_pop_vlan();

  action_set action_set;
  memset(&action_set, 0, sizeof(action_set));
  action_set.pop_vlan = pop_vlan;

  assert_true(execute_action_set( &action_set, frame) == OFDPE_SUCCESS);

  ether_header_t *ether_header = (ether_header_t *)frame->data;
  ipv4_header_t *ipv4_header =  (ipv4_header_t *)(((uint8_t *)ether_header) + sizeof(ether_header_t));

  assert_true(ipv4_header->version == 4);

  assert_int_equal(0, called_mock_send_data);

  free_buffer(frame);
}


static void
test_execute_action_set_4() {
  buffer *frame = copy_packet_to_buffer("./test_packets/mpls_8847.cap");
  parse_packet(frame);

  action *pop_mpls = create_action_pop_mpls(1);

  action_set action_set;
  memset(&action_set, 0, sizeof(action_set));
  action_set.pop_mpls = pop_mpls;

  assert_true(execute_action_set( &action_set, frame) == OFDPE_SUCCESS);

  ether_header_t *ether_header = (ether_header_t *)frame->data;
  ipv4_header_t *ipv4_header =  (ipv4_header_t *)(((uint8_t *)ether_header) + sizeof(ether_header_t));

  assert_true(ipv4_header->version == 4);

  assert_int_equal(0, called_mock_send_data);

  free_buffer(frame);
}


static void
test_execute_action_set_5() {

  buffer *frame = copy_packet_to_buffer("./test_packets/mpls_8847.cap");
  parse_packet(frame);

  action *decr_mpls = create_action_decr_mpls_ttl();

  action_set action_set;
  memset(&action_set, 0, sizeof(action_set));
  action_set.dec_mpls_ttl = decr_mpls;

  assert_true(execute_action_set( &action_set, frame) == OFDPE_SUCCESS);

  ether_header_t *ether_header = (ether_header_t *)frame->data;
  uint32_t *mpls = (uint32_t *)(((uint8_t *)ether_header) + sizeof(ether_header_t));

  assert_true(*mpls == htonl(0x0001d1fe));

  assert_int_equal(0, called_mock_send_data);

  free_buffer(frame);
}


static void
test_execute_action_set_6() {

  buffer *frame = copy_packet_to_buffer("./test_packets/mpls_8847.cap");
  parse_packet(frame);

  action *set_mpls_ttl = create_action_set_mpls_ttl(0x23);

  action_set action_set;
  memset(&action_set, 0, sizeof(action_set));
  action_set.set_mpls_ttl = set_mpls_ttl;

  assert_true(execute_action_set( &action_set, frame) == OFDPE_SUCCESS);

  ether_header_t *ether_header = (ether_header_t *)frame->data;
  uint32_t *mpls = (uint32_t *)(((uint8_t *)ether_header) + sizeof(ether_header_t));
  assert_true(*mpls == htonl(0x0001d123));

  assert_int_equal(0, called_mock_send_data);

  free_buffer(frame);
}


static void
test_execute_action_set_7() {

  action_list *actions = init_action_list();
  action *action1 = create_action_decr_ipv4_ttl();
  action *action2 = create_action_decr_ipv4_ttl();
  append_action(actions, action1);
  append_action(actions, action2);
  bucket *bucket = create_action_bucket(1, 2, 3, actions);

  bucket_list *buckets = create_action_bucket_list();
  append_action_bucket(buckets, bucket);

  group_entry *group = create_group_entry(OFPGT_INDIRECT, buckets);

  append_group_entry(group);

  buffer *frame = copy_packet_to_buffer("./test_packets/udp.cap");
  parse_packet(frame);

  action *action_group = create_action_group(0x00);

  action_set action_set;
  memset(&action_set, 0, sizeof(action_set));
  action_set.group = action_group;

  assert_true(execute_action_set( &action_set, frame) == OFDPE_SUCCESS);

  ether_header_t *ether_header = (ether_header_t *)frame->data;
  ipv4_header_t *ipv4_header =  (ipv4_header_t *)(((uint8_t *)ether_header) + sizeof(ether_header_t));

  assert_true(ipv4_header->ttl == 0x7e);

  assert_int_equal(0, called_mock_send_data);

  free_buffer(frame);
}


static void
test_execute_action_packet_out_no_buffer() {

  buffer *frame = copy_packet_to_buffer("./test_packets/udp.cap");

  action_list *actions = init_action_list();
  action *action1 = create_action_decr_ipv4_ttl();
  append_action(actions, action1);


  uint32_t buffer_id = OFP_NO_BUFFER;
  uint32_t in_port = 1;

  assert_true(execute_action_packet_out( buffer_id, in_port, actions, frame ) == OFDPE_SUCCESS);

  free_buffer(frame);
  finalize_action_list(&actions);
}

static void
test_execute_action_packet_out_use_buffer() {

  buffer *frame = copy_packet_to_buffer("./test_packets/udp.cap");

  action_list *actions = init_action_list();
  action *action1 = create_action_output(1, 1);
  append_action(actions, action1);

  uint32_t buffer_id = 0;
  uint32_t in_port = 1;

  register_notify_handler_to_controller(NOTIFY_TYPE_PACKET_IN ,mock_handler_notify_to_controller);
  notify_parameter_packet_in parameter;
  parameter.packet = frame;

  notify_packet_in( &parameter );

  assert_true(execute_action_packet_out( buffer_id, in_port, actions, NULL ) == OFDPE_SUCCESS);
  assert_int_equal(1, called_mock_send_data);

  finalize_action_list(&actions);
}


static void
test_check_backet_false() {
  action_list *actions = init_action_list();
  action *output1 = create_action_output(1, 1);
  action *output2 = create_action_output(1, 1);

  ret_mock_is_device_linkup[0] = false;
  append_action(actions, output1);
  append_action(actions, output2);
  assert_false(check_backet(actions));

  ret_mock_is_device_linkup[1] = true;
  ret_mock_is_device_linkup[2] = false;
  assert_false(check_backet(actions));

  finalize_action_list(&actions);
}


static void
test_check_backet_true() {

  action_list *actions = init_action_list();
  action *output1 = create_action_output(1, 1);
  action *output2 = create_action_output(1, 1);
  action *set_mpls_ttl = create_action_set_mpls_ttl(1);

  append_action(actions, set_mpls_ttl);
  assert_true(check_backet(actions));

  ret_mock_is_device_linkup[0] = true;
  ret_mock_is_device_linkup[1] = true;
  append_action(actions, output1);
  append_action(actions, output2);
  assert_true(check_backet(actions));

  finalize_action_list(&actions);
}


static void
test_execute_group_all() {
  original_execute_action_list = execute_action_list;
  execute_action_list = mock_execute_action_list;

  action_list *actions1 = init_action_list();
  action_list *actions2 = init_action_list();

  bucket_list *buckets = create_action_bucket_list();
  bucket *bucket1 = create_action_bucket(1, 2, 3, actions1);
  bucket *bucket2 = create_action_bucket(1, 2, 3, actions2);

  append_action_bucket(buckets, bucket1);
  append_action_bucket(buckets, bucket2);

  buffer *frame = copy_packet_to_buffer("./test_packets/udp.cap");

  assert_true(execute_group_all(frame, buckets ));

  assert_int_equal(called_mock_execute_action_list, 2);

  delete_action_bucket_list(&buckets);
  free_buffer(frame);
  execute_action_list = original_execute_action_list;
}

static void
test_execute_group_select() {
  original_execute_action_list = execute_action_list;
  execute_action_list = mock_execute_action_list;

  action_list *actions1 = init_action_list();
  action_list *actions2 = init_action_list();

  bucket_list *buckets = create_action_bucket_list();
  bucket *bucket1 = create_action_bucket(1, 2, 3, actions1);
  bucket *bucket2 = create_action_bucket(1, 2, 3, actions2);

  append_action_bucket(buckets, bucket1);
  append_action_bucket(buckets, bucket2);

  buffer *frame = copy_packet_to_buffer("./test_packets/udp.cap");

  assert_true(execute_group_select(frame, buckets ));

  assert_int_equal(called_mock_execute_action_list, 1);

  delete_action_bucket_list(&buckets);
  free_buffer(frame);
  execute_action_list = original_execute_action_list;
}

static void
test_execute_group_indirect() {
  original_execute_action_list = execute_action_list;
  execute_action_list = mock_execute_action_list;

  action_list *actions = init_action_list();

  buffer *frame = copy_packet_to_buffer("./test_packets/udp.cap");

  assert_true(execute_group_indirect(frame, actions));

  assert_int_equal(called_mock_execute_action_list, 1);

  finalize_action_list(&actions);
  free_buffer(frame);
  execute_action_list = original_execute_action_list;
}




/******************************************************************************
 * Run tests.
 ******************************************************************************/

int
action_executor_main() {
  UnitTest tests[] = {

    unit_test_setup_teardown( test_set_ipv4_checksum, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_ipv4_udp_checksum, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_ipv6_udp_checksum, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_ipv4_tcp_checksum, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_ipv6_tcp_checksum, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_icmpv4_checksum, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_icmpv6_checksum, action_executor_setup, action_executor_teardown ),

    unit_test_setup_teardown( test_init_action_executor, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_finalize_action_executor, action_executor_setup, action_executor_teardown ),

    unit_test_setup_teardown( test_get_packet_info_data, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_address, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_dl_address, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_ipv6_address, action_executor_setup, action_executor_teardown ),

    unit_test_setup_teardown( test_set_dl_dst, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_dl_src, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_dl_type, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_vlan_vid, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_vlan_pcp, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_nw_tos, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_nw_ecn, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_ip_proto, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_ipv4_src, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_ipv4_dst, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_tcp_src, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_tcp_dst, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_udp_src, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_udp_dst, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_icmpv4_type, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_icmpv4_code, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_arp_op, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_arp_spa, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_arp_tpa, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_arp_sha, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_arp_tha, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_ipv6_src, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_ipv6_dst, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_ipv6_flabel, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_icmpv6_type, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_icmpv6_code, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_ipv6_nd_target, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_ipv6_nd_sll, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_ipv6_nd_tll, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_mpls_label, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_mpls_tc, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_set_mpls_bos, action_executor_setup, action_executor_teardown ),

    unit_test_setup_teardown( test_push_linklayer_tag, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_pop_linklayer_tag, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_push_vlan_tag, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_pop_vlan_tag, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_push_mpls_tag, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_pop_mpls_tag, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_decrement_ttl, action_executor_setup, action_executor_teardown ),

    unit_test_setup_teardown( test_execute_action_copy_ttl_in, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_copy_ttl_out, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_pop_mpls, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_pop_vlan, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_push_mpls, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_push_vlan, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_dec_mpls_ttl, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_dec_nw_ttl_ipv4, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_dec_nw_ttl_ipv6, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_set_mpls_ttl, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_set_nw_ttl_ipv4, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_set_nw_ttl_ipv6, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_set_field_ether, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_set_field_arp, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_set_field_vlan, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_set_field_ipv4, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_set_field_ipv6, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_set_field_icmpv4, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_set_field_icmpv6, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_set_field_icmpv6_nd_sll, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_set_field_icmpv6_nd_tll, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_set_field_udp, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_set_field_tcp, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_set_field_mpls, action_executor_setup, action_executor_teardown ),

    unit_test_setup_teardown( test_execute_action_group_all, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_group_select, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_group_indirect, action_executor_setup, action_executor_teardown ),

    unit_test_setup_teardown( test_execute_group_all, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_check_backet_false, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_check_backet_true, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_group_select, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_group_indirect, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_output, action_executor_setup, action_executor_teardown ),

    unit_test_setup_teardown( test_execute_action_list_1, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_list_2, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_list_3, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_list_4, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_list_5, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_list_6, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_list_7, action_executor_setup, action_executor_teardown ),

    unit_test_setup_teardown( test_execute_action_set_1, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_set_2, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_set_3, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_set_4, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_set_5, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_set_6, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_set_7, action_executor_setup, action_executor_teardown ),

    unit_test_setup_teardown( test_execute_action_packet_out_no_buffer, action_executor_setup, action_executor_teardown ),
    unit_test_setup_teardown( test_execute_action_packet_out_use_buffer, action_executor_setup, action_executor_teardown ),
  };
  return run_tests( tests );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
