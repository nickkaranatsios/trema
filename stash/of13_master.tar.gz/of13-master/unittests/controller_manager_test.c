
#include <assert.h>
#include <netinet/ip.h>
#include <stdio.h>
#include <string.h>
#include "checks.h"
#include "cmockery_trema.h"
#include "utility.h"
#include "wrapper.h"
#include "linked_list.h"
#include "mutex_lock.h"
#include "test_mocks.h"
#include "trema_wrapper.h"
#include "controller_manager.h"
#include "port_manager.h"
#include "packet_buffer_pool.h"
#include "ofdp.h"

/******************************************************************************
 * Mocks.
 ******************************************************************************/

static void ( *original_die )( const char *format, ... );
static void ( *original_malloc )( size_t size );
static OFDPE ( *original_init_device )( argument_device_info *device_info);
static OFDPE ( *original_finalize_device )( const uint32_t port_no );
static OFDPE ( *original_send_for_notify_port_config)(uint32_t port_no, uint8_t reason);

static void free_testfunction_paramter(void** parameter) {
	if(*parameter != NULL) {
		xfree(*parameter);
		*parameter = NULL;
	}
}
static void* testfunction_paramter = NULL;
static int count_of_called_testfunction_notify_packet_in = 0;
static void
testfunction_notify_packet_in( void* notify_parameter ) {
	count_of_called_testfunction_notify_packet_in ++;
	testfunction_paramter = notify_parameter;
}

static int count_of_called_testfunction_notify_flow_removed = 0;
static void
testfunction_notify_flow_removed( void* notify_parameter ) {
	count_of_called_testfunction_notify_flow_removed ++;
	testfunction_paramter = notify_parameter;
}

static int count_of_called_testfunction_notify_port_status = 0;
static void
testfunction_notify_port_status( void* notify_parameter ) {
	count_of_called_testfunction_notify_port_status ++;
	testfunction_paramter = notify_parameter;
}

static int count_of_called_testfunction_notify_error = 0;
static void
testfunction_notify_error( void* notify_parameter ) {
	count_of_called_testfunction_notify_error ++;
	testfunction_paramter = notify_parameter;
}

static int count_of_called_mock_init_device = 0;
static OFDPE
mock_init_device( argument_device_info *device_info) {
	count_of_called_mock_init_device++;
	return OFDPE_SUCCESS;
}

static int count_of_called_mock_finalize_device = 0;
static OFDPE
mock_finalize_device(const uint32_t port_no) {
	count_of_called_mock_finalize_device++;
	return OFDPE_SUCCESS;
}

static int count_of_called_mock_send_for_notify_port_config = 0;
static OFDPE
mock_send_for_notify_port_config(uint32_t port_no, uint8_t reason) {
  count_of_called_mock_send_for_notify_port_config ++;
  return OFDPE_SUCCESS;
}

static library_status
mock_get_library_status() {
  return STARTED;
}

/******************************************************************************
 * static finction extern
 ******************************************************************************/
typedef enum {
  external_message_type_port_add = 0,
  external_message_type_port_delete,
  external_message_type_port_conf
} external_message_type;

typedef struct {
  handler_notify_to_controller notify_packet_in;
  handler_notify_to_controller notify_flow_removed;
  handler_notify_to_controller notify_port_status;
  handler_notify_to_controller notify_errors;
} contoroller_handlers ;


typedef struct {
  buffer *packet;
  uint32_t buffer_id;
  struct timespec saved_at;
}  packet_in_buffer_element;



typedef struct {
  external_message_type type;
  void *parameter;
} external_message;

typedef struct {
  argument_device_info device_info;
} external_message_add_port;

typedef struct {
  uint32_t port_no;
} external_message_delete_port;

typedef struct {
  uint64_t max;
  list_element *list;
  pthread_mutex_t mutex;
} data_list;

typedef struct {
  contoroller_handlers handlers;
  data_list packet_in_buffer;
  data_list external;
} controller_manager;

extern uint32_t
get_packet_in_buffer_id(const data_list *list);

extern packet_in_buffer_element*
create_packet_in_buffer_element(buffer *packet, uint32_t buffer_id);

extern uint32_t
append_packet_in_buffer(data_list *list, buffer *packet);

extern void*
duplicate_parameter_memory(void* parameter, size_t size);

extern void*
duplicate_parameter(nofity_type type, void* original);

extern OFDPE
init_data_list(data_list *list, uint64_t max);

extern void
finalize_packet_in_buffer_data_list(data_list *list);

extern void
finalize_external_data_list(data_list *list);

extern OFDPE
append_external_message(void* message);

extern controller_manager controller;

/******************************************************************************
 * Setup and teardown.
 ******************************************************************************/



static void
controller_managet_setup() {
	original_die = die;
	die = mock_die;
	controller.handlers.notify_packet_in = NULL;
	controller.handlers.notify_flow_removed = NULL;
	controller.handlers.notify_port_status = NULL;
	controller.handlers.notify_errors = NULL;

	free_testfunction_paramter(&testfunction_paramter);

	count_of_called_testfunction_notify_packet_in = 0;
	count_of_called_testfunction_notify_flow_removed = 0;
	count_of_called_testfunction_notify_port_status = 0;
	count_of_called_testfunction_notify_error = 0;

	original_init_device = init_device;
	init_device = mock_init_device;
	count_of_called_mock_init_device = 0;

  original_finalize_device = finalize_device;
  finalize_device = mock_finalize_device;
	count_of_called_mock_finalize_device = 0;

	original_send_for_notify_port_config = send_for_notify_port_config;
	send_for_notify_port_config = mock_send_for_notify_port_config;
	count_of_called_mock_send_for_notify_port_config = 0;

	finalize_mutex(&controller.packet_in_buffer.mutex);
	finalize_mutex(&controller.external.mutex);

	init_packet_buffer_pool(100, 1500);
}


static void
controller_managet_teardown() {
	controller.handlers.notify_packet_in = NULL;
	controller.handlers.notify_flow_removed = NULL;
	controller.handlers.notify_port_status = NULL;
	controller.handlers.notify_errors = NULL;

	free_testfunction_paramter(&testfunction_paramter);

	count_of_called_testfunction_notify_packet_in = 0;
	count_of_called_testfunction_notify_flow_removed = 0;
	count_of_called_testfunction_notify_port_status = 0;
	count_of_called_testfunction_notify_error = 0;

	init_device = original_init_device;
	count_of_called_mock_init_device = 0;

  finalize_device = original_finalize_device;
	count_of_called_mock_finalize_device = 0;

	finalize_mutex(&controller.packet_in_buffer.mutex);
	finalize_mutex(&controller.external.mutex);

	finalize_packet_buffer_pool();
}

/******************************************************************************
 * Tests.
 ******************************************************************************/

static void
test_get_packet_in_buffer_id() {

  data_list data_list;
  memset(&data_list, 0, sizeof(data_list));
	list_element *list = NULL;

	assert_true(create_list(&list));

	assert_int_equal(0xffffffff, get_packet_in_buffer_id(&data_list));

  packet_in_buffer_element element[3];
  memset(&element[0], 0, sizeof(element));
	element[0].buffer_id = 1;

	assert_true(append_to_tail(&list, &element[0]));
	data_list.max = sizeof(element)/sizeof(element[0]);
  data_list.list = list;

  now(&element[0].saved_at);
	assert_int_equal(0xffffffff, get_packet_in_buffer_id(&data_list));

	element[0].saved_at.tv_sec = element[0].saved_at.tv_sec - 2;
  assert_int_equal(0x00000001, get_packet_in_buffer_id(&data_list));

	assert_true(delete_list(data_list.list));
}

static void
test_create_packet_in_buffer_element() {
	buffer *packet = allocate_packet_buffer();
	packet->length = 128;

	packet_in_buffer_element* element = create_packet_in_buffer_element(packet, 5);

	assert_memory_equal(packet->data, element->packet->data, 128);
	assert_int_equal(5, element->buffer_id);

        free_packet_buffer_pool_entry(element->packet);
	xfree(element);
	free_packet_buffer_pool_entry(packet);
}

static void
test_append_packet_in_buffer() {

	data_list list;
	buffer *packet[3];
	packet[0] = allocate_packet_buffer();
	packet[1] = allocate_packet_buffer();
	packet[2] = allocate_packet_buffer();

	init_mutex(&list.mutex);
	list.list = NULL;
	list.max = 2;

	assert_int_equal(0, append_packet_in_buffer(&list, packet[0]));
	assert_int_equal(1, append_packet_in_buffer(&list, packet[1]));
	assert_true(0xffffffff == append_packet_in_buffer(&list, packet[2]));
	list.max = 3;
	assert_int_equal(2, append_packet_in_buffer(&list, packet[2]));

	list_element *element = list.list;
	packet_in_buffer_element *data = element->data;
	assert_int_equal(0, data->buffer_id);
	delete_element(&element, data);
	xfree(data);

	data = element->data;
	assert_int_equal(1, data->buffer_id);
	delete_element(&element, data);
	xfree(data);

	data = element->data;
	assert_int_equal(2, data->buffer_id);
	delete_element(&element, data);
	xfree(data);

	finalize_mutex(&list.mutex);
	free_packet_buffer_pool_entry(packet[0]);
	free_packet_buffer_pool_entry(packet[1]);
	free_packet_buffer_pool_entry(packet[2]);
}


static void
test_duplicate_parameter_memory() {

	int param[10];
	void* ret = NULL;

	ret = duplicate_parameter_memory(&param[0], sizeof(param));
	assert_memory_equal(ret, &param[0], sizeof(param));
	xfree(ret);
}

static void
test_duplicate_parameter() {

	void* ret = NULL;

	notify_parameter_packet_in packet_in;
	buffer *packet = allocate_packet_buffer();
	memset(&packet_in, 0, sizeof(packet_in));
	packet_in.buffer_id = 1;
	packet_in.cookie = 2;
	packet_in.match.arp_op.value = 3;
	packet_in.max_len = 4;
	packet_in.packet = packet;
	packet_in.table_id = 5;
	ret = duplicate_parameter(NOTIFY_TYPE_PACKET_IN, &packet_in);
 assert_int_equal(packet_in.buffer_id, ((notify_parameter_packet_in *)ret)->buffer_id);
 assert_int_equal(packet_in.cookie, ((notify_parameter_packet_in *)ret)->cookie);
 assert_int_equal(packet_in.match.arp_op.value, ((notify_parameter_packet_in *)ret)->match.arp_op.value);
 assert_int_equal(packet_in.max_len, ((notify_parameter_packet_in *)ret)->max_len);
 assert_int_equal(packet_in.table_id, ((notify_parameter_packet_in *)ret)->table_id);
 assert_false(packet_in.packet == ((notify_parameter_packet_in *)ret)->packet);

 free_packet_buffer_pool_entry(((notify_parameter_packet_in *)ret)->packet);
 free_packet_buffer_pool_entry(packet);
	xfree(ret);

	notify_parameter_flow_removed flow_removed;
	memset(&flow_removed, 0, sizeof(flow_removed));
	flow_removed.byte_count = 1;
	flow_removed.cookie = 2;
	flow_removed.duration_nsec = 3;
	flow_removed.duration_sec	= 4;
	flow_removed.hard_timeout	= 5;
	flow_removed.idle_timeout = 6;
	flow_removed.match.arp_op.value = 7;
	flow_removed.packet_count	= 8;
	flow_removed.priority = 9;
	flow_removed.reason = 10;
	flow_removed.table_id = 11;
	ret = duplicate_parameter(NOTIFY_TYPE_FLOW_REMOVED, &flow_removed);
	assert_memory_equal(&flow_removed, ret, sizeof(flow_removed));
	xfree(ret);

	notify_parameter_port_status port_status;
	memset(&port_status, 0, sizeof(port_status));
	port_status.desc.advertised = 1;
	port_status.reason = 2;
	ret = duplicate_parameter(NOTIFY_TYPE_PORT_STATUS, &port_status);
	assert_memory_equal(&port_status, ret, sizeof(port_status));
	xfree(ret);

	notify_parameter_error error;
	memset(&error, 0, sizeof(error));
 packet = allocate_packet_buffer();
 error.packet = packet;
//	error.code = 1;
//	error.type = 2;
	error.error_code = 1;
	ret = duplicate_parameter(NOTIFY_TYPE_ERROR, &error);
// assert_int_equal(error.code, ((notify_parameter_error *)ret)->code);
// assert_int_equal(error.type, ((notify_parameter_error *)ret)->type);
 assert_int_equal(error.error_code, ((notify_parameter_error *)ret)->error_code);
 assert_false(error.packet == ((notify_parameter_error *)ret)->packet);
 free_packet_buffer_pool_entry(((notify_parameter_error *)ret)->packet);
 free_packet_buffer_pool_entry(packet);
	xfree(ret);

	ret = duplicate_parameter(0xFFFFFFFF, &error);
	assert_true(ret == NULL);

}

static void
test_init_data_list() {

	data_list list;
	memset(&list, 0, sizeof(list));
	assert_int_equal(OFDPE_SUCCESS, init_data_list(&list, 5));
	assert_int_equal(5, list.max);

	assert_true(lock_mutex(&list.mutex));
	assert_true(unlock_mutex(&list.mutex));
	assert_true(finalize_mutex(&list.mutex));
}

static void
test_finalize_packet_in_buffer_data_list() {

	data_list list;
	memset(&list, 0, sizeof(list));
	assert_int_equal(OFDPE_SUCCESS, init_data_list(&list, 5));

	packet_in_buffer_element* buffer_element[3];
	buffer_element[0] = xmalloc(sizeof(packet_in_buffer_element));
	buffer_element[1] = xmalloc(sizeof(packet_in_buffer_element));
	buffer_element[2] = xmalloc(sizeof(packet_in_buffer_element));

	buffer* packet[3];
	packet[0] = allocate_packet_buffer();
	packet[1] = allocate_packet_buffer();
	packet[2] = allocate_packet_buffer();

	buffer_element[0]->packet = packet[0];
	buffer_element[1]->packet = packet[1];
	buffer_element[2]->packet = packet[2];

	append_to_tail(&list.list, buffer_element[0]);
	append_to_tail(&list.list, buffer_element[1]);
	append_to_tail(&list.list, buffer_element[2]);

	finalize_packet_in_buffer_data_list(&list);

	assert_false(lock_mutex(&list.mutex));
}

static void
test_finalize_external_data_list() {

	data_list list;
	memset(&list, 0, sizeof(list));
	assert_int_equal(OFDPE_SUCCESS, init_data_list(&list, 5));

	external_message* buffer_element[3];
	buffer_element[0] = xmalloc(sizeof(external_message));
	buffer_element[1] = xmalloc(sizeof(external_message));
	buffer_element[2] = xmalloc(sizeof(external_message));

	external_message_add_port* parameter[3];
	parameter[0] = xmalloc(sizeof(external_message_add_port));
	parameter[1] = xmalloc(sizeof(external_message_add_port));
	parameter[2] = xmalloc(sizeof(external_message_add_port));

	buffer_element[0]->parameter = parameter[0];
	buffer_element[1]->parameter = parameter[1];
	buffer_element[2]->parameter = parameter[2];

	append_to_tail(&list.list, buffer_element[0]);
	append_to_tail(&list.list, buffer_element[1]);
	append_to_tail(&list.list, buffer_element[2]);

	finalize_external_data_list(&list);

	assert_false(lock_mutex(&list.mutex));
}

/******************************************************************************
 * global.
 ******************************************************************************/
static void
test_initialize_controller_manager() {

	assert_int_equal(OFDPE_SUCCESS, init_controller_manager(3));
	assert_true(controller.handlers.notify_packet_in == NULL);
	assert_true(controller.handlers.notify_flow_removed == NULL);
	assert_true(controller.handlers.notify_port_status == NULL);
	assert_true(controller.handlers.notify_errors == NULL);

	assert_int_equal(3, controller.packet_in_buffer.max);
	assert_int_equal(3, controller.external.max);

	assert_int_equal(3, controller.external.max);
	assert_int_equal(3, controller.external.max);

	assert_true(finalize_mutex(&controller.packet_in_buffer.mutex));
	assert_true(finalize_mutex(&controller.external.mutex));
}

static void
test_finalize_controller_manager() {

	init_mutex(&controller.packet_in_buffer.mutex);
	init_mutex(&controller.external.mutex);

	assert_int_equal(OFDPE_SUCCESS, finalize_controller_manager());

	assert_false(lock_mutex(&controller.packet_in_buffer.mutex));
	assert_false(lock_mutex(&controller.external.mutex));
}

static void
test_notify_packet_in() {

	notify_parameter_packet_in parameter;
	buffer *packet = allocate_packet_buffer();
	packet->length = 123;
	parameter.table_id = 456;
	parameter.packet = packet;
	assert_int_equal(OFDPE_SUCCESS, notify_packet_in(&parameter));
	assert_int_equal(0, count_of_called_testfunction_notify_packet_in);

	assert_int_equal(OFDPE_SUCCESS,
			register_notify_handler_to_controller( NOTIFY_TYPE_PACKET_IN, testfunction_notify_packet_in ));
  assert_int_equal(OFDPE_SUCCESS, notify_packet_in(&parameter));
	assert_int_equal(1, count_of_called_testfunction_notify_packet_in);
	assert_int_equal(456, ((notify_parameter_packet_in *)testfunction_paramter)->table_id);
	assert_true(packet != ((notify_parameter_packet_in *)testfunction_paramter)->packet);
	free_packet_buffer_pool_entry(((notify_parameter_packet_in *)testfunction_paramter)->packet);
	free_testfunction_paramter(&testfunction_paramter);

	init_mutex(&controller.packet_in_buffer.mutex);
	assert_int_equal(OFDPE_SUCCESS, notify_packet_in(&parameter));

	assert_int_equal(2, count_of_called_testfunction_notify_packet_in);
	assert_int_equal(456, ((notify_parameter_packet_in *)testfunction_paramter)->table_id);
	assert_true(packet != ((notify_parameter_packet_in *)testfunction_paramter)->packet);

	assert_true(finalize_mutex(&controller.packet_in_buffer.mutex));
	packet_in_buffer_element* element = controller.packet_in_buffer.list->data;
	delete_element(&controller.packet_in_buffer.list, element);
	xfree(element);
	free_packet_buffer_pool_entry(((notify_parameter_packet_in *)testfunction_paramter)->packet);
	free_testfunction_paramter(&testfunction_paramter);
	free_packet_buffer_pool_entry(packet);
}

static void
test_notify_flow_removed()  {
	notify_parameter_flow_removed parameter;
	parameter.table_id = 123;
	assert_int_equal(OFDPE_SUCCESS, notify_flow_removed(&parameter));
	assert_int_equal(0, count_of_called_testfunction_notify_flow_removed);

	assert_int_equal(OFDPE_SUCCESS,
			register_notify_handler_to_controller( NOTIFY_TYPE_FLOW_REMOVED, testfunction_notify_flow_removed ));
	assert_int_equal(OFDPE_SUCCESS, notify_flow_removed(&parameter));
	assert_int_equal(1, count_of_called_testfunction_notify_flow_removed);

	assert_int_equal(123, ((notify_parameter_flow_removed *)testfunction_paramter)->table_id);

	free_testfunction_paramter(&testfunction_paramter);
}

static void
test_notify_port_status() {
	notify_parameter_port_status parameter;
	parameter.reason = 123;
	assert_int_equal(OFDPE_SUCCESS, notify_port_status(&parameter));
	assert_int_equal(0, count_of_called_testfunction_notify_port_status);

	assert_int_equal(OFDPE_SUCCESS,
			register_notify_handler_to_controller( NOTIFY_TYPE_PORT_STATUS, testfunction_notify_port_status ));
	assert_int_equal(OFDPE_SUCCESS, notify_port_status(&parameter));
	assert_int_equal(1, count_of_called_testfunction_notify_port_status);

	assert_int_equal(123, ((notify_parameter_port_status *)testfunction_paramter)->reason);

	free_testfunction_paramter(&testfunction_paramter);
}

static void
test_notify_error() {
	notify_parameter_error parameter;
//        parameter.code = 123;
        parameter.error_code = 123;
	buffer *packet = allocate_packet_buffer();
	packet->length = 128;
	parameter.packet = packet;
	assert_int_equal(OFDPE_SUCCESS, notify_error(&parameter));
	assert_int_equal(0, count_of_called_testfunction_notify_error);

	assert_int_equal(OFDPE_SUCCESS,
			register_notify_handler_to_controller( NOTIFY_TYPE_ERROR, testfunction_notify_error ));
	assert_int_equal(OFDPE_SUCCESS, notify_error(&parameter));
	assert_int_equal(1, count_of_called_testfunction_notify_error);

//        assert_int_equal(123, ((notify_parameter_error *)testfunction_paramter)->code);
        assert_int_equal(123, ((notify_parameter_error *)testfunction_paramter)->error_code);
	assert_memory_equal(packet->data, ((notify_parameter_error *)testfunction_paramter)->packet->data, 128);
	free_packet_buffer_pool_entry(((notify_parameter_error *)testfunction_paramter)->packet);
 free_testfunction_paramter(&testfunction_paramter);
 free_packet_buffer_pool_entry(packet);
}

static void
test_register_notify_handler_to_controller() {

	assert_int_equal(OFDPE_FAILED,
				register_notify_handler_to_controller( 0xFFFFFFFF, testfunction_notify_error ));
	assert_true(controller.handlers.notify_errors == NULL);

	assert_int_equal(OFDPE_SUCCESS,
			register_notify_handler_to_controller( NOTIFY_TYPE_PACKET_IN, testfunction_notify_packet_in ));
	assert_true(controller.handlers.notify_packet_in == testfunction_notify_packet_in);
	assert_int_equal(OFDPE_SUCCESS,
			register_notify_handler_to_controller( NOTIFY_TYPE_FLOW_REMOVED, testfunction_notify_flow_removed ));
	assert_true(controller.handlers.notify_flow_removed == testfunction_notify_flow_removed);
	assert_int_equal(OFDPE_SUCCESS,
			register_notify_handler_to_controller( NOTIFY_TYPE_PORT_STATUS, testfunction_notify_port_status ));
	assert_true(controller.handlers.notify_port_status == testfunction_notify_port_status);
	assert_int_equal(OFDPE_SUCCESS,
			register_notify_handler_to_controller( NOTIFY_TYPE_ERROR, testfunction_notify_error ));
	assert_true(controller.handlers.notify_errors == testfunction_notify_error);
}

static void
test_get_packet_buffer() {

	buffer* result_packet = NULL;
	assert_true(OFDPE_FAILED == get_packet_buffer(1, &result_packet));

	init_mutex(&controller.packet_in_buffer.mutex);
	controller.packet_in_buffer.list = NULL;
	controller.packet_in_buffer.max = 3;

	assert_true(OFDPE_FAILED == get_packet_buffer( 1, &result_packet ));
	assert_true(result_packet == NULL);

	packet_in_buffer_element* element[3];
	element[0] = xmalloc(sizeof(packet_in_buffer_element));
	element[1] = xmalloc(sizeof(packet_in_buffer_element));
	element[2] = xmalloc(sizeof(packet_in_buffer_element));
	element[0]->buffer_id = 1;
	element[1]->buffer_id = 2;
	element[2]->buffer_id = 3;

	buffer* packet[3];
	packet[0] = allocate_packet_buffer();
	packet[1] = allocate_packet_buffer();
	packet[2] = allocate_packet_buffer();

	element[0]->packet = packet[0];
	element[1]->packet = packet[1];
	element[2]->packet = packet[2];

	append_to_tail(&controller.packet_in_buffer.list, element[0]);
	append_to_tail(&controller.packet_in_buffer.list, element[1]);
	append_to_tail(&controller.packet_in_buffer.list, element[2]);

	assert_int_equal(OFDPE_SUCCESS, get_packet_buffer( 2, &result_packet ));
	assert_memory_equal(packet[1], result_packet, sizeof(buffer));
	delete_element(&controller.packet_in_buffer.list, controller.packet_in_buffer.list->data);
	delete_element(&controller.packet_in_buffer.list, controller.packet_in_buffer.list->data);
	free_packet_buffer_pool_entry(packet[0]);
	free_packet_buffer_pool_entry(packet[1]);
	free_packet_buffer_pool_entry(packet[2]);
	xfree(element[0]);
	// free in function
	//xfree(element[1]);
	xfree(element[2]);
}

static void
test_append_external_message() {

	external_message *message[3];
	message[0] = xmalloc(sizeof(external_message));
	message[1] = xmalloc(sizeof(external_message));
	message[2] = xmalloc(sizeof(external_message));

	assert_int_equal(	ERROR_LOCK, append_external_message(message[0]) );

	assert_true(init_mutex(&controller.external.mutex));
	controller.external.list = NULL;
	controller.external.max = 3;

	external_message_add_port* message_add_port[3];
	message_add_port[0] = xmalloc(sizeof(external_message_add_port));
	message_add_port[1] = xmalloc(sizeof(external_message_add_port));
	message_add_port[2] = xmalloc(sizeof(external_message_add_port));
	message_add_port[0]->device_info.port_no = 1;
	message_add_port[1]->device_info.port_no = 2;
	message_add_port[2]->device_info.port_no = 3;

	message[0]->parameter = message_add_port[0];
	message[1]->parameter = message_add_port[1];
	message[2]->parameter = message_add_port[2];
	assert_int_equal(	OFDPE_SUCCESS, append_external_message(message[0]) );
	assert_int_equal( 1, list_length_of(controller.external.list) );
	assert_memory_equal(message[0], controller.external.list->data, sizeof(external_message));
	assert_int_equal(	OFDPE_SUCCESS, append_external_message(message[1]) );
	assert_int_equal( 2, list_length_of(controller.external.list) );
	assert_memory_equal(message[1], controller.external.list->next->data, sizeof(external_message));
	assert_int_equal(	OFDPE_SUCCESS, append_external_message(message[2]) );
	assert_int_equal( 3, list_length_of(controller.external.list) );
	assert_memory_equal(message[2], controller.external.list->next->next->data, sizeof(external_message));

	delete_element(&controller.external.list, controller.external.list->data);
	delete_element(&controller.external.list, controller.external.list->data);
	delete_element(&controller.external.list, controller.external.list->data);

	xfree(message[0]);
	xfree(message[1]);
	xfree(message[2]);
	xfree(message_add_port[0]);
	xfree(message_add_port[1]);
	xfree(message_add_port[2]);
}

static void
test_add_port() {
  get_library_status = mock_get_library_status;

	assert_int_equal(	OFDPE_FAILED, add_port(1, "eth0") );

	assert_true(init_mutex(&controller.external.mutex));
	controller.external.list = NULL;
	controller.external.max = 3;

	assert_int_equal(	OFDPE_SUCCESS, add_port(1, "eth0") );
	assert_int_equal( 1, list_length_of(controller.external.list) );
	external_message *message = controller.external.list->data;
	assert_int_equal( external_message_type_port_add, message->type );
	external_message_add_port *message_add_port = message->parameter;
	assert_int_equal( 1, message_add_port->device_info.port_no );
	assert_string_equal( "eth0", message_add_port->device_info.device_name );

	assert_int_equal(	OFDPE_SUCCESS, add_port(2, "eth1") );
	assert_int_equal( 2, list_length_of(controller.external.list) );
	message = controller.external.list->next->data;
	assert_int_equal( external_message_type_port_add, message->type );
	message_add_port = message->parameter;
	assert_int_equal( 2, message_add_port->device_info.port_no );
	assert_string_equal( "eth1", message_add_port->device_info.device_name );

	message = controller.external.list->data;
	delete_element(&controller.external.list, message);
	xfree(message->parameter);
	xfree(message);
	message = controller.external.list->data;
	delete_element(&controller.external.list, message);
	xfree(message->parameter);
	xfree(message);
}

static void
test_delete_port() {
	assert_int_equal(	OFDPE_FAILED, delete_port(1) );

	assert_true(init_mutex(&controller.external.mutex));
	controller.external.list = NULL;
	controller.external.max = 3;

	assert_int_equal(	OFDPE_SUCCESS, delete_port(3) );
	assert_int_equal( 1, list_length_of(controller.external.list) );
	external_message *message = controller.external.list->data;
	assert_int_equal( external_message_type_port_delete, message->type );
	external_message_delete_port *message_delete_port = message->parameter;
	assert_int_equal( 3, message_delete_port->port_no );

	assert_int_equal(	OFDPE_SUCCESS, delete_port(1) );
	assert_int_equal( 2, list_length_of(controller.external.list) );
	message = controller.external.list->next->data;
	assert_int_equal( external_message_type_port_delete, message->type );
	message_delete_port = message->parameter;
	assert_int_equal( 1, message_delete_port->port_no );

	message = controller.external.list->data;
	delete_element(&controller.external.list, message);
	xfree(message->parameter);
	xfree(message);
	message = controller.external.list->data;
	delete_element(&controller.external.list, message);
	xfree(message->parameter);
	xfree(message);
}

static void
test_execute_external_message() {
	execute_external_message();
	assert_int_equal(0, count_of_called_mock_init_device);
	assert_int_equal(0, count_of_called_mock_finalize_device);

	external_message *message[4];
	external_message_add_port *message_add_port[2];
	external_message_delete_port *message_delete_port[2];

	message[0] = xmalloc(sizeof(external_message));
	message[1] = xmalloc(sizeof(external_message));
	message[2] = xmalloc(sizeof(external_message));
	message[3] = xmalloc(sizeof(external_message));

	message_add_port[0] = xmalloc(sizeof(external_message_add_port));
	memcpy(message_add_port[0]->device_info.device_name, "eth0",
					sizeof(message_add_port[0]->device_info.device_name));
	message_add_port[0]->device_info.port_no = 1;
	message_add_port[1] = xmalloc(sizeof(external_message_add_port));
	memcpy(message_add_port[0]->device_info.device_name, "eth1",
					sizeof(message_add_port[0]->device_info.device_name));
	message_add_port[0]->device_info.port_no = 5;

	message_delete_port[0] = xmalloc(sizeof(external_message_delete_port));
	message_delete_port[0]->port_no = 2;
	message_delete_port[1] = xmalloc(sizeof(external_message_delete_port));
	message_delete_port[0]->port_no = 1;

	message[0]->type = external_message_type_port_add;
	message[0]->parameter = message_add_port[0];
	message[1]->type = external_message_type_port_delete;
	message[1]->parameter = message_delete_port[0];
	message[2]->type = external_message_type_port_delete;
	message[2]->parameter = message_delete_port[1];
	message[3]->type = external_message_type_port_add;
	message[3]->parameter = message_add_port[1];

	assert_true(init_mutex(&controller.external.mutex));
	controller.external.list = NULL;
	controller.external.max = 4;

	append_to_tail(&controller.external.list, message[0]);
	append_to_tail(&controller.external.list, message[1]);
	append_to_tail(&controller.external.list, message[2]);
	append_to_tail(&controller.external.list, message[3]);

	execute_external_message();

	assert_int_equal(2, count_of_called_mock_init_device);
	assert_int_equal(2, count_of_called_mock_finalize_device);
}

/******************************************************************************
 * Run tests.
 ******************************************************************************/

int
controller_manager_main() {
  UnitTest tests[] = {

    unit_test_setup_teardown( test_get_packet_in_buffer_id, controller_managet_setup, controller_managet_teardown ),
    unit_test_setup_teardown( test_create_packet_in_buffer_element, controller_managet_setup, controller_managet_teardown ),
    unit_test_setup_teardown( test_append_packet_in_buffer, controller_managet_setup, controller_managet_teardown ),
    unit_test_setup_teardown( test_duplicate_parameter_memory, controller_managet_setup, controller_managet_teardown ),
    unit_test_setup_teardown( test_duplicate_parameter, controller_managet_setup, controller_managet_teardown ),
    unit_test_setup_teardown( test_init_data_list, controller_managet_setup, controller_managet_teardown ),
    unit_test_setup_teardown( test_finalize_packet_in_buffer_data_list, controller_managet_setup, controller_managet_teardown ),
    unit_test_setup_teardown( test_finalize_external_data_list, controller_managet_setup, controller_managet_teardown ),
    unit_test_setup_teardown( test_initialize_controller_manager, controller_managet_setup, controller_managet_teardown ),
    unit_test_setup_teardown( test_finalize_controller_manager, controller_managet_setup, controller_managet_teardown ),
    unit_test_setup_teardown( test_notify_packet_in, controller_managet_setup, controller_managet_teardown ),
    unit_test_setup_teardown( test_notify_flow_removed, controller_managet_setup, controller_managet_teardown ),
    unit_test_setup_teardown( test_notify_port_status, controller_managet_setup, controller_managet_teardown ),
    unit_test_setup_teardown( test_notify_error, controller_managet_setup, controller_managet_teardown ),
    unit_test_setup_teardown( test_register_notify_handler_to_controller, controller_managet_setup, controller_managet_teardown ),
    unit_test_setup_teardown( test_get_packet_buffer, controller_managet_setup, controller_managet_teardown ),
    unit_test_setup_teardown( test_append_external_message, controller_managet_setup, controller_managet_teardown ),
    unit_test_setup_teardown( test_add_port, controller_managet_setup, controller_managet_teardown ),
    unit_test_setup_teardown( test_delete_port, controller_managet_setup, controller_managet_teardown ),
    unit_test_setup_teardown( test_execute_external_message, controller_managet_setup, controller_managet_teardown ),

  };
  return run_tests( tests );
}



/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
