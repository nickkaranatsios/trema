#include "cmockery_trema.h"
#include "packet_buffer_pool.h"

#define POOL_SIZE	2
#define ALLOC_SIZE 0x000f

extern int get_free_list_count();

/********************************************************************************
 * Tests.
 ********************************************************************************/

static void
test_init_packet_buffer_pool() {
	assert_true( init_packet_buffer_pool(POOL_SIZE, ALLOC_SIZE) == OFDPE_SUCCESS );
	assert_true( get_free_list_count() == POOL_SIZE );
	finalize_packet_buffer_pool();

	assert_true( init_packet_buffer_pool(0, ALLOC_SIZE) == ERROR_ILLIGAL_PARAMETER );

	assert_true( init_packet_buffer_pool(POOL_SIZE, 0) == ERROR_ILLIGAL_PARAMETER );

}

static void
test_finalize_packet_buffer_pool() {
	init_packet_buffer_pool(POOL_SIZE, ALLOC_SIZE);
	assert_true( get_free_list_count() == POOL_SIZE );
	assert_true( finalize_packet_buffer_pool() == OFDPE_SUCCESS );
}

static void
test_alloc_packet_buffer_pool_entry() {
	init_packet_buffer_pool(POOL_SIZE, ALLOC_SIZE);
	buffer *buf = NULL;

	buf = allocate_packet_buffer_pool_entry(0x0001);
	assert_true( buf != NULL );
	assert_true( buf->data != NULL );
	assert_true( buf->length = 0x0001 );
	assert_true( get_free_list_count() == (POOL_SIZE - 1));
	free_packet_buffer_pool_entry(buf);
	assert_true( get_free_list_count() == POOL_SIZE );

	buf = allocate_packet_buffer_pool_entry(0x000e);
	assert_true( buf != NULL );
	assert_true( buf->data != NULL );
	assert_true( buf->length = 0x000e );
	assert_true( get_free_list_count() == (POOL_SIZE - 1));
	free_packet_buffer_pool_entry(buf);
	assert_true( get_free_list_count() == POOL_SIZE );

	buf = allocate_packet_buffer_pool_entry(0x000f);
	assert_true( buf != NULL );
	assert_true( buf->data != NULL );
	assert_true( buf->length = 0x000f );
	assert_true( get_free_list_count() == (POOL_SIZE - 1));
	free_packet_buffer_pool_entry(buf);
	assert_true( get_free_list_count() == POOL_SIZE );

	buf = allocate_packet_buffer_pool_entry(0x0010);
	assert_true( buf == NULL );
	assert_true( get_free_list_count() == POOL_SIZE );

	buf = allocate_packet_buffer_pool_entry(0xffff);
	assert_true( buf == NULL );
	assert_true( get_free_list_count() == POOL_SIZE );

	buf = allocate_packet_buffer_pool_entry(0);
	assert_true( buf == NULL );
	assert_true( get_free_list_count() == POOL_SIZE );

	buffer *buf_arr[POOL_SIZE];
	for(int i = 0; i < POOL_SIZE; i++) {
		buf_arr[i] = allocate_packet_buffer_pool_entry(i + 1);
		assert_true( buf_arr[i] != NULL );
		assert_true( (buf_arr[i])->length = (i + 1));
		assert_true( get_free_list_count() == (POOL_SIZE - i - 1));
	}
	for(int i = 0; i < POOL_SIZE; i++) {
		free_packet_buffer_pool_entry(buf_arr[i]);
	}

	finalize_packet_buffer_pool();
}

static void
test_free_packet_buffer_pool_entry() {
	init_packet_buffer_pool(POOL_SIZE, ALLOC_SIZE);
	buffer *buf = NULL;

	buf = allocate_packet_buffer_pool_entry(0x0001);
	assert_true( buf != NULL );
	assert_true( buf->data != NULL );
	assert_true( buf->length = 0x0001 );
	assert_true( get_free_list_count() == (POOL_SIZE - 1));
	assert_true( free_packet_buffer_pool_entry(buf) == OFDPE_SUCCESS );
	assert_true( get_free_list_count() == POOL_SIZE );

	finalize_packet_buffer_pool();

	assert_true( free_packet_buffer_pool_entry(NULL) == ERROR_ILLIGAL_PARAMETER );
}

/********************************************************************************
 * Run tests.
 ********************************************************************************/

int
packet_buffer_pool_main() {
  const UnitTest tests[] = {
		    unit_test( test_init_packet_buffer_pool ),
		    unit_test( test_finalize_packet_buffer_pool ),
		    unit_test( test_alloc_packet_buffer_pool_entry ),
		    unit_test( test_free_packet_buffer_pool_entry ),
  };
  setup_leak_detector();
  return run_tests( tests );
}
