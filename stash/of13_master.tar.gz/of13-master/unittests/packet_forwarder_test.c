#include "cmockery_trema.h"
#include "packet_forwarder.h"
#include "wrapper.h"
#include "table_manager.h"
#include "packet_buffer_pool.h"

#define POOL_SIZE	2
#define ALLOC_SIZE 0x000f

typedef struct processing_request_entry {
	switch_port *port;
	buffer *parsed_buf;
} processing_request_entry;

extern processing_request_entry *(*dequeue_processing_list)(void);
extern unsigned int (*length_of_processing_list)(void);
extern void (*execute_processing)( switch_port *port, buffer *parsed_buf );

static void mock_execute_processing(switch_port *port, buffer *parsed_buf) {
	(void)port;
	(void)parsed_buf;
	return;
}

/********************************************************************************
 * Tests.
 ********************************************************************************/

static void
test_init_packet_forwarder() {
	assert_true( init_packet_forwarder() == OFDPE_SUCCESS );
	finalize_packet_forwarder();
}

static void
test_finalize_packet_forwarder() {
	init_packet_forwarder();
	assert_true( finalize_packet_forwarder() == OFDPE_SUCCESS );
}

static void
test_accept_recv_data() {
	init_packet_buffer_pool(POOL_SIZE, ALLOC_SIZE);
	init_packet_forwarder();
	init_table_manager();

	execute_processing = mock_execute_processing;

	switch_port port;
	port.port_no = 1;
	buffer *buf = allocate_packet_buffer();
	assert_true( accept_recv_data(&port, buf) == OFDPE_SUCCESS );

	assert_true( accept_recv_data(NULL, buf) == ERROR_ILLIGAL_PARAMETER );
	assert_true( accept_recv_data(&port, NULL) == ERROR_ILLIGAL_PARAMETER );
	assert_true( accept_recv_data(NULL, NULL) == ERROR_ILLIGAL_PARAMETER );

	finalize_packet_buffer_pool();
	finalize_table_manager();
	finalize_packet_forwarder();
}

static void
test_enqueue_head_recv_data() {
	init_packet_forwarder();

	assert_true( length_of_processing_list() == 0 );

	switch_port port01;
	port01.port_no = 1;
	buffer buf;
	assert_true( enqueue_head_recv_data(&port01, &buf) == OFDPE_SUCCESS );
	assert_true( length_of_processing_list() == 1 );

	switch_port port02;
	port02.port_no = 2;
	assert_true( enqueue_head_recv_data(&port02, &buf) == OFDPE_SUCCESS );
	assert_true( length_of_processing_list() == 2 );


	processing_request_entry *entry;

	entry = dequeue_processing_list();
	assert_true( entry->port->port_no == port02.port_no );
	xfree(entry);
	assert_true( length_of_processing_list() == 1 );

	entry = dequeue_processing_list();
	assert_true( entry->port->port_no == port01.port_no );
	xfree(entry);
	assert_true( length_of_processing_list() == 0 );


	switch_port port;

	assert_true( enqueue_head_recv_data(NULL, &buf) == ERROR_ILLIGAL_PARAMETER );
	assert_true( length_of_processing_list() == 0 );

	assert_true( enqueue_head_recv_data(&port, NULL) == ERROR_ILLIGAL_PARAMETER );
	assert_true( length_of_processing_list() == 0 );

	assert_true( enqueue_head_recv_data(NULL, NULL) == ERROR_ILLIGAL_PARAMETER );
	assert_true( length_of_processing_list() == 0 );

	finalize_packet_forwarder();

	assert_true( length_of_processing_list() == 0 );
}

/********************************************************************************
 * Run tests.
 ********************************************************************************/

int
packet_forwarder_main() {
  const UnitTest tests[] = {
		    unit_test( test_init_packet_forwarder ),
		    unit_test( test_finalize_packet_forwarder ),
		    unit_test( test_accept_recv_data ),
		    unit_test( test_enqueue_head_recv_data ),
  };
  setup_leak_detector();
  return run_tests( tests );
}
