/*
 * Unit tests for Packet Matcher methods.
 * 
 *  Created on: 2012/08/17
 *      Author: kitajima
 */

#include <setjmp.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "ofdp_common.h"
#include "cmockery_trema.h"
#include "table_manager.h"
#include "packet_matcher_private.h"
#include "log.h"
#include "trema_wrapper.h"
#include "test_util.h"

/********************************************************************************
 * Setup and teardown
 ********************************************************************************/

static void
(*original_critical)(const char *format, ...);

static void
mock_critical(const char *format, ...)
{
  char output[256];
  va_list args;
  va_start( args, format);
  vsprintf(output, format, args);
  va_end( args);
  check_expected( output);
}

static void
(*original_abort)(void);

static void
stub_abort()
{
  // Do nothing.
}

static void
setup()
{
  original_critical = critical;
  critical = mock_critical;

  original_abort = abort;
  trema_abort = stub_abort;
}

static void
teardown()
{
  critical = original_critical;
  trema_abort = original_abort;
}



/********************************************************************************
 * Tests for match packet -> match Utility Functions
 ********************************************************************************/

static void
test_match_packet_8_match()
{
  uint8_t packet;
  match8 match;

  srand((unsigned) time(NULL ));
  packet = uint8_rand();
  match.valid = false;
  assert_true(match_packet_8_to_match(packet, match));

  packet = -1;
  match.valid = true;
  assert_false(match_packet_8_to_match(packet, match));

  for (int i = 0; i < 16; i++)
    {
      packet = uint8_rand();
      match.mask = uint8_rand();
      match.value = uint8_rand();
      match.valid = true;
      assert_true(
          match_packet_8_to_match(packet, match) == ((packet & match.mask) == (match.value & match.mask)));
      match.value = packet;
      assert_true(
          match_packet_8_to_match(packet, match) == ((packet & match.mask) == (match.value & match.mask)));
    }
}

static void
test_match_packet_16_match()
{
  uint16_t packet;
  match16 match;

  srand((unsigned) time(NULL ));
  packet = uint16_rand();
  match.valid = false;
  assert_true(match_packet_16_to_match(packet, match));

  packet = -1;
  match.valid = true;
  assert_false(match_packet_16_to_match(packet, match));

  for (int i = 0; i < 16; i++)
    {
      packet = (rand()) & ULONG_MAX;
      match.mask = (rand()) & ULONG_MAX;
      match.value = (rand()) & ULONG_MAX;
      match.valid = true;
      assert_true(
          match_packet_16_to_match(packet, match) == ((packet & match.mask) == (match.value & match.mask)));
      match.value = packet;
      assert_true(
          match_packet_16_to_match(packet, match) == ((packet & match.mask) == (match.value & match.mask)));
    }
}

static void
test_match_packet_32_match()
{
  uint32_t packet;
  match32 match;

  srand((unsigned) time(NULL ));
  packet = uint32_rand();
  match.valid = false;
  assert_true(match_packet_32_to_match(packet, match));

  packet = -1;
  match.valid = true;
  assert_false(match_packet_32_to_match(packet, match));

  for (int i = 0; i < 16; i++)
    {
      packet = uint32_rand();
      match.mask = uint32_rand();
      match.value = uint32_rand();
      match.valid = true;
      assert_true(
          match_packet_32_to_match(packet, match) == ((packet & match.mask) == (match.value & match.mask)));
      match.value = packet;
      assert_true(
          match_packet_32_to_match(packet, match) == ((packet & match.mask) == (match.value & match.mask)));
    }
}

static void
test_match_packet_64_match()
{
  uint64_t packet;
  match64 match;

  srand((unsigned) time(NULL ));
  packet = uint64_rand();
  match.valid = false;
  assert_true(match_packet_64_to_match(packet, match));

  packet = -1;
  match.valid = true;
  assert_false(match_packet_64_to_match(packet, match));

  for (int i = 0; i < 16; i++)
    {
      packet = uint64_rand();
      match.mask = uint64_rand();
      match.value = uint64_rand();
      match.valid = true;
      assert_true(
          match_packet_64_to_match(packet, match) == ((packet & match.mask) == (match.value & match.mask)));
      match.value = packet;
      assert_true(
          match_packet_64_to_match(packet, match) == ((packet & match.mask) == (match.value & match.mask)));
    }
}

/********************************************************************************
 * Tests for match match -> match Utility Functions
 ********************************************************************************/

static void
test_match_match_8_match()
{
  match8 x;
  match8 y;

  srand((unsigned) time(NULL ));
  x.mask = uint8_rand();
  x.value = uint8_rand();
  y.mask = uint8_rand();
  y.value = uint8_rand();

  x.valid = true;
  y.valid = false;
  assert_true(match_match_8_to_match(x, y));

  x.valid = false;
  y.valid = false;
  assert_true(match_match_8_to_match(x, y));

  x.valid = false;
  y.valid = true;
  assert_false(match_match_8_to_match(x, y));

  x.valid = true;
  y.valid = true;

  for (int i = 0; i < 16; i++)
    {
      do
        {
          x.mask = uint8_rand();
        }
      while (x.mask == UCHAR_MAX);
      y.mask = x.mask & (rand() & UCHAR_MAX);
      x.value = uint8_rand();
      y.value = uint8_rand();
      assert_true(
          match_match_8_to_match(x, y) == ((x.value & y.mask) == (y.value & y.mask)));
      y.value = x.value;
      assert_true(
          match_match_8_to_match(x, y) == ((x.value & y.mask) == (y.value & y.mask)));
      y.value = uint8_rand();
      do
        {
          y.mask = uint8_rand();
        }
      while ((x.mask & y.mask) == y.mask);
      assert_false(match_match_8_to_match(x, y));
      y.value = x.value;
      assert_false(match_match_8_to_match(x, y));
    }
}

static void
test_match_match_16_match()
{
  match16 x;
  match16 y;

  srand((unsigned) time(NULL ));
  x.mask = uint16_rand();
  x.value = uint16_rand();
  y.mask = uint16_rand();
  y.value = uint16_rand();

  x.valid = true;
  y.valid = false;
  assert_true(match_match_16_to_match(x, y));

  x.valid = false;
  y.valid = false;
  assert_true(match_match_16_to_match(x, y));

  x.valid = false;
  y.valid = true;
  assert_false(match_match_16_to_match(x, y));

  x.valid = true;
  y.valid = true;

  for (int i = 0; i < 16; i++)
    {
      do
        {
          x.mask = uint16_rand();
        }
      while (x.mask == UINT_MAX);
      y.mask = x.mask & (rand() & UINT_MAX);
      x.value = uint16_rand();
      y.value = uint16_rand();
      assert_true(
          match_match_16_to_match(x, y) == ((x.value & y.mask) == (y.value & y.mask)));
      y.value = x.value;
      assert_true(
          match_match_16_to_match(x, y) == ((x.value & y.mask) == (y.value & y.mask)));
      y.value = uint16_rand();
      do
        {
          y.mask = uint16_rand();
        }
      while ((x.mask & y.mask) == y.mask);
      assert_false(match_match_16_to_match(x, y));
      y.value = x.value;
      assert_false(match_match_16_to_match(x, y));
    }
}
static void
test_match_match_32_match()
{
  match32 x;
  match32 y;

  srand((unsigned) time(NULL ));
  x.mask = uint32_rand();
  x.value = uint32_rand();
  y.mask = uint32_rand();
  y.value = uint32_rand();

  x.valid = true;
  y.valid = false;
  assert_true(match_match_32_to_match(x, y));

  x.valid = false;
  y.valid = false;
  assert_true(match_match_32_to_match(x, y));

  x.valid = false;
  y.valid = true;
  assert_false(match_match_32_to_match(x, y));

  x.valid = true;
  y.valid = true;

  for (int i = 0; i < 16; i++)
    {
      do
        {
          x.mask = uint32_rand();
        }
      while (x.mask == ULONG_MAX);
      y.mask = x.mask & uint32_rand();
      x.value = uint32_rand();
      y.value = uint32_rand();
      assert_true(
          match_match_32_to_match(x, y) == ((x.value & y.mask) == (y.value & y.mask)));
      y.value = x.value;
      assert_true(
          match_match_32_to_match(x, y) == ((x.value & y.mask) == (y.value & y.mask)));
      y.value = uint32_rand();
      do
        {
          y.mask = uint32_rand();
        }
      while ((x.mask & y.mask) == y.mask);
      assert_false(match_match_32_to_match(x, y));
      y.value = x.value;
      assert_false(match_match_32_to_match(x, y));
    }
}

static void
test_match_match_64_match()
{
  match64 x;
  match64 y;

  srand((unsigned) time(NULL ));
  x.mask = uint64_rand();
  x.value = uint64_rand();
  y.mask = uint64_rand();
  y.value = uint64_rand();

  x.valid = true;
  y.valid = false;
  assert_true(match_match_64_to_match(x, y));

  x.valid = false;
  y.valid = false;
  assert_true(match_match_64_to_match(x, y));

  x.valid = false;
  y.valid = true;
  assert_false(match_match_64_to_match(x, y));

  x.valid = true;
  y.valid = true;

  for (int i = 0; i < 16; i++)
    {
      do
        {
          x.mask = uint64_rand();
        }
      while (x.mask == ULLONG_MAX);
      y.mask = x.mask & uint64_rand();
      x.value = uint64_rand();
      y.value = uint64_rand();
      assert_true(
          match_match_64_to_match(x, y) == ((x.value & y.mask) == (y.value & y.mask)));
      y.value = x.value;
      assert_true(
          match_match_64_to_match(x, y) == ((x.value & y.mask) == (y.value & y.mask)));
      y.value = uint64_rand();
      do
        {
          y.mask = uint64_rand();
        }
      while ((x.mask & y.mask) == y.mask);
      assert_false(match_match_64_to_match(x, y));
      y.value = x.value;
      assert_false(match_match_64_to_match(x, y));
    }
}

/********************************************************************************
 * Tests for compare match -> match Utility Functions
 ********************************************************************************/

static void
test_compare_match_8_match()
{
  match8 x;
  match8 y;

  srand((unsigned) time(NULL ));
  x.mask = uint8_rand();
  x.value = uint8_rand();
  y.mask = uint8_rand();//  (*match)->wildcards |= ( 4 << OFPFW_NW_DST_SHIFT );

  y.value = uint8_rand();

  x.valid = true;
  y.valid = false;
  assert_false(compare_match_8_to_match(x, y));

  x.valid = false;
  y.valid = false;
  assert_true(compare_match_8_to_match(x, y));

  x.valid = false;
  y.valid = true;
  assert_false(compare_match_8_to_match(x, y));

  x.valid = true;
  y.valid = true;

  for (int i = 0; i < 16; i++)
    {
      x.mask = uint8_rand();
      y.mask = x.mask;
      x.value = uint8_rand();
      y.value = uint8_rand();
      assert_true(
          compare_match_8_to_match(x, y) == ((x.value & x.mask) == (y.value & y.mask)));
      y.value = x.value;
      assert_true(
          compare_match_8_to_match(x, y) == ((x.value & x.mask) == (y.value & y.mask)));
      y.value = uint8_rand();
      do
        {
          y.mask = uint8_rand();
        }
      while (x.mask == y.mask);
      assert_false(compare_match_8_to_match(x, y));
      y.value = x.value;
      assert_false(compare_match_8_to_match(x, y));
    }
}

static void
test_compare_match_16_match()
{
  match16 x;
  match16 y;

  srand((unsigned) time(NULL ));
  x.mask = uint16_rand();
  x.value = uint16_rand();
  y.mask = uint16_rand();
  y.value = uint16_rand();

  x.valid = true;
  y.valid = false;
  assert_false(compare_match_16_to_match(x, y));

  x.valid = false;
  y.valid = false;
  assert_true(compare_match_16_to_match(x, y));

  x.valid = false;
  y.valid = true;
  assert_false(compare_match_16_to_match(x, y));

  x.valid = true;
  y.valid = true;

  for (int i = 0; i < 16; i++)
    {
      x.mask = uint16_rand();
      y.mask = x.mask;
      x.value = uint16_rand();
      y.value = uint16_rand();
      assert_true(
          compare_match_16_to_match(x, y) == ((x.value & x.mask) == (y.value & y.mask)));
      y.value = x.value;
      assert_true(
          compare_match_16_to_match(x, y) == ((x.value & x.mask) == (y.value & y.mask)));
      y.value = uint16_rand();
      do
        {
          y.mask = uint16_rand();
        }
      while (x.mask == y.mask);
      assert_false(compare_match_16_to_match(x, y));
      y.value = x.value;
      assert_false(compare_match_16_to_match(x, y));
    }
}
static void
test_compare_match_32_match()
{
  match32 x;
  match32 y;

  srand((unsigned) time(NULL ));
  x.mask = uint32_rand();
  x.value = uint32_rand();
  y.mask = uint32_rand();
  y.value = uint32_rand();

  x.valid = true;
  y.valid = false;
  assert_false(compare_match_32_to_match(x, y));

  x.valid = false;
  y.valid = false;
  assert_true(compare_match_32_to_match(x, y));

  x.valid = false;
  y.valid = true;
  assert_false(compare_match_32_to_match(x, y));

  x.valid = true;
  y.valid = true;

  for (int i = 0; i < 16; i++)
    {
      x.mask = uint32_rand();
      y.mask = x.mask;
      x.value = uint32_rand();
      y.value = uint32_rand();
      assert_true(
          compare_match_32_to_match(x, y) == ((x.value & x.mask) == (y.value & y.mask)));
      y.value = x.value;
      assert_true(
          compare_match_32_to_match(x, y) == ((x.value & x.mask) == (y.value & y.mask)));
      y.value = uint32_rand();
      do
        {
          y.mask = uint32_rand();
        }
      while (x.mask == y.mask);
      assert_false(compare_match_32_to_match(x, y));
      y.value = x.value;
      assert_false(compare_match_32_to_match(x, y));
    }
}

static void
test_compare_match_64_match()
{
  match64 x;
  match64 y;

  srand((unsigned) time(NULL ));
  x.mask = uint64_rand();
  x.value = uint64_rand();
  y.mask = uint64_rand();
  y.value = uint64_rand();

  x.valid = true;
  y.valid = false;
  assert_false(compare_match_64_to_match(x, y));

  x.valid = false;
  y.valid = false;
  assert_true(compare_match_64_to_match(x, y));

  x.valid = false;
  y.valid = true;
  assert_false(compare_match_64_to_match(x, y));

  x.valid = true;
  y.valid = true;

  for (int i = 0; i < 16; i++)
    {
      x.mask = uint64_rand();
      y.mask = x.mask;
      x.value = uint64_rand();
      y.value = uint64_rand();
      assert_true(
          compare_match_64_to_match(x, y) == ((x.value & x.mask) == (y.value & y.mask)));
      y.value = x.value;
      assert_true(
          compare_match_64_to_match(x, y) == ((x.value & x.mask) == (y.value & y.mask)));
      y.value = uint64_rand();
      do
        {
          y.mask = uint64_rand();
        }
      while (x.mask == y.mask);
      assert_false(compare_match_64_to_match(x, y));
      y.value = x.value;
      assert_false(compare_match_64_to_match(x, y));
    }
}

/********************************************************************************
 * Tests for Packet Matcher
 ********************************************************************************/

static void
packet_initializer(packet_info * packet)
{
  memset(packet, 0, sizeof(packet_info));
}

static void
packet_randomizer(packet_info * packet)
{
  packet->arp_ar_op = uint16_rand();
  for (int i = 0; i < ETH_ADDRLEN; i++)
    {
      packet->arp_sha[i] = uint8_rand();
    }
  packet->arp_spa = uint32_rand();
  for (int i = 0; i < ETH_ADDRLEN; i++)
    {
      packet->arp_tha[i] = uint8_rand();
    }
  packet->arp_tpa = uint32_rand();
  packet->eth_in_phy_port = uint32_rand();
  packet->eth_in_port = uint32_rand();
  for (int i = 0; i < ETH_ADDRLEN; i++)
    {
      packet->eth_macda[i] = uint8_rand();
    }
  for (int i = 0; i < ETH_ADDRLEN; i++)
    {
      packet->eth_macsa[i] = uint8_rand();
    }
  packet->eth_type = uint16_rand();
  packet->icmpv4_code = uint8_rand();
  packet->icmpv4_type = uint8_rand();
  packet->icmpv6_code = uint8_rand();
  packet->icmpv6_type = uint8_rand();
  packet->ip_dscp = uint8_rand();
  packet->ip_ecn = uint8_rand();
  packet->ip_proto = uint8_rand();
  packet->ipv4_daddr = uint32_rand();
  packet->ipv4_saddr = uint32_rand();
  for (int i = 0; i < IPV6_ADDRLEN; i++)
    {
      packet->ipv6_daddr[i] = uint8_rand();
    }
  packet->ipv6_exthdr = uint16_rand();
  packet->ipv6_flowlabel = uint32_rand();
  for (int i = 0; i < IPV6_LINK_LAYER_LEN; i++)
    {
      packet->ipv6_nd_sll[i] = uint8_rand();
    }
  for (int i = 0; i < IPV6_ADDRLEN; i++)
    {
      packet->ipv6_nd_target[i] = uint8_rand();
    }
  for (int i = 0; i < IPV6_LINK_LAYER_LEN; i++)
    {
      packet->ipv6_nd_tll[i] = uint8_rand();
    }
  for (int i = 0; i < IPV6_ADDRLEN; i++)
    {
      packet->ipv6_saddr[i] = uint8_rand();
    }
  packet->metadata = uint64_rand();
  packet->mpls_bos = uint8_rand();
  packet->mpls_label = uint32_rand();
  packet->mpls_tc = uint8_rand();
  packet->sctp_dst_port = uint16_rand();
  packet->sctp_src_port = uint16_rand();
  packet->tcp_dst_port = uint16_rand();
  packet->tcp_src_port = uint16_rand();
  packet->tunnel_id = uint64_rand();
  packet->udp_dst_port = uint16_rand();
  packet->udp_src_port = uint16_rand();
  packet->vlan_pcp = uint8_rand();
  packet->vlan_vid = uint16_rand();
}


static void
test_match_packet_match()
{
  packet_info packet;
  match match;

  packet_initializer(&packet);
  packet_randomizer(&packet);

  match_builder(&match, &packet);

  // Normal Pattern
  assert_true(match_packet_match(&packet, &match));

  // validation false test
  match.arp_op.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.arp_op.valid = true;
  match.arp_sha[0].valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.arp_sha[0].valid = true;
  match.arp_spa.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.arp_spa.valid = true;
  match.arp_tha[0].valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.arp_tha[0].valid = true;
  match.arp_tpa.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.arp_tpa.valid = true;
  match.in_phy_port.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.in_phy_port.valid = true;
  match.in_port.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.in_port.valid = true;
  match.eth_dst[0].valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.eth_dst[0].valid = true;
  match.eth_src[0].valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.eth_src[0].valid = true;
  match.eth_type.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.eth_type.valid = true;
  match.icmpv4_code.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.icmpv4_code.valid = true;
  match.icmpv4_type.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.icmpv4_type.valid = true;
  match.icmpv6_code.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.icmpv6_code.valid = true;
  match.icmpv6_type.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.icmpv6_type.valid = true;
  match.ip_dscp.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.ip_dscp.valid = true;
  match.ip_ecn.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.ip_ecn.valid = true;
  match.ip_proto.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.ip_proto.valid = true;
  match.ipv4_dst.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.ipv4_dst.valid = true;
  match.ipv4_src.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.ipv4_src.valid = true;
  match.ipv6_dst[0].valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.ipv6_dst[0].valid = true;
  match.ipv6_exthdr.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.ipv6_exthdr.valid = true;
  match.ipv6_flabel.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.ipv6_flabel.valid = true;
  match.ipv6_nd_sll[0].valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.ipv6_nd_sll[0].valid = true;
  match.ipv6_nd_target[0].valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.ipv6_nd_target[0].valid = true;
  match.ipv6_nd_tll[0].valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.ipv6_nd_tll[0].valid = true;
  match.ipv6_src[0].valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.ipv6_src[0].valid = true;
  match.metadata.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.metadata.valid = true;
  match.mpls_bos.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.mpls_bos.valid = true;
  match.mpls_label.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.mpls_label.valid = true;
  match.mpls_tc.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.mpls_tc.valid = true;
  match.sctp_dst.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.sctp_dst.valid = true;
  match.sctp_src.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.sctp_src.valid = true;
  match.tcp_dst.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.tcp_dst.valid = true;
  match.tcp_src.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.tcp_src.valid = true;
  match.tunnel_id.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.tunnel_id.valid = true;
  match.udp_dst.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.udp_dst.valid = true;
  match.udp_src.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.udp_src.valid = true;
  match.vlan_pcp.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.vlan_pcp.valid = true;
  match.vlan_vid.valid = false;
  assert_true(match_packet_match(&packet, &match));
  match.vlan_vid.valid = true;

// mask test: desired value = true
  match.arp_op.mask = uint16_rand();
  assert_true(match_packet_match(&packet, &match));
  match.arp_op.mask = -1;
  for (int i = 0; i < ETH_ADDRLEN; i++)
    {
      match.arp_sha[i].mask = uint8_rand();
      assert_true(match_packet_match(&packet, &match));
      match.arp_sha[i].mask = -1;
    }
  match.arp_spa.mask = uint32_rand();
  assert_true(match_packet_match(&packet, &match));
  match.arp_spa.mask = -1;
  for (int i = 0; i < ETH_ADDRLEN; i++)
    {
      match.arp_tha[i].mask = uint8_rand();
      assert_true(match_packet_match(&packet, &match));
      match.arp_tha[i].mask = -1;
    }
  match.arp_tpa.mask = uint32_rand();
  assert_true(match_packet_match(&packet, &match));
  match.arp_tpa.mask = -1;
  match.in_phy_port.mask = uint32_rand();
  assert_true(match_packet_match(&packet, &match));
  match.in_phy_port.mask = -1;
  match.in_port.mask = uint32_rand();
  assert_true(match_packet_match(&packet, &match));
  match.in_port.mask = -1;
  for (int i = 0; i < ETH_ADDRLEN; i++)
    {
      match.eth_dst[i].mask = uint8_rand();
      assert_true(match_packet_match(&packet, &match));
      match.eth_dst[i].mask = -1;
    }
  for (int i = 0; i < ETH_ADDRLEN; i++)
    {
      match.eth_src[i].mask = uint8_rand();
      assert_true(match_packet_match(&packet, &match));
      match.eth_src[i].mask = -1;
    }
  match.eth_type.mask = uint16_rand();
  assert_true(match_packet_match(&packet, &match));
  match.eth_type.mask = -1;
  match.icmpv4_code.mask = uint8_rand();
  assert_true(match_packet_match(&packet, &match));
  match.icmpv4_code.mask = -1;
  match.icmpv4_type.mask = uint8_rand();
  assert_true(match_packet_match(&packet, &match));
  match.icmpv4_type.mask = -1;
  match.icmpv6_code.mask = uint8_rand();
  assert_true(match_packet_match(&packet, &match));
  match.icmpv6_code.mask = -1;
  match.icmpv6_type.mask = uint8_rand();
  assert_true(match_packet_match(&packet, &match));
  match.icmpv6_type.mask = -1;
  match.ip_dscp.mask = uint8_rand();
  assert_true(match_packet_match(&packet, &match));
  match.ip_dscp.mask = -1;
  match.ip_ecn.mask = uint8_rand();
  assert_true(match_packet_match(&packet, &match));
  match.ip_ecn.mask = -1;
  match.ip_proto.mask = uint8_rand();
  assert_true(match_packet_match(&packet, &match));
  match.ip_proto.mask = -1;
  match.ipv4_dst.mask = uint32_rand();
  assert_true(match_packet_match(&packet, &match));
  match.ipv4_dst.mask = -1;
  match.ipv4_src.mask = uint32_rand();
  assert_true(match_packet_match(&packet, &match));
  match.ipv4_src.mask = -1;
  for (int i = 0; i < IPV6_ADDRLEN; i++)
    {
      match.ipv6_dst[i].mask = uint8_rand();
      assert_true(match_packet_match(&packet, &match));
      match.ipv6_dst[i].mask = -1;
    }
  match.ipv6_exthdr.mask = uint16_rand();
  assert_true(match_packet_match(&packet, &match));
  match.ipv6_exthdr.mask = -1;
  match.ipv6_flabel.mask = uint32_rand();
  assert_true(match_packet_match(&packet, &match));
  match.ipv6_flabel.mask = -1;
  for (int i = 0; i < IPV6_LINK_LAYER_LEN; i++)
    {
      match.ipv6_nd_sll[i].mask = uint8_rand();
      assert_true(match_packet_match(&packet, &match));
      match.ipv6_nd_sll[i].mask = -1;
    }
  for (int i = 0; i < IPV6_ADDRLEN; i++)
    {
      match.ipv6_nd_target[i].mask = uint8_rand();
      assert_true(match_packet_match(&packet, &match));
      match.ipv6_nd_target[i].mask = -1;
    }
  for (int i = 0; i < IPV6_LINK_LAYER_LEN; i++)
    {
      match.ipv6_nd_tll[i].mask = uint8_rand();
      assert_true(match_packet_match(&packet, &match));
      match.ipv6_nd_tll[i].mask = -1;
    }
  for (int i = 0; i < IPV6_ADDRLEN; i++)
    {
      match.ipv6_src[i].mask = uint8_rand();
      assert_true(match_packet_match(&packet, &match));
      match.ipv6_src[i].mask = -1;
    }
  match.metadata.mask = uint64_rand();
  assert_true(match_packet_match(&packet, &match));
  match.metadata.mask = -1;
  match.mpls_bos.mask = uint8_rand();
  assert_true(match_packet_match(&packet, &match));
  match.mpls_bos.mask = -1;
  match.mpls_label.mask = uint32_rand();
  assert_true(match_packet_match(&packet, &match));
  match.mpls_label.mask = -1;
  match.mpls_tc.mask = uint8_rand();
  assert_true(match_packet_match(&packet, &match));
  match.mpls_tc.mask = -1;
  match.sctp_dst.mask = uint16_rand();
  assert_true(match_packet_match(&packet, &match));
  match.sctp_dst.mask = -1;
  match.sctp_src.mask = uint16_rand();
  assert_true(match_packet_match(&packet, &match));
  match.sctp_src.mask = -1;
  match.tcp_dst.mask = uint16_rand();
  assert_true(match_packet_match(&packet, &match));
  match.tcp_dst.mask = -1;
  match.tcp_src.mask = uint16_rand();
  assert_true(match_packet_match(&packet, &match));
  match.tcp_src.mask = -1;
  match.tunnel_id.mask = uint64_rand();
  assert_true(match_packet_match(&packet, &match));
  match.tunnel_id.mask = -1;
  match.udp_dst.mask = uint16_rand();
  assert_true(match_packet_match(&packet, &match));
  match.udp_dst.mask = -1;
  match.udp_src.mask = uint16_rand();
  assert_true(match_packet_match(&packet, &match));
  match.udp_src.mask = -1;
  match.vlan_pcp.mask = uint8_rand();
  assert_true(match_packet_match(&packet, &match));
  match.vlan_pcp.mask = -1;
  match.vlan_vid.mask = uint16_rand();
  assert_true(match_packet_match(&packet, &match));
  match.vlan_vid.mask = -1;

  // value test: desired value = false
  do
    {
      match.arp_op.value = uint16_rand();
    }
  while (match.arp_op.value == packet.arp_ar_op);
  assert_false(match_packet_match(&packet, &match));
  match.arp_op.value = packet.arp_ar_op;
  for (int i = 0; i < ETH_ADDRLEN; i++)
    {
      do
        {
          match.arp_sha[i].value = uint8_rand();
        }
      while (match.arp_sha[i].value == packet.arp_sha[i]);
      assert_false(match_packet_match(&packet, &match));
      match.arp_sha[i].value = packet.arp_sha[i];
    }
  do
    {
      match.arp_spa.value = uint32_rand();
    }
  while (match.arp_spa.value == packet.arp_spa);
  assert_false(match_packet_match(&packet, &match));
  match.arp_spa.value = packet.arp_spa;
  for (int i = 0; i < ETH_ADDRLEN; i++)
    {
      do
        {
          match.arp_tha[i].value = uint8_rand();
        }
      while (match.arp_tha[i].value == packet.arp_tha[i]);
      assert_false(match_packet_match(&packet, &match));
      match.arp_tha[i].value = packet.arp_tha[i];
    }
  do
    {
      match.arp_tpa.value = uint32_rand();
    }
  while (match.arp_tpa.value == packet.arp_tpa);
  assert_false(match_packet_match(&packet, &match));
  match.arp_tpa.value = packet.arp_tpa;
  do
    {
      match.in_phy_port.value = uint32_rand();
    }
  while (match.in_phy_port.value == packet.eth_in_phy_port);
  assert_false(match_packet_match(&packet, &match));
  match.in_phy_port.value = packet.eth_in_phy_port;
  do
    {
      match.in_port.value = uint32_rand();
    }
  while (match.in_port.value == packet.eth_in_port);
  assert_false(match_packet_match(&packet, &match));
  match.in_port.value = packet.eth_in_port;
  for (int i = 0; i < ETH_ADDRLEN; i++)
    {
      do
        {
          match.eth_dst[i].value = uint8_rand();
        }
      while (match.eth_dst[i].value == packet.eth_macda[i]);
      assert_false(match_packet_match(&packet, &match));
      match.eth_dst[i].value = packet.eth_macda[i];
    }
  for (int i = 0; i < ETH_ADDRLEN; i++)
    {
      do
        {
          match.eth_src[i].value = uint8_rand();
        }
      while (match.eth_src[i].value == packet.eth_macsa[i]);
      assert_false(match_packet_match(&packet, &match));
      match.eth_src[i].value = packet.eth_macsa[i];
    }
  do
    {
      match.eth_type.value = uint16_rand();
    }
  while (match.eth_type.value == packet.eth_type);
  assert_false(match_packet_match(&packet, &match));
  match.eth_type.value = packet.eth_type;
  do
    {
      match.icmpv4_code.value = uint8_rand();
    }
  while (match.icmpv4_code.value == packet.icmpv4_code);
  assert_false(match_packet_match(&packet, &match));
  match.icmpv4_code.value = packet.icmpv4_code;
  do
    {
      match.icmpv4_type.value = uint8_rand();
    }
  while (match.icmpv4_type.value == packet.icmpv4_type);
  assert_false(match_packet_match(&packet, &match));
  match.icmpv4_type.value = packet.icmpv4_type;
  do
    {
      match.icmpv6_code.value = uint8_rand();
    }
  while (match.icmpv6_code.value == packet.icmpv6_code);
  assert_false(match_packet_match(&packet, &match));
  match.icmpv6_code.value = packet.icmpv6_code;
  do
    {
      match.icmpv6_type.value = uint8_rand();
    }
  while (match.icmpv6_type.value == packet.icmpv6_type);
  assert_false(match_packet_match(&packet, &match));
  match.icmpv6_type.value = packet.icmpv6_type;
  do
    {
      match.ip_dscp.value = uint8_rand();
    }
  while (match.ip_dscp.value == packet.ip_dscp);
  assert_false(match_packet_match(&packet, &match));
  match.ip_dscp.value = packet.ip_dscp;
  do
    {
      match.ip_ecn.value = uint8_rand();
    }
  while (match.ip_ecn.value == packet.ip_ecn);
  assert_false(match_packet_match(&packet, &match));
  match.ip_ecn.value = packet.ip_ecn;
  do
    {
      match.ip_proto.value = uint8_rand();
    }
  while (match.ip_proto.value == packet.ip_proto);
  assert_false(match_packet_match(&packet, &match));
  match.ip_proto.value = packet.ip_proto;
  do
    {
      match.ipv4_dst.value = uint32_rand();
    }
  while (match.ipv4_dst.value == packet.ipv4_daddr);
  assert_false(match_packet_match(&packet, &match));
  match.ipv4_dst.value = packet.ipv4_daddr;
  do
    {
      match.ipv4_src.value = uint32_rand();
    }
  while (match.ipv4_src.value == packet.ipv4_saddr);
  assert_false(match_packet_match(&packet, &match));
  match.ipv4_src.value = packet.ipv4_saddr;
  for (int i = 0; i < IPV6_ADDRLEN; i++)
    {
      do
        {
          match.ipv6_dst[i].value = uint8_rand();
        }
      while (match.ipv6_dst[i].value == packet.ipv6_daddr[i]);
      assert_false(match_packet_match(&packet, &match));
      match.ipv6_dst[i].value = packet.ipv6_daddr[i];
    }
  do
    {
      match.ipv6_exthdr.value = uint16_rand();
    }
  while (match.ipv6_exthdr.value == packet.ipv6_exthdr);
  assert_false(match_packet_match(&packet, &match));
  match.ipv6_exthdr.value = packet.ipv6_exthdr;
  do
    {
      match.ipv6_flabel.value = uint32_rand();
    }
  while (match.ipv6_flabel.value == packet.ipv6_flowlabel);
  assert_false(match_packet_match(&packet, &match));
  match.ipv6_flabel.value = packet.ipv6_flowlabel;
  for (int i = 0; i < IPV6_LINK_LAYER_LEN; i++)
    {
      do
        {
          match.ipv6_nd_sll[i].value = uint8_rand();
        }
      while (match.ipv6_nd_sll[i].value == packet.ipv6_nd_sll[i]);
      assert_false(match_packet_match(&packet, &match));
      match.ipv6_nd_sll[i].value = packet.ipv6_nd_sll[i];
    }
  for (int i = 0; i < IPV6_ADDRLEN; i++)
    {
      do
        {
          match.ipv6_nd_target[i].value = uint8_rand();
        }
      while (match.ipv6_nd_target[i].value == packet.ipv6_nd_target[i]);
      assert_false(match_packet_match(&packet, &match));
      match.ipv6_nd_target[i].value = packet.ipv6_nd_target[i];
    }
  for (int i = 0; i < IPV6_LINK_LAYER_LEN; i++)
    {
      do
        {
          match.ipv6_nd_tll[i].value = uint8_rand();
        }
      while (match.ipv6_nd_tll[i].value == packet.ipv6_nd_tll[i]);
      assert_false(match_packet_match(&packet, &match));
      match.ipv6_nd_tll[i].value = packet.ipv6_nd_tll[i];
    }
  for (int i = 0; i < IPV6_ADDRLEN; i++)
    {
      do
        {
          match.ipv6_src[i].value = uint8_rand();
        }
      while (match.ipv6_src[i].value == packet.ipv6_saddr[i]);
      assert_false(match_packet_match(&packet, &match));
      match.ipv6_src[i].value = packet.ipv6_saddr[i];
    }
  do
    {
      match.metadata.value = uint64_rand();
    }
  while (match.metadata.value == packet.metadata);
  assert_false(match_packet_match(&packet, &match));
  match.metadata.value = packet.metadata;
  do
    {
      match.mpls_bos.value = uint8_rand();
    }
  while (match.mpls_bos.value == packet.mpls_bos);
  assert_false(match_packet_match(&packet, &match));
  match.mpls_bos.value = packet.mpls_bos;
  do
    {
      match.mpls_label.value = uint32_rand();
    }
  while (match.mpls_label.value == packet.mpls_label);
  assert_false(match_packet_match(&packet, &match));
  match.mpls_label.value = packet.mpls_label;
  do
    {
      match.mpls_tc.value = uint8_rand();
    }
  while (match.mpls_tc.value == packet.mpls_tc);
  assert_false(match_packet_match(&packet, &match));
  match.mpls_tc.value = packet.mpls_tc;
  do
    {
      match.sctp_dst.value = uint16_rand();
    }
  while (match.sctp_dst.value == packet.sctp_dst_port);
  assert_false(match_packet_match(&packet, &match));
  match.sctp_dst.value = packet.sctp_dst_port;
  do
    {
      match.sctp_src.value = uint16_rand();
    }
  while (match.sctp_src.value == packet.sctp_src_port);
  assert_false(match_packet_match(&packet, &match));
  match.sctp_src.value = packet.sctp_src_port;
  do
    {
      match.tcp_dst.value = uint16_rand();
    }
  while (match.tcp_dst.value == packet.tcp_dst_port);
  assert_false(match_packet_match(&packet, &match));
  match.tcp_dst.value = packet.tcp_dst_port;
  do
    {
      match.tcp_src.value = uint16_rand();
    }
  while (match.tcp_src.value == packet.tcp_src_port);
  assert_false(match_packet_match(&packet, &match));
  match.tcp_src.value = packet.tcp_src_port;
  do
    {
      match.tunnel_id.value = uint64_rand();
    }
  while (match.tunnel_id.value == packet.tunnel_id);
  assert_false(match_packet_match(&packet, &match));
  match.tunnel_id.value = packet.tunnel_id;
  do
    {
      match.udp_dst.value = uint16_rand();
    }
  while (match.udp_dst.value == packet.udp_dst_port);
  assert_false(match_packet_match(&packet, &match));
  match.udp_dst.value = packet.udp_dst_port;
  do
    {
      match.udp_src.value = uint16_rand();
    }
  while (match.udp_src.value == packet.udp_src_port);
  assert_false(match_packet_match(&packet, &match));
  match.udp_src.value = packet.udp_src_port;
  do
    {
      match.vlan_pcp.value = uint8_rand();
    }
  while (match.vlan_pcp.value == packet.vlan_pcp);
  assert_false(match_packet_match(&packet, &match));
  match.vlan_pcp.value = packet.vlan_pcp;
  do
    {
      match.vlan_vid.value = uint16_rand();
    }
  while (match.vlan_vid.value == packet.vlan_vid);
  assert_false(match_packet_match(&packet, &match));
  match.vlan_vid.value = packet.vlan_vid;



}

static void
test_match_packet_match_combination()
{

  packet_info packet;
  match match;

  packet_initializer(&packet);
  packet_randomizer(&packet);

  match_builder(&match, &packet);

  // Normal Pattern
  assert_true(match_packet_match(&packet, &match));

  // Combination Test
  match.arp_op.mask = uint16_rand(); match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_op.mask = uint16_rand(); match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_spa.mask = uint32_rand();     match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.arp_tpa.mask = uint32_rand();     match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_phy_port.mask = uint32_rand(); match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.in_port.mask = uint32_rand();     match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.eth_type.mask = uint16_rand();    match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_code.mask = uint8_rand();  match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv4_type.mask = uint8_rand();  match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_code.mask = uint8_rand();  match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.icmpv6_type.mask = uint8_rand();  match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_dscp.mask = uint8_rand();      match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_ecn.mask = uint8_rand();       match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ip_proto.mask = uint8_rand();     match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_dst.mask = uint32_rand();    match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv4_src.mask = uint32_rand();    match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_exthdr.mask = uint16_rand(); match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.ipv6_flabel.mask = uint32_rand(); match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.metadata.mask = uint64_rand();    match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_bos.mask = uint8_rand();     match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_label.mask = uint32_rand();  match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.mpls_tc.mask = uint8_rand();      match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_dst.mask = uint16_rand();    match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.sctp_src.mask = uint16_rand();    match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_dst.mask = uint16_rand();     match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tcp_src.mask = uint16_rand();     match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.tunnel_id.mask = uint64_rand();   match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_dst.mask = uint16_rand();     match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.udp_src.mask = uint16_rand();     match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_pcp.mask = uint8_rand();     match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.arp_op.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_sha[i].mask = uint16_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.arp_spa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.arp_tha[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.arp_tpa.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.in_phy_port.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.in_port.mask = uint32_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_dst[i].mask = uint32_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    for(int i = 0; i < ETH_ADDRLEN; i++){match.eth_src[i].mask = uint8_rand();}     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.eth_type.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.icmpv4_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.icmpv4_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.icmpv6_code.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.icmpv6_type.mask = uint8_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.ip_dscp.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.ip_ecn.mask = uint8_rand();       assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.ip_proto.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.ipv4_dst.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.ipv4_src.mask = uint32_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_dst[i].mask = uint32_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.ipv6_exthdr.mask = uint16_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.ipv6_flabel.mask = uint32_rand(); assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_sll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_nd_target[i].mask = uint8_rand();}    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    for(int i = 0; i < IPV6_LINK_LAYER_LEN; i++){match.ipv6_nd_tll[i].mask = uint8_rand();}        assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    for(int i = 0; i < IPV6_ADDRLEN; i++){match.ipv6_src[i].mask = uint16_rand();}  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.metadata.mask = uint64_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.mpls_bos.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.mpls_label.mask = uint32_rand();  assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.mpls_tc.mask = uint8_rand();      assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.sctp_dst.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.sctp_src.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.tcp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.tcp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.tunnel_id.mask = uint64_rand();   assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.udp_dst.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.udp_src.mask = uint16_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.vlan_pcp.mask = uint8_rand();     assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);
  match.vlan_vid.mask = uint16_rand();    match.vlan_vid.mask = uint16_rand();    assert_true(match_packet_match(&packet, &match));       match_builder(&match, &packet);


}

static void
test_match_match_match()
{
  packet_info packet;
  match x;
  match y;

  packet_initializer(&packet);
  packet_randomizer(&packet);

  match_builder(&x, &packet);
  match_builder(&y, &packet);

  // Normal Pattern
  assert_true(match_match_match(&x, &y));

  // validation false test
  y.arp_op.valid = false;
  assert_true(match_match_match(&x, &y));
  y.arp_op.valid = true;
  y.arp_sha[0].valid = false;
  assert_true(match_match_match(&x, &y));
  y.arp_sha[0].valid = true;
  y.arp_spa.valid = false;
  assert_true(match_match_match(&x, &y));
  y.arp_spa.valid = true;
  y.arp_tha[0].valid = false;
  assert_true(match_match_match(&x, &y));
  y.arp_tha[0].valid = true;
  y.arp_tpa.valid = false;
  assert_true(match_match_match(&x, &y));
  y.arp_tpa.valid = true;
  y.in_phy_port.valid = false;
  assert_true(match_match_match(&x, &y));
  y.in_phy_port.valid = true;
  y.in_port.valid = false;
  assert_true(match_match_match(&x, &y));
  y.in_port.valid = true;
  y.eth_dst[0].valid = false;
  assert_true(match_match_match(&x, &y));
  y.eth_dst[0].valid = true;
  y.eth_src[0].valid = false;
  assert_true(match_match_match(&x, &y));
  y.eth_src[0].valid = true;
  y.eth_type.valid = false;
  assert_true(match_match_match(&x, &y));
  y.eth_type.valid = true;
  y.icmpv4_code.valid = false;
  assert_true(match_match_match(&x, &y));
  y.icmpv4_code.valid = true;
  y.icmpv4_type.valid = false;
  assert_true(match_match_match(&x, &y));
  y.icmpv4_type.valid = true;
  y.icmpv6_code.valid = false;
  assert_true(match_match_match(&x, &y));
  y.icmpv6_code.valid = true;
  y.icmpv6_type.valid = false;
  assert_true(match_match_match(&x, &y));
  y.icmpv6_type.valid = true;
  y.ip_dscp.valid = false;
  assert_true(match_match_match(&x, &y));
  y.ip_dscp.valid = true;
  y.ip_ecn.valid = false;
  assert_true(match_match_match(&x, &y));
  y.ip_ecn.valid = true;
  y.ip_proto.valid = false;
  assert_true(match_match_match(&x, &y));
  y.ip_proto.valid = true;
  y.ipv4_dst.valid = false;
  assert_true(match_match_match(&x, &y));
  y.ipv4_dst.valid = true;
  y.ipv4_src.valid = false;
  assert_true(match_match_match(&x, &y));
  y.ipv4_src.valid = true;
  y.ipv6_dst[0].valid = false;
  assert_true(match_match_match(&x, &y));
  y.ipv6_dst[0].valid = true;
  y.ipv6_exthdr.valid = false;
  assert_true(match_match_match(&x, &y));
  y.ipv6_exthdr.valid = true;
  y.ipv6_flabel.valid = false;
  assert_true(match_match_match(&x, &y));
  y.ipv6_flabel.valid = true;
  y.ipv6_nd_sll[0].valid = false;
  assert_true(match_match_match(&x, &y));
  y.ipv6_nd_sll[0].valid = true;
  y.ipv6_nd_target[0].valid = false;
  assert_true(match_match_match(&x, &y));
  y.ipv6_nd_target[0].valid = true;
  y.ipv6_nd_tll[0].valid = false;
  assert_true(match_match_match(&x, &y));
  y.ipv6_nd_tll[0].valid = true;
  y.ipv6_src[0].valid = false;
  assert_true(match_match_match(&x, &y));
  y.ipv6_src[0].valid = true;
  y.metadata.valid = false;
  assert_true(match_match_match(&x, &y));
  y.metadata.valid = true;
  y.mpls_bos.valid = false;
  assert_true(match_match_match(&x, &y));
  y.mpls_bos.valid = true;
  y.mpls_label.valid = false;
  assert_true(match_match_match(&x, &y));
  y.mpls_label.valid = true;
  y.mpls_tc.valid = false;
  assert_true(match_match_match(&x, &y));
  y.mpls_tc.valid = true;
  y.sctp_dst.valid = false;
  assert_true(match_match_match(&x, &y));
  y.sctp_dst.valid = true;
  y.sctp_src.valid = false;
  assert_true(match_match_match(&x, &y));
  y.sctp_src.valid = true;
  y.tcp_dst.valid = false;
  assert_true(match_match_match(&x, &y));
  y.tcp_dst.valid = true;
  y.tcp_src.valid = false;
  assert_true(match_match_match(&x, &y));
  y.tcp_src.valid = true;
  y.tunnel_id.valid = false;
  assert_true(match_match_match(&x, &y));
  y.tunnel_id.valid = true;
  y.udp_dst.valid = false;
  assert_true(match_match_match(&x, &y));
  y.udp_dst.valid = true;
  y.udp_src.valid = false;
  assert_true(match_match_match(&x, &y));
  y.udp_src.valid = true;
  y.vlan_pcp.valid = false;
  assert_true(match_match_match(&x, &y));
  y.vlan_pcp.valid = true;
  y.vlan_vid.valid = false;
  assert_true(match_match_match(&x, &y));
  y.vlan_vid.valid = true;

  // validation false test desired = false
  x.arp_op.valid = false;
  assert_false(match_match_match(&x, &y));
  x.arp_op.valid = true;
  x.arp_sha[0].valid = false;
  assert_false(match_match_match(&x, &y));
  x.arp_sha[0].valid = true;
  x.arp_spa.valid = false;
  assert_false(match_match_match(&x, &y));
  x.arp_spa.valid = true;
  x.arp_tha[0].valid = false;
  assert_false(match_match_match(&x, &y));
  x.arp_tha[0].valid = true;
  x.arp_tpa.valid = false;
  assert_false(match_match_match(&x, &y));
  x.arp_tpa.valid = true;
  x.in_phy_port.valid = false;
  assert_false(match_match_match(&x, &y));
  x.in_phy_port.valid = true;
  x.in_port.valid = false;
  assert_false(match_match_match(&x, &y));
  x.in_port.valid = true;
  x.eth_dst[0].valid = false;
  assert_false(match_match_match(&x, &y));
  x.eth_dst[0].valid = true;
  x.eth_src[0].valid = false;
  assert_false(match_match_match(&x, &y));
  x.eth_src[0].valid = true;
  x.eth_type.valid = false;
  assert_false(match_match_match(&x, &y));
  x.eth_type.valid = true;
  x.icmpv4_code.valid = false;
  assert_false(match_match_match(&x, &y));
  x.icmpv4_code.valid = true;
  x.icmpv4_type.valid = false;
  assert_false(match_match_match(&x, &y));
  x.icmpv4_type.valid = true;
  x.icmpv6_code.valid = false;
  assert_false(match_match_match(&x, &y));
  x.icmpv6_code.valid = true;
  x.icmpv6_type.valid = false;
  assert_false(match_match_match(&x, &y));
  x.icmpv6_type.valid = true;
  x.ip_dscp.valid = false;
  assert_false(match_match_match(&x, &y));
  x.ip_dscp.valid = true;
  x.ip_ecn.valid = false;
  assert_false(match_match_match(&x, &y));
  x.ip_ecn.valid = true;
  x.ip_proto.valid = false;
  assert_false(match_match_match(&x, &y));
  x.ip_proto.valid = true;
  x.ipv4_dst.valid = false;
  assert_false(match_match_match(&x, &y));
  x.ipv4_dst.valid = true;
  x.ipv4_src.valid = false;
  assert_false(match_match_match(&x, &y));
  x.ipv4_src.valid = true;
  x.ipv6_dst[0].valid = false;
  assert_false(match_match_match(&x, &y));
  x.ipv6_dst[0].valid = true;
  x.ipv6_exthdr.valid = false;
  assert_false(match_match_match(&x, &y));
  x.ipv6_exthdr.valid = true;
  x.ipv6_flabel.valid = false;
  assert_false(match_match_match(&x, &y));
  x.ipv6_flabel.valid = true;
  x.ipv6_nd_sll[0].valid = false;
  assert_false(match_match_match(&x, &y));
  x.ipv6_nd_sll[0].valid = true;
  x.ipv6_nd_target[0].valid = false;
  assert_false(match_match_match(&x, &y));
  x.ipv6_nd_target[0].valid = true;
  x.ipv6_nd_tll[0].valid = false;
  assert_false(match_match_match(&x, &y));
  x.ipv6_nd_tll[0].valid = true;
  x.ipv6_src[0].valid = false;
  assert_false(match_match_match(&x, &y));
  x.ipv6_src[0].valid = true;
  x.metadata.valid = false;
  assert_false(match_match_match(&x, &y));
  x.metadata.valid = true;
  x.mpls_bos.valid = false;
  assert_false(match_match_match(&x, &y));
  x.mpls_bos.valid = true;
  x.mpls_label.valid = false;
  assert_false(match_match_match(&x, &y));
  x.mpls_label.valid = true;
  x.mpls_tc.valid = false;
  assert_false(match_match_match(&x, &y));
  x.mpls_tc.valid = true;
  x.sctp_dst.valid = false;
  assert_false(match_match_match(&x, &y));
  x.sctp_dst.valid = true;
  x.sctp_src.valid = false;
  assert_false(match_match_match(&x, &y));
  x.sctp_src.valid = true;
  x.tcp_dst.valid = false;
  assert_false(match_match_match(&x, &y));
  x.tcp_dst.valid = true;
  x.tcp_src.valid = false;
  assert_false(match_match_match(&x, &y));
  x.tcp_src.valid = true;
  x.tunnel_id.valid = false;
  assert_false(match_match_match(&x, &y));
  x.tunnel_id.valid = true;
  x.udp_dst.valid = false;
  assert_false(match_match_match(&x, &y));
  x.udp_dst.valid = true;
  x.udp_src.valid = false;
  assert_false(match_match_match(&x, &y));
  x.udp_src.valid = true;
  x.vlan_pcp.valid = false;
  assert_false(match_match_match(&x, &y));
  x.vlan_pcp.valid = true;
  x.vlan_vid.valid = false;
  assert_false(match_match_match(&x, &y));
  x.vlan_vid.valid = true;

  // mask test: desired value = true
    y.arp_op.mask = uint16_rand();
    assert_true(match_match_match(&x, &y));
    y.arp_op.mask = -1;
    for (int i = 0; i < ETH_ADDRLEN; i++)
      {
        y.arp_sha[i].mask = uint8_rand();
        assert_true(match_match_match(&x, &y));
        y.arp_sha[i].mask = -1;
      }
    y.arp_spa.mask = uint32_rand();
    assert_true(match_match_match(&x, &y));
    y.arp_spa.mask = -1;
    for (int i = 0; i < ETH_ADDRLEN; i++)
      {
        y.arp_tha[i].mask = uint8_rand();
        assert_true(match_match_match(&x, &y));
        y.arp_tha[i].mask = -1;
      }
    y.arp_tpa.mask = uint32_rand();
    assert_true(match_match_match(&x, &y));
    y.arp_tpa.mask = -1;
    y.in_phy_port.mask = uint32_rand();
    assert_true(match_match_match(&x, &y));
    y.in_phy_port.mask = -1;
    y.in_port.mask = uint32_rand();
    assert_true(match_match_match(&x, &y));
    y.in_port.mask = -1;
    for (int i = 0; i < ETH_ADDRLEN; i++)
      {
        y.eth_dst[i].mask = uint8_rand();
        assert_true(match_match_match(&x, &y));
        y.eth_dst[i].mask = -1;
      }
    for (int i = 0; i < ETH_ADDRLEN; i++)
      {
        y.eth_src[i].mask = uint8_rand();
        assert_true(match_match_match(&x, &y));
        y.eth_src[i].mask = -1;
      }
    y.eth_type.mask = uint16_rand();
    assert_true(match_match_match(&x, &y));
    y.eth_type.mask = -1;
    y.icmpv4_code.mask = uint8_rand();
    assert_true(match_match_match(&x, &y));
    y.icmpv4_code.mask = -1;
    y.icmpv4_type.mask = uint8_rand();
    assert_true(match_match_match(&x, &y));
    y.icmpv4_type.mask = -1;
    y.icmpv6_code.mask = uint8_rand();
    assert_true(match_match_match(&x, &y));
    y.icmpv6_code.mask = -1;
    y.icmpv6_type.mask = uint8_rand();
    assert_true(match_match_match(&x, &y));
    y.icmpv6_type.mask = -1;
    y.ip_dscp.mask = uint8_rand();
    assert_true(match_match_match(&x, &y));
    y.ip_dscp.mask = -1;
    y.ip_ecn.mask = uint8_rand();
    assert_true(match_match_match(&x, &y));
    y.ip_ecn.mask = -1;
    y.ip_proto.mask = uint8_rand();
    assert_true(match_match_match(&x, &y));
    y.ip_proto.mask = -1;
    y.ipv4_dst.mask = uint32_rand();
    assert_true(match_match_match(&x, &y));
    y.ipv4_dst.mask = -1;
    y.ipv4_src.mask = uint32_rand();
    assert_true(match_match_match(&x, &y));
    y.ipv4_src.mask = -1;
    for (int i = 0; i < IPV6_ADDRLEN; i++)
      {
        y.ipv6_dst[i].mask = uint8_rand();
        assert_true(match_match_match(&x, &y));
        y.ipv6_dst[i].mask = -1;
      }
    y.ipv6_exthdr.mask = uint16_rand();
    assert_true(match_match_match(&x, &y));
    y.ipv6_exthdr.mask = -1;
    y.ipv6_flabel.mask = uint32_rand();
    assert_true(match_match_match(&x, &y));
    y.ipv6_flabel.mask = -1;
    for (int i = 0; i < IPV6_LINK_LAYER_LEN; i++)
      {
        y.ipv6_nd_sll[i].mask = uint8_rand();
        assert_true(match_match_match(&x, &y));
        y.ipv6_nd_sll[i].mask = -1;
      }
    for (int i = 0; i < IPV6_ADDRLEN; i++)
      {
        y.ipv6_nd_target[i].mask = uint8_rand();
        assert_true(match_match_match(&x, &y));
        y.ipv6_nd_target[i].mask = -1;
      }
    for (int i = 0; i < IPV6_LINK_LAYER_LEN; i++)
      {
        y.ipv6_nd_tll[i].mask = uint8_rand();
        assert_true(match_match_match(&x, &y));
        y.ipv6_nd_tll[i].mask = -1;
      }
    for (int i = 0; i < IPV6_ADDRLEN; i++)
      {
        y.ipv6_src[i].mask = uint8_rand();
        assert_true(match_match_match(&x, &y));
        y.ipv6_src[i].mask = -1;
      }
    y.metadata.mask = uint64_rand();
    assert_true(match_match_match(&x, &y));
    y.metadata.mask = -1;
    y.mpls_bos.mask = uint8_rand();
    assert_true(match_match_match(&x, &y));
    y.mpls_bos.mask = -1;
    y.mpls_label.mask = uint32_rand();
    assert_true(match_match_match(&x, &y));
    y.mpls_label.mask = -1;
    y.mpls_tc.mask = uint8_rand();
    assert_true(match_match_match(&x, &y));
    y.mpls_tc.mask = -1;
    y.sctp_dst.mask = uint16_rand();
    assert_true(match_match_match(&x, &y));
    y.sctp_dst.mask = -1;
    y.sctp_src.mask = uint16_rand();
    assert_true(match_match_match(&x, &y));
    y.sctp_src.mask = -1;
    y.tcp_dst.mask = uint16_rand();
    assert_true(match_match_match(&x, &y));
    y.tcp_dst.mask = -1;
    y.tcp_src.mask = uint16_rand();
    assert_true(match_match_match(&x, &y));
    y.tcp_src.mask = -1;
    y.tunnel_id.mask = uint64_rand();
    assert_true(match_match_match(&x, &y));
    y.tunnel_id.mask = -1;
    y.udp_dst.mask = uint16_rand();
    assert_true(match_match_match(&x, &y));
    y.udp_dst.mask = -1;
    y.udp_src.mask = uint16_rand();
    assert_true(match_match_match(&x, &y));
    y.udp_src.mask = -1;
    y.vlan_pcp.mask = uint8_rand();
    assert_true(match_match_match(&x, &y));
    y.vlan_pcp.mask = -1;
    y.vlan_vid.mask = uint16_rand();
    assert_true(match_match_match(&x, &y));
    y.vlan_vid.mask = -1;

}
static void
test_compare_match_match()
{
  packet_info packet;
  match x;
  match y;

  packet_initializer(&packet);
  packet_randomizer(&packet);

  match_builder(&x, &packet);
  match_builder(&y, &packet);

  // Normal Pattern
  assert_true(compare_match_match(&x, &y));


  // validation false test
  y.arp_op.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.arp_op.valid = true;
  y.arp_sha[0].valid = false;
  assert_false(compare_match_match(&x, &y));
  y.arp_sha[0].valid = true;
  y.arp_spa.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.arp_spa.valid = true;
  y.arp_tha[0].valid = false;
  assert_false(compare_match_match(&x, &y));
  y.arp_tha[0].valid = true;
  y.arp_tpa.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.arp_tpa.valid = true;
  y.in_phy_port.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.in_phy_port.valid = true;
  y.in_port.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.in_port.valid = true;
  y.eth_dst[0].valid = false;
  assert_false(compare_match_match(&x, &y));
  y.eth_dst[0].valid = true;
  y.eth_src[0].valid = false;
  assert_false(compare_match_match(&x, &y));
  y.eth_src[0].valid = true;
  y.eth_type.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.eth_type.valid = true;
  y.icmpv4_code.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.icmpv4_code.valid = true;
  y.icmpv4_type.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.icmpv4_type.valid = true;
  y.icmpv6_code.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.icmpv6_code.valid = true;
  y.icmpv6_type.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.icmpv6_type.valid = true;
  y.ip_dscp.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.ip_dscp.valid = true;
  y.ip_ecn.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.ip_ecn.valid = true;
  y.ip_proto.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.ip_proto.valid = true;
  y.ipv4_dst.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.ipv4_dst.valid = true;
  y.ipv4_src.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.ipv4_src.valid = true;
  y.ipv6_dst[0].valid = false;
  assert_false(compare_match_match(&x, &y));
  y.ipv6_dst[0].valid = true;
  y.ipv6_exthdr.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.ipv6_exthdr.valid = true;
  y.ipv6_flabel.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.ipv6_flabel.valid = true;
  y.ipv6_nd_sll[0].valid = false;
  assert_false(compare_match_match(&x, &y));
  y.ipv6_nd_sll[0].valid = true;
  y.ipv6_nd_target[0].valid = false;
  assert_false(compare_match_match(&x, &y));
  y.ipv6_nd_target[0].valid = true;
  y.ipv6_nd_tll[0].valid = false;
  assert_false(compare_match_match(&x, &y));
  y.ipv6_nd_tll[0].valid = true;
  y.ipv6_src[0].valid = false;
  assert_false(compare_match_match(&x, &y));
  y.ipv6_src[0].valid = true;
  y.metadata.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.metadata.valid = true;
  y.mpls_bos.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.mpls_bos.valid = true;
  y.mpls_label.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.mpls_label.valid = true;
  y.mpls_tc.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.mpls_tc.valid = true;
  y.sctp_dst.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.sctp_dst.valid = true;
  y.sctp_src.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.sctp_src.valid = true;
  y.tcp_dst.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.tcp_dst.valid = true;
  y.tcp_src.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.tcp_src.valid = true;
  y.tunnel_id.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.tunnel_id.valid = true;
  y.udp_dst.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.udp_dst.valid = true;
  y.udp_src.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.udp_src.valid = true;
  y.vlan_pcp.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.vlan_pcp.valid = true;
  y.vlan_vid.valid = false;
  assert_false(compare_match_match(&x, &y));
  y.vlan_vid.valid = true;

  // validation false test desired = false
  x.arp_op.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.arp_op.valid = true;
  x.arp_sha[0].valid = false;
  assert_false(compare_match_match(&x, &y));
  x.arp_sha[0].valid = true;
  x.arp_spa.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.arp_spa.valid = true;
  x.arp_tha[0].valid = false;
  assert_false(compare_match_match(&x, &y));
  x.arp_tha[0].valid = true;
  x.arp_tpa.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.arp_tpa.valid = true;
  x.in_phy_port.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.in_phy_port.valid = true;
  x.in_port.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.in_port.valid = true;
  x.eth_dst[0].valid = false;
  assert_false(compare_match_match(&x, &y));
  x.eth_dst[0].valid = true;
  x.eth_src[0].valid = false;
  assert_false(compare_match_match(&x, &y));
  x.eth_src[0].valid = true;
  x.eth_type.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.eth_type.valid = true;
  x.icmpv4_code.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.icmpv4_code.valid = true;
  x.icmpv4_type.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.icmpv4_type.valid = true;
  x.icmpv6_code.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.icmpv6_code.valid = true;
  x.icmpv6_type.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.icmpv6_type.valid = true;
  x.ip_dscp.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.ip_dscp.valid = true;
  x.ip_ecn.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.ip_ecn.valid = true;
  x.ip_proto.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.ip_proto.valid = true;
  x.ipv4_dst.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.ipv4_dst.valid = true;
  x.ipv4_src.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.ipv4_src.valid = true;
  x.ipv6_dst[0].valid = false;
  assert_false(compare_match_match(&x, &y));
  x.ipv6_dst[0].valid = true;
  x.ipv6_exthdr.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.ipv6_exthdr.valid = true;
  x.ipv6_flabel.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.ipv6_flabel.valid = true;
  x.ipv6_nd_sll[0].valid = false;
  assert_false(compare_match_match(&x, &y));
  x.ipv6_nd_sll[0].valid = true;
  x.ipv6_nd_target[0].valid = false;
  assert_false(compare_match_match(&x, &y));
  x.ipv6_nd_target[0].valid = true;
  x.ipv6_nd_tll[0].valid = false;
  assert_false(compare_match_match(&x, &y));
  x.ipv6_nd_tll[0].valid = true;
  x.ipv6_src[0].valid = false;
  assert_false(compare_match_match(&x, &y));
  x.ipv6_src[0].valid = true;
  x.metadata.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.metadata.valid = true;
  x.mpls_bos.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.mpls_bos.valid = true;
  x.mpls_label.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.mpls_label.valid = true;
  x.mpls_tc.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.mpls_tc.valid = true;
  x.sctp_dst.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.sctp_dst.valid = true;
  x.sctp_src.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.sctp_src.valid = true;
  x.tcp_dst.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.tcp_dst.valid = true;
  x.tcp_src.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.tcp_src.valid = true;
  x.tunnel_id.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.tunnel_id.valid = true;
  x.udp_dst.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.udp_dst.valid = true;
  x.udp_src.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.udp_src.valid = true;
  x.vlan_pcp.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.vlan_pcp.valid = true;
  x.vlan_vid.valid = false;
  assert_false(compare_match_match(&x, &y));
  x.vlan_vid.valid = true;

  // mask test: desired value = false
    y.arp_op.mask = uint16_rand();
    assert_false(compare_match_match(&x, &y));
    y.arp_op.mask = -1;
    for (int i = 0; i < ETH_ADDRLEN; i++)
      {
        y.arp_sha[i].mask = uint8_rand();
        assert_false(compare_match_match(&x, &y));
        y.arp_sha[i].mask = -1;
      }
    y.arp_spa.mask = uint32_rand();
    assert_false(compare_match_match(&x, &y));
    y.arp_spa.mask = -1;
    for (int i = 0; i < ETH_ADDRLEN; i++)
      {
        y.arp_tha[i].mask = uint8_rand();
        assert_false(compare_match_match(&x, &y));
        y.arp_tha[i].mask = -1;
      }
    y.arp_tpa.mask = uint32_rand();
    assert_false(compare_match_match(&x, &y));
    y.arp_tpa.mask = -1;
    y.in_phy_port.mask = uint32_rand();
    assert_false(compare_match_match(&x, &y));
    y.in_phy_port.mask = -1;
    y.in_port.mask = uint32_rand();
    assert_false(compare_match_match(&x, &y));
    y.in_port.mask = -1;
    for (int i = 0; i < ETH_ADDRLEN; i++)
      {
        y.eth_dst[i].mask = uint8_rand();
        assert_false(compare_match_match(&x, &y));
        y.eth_dst[i].mask = -1;
      }
    for (int i = 0; i < ETH_ADDRLEN; i++)
      {
        y.eth_src[i].mask = uint8_rand();
        assert_false(compare_match_match(&x, &y));
        y.eth_src[i].mask = -1;
      }
    y.eth_type.mask = uint16_rand();
    assert_false(compare_match_match(&x, &y));
    y.eth_type.mask = -1;
    y.icmpv4_code.mask = uint8_rand();
    assert_false(compare_match_match(&x, &y));
    y.icmpv4_code.mask = -1;
    y.icmpv4_type.mask = uint8_rand();
    assert_false(compare_match_match(&x, &y));
    y.icmpv4_type.mask = -1;
    y.icmpv6_code.mask = uint8_rand();
    assert_false(compare_match_match(&x, &y));
    y.icmpv6_code.mask = -1;
    y.icmpv6_type.mask = uint8_rand();
    assert_false(compare_match_match(&x, &y));
    y.icmpv6_type.mask = -1;
    y.ip_dscp.mask = uint8_rand();
    assert_false(compare_match_match(&x, &y));
    y.ip_dscp.mask = -1;
    y.ip_ecn.mask = uint8_rand();
    assert_false(compare_match_match(&x, &y));
    y.ip_ecn.mask = -1;
    y.ip_proto.mask = uint8_rand();
    assert_false(compare_match_match(&x, &y));
    y.ip_proto.mask = -1;
    y.ipv4_dst.mask = uint32_rand();
    assert_false(compare_match_match(&x, &y));
    y.ipv4_dst.mask = -1;
    y.ipv4_src.mask = uint32_rand();
    assert_false(compare_match_match(&x, &y));
    y.ipv4_src.mask = -1;
    for (int i = 0; i < IPV6_ADDRLEN; i++)
      {
        y.ipv6_dst[i].mask = uint8_rand();
        assert_false(compare_match_match(&x, &y));
        y.ipv6_dst[i].mask = -1;
      }
    y.ipv6_exthdr.mask = uint16_rand();
    assert_false(compare_match_match(&x, &y));
    y.ipv6_exthdr.mask = -1;
    y.ipv6_flabel.mask = uint32_rand();
    assert_false(compare_match_match(&x, &y));
    y.ipv6_flabel.mask = -1;
    for (int i = 0; i < IPV6_LINK_LAYER_LEN; i++)
      {
        y.ipv6_nd_sll[i].mask = uint8_rand();
        assert_false(compare_match_match(&x, &y));
        y.ipv6_nd_sll[i].mask = -1;
      }
    for (int i = 0; i < IPV6_ADDRLEN; i++)
      {
        y.ipv6_nd_target[i].mask = uint8_rand();
        assert_false(compare_match_match(&x, &y));
        y.ipv6_nd_target[i].mask = -1;
      }
    for (int i = 0; i < IPV6_LINK_LAYER_LEN; i++)
      {
        y.ipv6_nd_tll[i].mask = uint8_rand();
        assert_false(compare_match_match(&x, &y));
        y.ipv6_nd_tll[i].mask = -1;
      }
    for (int i = 0; i < IPV6_ADDRLEN; i++)
      {
        y.ipv6_src[i].mask = uint8_rand();
        assert_false(compare_match_match(&x, &y));
        y.ipv6_src[i].mask = -1;
      }
    y.metadata.mask = uint64_rand();
    assert_false(compare_match_match(&x, &y));
    y.metadata.mask = -1;
    y.mpls_bos.mask = uint8_rand();
    assert_false(compare_match_match(&x, &y));
    y.mpls_bos.mask = -1;
    y.mpls_label.mask = uint32_rand();
    assert_false(compare_match_match(&x, &y));
    y.mpls_label.mask = -1;
    y.mpls_tc.mask = uint8_rand();
    assert_false(compare_match_match(&x, &y));
    y.mpls_tc.mask = -1;
    y.sctp_dst.mask = uint16_rand();
    assert_false(compare_match_match(&x, &y));
    y.sctp_dst.mask = -1;
    y.sctp_src.mask = uint16_rand();
    assert_false(compare_match_match(&x, &y));
    y.sctp_src.mask = -1;
    y.tcp_dst.mask = uint16_rand();
    assert_false(compare_match_match(&x, &y));
    y.tcp_dst.mask = -1;
    y.tcp_src.mask = uint16_rand();
    assert_false(compare_match_match(&x, &y));
    y.tcp_src.mask = -1;
    y.tunnel_id.mask = uint64_rand();
    assert_false(compare_match_match(&x, &y));
    y.tunnel_id.mask = -1;
    y.udp_dst.mask = uint16_rand();
    assert_false(compare_match_match(&x, &y));
    y.udp_dst.mask = -1;
    y.udp_src.mask = uint16_rand();
    assert_false(compare_match_match(&x, &y));
    y.udp_src.mask = -1;
    y.vlan_pcp.mask = uint8_rand();
    assert_false(compare_match_match(&x, &y));
    y.vlan_pcp.mask = -1;
    y.vlan_vid.mask = uint16_rand();
    assert_false(compare_match_match(&x, &y));
    y.vlan_vid.mask = -1;

}

static void test_packet_matcher()
{
  assert_int_equal(initialize_packet_matcher(), 0);
  assert_int_equal(finalize_packet_matcher(), 0);

}

/********************************************************************************
 * Run tests.
 ********************************************************************************/

int
packet_matcher_main()
{
  const UnitTest tests[] =
    {
unit_test( test_match_packet_8_match ),
unit_test( test_match_packet_16_match ),
unit_test( test_match_packet_32_match ),
unit_test( test_match_packet_64_match ),
unit_test( test_match_match_8_match ),
unit_test( test_match_match_16_match ),
unit_test( test_match_match_32_match ),
unit_test( test_match_match_64_match ),
unit_test( test_compare_match_8_match ),
unit_test( test_compare_match_16_match ),
unit_test( test_compare_match_32_match ),
unit_test( test_compare_match_64_match ),
unit_test( test_match_packet_match ),
unit_test( test_match_packet_match_combination ),
unit_test( test_match_match_match ),
unit_test( test_compare_match_match ),
unit_test( test_packet_matcher ),
    };
  int retval = 0;

  setup_leak_detector();
  setup();
  retval = run_tests( tests );
  teardown();

  return retval;
}

/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
