/*
 * Unit tests for packet_parser functions and macros.
 *
 * Author: Kazuya Suzuki
 *
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */



#include <assert.h>
#include <string.h>
#include <stdio.h>
#include <pcap.h>
#include <netinet/ip.h>
#include <netinet/igmp.h>
#include "checks.h"
#include "cmockery_trema.h"
#include "packet_info.h"
#include "wrapper.h"
#include "packet_buffer_pool.h"
#include "packet_parser.h"

/******************************************************************************
 * Helper functions.
 ******************************************************************************/

#define XFREE( x ) ({ void *p = ( x ); assert_true( p != NULL ); xfree( p ); })

static void ( *original_die )( const char *format, ... );

static void
mock_die( const char *format, ... ) {
  UNUSED( format );
  mock_assert( false, "mock_die", __FILE__, __LINE__ );
} // Hoaxes gcov.

#define POOL_SIZE       2
#define ALLOC_SIZE 0xffff

static void
setup() {
  original_die = die;
  die = mock_die;
  init_packet_buffer_pool(POOL_SIZE, ALLOC_SIZE);
}

static void
teardown() {
  die = original_die;
  finalize_packet_buffer_pool();
}


static buffer *
store_packet_to_buffer( const char *filename ) {
  assert( filename != NULL );

  FILE *fp = fopen( filename, "r" );
  if ( fp == NULL ) {
    // "Can't open a file of test data."
    return NULL;
  }
  
  // Skip 
  if ( fseek( fp, sizeof( struct pcap_file_header ) + sizeof( uint32_t ) * 2,
              SEEK_CUR ) != 0 ) {
    fclose( fp );
    return NULL;
  }  
  
  uint32_t length[ 2 ];
  size_t size = fread( &length, 1, sizeof( length ), fp );
  if ( size < sizeof( length ) ) {
    fclose( fp );
    return NULL;
  }  

  buffer *buf = allocate_packet_buffer();
  if ( buf == NULL ) {
    fclose( fp );
    return NULL;
  }
  size = fread( append_back_buffer_pool_entry( buf, length[ 0 ] ), 1, length[ 0 ], fp );
  if ( size < buf->length ) {
	free_packet_buffer_pool_entry( buf );
    fclose( fp );
    return NULL;
  }  

  fclose( fp );
  return buf;
}


/******************************************************************************
 * Test functions.
 ******************************************************************************/

static void
test_parse_packet_snap_succeeds() {
  const char filename[] = "./test_packets/ipx.cap";
  buffer *buffer = store_packet_to_buffer( filename );

  assert_true( parse_packet( buffer ) );

  packet_info *packet_info = buffer->user_data;

  assert_int_equal( packet_info->format, ETH_8023_SNAP );
  
  u_char macda[] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };
  u_char macsa[] = { 0x00, 0x19, 0xdb, 0x17, 0xb9, 0x6f };
  assert_memory_equal( packet_info->eth_macda, macda, ETH_ADDRLEN );
  assert_memory_equal( packet_info->eth_macsa, macsa, ETH_ADDRLEN );
  assert_true( packet_info->eth_type < ETH_MTU );

  u_char llc[] = { 0xe0, 0xe0, 0x03 };
  u_char oui[] = { 0xff, 0xff, 0x00 };
  assert_memory_equal( packet_info->snap_llc, llc, SNAP_LLC_LENGTH );
  assert_memory_equal( packet_info->snap_oui, oui, SNAP_OUI_LENGTH );
  assert_int_equal( packet_info->snap_type, 0xb700 );

  uint16_t sample = ntohs( * ( uint16_t * ) packet_info->l2_payload );
  assert_int_equal( sample, 0x0400 );

  assert_int_equal( packet_info->l2_payload_length, 0xb2 );

  free_packet_buffer_pool_entry( buffer );
}


static void
test_parse_packet_arp_request_succeeds() {
  const char filename[] = "./test_packets/arp_req.cap";
  buffer *buffer = store_packet_to_buffer( filename );

  assert_true( parse_packet( buffer ) );
  packet_info *packet_info = buffer->user_data;

  assert_int_equal( packet_info->format, ETH_ARP );

  u_char macda[] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };
  u_char macsa[] = { 0x8c, 0x89, 0xa5, 0x16, 0x22, 0x09 };
  assert_memory_equal( packet_info->eth_macda, macda, ETH_ADDRLEN );
  assert_memory_equal( packet_info->eth_macsa, macsa, ETH_ADDRLEN );
  assert_int_equal( packet_info->eth_type, ETH_ETHTYPE_ARP );

  assert_int_equal( packet_info->l2_payload_length, 46 );

  assert_int_equal( packet_info->arp_ar_hrd, 0x0001 );
  assert_int_equal( packet_info->arp_ar_pro, 0x0800 );
  assert_int_equal( packet_info->arp_ar_hln, 6 );
  assert_int_equal( packet_info->arp_ar_pln, 4 );
  assert_int_equal( packet_info->arp_ar_op, 1 );
  assert_int_equal( packet_info->arp_spa, 0xc0a8642c );
  assert_memory_equal( packet_info->arp_sha, macsa, ETH_ADDRLEN );
  assert_int_equal( packet_info->arp_tpa, 0xc0a8642b );
  u_char maczero[] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
  assert_memory_equal( packet_info->arp_tha, maczero, ETH_ADDRLEN );  

  assert_true( packet_type_arp_request( buffer ) );

  free_packet_buffer_pool_entry( buffer );
}


static void
test_parse_packet_udp_succeeds() {
  const char filename[] = "./test_packets/udp.cap";
  buffer *buffer = store_packet_to_buffer( filename );

  assert_true( parse_packet( buffer ) );

  packet_info *packet_info = buffer->user_data;

  assert_int_equal( packet_info->format, ETH_IPV4_UDP );

  u_char macda[] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };
  u_char macsa[] = { 0x00, 0x21, 0x85, 0x91, 0x92, 0xdb };
  assert_memory_equal( packet_info->eth_macda, macda, ETH_ADDRLEN );
  assert_memory_equal( packet_info->eth_macsa, macsa, ETH_ADDRLEN );
  assert_int_equal( packet_info->eth_type, ETH_ETHTYPE_IPV4 );
  
  assert_int_equal( packet_info->l2_payload_length, 76 );

  assert_int_equal( packet_info->ipv4_version, 4 );
  assert_int_equal( packet_info->ipv4_ihl, 5 );
  assert_int_equal( packet_info->ipv4_tos, 0 );
  assert_int_equal( packet_info->ipv4_tot_len, 0x4c );
  assert_int_equal( packet_info->ipv4_id, 0x48d8 );
  assert_int_equal( packet_info->ipv4_frag_off, 0 );
  assert_int_equal( packet_info->ipv4_ttl, 0x80 );
  assert_int_equal( packet_info->ipv4_protocol, IPPROTO_UDP );
  assert_int_equal( packet_info->ipv4_checksum, 0x6fab );
  assert_int_equal( packet_info->ipv4_saddr, 0x0a3835af );
  assert_int_equal( packet_info->ipv4_daddr, 0x0a3837ff );

  assert_int_equal( packet_info->l3_payload_length, 56 );

  assert_int_equal( packet_info->udp_src_port, 61616 );
  assert_int_equal( packet_info->udp_dst_port, 23499 );
  assert_int_equal( packet_info->udp_len, 0x38 );
  assert_int_equal( packet_info->udp_checksum, 0x04a1 );

  uint16_t sample = ntohs( * ( uint16_t * ) packet_info->l4_payload );
  assert_int_equal( sample, 0xf937 );

  assert_int_equal( packet_info->l4_payload_length, 48 );

  free_packet_buffer_pool_entry( buffer );
}


static void
test_parse_packet_udp_fragmented_head_succeeds() {
  const char filename[] = "./test_packets/udp_frag_head.cap";
  buffer *buffer = store_packet_to_buffer( filename );

  assert_true( parse_packet( buffer ) );

  packet_info *packet_info = buffer->user_data;

  assert_int_equal( packet_info->format, ETH_IPV4_UDP );

  u_char macda[] = { 0x8c, 0x89, 0xa5, 0x15, 0x84, 0xcb };
  u_char macsa[] = { 0x8c, 0x89, 0xa5, 0x16, 0x22, 0x09 };
  assert_memory_equal( packet_info->eth_macda, macda, ETH_ADDRLEN );
  assert_memory_equal( packet_info->eth_macsa, macsa, ETH_ADDRLEN );
  assert_int_equal( packet_info->eth_type, ETH_ETHTYPE_IPV4 );

  assert_int_equal( packet_info->l2_payload_length, 1500 );
  
  assert_int_equal( packet_info->ipv4_version, 4 );
  assert_int_equal( packet_info->ipv4_ihl, 5 );
  assert_int_equal( packet_info->ipv4_tos, 0 );
  assert_int_equal( packet_info->ipv4_tot_len, 0x05dc );
  assert_int_equal( packet_info->ipv4_id, 0x2b33 );
  assert_int_equal( packet_info->ipv4_frag_off, 0x2000 );
  assert_int_equal( packet_info->ipv4_ttl, 0x40 );
  assert_int_equal( packet_info->ipv4_protocol, IPPROTO_UDP );
  assert_int_equal( packet_info->ipv4_checksum, 0xe035 );
  assert_int_equal( packet_info->ipv4_saddr, 0xc0a8642c );
  assert_int_equal( packet_info->ipv4_daddr, 0xc0a8642b );

  assert_int_equal( packet_info->l3_payload_length, 1480 );

  assert_int_equal( packet_info->udp_src_port, 0xa2c7 );
  assert_int_equal( packet_info->udp_dst_port, 0x1f90 );
  assert_int_equal( packet_info->udp_len, 0x2330 );
  assert_int_equal( packet_info->udp_checksum, 0x8749 );

  uint16_t sample = ntohs( * ( uint16_t * ) packet_info->l4_payload );
  assert_int_equal( sample, 0x8020 );

  assert_int_equal( packet_info->l4_payload_length, 1472 );

  free_packet_buffer_pool_entry( buffer );
}


static void
test_parse_packet_udp_fragmented_next_succeeds() {
  const char filename[] = "./test_packets/udp_frag_next.cap";
  buffer *buffer = store_packet_to_buffer( filename );

  assert_true( parse_packet( buffer ) );

  packet_info *packet_info = buffer->user_data;

  assert_int_equal( packet_info->format, ETH_IPV4 );

  u_char macda[] = { 0x8c, 0x89, 0xa5, 0x15, 0x84, 0xcb };
  u_char macsa[] = { 0x8c, 0x89, 0xa5, 0x16, 0x22, 0x09 };
  assert_memory_equal( packet_info->eth_macda, macda, ETH_ADDRLEN );
  assert_memory_equal( packet_info->eth_macsa, macsa, ETH_ADDRLEN );
  assert_int_equal( packet_info->eth_type, ETH_ETHTYPE_IPV4 );
  
  assert_int_equal( packet_info->l2_payload_length, 1500 );

  assert_int_equal( packet_info->ipv4_version, 4 );
  assert_int_equal( packet_info->ipv4_ihl, 5 );
  assert_int_equal( packet_info->ipv4_tos, 0 );
  assert_int_equal( packet_info->ipv4_tot_len, 0x05dc );
  assert_int_equal( packet_info->ipv4_id, 0x2b33 );
  assert_int_equal( packet_info->ipv4_frag_off, 0x20b9 );
  assert_int_equal( packet_info->ipv4_ttl, 0x40 );
  assert_int_equal( packet_info->ipv4_protocol, IPPROTO_UDP );
  assert_int_equal( packet_info->ipv4_checksum, 0xdf7c );
  assert_int_equal( packet_info->ipv4_saddr, 0xc0a8642c );
  assert_int_equal( packet_info->ipv4_daddr, 0xc0a8642b );

  uint16_t sample = ntohs( * ( uint16_t * ) packet_info->l3_payload );
  assert_int_equal( sample, 0x9102 );

  assert_int_equal( packet_info->l3_payload_length, 1480 );

  // L4 parsing phase is skipped for fragmented packets.
  assert_int_equal( packet_info->udp_src_port, 0 );
  assert_int_equal( packet_info->udp_dst_port, 0 );
  assert_int_equal( packet_info->udp_len, 0 );
  assert_int_equal( packet_info->udp_checksum, 0 );

  assert_true( packet_info->l4_payload == NULL );
  assert_int_equal( packet_info->l4_payload_length, 0 );

  free_packet_buffer_pool_entry( buffer );
}


static void
test_parse_packet_tcp_syn_succeeds() {
  const char filename[] = "./test_packets/tcp_syn.cap";
  buffer *buffer = store_packet_to_buffer( filename );

  assert_true( parse_packet( buffer ) );

  packet_info *packet_info = buffer->user_data;

  assert_int_equal( packet_info->format, ETH_IPV4_TCP );

  u_char macda[] = { 0x00, 0x16, 0x17, 0x00, 0x43, 0xf3 };
  u_char macsa[] = { 0x8c, 0x89, 0xa5, 0x15, 0x84, 0xcb };
  assert_memory_equal( packet_info->eth_macda, macda, ETH_ADDRLEN );
  assert_memory_equal( packet_info->eth_macsa, macsa, ETH_ADDRLEN );
  assert_int_equal( packet_info->eth_type, ETH_ETHTYPE_IPV4 );
  
  assert_int_equal( packet_info->l2_payload_length, 60 );

  assert_int_equal( packet_info->ipv4_version, 4 );
  assert_int_equal( packet_info->ipv4_ihl, 5 );
  assert_int_equal( packet_info->ipv4_tos, 0x10 );
  assert_int_equal( packet_info->ipv4_tot_len, 0x003c );
  assert_int_equal( packet_info->ipv4_id, 0x5551 );
  assert_int_equal( packet_info->ipv4_frag_off, 0x4000 );
  assert_int_equal( packet_info->ipv4_ttl, 0x40 );
  assert_int_equal( packet_info->ipv4_protocol, IPPROTO_TCP );
  assert_int_equal( packet_info->ipv4_checksum, 0x9afd );
  assert_int_equal( packet_info->ipv4_saddr, 0xc0a8642b );
  assert_int_equal( packet_info->ipv4_daddr, 0xc0a864e1 );

  assert_int_equal( packet_info->l3_payload_length, 40 );

  assert_int_equal( packet_info->tcp_src_port, 0xad49 );
  assert_int_equal( packet_info->tcp_dst_port, 0x0050 );
  assert_int_equal( packet_info->tcp_seq_no, 0x51de9851 );
  assert_int_equal( packet_info->tcp_ack_no, 0 );
  assert_int_equal( packet_info->tcp_offset, 0xa );
  assert_int_equal( packet_info->tcp_flags, 0x02 );
  assert_int_equal( packet_info->tcp_window, 0x16d0 );
  assert_int_equal( packet_info->tcp_checksum, 0x76bb );
  assert_int_equal( packet_info->tcp_urgent, 0 );

  assert_true( packet_info->l4_payload == NULL );
  assert_int_equal( packet_info->l4_payload_length, 0 );

  free_packet_buffer_pool_entry( buffer );
}


static void
test_parse_packet_tcp_succeeds() {
  const char filename[] = "./test_packets/tcp.cap";
  buffer *buffer = store_packet_to_buffer( filename );

  assert_true( parse_packet( buffer ) );

  packet_info *packet_info = buffer->user_data;

  assert_int_equal( packet_info->format, ETH_IPV4_TCP );

  u_char macda[] = { 0x8c, 0x89, 0xa5, 0x15, 0x84, 0xcb };
  u_char macsa[] = { 0x00, 0x16, 0x17, 0x00, 0x43, 0xf3 };
  assert_memory_equal( packet_info->eth_macda, macda, ETH_ADDRLEN );
  assert_memory_equal( packet_info->eth_macsa, macsa, ETH_ADDRLEN );
  assert_int_equal( packet_info->eth_type, ETH_ETHTYPE_IPV4 );
  
  assert_int_equal( packet_info->l2_payload_length, 82 );

  assert_int_equal( packet_info->ipv4_version, 4 );
  assert_int_equal( packet_info->ipv4_ihl, 5 );
  assert_int_equal( packet_info->ipv4_tos, 0 );
  assert_int_equal( packet_info->ipv4_tot_len, 0x01dd );
  assert_int_equal( packet_info->ipv4_id, 0x0399 );
  assert_int_equal( packet_info->ipv4_frag_off, 0x4000 );
  assert_int_equal( packet_info->ipv4_ttl, 0x40 );
  assert_int_equal( packet_info->ipv4_protocol, IPPROTO_TCP );
  assert_int_equal( packet_info->ipv4_checksum, 0xeb24 );
  assert_int_equal( packet_info->ipv4_saddr, 0xc0a864e1 );
  assert_int_equal( packet_info->ipv4_daddr, 0xc0a8642b );

  assert_int_equal( packet_info->l3_payload_length, 62 );

  assert_int_equal( packet_info->tcp_src_port, 0x0050 );
  assert_int_equal( packet_info->tcp_dst_port, 0xad49 );
  assert_int_equal( packet_info->tcp_seq_no, 0x20656b68 );
  assert_int_equal( packet_info->tcp_ack_no, 0x51de986e );
  assert_int_equal( packet_info->tcp_offset, 0x8 );
  assert_int_equal( packet_info->tcp_flags, 0x18 );
  assert_int_equal( packet_info->tcp_window, 0x2086 );
  assert_int_equal( packet_info->tcp_checksum, 0x4c2d );
  assert_int_equal( packet_info->tcp_urgent, 0 );

  uint16_t sample = ntohs( * ( uint16_t * ) packet_info->l4_payload );
  assert_int_equal( sample, 0x4854 );

  assert_int_equal( packet_info->l4_payload_length, 30 );

  free_packet_buffer_pool_entry( buffer );
}


static void
test_parse_packet_icmpv4_echo_request_succeeds() {
  const char filename[] = "./test_packets/icmp_echo_req.cap";
  buffer *buffer = store_packet_to_buffer( filename );

  assert_true( parse_packet( buffer ) );

  packet_info *packet_info = buffer->user_data;

  assert_int_equal( packet_info->format, ETH_IPV4_ICMPV4 );

  u_char macda[] = { 0x8c, 0x89, 0xa5, 0x15, 0x84, 0xcb };
  u_char macsa[] = { 0x8c, 0x89, 0xa5, 0x16, 0x22, 0x09 };
  assert_memory_equal( packet_info->eth_macda, macda, ETH_ADDRLEN );
  assert_memory_equal( packet_info->eth_macsa, macsa, ETH_ADDRLEN );
  assert_int_equal( packet_info->eth_type, ETH_ETHTYPE_IPV4 );

  assert_int_equal( packet_info->l2_payload_length, 84 );

  assert_int_equal( packet_info->ipv4_version, 4 );
  assert_int_equal( packet_info->ipv4_ihl, 5 );
  assert_int_equal( packet_info->ipv4_tos, 0 );
  assert_int_equal( packet_info->ipv4_tot_len, 0x54 );
  assert_int_equal( packet_info->ipv4_id, 0 );
  assert_int_equal( packet_info->ipv4_frag_off, 0x4000 );
  assert_int_equal( packet_info->ipv4_ttl, 0x40 );
  assert_int_equal( packet_info->ipv4_protocol, IPPROTO_ICMP );
  assert_int_equal( packet_info->ipv4_checksum, 0xf100 );
  assert_int_equal( packet_info->ipv4_saddr, 0xc0a8642c );
  assert_int_equal( packet_info->ipv4_daddr, 0xc0a8642b );

  assert_int_equal( packet_info->l3_payload_length, 64 );

  assert_int_equal( packet_info->icmpv4_type, ICMP_TYPE_ECHOREQ );
  assert_int_equal( packet_info->icmpv4_code, 0 );
  assert_int_equal( packet_info->icmpv4_id, 1076 );
  assert_int_equal( packet_info->icmpv4_seq, 1 );

  uint16_t sample = ntohs( * ( uint16_t * ) packet_info->l4_payload );
  assert_int_equal( sample, 0xa0a9 );

  assert_int_equal( packet_info->l4_payload_length, 56 );

  free_packet_buffer_pool_entry( buffer );
}


static void
test_parse_packet_vtag_icmpv4_echo_request_succeeds() {
  const char filename[] = "./test_packets/vtag_icmp_echo_req.cap";
  buffer *buffer = store_packet_to_buffer( filename );

  assert_true( parse_packet( buffer ) );

  packet_info *packet_info = buffer->user_data;

  assert_int_equal( packet_info->format, ETH_VTAG_IPV4_ICMPV4 );

  u_char macda[] = { 0x00, 0x13, 0xd3, 0x40, 0x2e, 0x22 };
  u_char macsa[] = { 0x00, 0x1f, 0x3c, 0x48, 0xad, 0x3a };
  assert_memory_equal( packet_info->eth_macda, macda, ETH_ADDRLEN );
  assert_memory_equal( packet_info->eth_macsa, macsa, ETH_ADDRLEN );

  assert_int_equal( packet_info->vlan_tci, 0x0f9f );
  assert_int_equal( packet_info->vlan_tpid, ETH_ETHTYPE_TPID );
  assert_int_equal( packet_info->vlan_prio, 0 );
  assert_int_equal( packet_info->vlan_cfi, 0 );
  assert_int_equal( packet_info->vlan_vid, 0x0f9f );

  assert_int_equal( packet_info->eth_type, ETH_ETHTYPE_IPV4 );

  assert_int_equal( packet_info->l2_payload_length, 60 );

  assert_int_equal( packet_info->ipv4_version, 4 );
  assert_int_equal( packet_info->ipv4_ihl, 5 );
  assert_int_equal( packet_info->ipv4_tos, 0 );
  assert_int_equal( packet_info->ipv4_tot_len, 0x3c );
  assert_int_equal( packet_info->ipv4_id, 0x8c1b );
  assert_int_equal( packet_info->ipv4_frag_off, 0 );
  assert_int_equal( packet_info->ipv4_ttl, 0x80 );
  assert_int_equal( packet_info->ipv4_protocol, IPPROTO_ICMP );
  assert_int_equal( packet_info->ipv4_checksum, 0xed09 );
  assert_int_equal( packet_info->ipv4_saddr, 0xc0a8204a );
  assert_int_equal( packet_info->ipv4_daddr, 0xc0a82001 );

  assert_int_equal( packet_info->l3_payload_length, 40 );

  assert_int_equal( packet_info->icmpv4_type, ICMP_TYPE_ECHOREQ );
  assert_int_equal( packet_info->icmpv4_code, 0 );
  assert_int_equal( packet_info->icmpv4_id, 1024 );
  assert_int_equal( packet_info->icmpv4_seq, 24576 );

  assert_true( packet_info->l2_vlan_header == ((uint8_t *)buffer->data + sizeof(ether_header_t)));

  uint16_t sample = ntohs( * ( uint16_t * ) packet_info->l4_payload );
  assert_int_equal( sample, 0x6162 );
  assert_int_equal( packet_info->l4_payload_length, 32 );

  free_packet_buffer_pool_entry( buffer );
}


static void
test_parse_packet_vtag_icmpv4_echo_reply_succeeds() {
  const char filename[] = "./test_packets/vtag_icmp_echo_rep.cap";
  buffer *buffer = store_packet_to_buffer( filename );

  assert_true( parse_packet( buffer ) );

  packet_info *packet_info = buffer->user_data;

  assert_int_equal( packet_info->format, ETH_VTAG_IPV4_ICMPV4 );

  u_char macda[] = { 0x00, 0x1f, 0x3c, 0x48, 0xad, 0x3a };
  u_char macsa[] = { 0x00, 0x13, 0xd3, 0x40, 0x2e, 0x22 };
  assert_memory_equal( packet_info->eth_macda, macda, ETH_ADDRLEN );
  assert_memory_equal( packet_info->eth_macsa, macsa, ETH_ADDRLEN );

  assert_int_equal( packet_info->vlan_tci, 0x6f9f );
  assert_int_equal( packet_info->vlan_tpid, ETH_ETHTYPE_TPID );
  assert_int_equal( packet_info->vlan_prio, 3 );
  assert_int_equal( packet_info->vlan_cfi, 0 );
  assert_int_equal( packet_info->vlan_vid, 0x0f9f );

  assert_int_equal( packet_info->eth_type, ETH_ETHTYPE_IPV4 );

  assert_int_equal( packet_info->l2_payload_length, 60 );

  assert_int_equal( packet_info->ipv4_version, 4 );
  assert_int_equal( packet_info->ipv4_ihl, 5 );
  assert_int_equal( packet_info->ipv4_tos, 0 );
  assert_int_equal( packet_info->ipv4_tot_len, 0x3c );
  assert_int_equal( packet_info->ipv4_id, 0x1652 );
  assert_int_equal( packet_info->ipv4_frag_off, 0 );
  assert_int_equal( packet_info->ipv4_ttl, 0x40 );
  assert_int_equal( packet_info->ipv4_protocol, IPPROTO_ICMP );
  assert_int_equal( packet_info->ipv4_checksum, 0xa2d3 );
  assert_int_equal( packet_info->ipv4_saddr, 0xc0a82001 );
  assert_int_equal( packet_info->ipv4_daddr, 0xc0a8204a );

  assert_int_equal( packet_info->l3_payload_length, 40 );

  assert_int_equal( packet_info->icmpv4_type, ICMP_TYPE_ECHOREP );
  assert_int_equal( packet_info->icmpv4_code, 0 );
  assert_int_equal( packet_info->icmpv4_id, 1024 );
  assert_int_equal( packet_info->icmpv4_seq, 24576 );

  assert_true( packet_info->l2_vlan_header == ((uint8_t *)buffer->data + sizeof(ether_header_t)));


  uint16_t sample = ntohs( * ( uint16_t * ) packet_info->l4_payload );
  assert_int_equal( sample, 0x6162 );
  assert_int_equal( packet_info->l4_payload_length, 32 );

  free_packet_buffer_pool_entry( buffer );
}


static void
test_parse_packet_igmp_query_v2_succeeds() {
  const char filename[] = "./test_packets/igmp_query_v2.cap";
  buffer *buffer = store_packet_to_buffer( filename );

  assert_true( parse_packet( buffer ) );

  packet_info *packet_info = buffer->user_data;

  assert_int_equal( packet_info->format, ETH_IPV4_IGMP );

  u_char macda[] = { 0x01, 0x00, 0x5e, 0x00, 0x00, 0x01 };
  u_char macsa[] = { 0x8c, 0x89, 0xa5, 0x15, 0x84, 0xcb };
  assert_memory_equal( packet_info->eth_macda, macda, ETH_ADDRLEN );
  assert_memory_equal( packet_info->eth_macsa, macsa, ETH_ADDRLEN );

  assert_int_equal( packet_info->l2_payload_length, 32 );

//  assert_int_equal( packet_info->igmp_type, IGMP_MEMBERSHIP_QUERY );
  assert_int_equal( packet_info->igmp_code, 100 );
//  assert_int_equal( packet_info->igmp_checksum, 0xee9b );
  assert_int_equal( packet_info->igmp_group, 0 );

  assert_true( packet_type_igmp_membership_query( buffer ) );

  free_packet_buffer_pool_entry( buffer );
}


static void
test_parse_packet_lldp_succeeds() {
  const char filename[] = "./test_packets/lldp.cap";
  buffer *buffer = store_packet_to_buffer( filename );

  assert_true( parse_packet( buffer ) );

  packet_info *packet_info = buffer->user_data;

  assert_int_equal( packet_info->format, ETH_LLDP );

  u_char macda[] = { 0x01, 0x80, 0xc2, 0x00, 0x00, 0x0e };
  u_char macsa[] = { 0xba, 0x22, 0xd3, 0x75, 0x8f, 0x7c };
  assert_memory_equal( packet_info->eth_macda, macda, ETH_ADDRLEN );
  assert_memory_equal( packet_info->eth_macsa, macsa, ETH_ADDRLEN );

  uint16_t sample = ntohs( * ( uint16_t * ) packet_info->l3_payload );
  assert_int_equal( sample, 0x0205 );
  assert_int_equal( packet_info->l3_payload_length, 46 );

  free_packet_buffer_pool_entry( buffer );
}


static void
test_parse_packet_lldp_over_ip_succeeds() {
  const char filename[] = "./test_packets/lldp_over_ip.cap";
  buffer *copy;
  buffer *buffer = store_packet_to_buffer( filename );

  assert_true( parse_packet( buffer ) );

  packet_info *packet_info = buffer->user_data;

  assert_int_equal( packet_info->format, ETH_IPV4_ETHERIP );

  u_char macda[] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };
  u_char macsa[] = { 0xfe, 0xab, 0x7e, 0x15, 0x3f, 0xc6 };
  assert_memory_equal( packet_info->eth_macda, macda, ETH_ADDRLEN );
  assert_memory_equal( packet_info->eth_macsa, macsa, ETH_ADDRLEN );

  assert_int_equal( packet_info->ipv4_version, 4 );
  assert_int_equal( packet_info->ipv4_ihl, 5 );
  assert_int_equal( packet_info->ipv4_tos, 0 );
  assert_int_equal( packet_info->ipv4_tot_len, 51 );
  assert_int_equal( packet_info->ipv4_id, 0 );
  assert_int_equal( packet_info->ipv4_frag_off, 0 );
  assert_int_equal( packet_info->ipv4_ttl, 1 );
  assert_int_equal( packet_info->ipv4_protocol, 97 );
  assert_int_equal( packet_info->ipv4_checksum, 0 );
  assert_int_equal( packet_info->ipv4_saddr, 0x0a2a7aca );
  assert_int_equal( packet_info->ipv4_daddr, 0x0a2a7ad4 );

  uint16_t sample = ntohs( * ( uint16_t * ) packet_info->l4_payload );
  assert_int_equal( sample, 0x0180 );
  assert_int_equal( packet_info->l4_payload_length, 31 );

  assert_int_equal( packet_info->etherip_version, ETHERIP_VERSION );
  assert_int_equal( packet_info->etherip_offset, 36 );

  copy = duplicate_packet_buffer_pool_entry( buffer );
  assert_true ( copy != NULL );
  assert_true( copy->length == buffer->length );
  copy->user_data = NULL;
  remove_front_buffer_pool_entry( copy, packet_info->etherip_offset );

  assert_true( parse_packet( copy ) );

  packet_info = copy->user_data;

  assert_int_equal( packet_info->format, ETH_LLDP );

  u_char lldp_macda[] = { 0x01, 0x80, 0xc2, 0x00, 0x00, 0x0e };
  u_char lldp_macsa[] = { 0xfe, 0xab, 0x7e, 0x15, 0x3f, 0xc6 };

  assert_memory_equal( packet_info->eth_macda, lldp_macda, ETH_ADDRLEN );
  assert_memory_equal( packet_info->eth_macsa, lldp_macsa, ETH_ADDRLEN );

  sample = ntohs( * ( uint16_t * ) packet_info->l3_payload );
  assert_int_equal( sample, 0x0205 );
  assert_int_equal( packet_info->l3_payload_length, 17 );

  free_packet_buffer_pool_entry( copy );

  free_packet_buffer_pool_entry( buffer );
}

static void
test_parse_packet_ipv6_nd_succeeds() {
  const char filename_sll[] = "./test_packets/v6_icmp_nd_sll.cap";
  buffer *buffer = store_packet_to_buffer( filename_sll );

  assert_true( parse_packet( buffer ) );

  packet_info *packet_info = buffer->user_data;

  assert_int_equal( packet_info->format, ETH_IPV6_ICMPV6 );

  u_char macda[] = { 0x00, 0x60, 0x97, 0x07, 0x69, 0x3a };
  u_char macsa[] = { 0x00, 0x00, 0x86, 0x05, 0x80, 0xda };
  assert_memory_equal( packet_info->eth_macda, macda, ETH_ADDRLEN );
  assert_memory_equal( packet_info->eth_macsa, macsa, ETH_ADDRLEN );

  assert_int_equal( packet_info->ipv6_version, 6 );
  u_char ipv6_daddr[] = { 0xfe, 0x80, 0x00, 0x00, 0x02, 0x60,
                          0x97, 0xff, 0xfe, 0x07, 0x69, 0xea };
  u_char ipv6_saddr[] = { 0xfe, 0x80, 0x00, 0x00, 0x02, 0x00,
                          0x86, 0xff, 0xfe, 0x05, 0x80, 0xda };
  assert_memory_equal( packet_info->ipv6_daddr, ipv6_daddr, IPV6_ADDRLEN );
  assert_memory_equal( packet_info->ipv6_saddr, ipv6_saddr, IPV6_ADDRLEN );
  assert_int_equal( packet_info->ipv6_tc, 0 );
  assert_int_equal( packet_info->ipv6_plen, 32 );
  assert_int_equal( packet_info->ipv6_nexthdr, 58 );
  assert_int_equal( packet_info->ipv6_hoplimit, 255 );

  assert_int_equal( packet_info->icmpv6_type, 135 );
  assert_int_equal( packet_info->icmpv6_code, 0 );

  u_char nd_sll[] = { 0x00, 0x00, 0x86, 0x05, 0x80, 0xda };
  assert_memory_equal( packet_info->ipv6_nd_sll, nd_sll, IPV6_LINK_LAYER_LEN );

  free_packet_buffer_pool_entry( buffer );
}

static void
test_parse_packet_ipv6_sll_succeeds() {
  const char filename[] = "./test_packets/v6_icmp_nd_sll.cap";
  buffer *buffer = store_packet_to_buffer( filename );

  assert_true( parse_packet( buffer ) );

  packet_info *packet_info = buffer->user_data;

  assert_int_equal( packet_info->format, ETH_IPV6_ICMPV6 );

  u_char macda[] = { 0x00, 0x60, 0x97, 0x07, 0x69, 0xea };
  u_char macsa[] = { 0x00, 0x00, 0x86, 0x05, 0x80, 0xda };
  assert_memory_equal( packet_info->eth_macda, macda, ETH_ADDRLEN );
  assert_memory_equal( packet_info->eth_macsa, macsa, ETH_ADDRLEN );

  assert_int_equal( packet_info->ipv6_version, 6 );
  u_char ipv6_daddr[] = { 0xfe, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                          0x02, 0x60, 0x97, 0xff, 0xfe, 0x07, 0x69, 0xea };
  u_char ipv6_saddr[] = { 0xfe, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                          0x02, 0x00, 0x86, 0xff, 0xfe, 0x05, 0x80, 0xda };
  assert_memory_equal( packet_info->ipv6_daddr, ipv6_daddr, IPV6_ADDRLEN );
  assert_memory_equal( packet_info->ipv6_saddr, ipv6_saddr, IPV6_ADDRLEN );
  assert_int_equal( packet_info->ipv6_tc, 0 );
  assert_int_equal( packet_info->ipv6_plen, 32 );
  assert_int_equal( packet_info->ipv6_nexthdr, 58 );
  assert_int_equal( packet_info->ipv6_hoplimit, 255 );

  assert_int_equal( packet_info->icmpv6_type, 135 );
  assert_int_equal( packet_info->icmpv6_code, 0 );

  u_char target[] = { 0xfe, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                      0x02, 0x60, 0x97, 0xff, 0xfe, 0x07, 0x69, 0xea };
  assert_memory_equal( packet_info->ipv6_nd_target, target, IPV6_ADDRLEN );
  u_char nd_sll[] = { 0x00, 0x00, 0x86, 0x05, 0x80, 0xda };
  assert_memory_equal( packet_info->ipv6_nd_sll, nd_sll, IPV6_LINK_LAYER_LEN );

  free_packet_buffer_pool_entry( buffer );
}

static void
test_parse_packet_ipv6_tll_succeeds() {
  const char filename[] = "./test_packets/v6_icmp_nd_tll.cap";
  buffer *buffer = store_packet_to_buffer( filename );

  assert_true( parse_packet( buffer ) );

  packet_info *packet_info = buffer->user_data;

  assert_int_equal( packet_info->format, ETH_IPV6_ICMPV6 );

  u_char macda[] = { 0x00, 0x00, 0x86, 0x05, 0x80, 0xda };
  u_char macsa[] = { 0x00, 0x60, 0x97, 0x07, 0x69, 0xea };
  assert_memory_equal( packet_info->eth_macda, macda, ETH_ADDRLEN );
  assert_memory_equal( packet_info->eth_macsa, macsa, ETH_ADDRLEN );

  assert_int_equal( packet_info->ipv6_version, 6 );
  u_char ipv6_daddr[] = { 0xfe, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                          0x02, 0x00, 0x86, 0xff, 0xfe, 0x05, 0x80, 0xda };
  u_char ipv6_saddr[] = { 0xfe, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                          0x02, 0x60, 0x97, 0xff, 0xfe, 0x07, 0x69, 0xea };
  assert_memory_equal( packet_info->ipv6_daddr, ipv6_daddr, IPV6_ADDRLEN );
  assert_memory_equal( packet_info->ipv6_saddr, ipv6_saddr, IPV6_ADDRLEN );
  assert_int_equal( packet_info->ipv6_tc, 0 );
  assert_int_equal( packet_info->ipv6_plen, 24 );
  assert_int_equal( packet_info->ipv6_nexthdr, 58 );
  assert_int_equal( packet_info->ipv6_hoplimit, 255 );

  assert_int_equal( packet_info->icmpv6_type, 136 );
  assert_int_equal( packet_info->icmpv6_code, 0 );

  u_char target[] = { 0xfe, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                      0x02, 0x60, 0x97, 0xff, 0xfe, 0x07, 0x69, 0xea };
  assert_memory_equal( packet_info->ipv6_nd_target, target, IPV6_ADDRLEN );

  free_packet_buffer_pool_entry( buffer );
}

static char *
test_helper_ipv6_create_filename(int i){


  char * ipv6_packet_filename;
  ipv6_packet_filename = xmalloc(1000);
  memset(ipv6_packet_filename, 0, 1000);
  strcat(ipv6_packet_filename ,"./test_packets/ipv6_exthdr/ipv6_packet");

  // Correct Sequences
  if ((i & (1 << 0)) != 0)
  {
      strcat(ipv6_packet_filename ,"_HopByHop");
  }

  if ((i & (1 << 1)) != 0)
  {
      strcat(ipv6_packet_filename ,"_Destination");
  }

  if ((i & (1 << 2)) != 0)
  {
      strcat(ipv6_packet_filename ,"_Routing");
  }

  if ((i & (1 << 3)) != 0)
  {
      strcat(ipv6_packet_filename ,"_Fragment");
  }

  if ((i & (1 << 4)) != 0)
  {
      strcat(ipv6_packet_filename ,"_Authentication");
  }

  if ((i & (1 << 5)) != 0)
  {
      strcat(ipv6_packet_filename ,"_Security");
  }

  if ((i & (1 << 6)) != 0)
  {
      strcat(ipv6_packet_filename ,"_Destination");
  }

  if ((i & (1 << 7)) != 0)
  {
      strcat(ipv6_packet_filename ,"_NoHeader");
  }

  strcat(ipv6_packet_filename ,".cap");

  return ipv6_packet_filename;
}

static uint16_t
test_helper_ipv6_create_flags(int i)
{
  uint16_t flags = 0;

  // Correct Sequences
  if ((i & (1 << 0)) != 0)
  {
      flags |= OFPIEH_HOP;
  }

  if ((i & (1 << 1)) != 0)
  {
      flags |= OFPIEH_DEST;
  }
  if ((i & (1 << 2)) != 0)
  {
      flags |= OFPIEH_ROUTER;
  }
  if ((i & (1 << 3)) != 0)
  {
      flags |= OFPIEH_FRAG;
  }
  if ((i & (1 << 4)) != 0)
  {
      flags |= OFPIEH_AUTH;
  }
  if ((i & (1 << 5)) != 0)
  {
      flags |= OFPIEH_ESP;
  }else{
    if ((i & (1 << 6)) != 0)
    {
        flags |= OFPIEH_DEST;
    }
    if ((i & (1 << 7)) != 0)
    {
        flags |= OFPIEH_NONEXT;
    }
  }
  return flags;
}

static void
test_parse_packet_ipv6_exthdr_correct() {
  char *filename;
  uint16_t exthdr_flags;

  for(int i = 0; i < 256 ; i++){
    filename = test_helper_ipv6_create_filename(i);
    assert_true(filename != NULL);
    buffer *buffer = store_packet_to_buffer( filename );

    assert_true( parse_packet( buffer ) );
    packet_info *packet_info = buffer->user_data;

    exthdr_flags = test_helper_ipv6_create_flags(i);

    if ( packet_info->ipv6_exthdr != exthdr_flags){ printf ("Error: i = %d\n", i); }
    assert_int_equal( packet_info->ipv6_exthdr, exthdr_flags);

    if ((exthdr_flags & OFPIEH_ESP) == 0){
        // Common Settings
      u_char macda[] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };
      u_char macsa[] = { 0x00, 0x21, 0x9b, 0x27, 0x3d, 0x95 };
      assert_memory_equal( packet_info->eth_macda, macda, ETH_ADDRLEN );
      assert_memory_equal( packet_info->eth_macsa, macsa, ETH_ADDRLEN );
      assert_int_equal( packet_info->eth_type, ETH_ETHTYPE_IPV6 );

      assert_int_equal( packet_info->ipv6_version, 6 );
      u_char ipv6_daddr[] = { 0x0f, 0x1e, 0x2d, 0x3c, 0x4b, 0x5a, 0x69, 0x78,
                              0x87, 0x96, 0xa5, 0xb4, 0xc3, 0xd2, 0xe1, 0xf0 };
      u_char ipv6_saddr[] = { 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77,
                              0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff };
      assert_memory_equal( packet_info->ipv6_daddr, ipv6_daddr, IPV6_ADDRLEN );
      assert_memory_equal( packet_info->ipv6_saddr, ipv6_saddr, IPV6_ADDRLEN );
      if (packet_info->ipv6_nexthdr == 6){
      //assert_int_equal( packet_info->ipv6_nexthdr, 6 );
      assert_int_equal( packet_info->tcp_src_port, 80 );
      assert_int_equal( packet_info->tcp_dst_port, 59201 );
      assert_int_equal( packet_info->tcp_seq_no, 0x014a7937 );
      assert_int_equal( packet_info->tcp_ack_no, 0xabdcd751 );

      assert_int_equal( packet_info->tcp_flags, 0x18 );
      assert_int_equal( packet_info->tcp_window, 65535 );
      assert_int_equal( packet_info->tcp_urgent, 0 );

      uint16_t sample = ntohs( * ( uint16_t * ) packet_info->l4_payload );

      assert_int_equal( packet_info->l4_payload_length, 827 + 4 );
      }
    } else {
        assert_int_equal( packet_info->ipv6_nexthdr, 50 );
    }
    free_packet_buffer_pool_entry(buffer);
    xfree(filename);
  }
}

static void
test_parse_packet_ipv6_exthdr_malformed() {
  uint16_t exthdr_flags;
  char *numbername = xmalloc(4);
  memset(numbername, 0, 4);
  int tmp1, tmp2;

  for(int i = 0; i < 200 ; i++){
    char *filename = xmalloc(1000);
    memset(filename, 0, 1000);
    strcat(filename ,"./test_packets/ipv6_exthdr/ipv6_malformed_");
    snprintf(numbername, 4, "%03d", i);
    strcat(filename , numbername);
    strcat(filename ,".cap");

    assert_true(filename != NULL);
    buffer *buffer = store_packet_to_buffer( filename );

    assert_true( parse_packet( buffer ));
    packet_info *packet_info = buffer->user_data;

    tmp1 = (packet_info->ipv6_exthdr) & OFPIEH_UNSEQ ;
    tmp2 = (packet_info->ipv6_exthdr) & OFPIEH_UNREP ;

    if (((tmp1 == OFPIEH_UNSEQ) || (tmp2 == OFPIEH_UNREP)) == false){
        printf ("ERROR: filename = %s\n", filename);
    }
    assert_true((tmp1 == OFPIEH_UNSEQ) || (tmp2 == OFPIEH_UNREP));

    free_packet_buffer_pool_entry(buffer);
    xfree(filename);
  }
  xfree(numbername);
}


static void
test_parse_packet_mpls(){
  const char filename[] = "./test_packets/mpls_8847.cap";
  buffer *buffer = store_packet_to_buffer( filename );
  assert_true( parse_packet( buffer ) );

  packet_info *packet_info = buffer->user_data;

  assert_int_equal( packet_info->format, ETH_MPLS_IPV4_ICMPV4 );
  assert_int_equal( packet_info->mpls_bos, 1);
  assert_int_equal( packet_info->mpls_label, 29);
  assert_int_equal( packet_info->mpls_tc, 0);

  u_char macda[] = { 0x00, 0x30, 0x96, 0xe6, 0xfc, 0x39 };
  u_char macsa[] = { 0x00, 0x30, 0x96, 0x05, 0x28, 0x38 };
  assert_memory_equal( packet_info->eth_macda, macda, ETH_ADDRLEN );
  assert_memory_equal( packet_info->eth_macsa, macsa, ETH_ADDRLEN );
  assert_int_equal( packet_info->eth_type, ETH_ETHTYPE_IPV4 );

  assert_int_equal( packet_info->l2_payload_length, 100 );

  assert_int_equal( packet_info->ipv4_version, 4 );
  assert_int_equal( packet_info->ipv4_ihl, 5 );
  assert_int_equal( packet_info->ipv4_tos, 0 );
  assert_int_equal( packet_info->ipv4_tot_len, 100 );
  assert_int_equal( packet_info->ipv4_id, 0x000a );
  assert_int_equal( packet_info->ipv4_frag_off, 0x0000 );
  assert_int_equal( packet_info->ipv4_ttl, 255 );
  assert_int_equal( packet_info->ipv4_protocol, IPPROTO_ICMP );
  assert_int_equal( packet_info->ipv4_checksum, 0xa56a );
  assert_int_equal( packet_info->ipv4_saddr, 0x0a010201 );
  assert_int_equal( packet_info->ipv4_daddr, 0x0a220001 );

  assert_true( packet_info->l2_mpls_header == ((uint8_t *)buffer->data + sizeof(ether_header_t)));

  assert_int_equal( packet_info->l3_payload_length, 80 );


  free_packet_buffer_pool_entry( buffer );
}


/******************************************************************************
 * Run tests.
 ******************************************************************************/


int
packet_parser_main() {
  UnitTest tests[] = {
// unit_test_setup_teardown( test_init_and_finalize_match_table_succeeds, setup, teardown ),

    unit_test_setup_teardown(  test_parse_packet_snap_succeeds, setup, teardown ),

    unit_test_setup_teardown(  test_parse_packet_arp_request_succeeds, setup, teardown ),

    unit_test_setup_teardown(  test_parse_packet_udp_succeeds, setup, teardown ),
    unit_test_setup_teardown(  test_parse_packet_udp_fragmented_head_succeeds, setup, teardown ),
    unit_test_setup_teardown(  test_parse_packet_udp_fragmented_next_succeeds, setup, teardown ),

    unit_test_setup_teardown(  test_parse_packet_tcp_syn_succeeds, setup, teardown ),
    unit_test_setup_teardown(  test_parse_packet_tcp_succeeds, setup, teardown ),

    unit_test_setup_teardown(  test_parse_packet_icmpv4_echo_request_succeeds, setup, teardown ),

    unit_test_setup_teardown(  test_parse_packet_vtag_icmpv4_echo_request_succeeds, setup, teardown ),
    unit_test_setup_teardown(  test_parse_packet_vtag_icmpv4_echo_reply_succeeds, setup, teardown ),

    unit_test_setup_teardown(  test_parse_packet_igmp_query_v2_succeeds, setup, teardown ),

    unit_test_setup_teardown(  test_parse_packet_lldp_succeeds, setup, teardown ),

    unit_test_setup_teardown(  test_parse_packet_lldp_over_ip_succeeds, setup, teardown ),

    unit_test_setup_teardown(  test_parse_packet_ipv6_sll_succeeds, setup, teardown ),
    unit_test_setup_teardown(  test_parse_packet_ipv6_tll_succeeds, setup, teardown ),

    unit_test_setup_teardown(  test_parse_packet_ipv6_exthdr_correct, setup, teardown ),
    unit_test_setup_teardown(  test_parse_packet_ipv6_exthdr_malformed, setup, teardown ),

    unit_test_setup_teardown(  test_parse_packet_mpls, setup, teardown ),
  };
  stub_logger();
  return run_tests( tests );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
