#include <string.h>
#include "cmockery_trema.h"
#include "port_manager.h"
#include "wrapper.h"
#include "packet_buffer_pool.h"

#define SELECT_TIMEOUT			100000
#define ILLIGAL_PORT_CONFIG		0xf000
#define VALID_DEVICE_NAME		"eth0"
#define INVALID_DEVICE_NAME		"NO_DEVICE"
#define MAX_SEND_QUEUE			10
#define MAX_RECV_QUEUE			10

static void
setup() {
	init_event_handler_datapath();
}

static void
teardown() {
	finalize_event_handler_datapath();
}

/********************************************************************************
 * Tests.
 ********************************************************************************/

static void test_init_port_manager() {
	assert_true(init_port_manager(SELECT_TIMEOUT, MAX_SEND_QUEUE, MAX_RECV_QUEUE) == OFDPE_SUCCESS);
	finalize_port_manager();

        assert_true(init_port_manager(0, MAX_SEND_QUEUE, MAX_RECV_QUEUE) == ERROR_ILLIGAL_PARAMETER);
        assert_true(init_port_manager(SELECT_TIMEOUT, 0, MAX_RECV_QUEUE) == ERROR_ILLIGAL_PARAMETER);
        assert_true(init_port_manager(SELECT_TIMEOUT, MAX_SEND_QUEUE, 0) == ERROR_ILLIGAL_PARAMETER);
}

static void test_finalize_port_manager() {
	init_port_manager(SELECT_TIMEOUT, MAX_SEND_QUEUE, MAX_RECV_QUEUE);
	assert_true(finalize_port_manager() == OFDPE_SUCCESS);
}

static void test_init_device() {
	argument_device_info device;
	strcpy(device.device_name, VALID_DEVICE_NAME);
	device.port_no = 1;

	init_port_manager(SELECT_TIMEOUT, MAX_SEND_QUEUE, MAX_RECV_QUEUE);

        assert_true(init_device(&device) == OFDPE_SUCCESS);
        finalize_device(device.port_no);

        assert_true(init_device(&device) == OFDPE_SUCCESS);
        assert_true(init_device(&device) == ERROR_OFDPE_PORT_MOD_FAILED_BAD_PORT);
        finalize_device(device.port_no);

        device.port_no = 0;
        assert_true(init_device(&device) == OFDPE_SUCCESS);
        device.port_no = 0;
        assert_true(init_device(&device) == OFDPE_SUCCESS);
        device.port_no = 0;
        assert_true(init_device(&device) == OFDPE_SUCCESS);
        assert_true(finalize_device(1) == OFDPE_SUCCESS);
        assert_true(finalize_device(2) == OFDPE_SUCCESS);
        assert_true(finalize_device(3) == OFDPE_SUCCESS);

	strcpy(device.device_name, INVALID_DEVICE_NAME);
	device.port_no = 2;
	assert_true(init_device(&device) == ERROR_OFDPE_PORT_MOD_FAILED_EPERM);

	assert_true(init_device(NULL) == ERROR_ILLIGAL_PARAMETER);

	finalize_port_manager();
}

static void test_finalize_device() {
	argument_device_info device;
	strcpy(device.device_name, VALID_DEVICE_NAME);
	device.port_no = 1;

	init_port_manager(SELECT_TIMEOUT, MAX_SEND_QUEUE, MAX_RECV_QUEUE);

	init_device(&device);
	assert_true(finalize_device(device.port_no) == OFDPE_SUCCESS);

	assert_true(finalize_device(100) == ERROR_ILLIGAL_PARAMETER);

	finalize_port_manager();
}

static void test_send_data() {
	argument_device_info device;
	strcpy(device.device_name, VALID_DEVICE_NAME);
	device.port_no = 1;

	init_packet_buffer_pool(10, 1500);
	init_port_manager(SELECT_TIMEOUT, MAX_SEND_QUEUE, MAX_RECV_QUEUE);
	init_device(&device);

	const size_t buf_length = 10;

	buffer *send_buf;
	send_buf = allocate_packet_buffer_pool_entry(buf_length);
	packet_info packet;
	packet.eth_in_port = device.port_no;
	send_buf->user_data = &packet;

	assert_true(send_data(1, send_buf) == OFDPE_SUCCESS);
	assert_true(send_data(2, send_buf) == ERROR_ILLIGAL_PARAMETER);
	assert_true(send_data(OFPP_IN_PORT, send_buf) == OFDPE_SUCCESS);
	assert_true(send_data(OFPP_ALL, send_buf) == OFDPE_SUCCESS);

	assert_true(send_data(OFPP_MAX, send_buf) == ERROR_ILLIGAL_PARAMETER);
	assert_true(send_data(OFPP_NORMAL, send_buf) == ERROR_ILLIGAL_PARAMETER);
	assert_true(send_data(OFPP_FLOOD, send_buf) == ERROR_ILLIGAL_PARAMETER);
	assert_true(send_data(OFPP_CONTROLLER, send_buf) == ERROR_ILLIGAL_PARAMETER);
	assert_true(send_data(OFPP_LOCAL, send_buf) == ERROR_ILLIGAL_PARAMETER);
//	assert_true(send_data(OFPP_TABLE, send_buf) == OFDPE_SUCCESS);

	free_packet_buffer_pool_entry(send_buf);

	finalize_device(device.port_no);


	init_device(&device);

	assert_true(send_data(1, NULL) == ERROR_ILLIGAL_PARAMETER);

	finalize_device(device.port_no);


	finalize_port_manager();
	finalize_packet_buffer_pool();
}

static void test_is_device_linkup() {
	init_port_manager(SELECT_TIMEOUT, MAX_SEND_QUEUE, MAX_RECV_QUEUE);

	argument_device_info device02;
	strcpy(device02.device_name, INVALID_DEVICE_NAME);
	device02.port_no = 2;
	init_device(&device02);

	argument_device_info device01;
	strcpy(device01.device_name, VALID_DEVICE_NAME);
	device01.port_no = 1;
	init_device(&device01);


	update_port_config(device01.port_no, OFPPC_PORT_DOWN, OFPPC_PORT_DOWN);
	assert_true(is_device_linkup(device01.port_no) == false);
        assert_true(is_device_linkup(OFPP_ALL) == false);

	update_port_config(device01.port_no, ( uint32_t ) ~OFPPC_PORT_DOWN, OFPPC_PORT_DOWN);
	assert_true(is_device_linkup(device01.port_no) == true);
        assert_true(is_device_linkup(OFPP_ALL) == true);

	assert_true(is_device_linkup(device02.port_no) == false);


	finalize_device(device01.port_no);
	finalize_port_manager();
}

static void test_get_device_statistics() {
	argument_device_info device01;
	strcpy(device01.device_name, VALID_DEVICE_NAME);
	device01.port_no = 1;

	argument_device_info device02;
	strcpy(device02.device_name, "lo");
	device02.port_no = 2;

	argument_device_info device03;
	strcpy(device03.device_name, INVALID_DEVICE_NAME);
	device03.port_no = 3;

	init_port_manager(SELECT_TIMEOUT, MAX_SEND_QUEUE, MAX_RECV_QUEUE);
	init_device(&device01);
	init_device(&device02);
	init_device(&device03);

	ofp_port_stats *stats;
	int num_stats;


	assert_true(get_device_statistics(device01.port_no, &stats, &num_stats) == OFDPE_SUCCESS);
	assert_true(num_stats == 1);
	assert_true(stats[0].port_no == device01.port_no);
	xfree(stats);

	assert_true(get_device_statistics(OFPP_ALL, &stats, &num_stats) == OFDPE_SUCCESS);
	assert_true(num_stats == 2);
	assert_true(stats[0].port_no == device02.port_no);
	assert_true(stats[1].port_no == device01.port_no);
	xfree(stats);

	assert_true(get_device_statistics(OFPP_TABLE, &stats, &num_stats) == ERROR_NO_SUPPORTED);

	assert_true(get_device_statistics(OFPP_IN_PORT, &stats, &num_stats) == ERROR_ILLIGAL_PARAMETER);
	assert_true(get_device_statistics(OFPP_MAX, &stats, &num_stats) == ERROR_ILLIGAL_PARAMETER);
	assert_true(get_device_statistics(OFPP_NORMAL, &stats, &num_stats) == ERROR_ILLIGAL_PARAMETER);
	assert_true(get_device_statistics(OFPP_FLOOD, &stats, &num_stats) == ERROR_ILLIGAL_PARAMETER);
	assert_true(get_device_statistics(OFPP_CONTROLLER, &stats, &num_stats) == ERROR_ILLIGAL_PARAMETER);
	assert_true(get_device_statistics(OFPP_LOCAL, &stats, &num_stats) == ERROR_ILLIGAL_PARAMETER);

	assert_true(get_device_statistics(10, &stats, &num_stats) == ERROR_ILLIGAL_PARAMETER);


	finalize_device(device01.port_no);
	finalize_device(device02.port_no);
	finalize_device(device03.port_no);
	finalize_port_manager();
}


static void test_increment_port_tx_dropped() {
	argument_device_info device01;
	strcpy(device01.device_name, VALID_DEVICE_NAME);
	device01.port_no = 1;

	argument_device_info device02;
	strcpy(device02.device_name, INVALID_DEVICE_NAME);
	device02.port_no = 2;

	init_port_manager(SELECT_TIMEOUT, MAX_SEND_QUEUE, MAX_RECV_QUEUE);
	init_device(&device01);
	init_device(&device02);


	switch_port *port = NULL;

	port = lookup_switch_port(device01.port_no);
	assert_true(port->device->stats.tx_dropped == 0);

	assert_true(increment_port_tx_dropped(device01.port_no) == OFDPE_SUCCESS);
	port = lookup_switch_port(device01.port_no);
	assert_true(port->device->stats.tx_dropped == 1);

	assert_true(increment_port_tx_dropped(device01.port_no) == OFDPE_SUCCESS);
	port = lookup_switch_port(device01.port_no);
	assert_true(port->device->stats.tx_dropped == 2);

	assert_true(increment_port_tx_dropped(device01.port_no) == OFDPE_SUCCESS);
	port = lookup_switch_port(device01.port_no);
	assert_true(port->device->stats.tx_dropped == 3);


	assert_true(increment_port_tx_dropped(device02.port_no) == ERROR_ILLIGAL_PARAMETER);


	finalize_device(device01.port_no);
	finalize_device(device02.port_no);
	finalize_port_manager();
}

static void test_update_port_config() {
	switch_port *port;

	argument_device_info device;
	strcpy(device.device_name, VALID_DEVICE_NAME);
	device.port_no = 1;

	init_port_manager(SELECT_TIMEOUT, MAX_SEND_QUEUE, MAX_RECV_QUEUE);

	init_device(&device);
	port = lookup_switch_port(device.port_no);


	assert_true(update_port_config(device.port_no, OFPPC_PORT_DOWN, OFPPC_PORT_DOWN) == OFDPE_SUCCESS);
	assert_true((port->config & OFPPC_PORT_DOWN) == OFPPC_PORT_DOWN);

	assert_true(update_port_config(device.port_no, ( uint32_t ) ~OFPPC_PORT_DOWN, OFPPC_PORT_DOWN) == OFDPE_SUCCESS);
	assert_true((port->config & OFPPC_PORT_DOWN) != OFPPC_PORT_DOWN);


	assert_true(update_port_config(device.port_no, OFPPC_NO_RECV, OFPPC_NO_RECV) == OFDPE_SUCCESS);
	assert_true((port->config & OFPPC_NO_RECV) == OFPPC_NO_RECV);

	assert_true(update_port_config(device.port_no, ( uint32_t ) ~OFPPC_NO_RECV, OFPPC_NO_RECV) == OFDPE_SUCCESS);
	assert_true((port->config & OFPPC_NO_RECV) != OFPPC_NO_RECV);


	assert_true(update_port_config(device.port_no, OFPPC_NO_FWD, OFPPC_NO_FWD) == OFDPE_SUCCESS);
	assert_true((port->config & OFPPC_NO_FWD) == OFPPC_NO_FWD);

	assert_true(update_port_config(device.port_no, ( uint32_t ) ~OFPPC_NO_FWD, OFPPC_NO_FWD) == OFDPE_SUCCESS);
	assert_true((port->config & OFPPC_NO_FWD) != OFPPC_NO_FWD);


	assert_true(update_port_config(device.port_no, OFPPC_NO_PACKET_IN, OFPPC_NO_PACKET_IN) == OFDPE_SUCCESS);
	assert_true((port->config & OFPPC_NO_PACKET_IN) == OFPPC_NO_PACKET_IN);

	assert_true(update_port_config(device.port_no, ( uint32_t ) ~OFPPC_NO_PACKET_IN, OFPPC_NO_PACKET_IN) == OFDPE_SUCCESS);
	assert_true((port->config & OFPPC_NO_PACKET_IN) != OFPPC_NO_PACKET_IN);


	assert_true(update_port_config(device.port_no, ILLIGAL_PORT_CONFIG, ILLIGAL_PORT_CONFIG) == ERROR_OFDPE_PORT_MOD_FAILED_BAD_CONFIG);


	finalize_device(device.port_no);
	finalize_port_manager();
}

static void test_get_switch_mtu() {
	argument_device_info device01;
	strcpy(device01.device_name, VALID_DEVICE_NAME);
	device01.port_no = 1;

	argument_device_info device02;
	strcpy(device02.device_name, INVALID_DEVICE_NAME);
	device02.port_no = 2;

	list_element list_01;
	list_element list_02;
	list_01.data = &device01;
	list_01.next = &list_02;
	list_02.data = &device02;
	list_02.next = NULL;

	assert_true(get_switch_mtu(&list_01) != 0);
	assert_true(get_switch_mtu(&list_02) == 0);
}


static void test_get_port_description() {
        argument_device_info device01;
        strcpy(device01.device_name, VALID_DEVICE_NAME);
        device01.port_no = 1;

        init_port_manager(SELECT_TIMEOUT, MAX_SEND_QUEUE, MAX_RECV_QUEUE);
        init_device(&device01);

        device01.port_no = 2;
        init_device(&device01);


        ofp_port *descriptions;
        uint32_t num;

        assert_true(get_port_description(device01.port_no, &descriptions, &num) == OFDPE_SUCCESS);
        assert_true(descriptions != NULL);
        assert_true(num == 1);
        xfree(descriptions);

        assert_true(get_port_description(OFPP_ALL, &descriptions, &num) == OFDPE_SUCCESS);
        assert_true(descriptions != NULL);
        assert_true(num == 2);
        xfree(descriptions);

        assert_true(get_port_description(device01.port_no, NULL, &num) == ERROR_ILLIGAL_PARAMETER);
        assert_true(get_port_description(device01.port_no, &descriptions, NULL) == ERROR_ILLIGAL_PARAMETER);
        assert_true(get_port_description(device01.port_no, NULL, NULL) == ERROR_ILLIGAL_PARAMETER);
        assert_true(get_port_description(9999, &descriptions, &num) == ERROR_ILLIGAL_PARAMETER);

        assert_true(get_port_description(OFPP_TABLE, &descriptions, &num) == ERROR_ILLIGAL_PARAMETER);
        assert_true(get_port_description(OFPP_IN_PORT, &descriptions, &num) == ERROR_ILLIGAL_PARAMETER);
        assert_true(get_port_description(OFPP_MAX, &descriptions, &num) == ERROR_ILLIGAL_PARAMETER);
        assert_true(get_port_description(OFPP_NORMAL, &descriptions, &num) == ERROR_ILLIGAL_PARAMETER);
        assert_true(get_port_description(OFPP_FLOOD, &descriptions, &num) == ERROR_ILLIGAL_PARAMETER);
        assert_true(get_port_description(OFPP_CONTROLLER, &descriptions, &num) == ERROR_ILLIGAL_PARAMETER);
        assert_true(get_port_description(OFPP_LOCAL, &descriptions, &num) == ERROR_ILLIGAL_PARAMETER);


        finalize_device(device01.port_no);
        finalize_port_manager();
}

/********************************************************************************
 * Run tests.
 ********************************************************************************/

int port_manager_main() {
	const UnitTest tests[] = {
			unit_test_setup_teardown(test_init_port_manager, setup, teardown ),
			unit_test_setup_teardown(test_finalize_port_manager, setup, teardown ),
			unit_test_setup_teardown(test_init_device, setup, teardown ),
			unit_test_setup_teardown(test_finalize_device, setup, teardown ),
			unit_test_setup_teardown(test_send_data, setup, teardown ),
			unit_test_setup_teardown(test_is_device_linkup, setup, teardown ),
			unit_test_setup_teardown(test_get_device_statistics, setup, teardown ),
			unit_test_setup_teardown(test_increment_port_tx_dropped, setup, teardown ),
			unit_test_setup_teardown(test_update_port_config, setup, teardown ),
                        unit_test_setup_teardown(test_get_switch_mtu, setup, teardown ),
                        unit_test(test_get_port_description),
	};
	setup_leak_detector();
	return run_tests(tests);
}
