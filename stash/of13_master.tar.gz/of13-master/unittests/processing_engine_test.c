#include "cmockery_trema.h"
#include "processing_engine.h"
#include "table_manager.h"
#include "action_executor.h"
#include "packet_info.h"
#include "packet_buffer_pool.h"
#include "port_manager.h"
#include "packet_matcher.h"

#define POOL_SIZE	2
#define ALLOC_SIZE 0x000f
#define SELECT_TIMEOUT			100000
#define MAX_SEND_QUEUE                  10
#define MAX_RECV_QUEUE                  10

static int test_no = 0;
static flow_entry *entry = NULL;
static uint16_t exec_action_list = 0;
static uint16_t exec_action_set = 0;

static flow_entry *mock_match_entry_fetcher(buffer *parsed_buffer, uint8_t table_id) {
	instruction_list *instructions = NULL;
	action *act = NULL;
	action_list *alist = NULL;
	UNUSED(parsed_buffer);
	match *p_match;

	exec_action_list = 0;
	exec_action_set = 0;

	switch(test_no) {
	case 1:
		if(table_id == 0 ) {
		    p_match = init_match();
		    instructions = init_instruction_list();
			append_instruction(instructions, create_instruction_goto_table(1));
			entry = create_flow_entry(p_match, instructions, 1, 0, 0, 0, 0);
		} else {
			delete_flow_entry(&entry);
			entry = NULL;
		}
		break;
	case 2:
          p_match = init_match();
		instructions = init_instruction_list();
		append_instruction(instructions, create_instruction_write_metadata(0xffffffffffffffff, 0x0000000000000001));
		entry = create_flow_entry(p_match, instructions, 1, 0, 0, 0, 0);
		break;
	case 3:
		if(table_id == 0 ) {
                    p_match = init_match();
			instructions = init_instruction_list();
			append_instruction(instructions, create_instruction_goto_table(1));

			alist = init_action_list();
			act = create_action_output( 1, 1500 );
			append_action( alist, act );
			append_instruction(instructions, create_instruction_write_actions( alist ));

			entry = create_flow_entry(p_match, instructions, 1, 0, 0, 0, 0);
		} else {
			delete_flow_entry(&entry);
			entry = NULL;

	                    p_match = init_match();
			instructions = init_instruction_list();
			append_instruction(instructions, create_instruction_clear_actions());
			entry = create_flow_entry(p_match, instructions, 1, 0, 0, 0, 0);
		}
		break;
	case 4:
		instructions = init_instruction_list();
                p_match = init_match();
		append_instruction(instructions, create_instruction_meter(1));
		entry = create_flow_entry(p_match, instructions, 1, 0, 0, 0, 0);
		break;
	case 101:
	case 201:
		alist = init_action_list();
		act = create_action_output(1, 1500);
		append_action(alist, act);

                p_match = init_match();
		instructions = init_instruction_list();
		if(test_no >= 200) {
			append_instruction(instructions, create_instruction_apply_actions(alist));
		} else {
			append_instruction(instructions, create_instruction_write_actions(alist));
		}
		entry = create_flow_entry(p_match, instructions, 1, 0, 0, 0, 0);
		break;
	case 102:
	case 202:
		alist = init_action_list();
		act = create_action_copy_ttl_out();
		append_action(alist, act);

                p_match = init_match();
		instructions = init_instruction_list();
		if(test_no >= 200) {
			append_instruction(instructions, create_instruction_apply_actions(alist));
		} else {
			append_instruction(instructions, create_instruction_write_actions(alist));
		}
		entry = create_flow_entry(p_match, instructions, 1, 0, 0, 0, 0);
		break;
	case 103:
	case 203:
		alist = init_action_list();
		act = create_action_copy_ttl_in();
		append_action(alist, act);

                p_match = init_match();
		instructions = init_instruction_list();
		if(test_no >= 200) {
			append_instruction(instructions, create_instruction_apply_actions(alist));
		} else {
			append_instruction(instructions, create_instruction_write_actions(alist));
		}
		entry = create_flow_entry(p_match, instructions, 1, 0, 0, 0, 0);
		break;
	case 104:
	case 204:
		alist = init_action_list();
		act = create_action_set_mpls_ttl(100);
		append_action(alist, act);

                p_match = init_match();
		instructions = init_instruction_list();
		if(test_no >= 200) {
			append_instruction(instructions, create_instruction_apply_actions(alist));
		} else {
			append_instruction(instructions, create_instruction_write_actions(alist));
		}
		entry = create_flow_entry(p_match, instructions, 1, 0, 0, 0, 0);
		break;
	case 105:
	case 205:
		alist = init_action_list();
		act = create_action_decr_mpls_ttl();
		append_action(alist, act);

                p_match = init_match();
		instructions = init_instruction_list();
		if(test_no >= 200) {
			append_instruction(instructions, create_instruction_apply_actions(alist));
		} else {
			append_instruction(instructions, create_instruction_write_actions(alist));
		}
		entry = create_flow_entry(p_match, instructions, 1, 0, 0, 0, 0);
		break;
	case 106:
	case 206:
		alist = init_action_list();
		act = create_action_push_vlan(1);
		append_action(alist, act);

                p_match = init_match();
		instructions = init_instruction_list();
		if(test_no >= 200) {
			append_instruction(instructions, create_instruction_apply_actions(alist));
		} else {
			append_instruction(instructions, create_instruction_write_actions(alist));
		}
		entry = create_flow_entry(p_match, instructions, 1, 0, 0, 0, 0);
		break;
	case 107:
	case 207:
		alist = init_action_list();
		act = create_action_pop_vlan();
		append_action(alist, act);

                p_match = init_match();
		instructions = init_instruction_list();
		if(test_no >= 200) {
			append_instruction(instructions, create_instruction_apply_actions(alist));
		} else {
			append_instruction(instructions, create_instruction_write_actions(alist));
		}
		entry = create_flow_entry(p_match, instructions, 1, 0, 0, 0, 0);
		break;
	case 108:
	case 208:
		alist = init_action_list();
		act = create_action_push_mpls(1);
		append_action(alist, act);

                p_match = init_match();
		instructions = init_instruction_list();
		if(test_no >= 200) {
			append_instruction(instructions, create_instruction_apply_actions(alist));
		} else {
			append_instruction(instructions, create_instruction_write_actions(alist));
		}
		entry = create_flow_entry(p_match, instructions, 1, 0, 0, 0, 0);
		break;
	case 109:
	case 209:
		alist = init_action_list();
		act = create_action_pop_mpls(1);
		append_action(alist, act);

                p_match = init_match();
		instructions = init_instruction_list();
		if(test_no >= 200) {
			append_instruction(instructions, create_instruction_apply_actions(alist));
		} else {
			append_instruction(instructions, create_instruction_write_actions(alist));
		}
		entry = create_flow_entry(p_match, instructions, 1, 0, 0, 0, 0);
		break;
	case 110:
	case 210:
		alist = init_action_list();
		act = create_action_set_queue(1);
		append_action(alist, act);

                p_match = init_match();
		instructions = init_instruction_list();
		if(test_no >= 200) {
			append_instruction(instructions, create_instruction_apply_actions(alist));
		} else {
			append_instruction(instructions, create_instruction_write_actions(alist));
		}
		entry = create_flow_entry(p_match, instructions, 1, 0, 0, 0, 0);
		break;
	case 111:
	case 211:
		alist = init_action_list();
		act = create_action_group(1);
		append_action(alist, act);

                p_match = init_match();
		instructions = init_instruction_list();
		if(test_no >= 200) {
			append_instruction(instructions, create_instruction_apply_actions(alist));
		} else {
			append_instruction(instructions, create_instruction_write_actions(alist));
		}
		entry = create_flow_entry(p_match, instructions, 1, 0, 0, 0, 0);
		break;
	case 112:
	case 212:
		alist = init_action_list();
		act = create_action_set_ipv4_ttl(1);
		append_action(alist, act);

                p_match = init_match();
		instructions = init_instruction_list();
		if(test_no >= 200) {
			append_instruction(instructions, create_instruction_apply_actions(alist));
		} else {
			append_instruction(instructions, create_instruction_write_actions(alist));
		}
		entry = create_flow_entry(p_match, instructions, 1, 0, 0, 0, 0);
		break;
	case 113:
	case 213:
		alist = init_action_list();
		act = create_action_decr_ipv4_ttl();
		append_action(alist, act);

                p_match = init_match();
		instructions = init_instruction_list();
		if(test_no >= 200) {
			append_instruction(instructions, create_instruction_apply_actions(alist));
		} else {
			append_instruction(instructions, create_instruction_write_actions(alist));
		}
		entry = create_flow_entry(p_match, instructions, 1, 0, 0, 0, 0);
		break;
	case 114:
	case 214:
		alist = init_action_list();
		act = create_action_set_field(NULL);
		append_action(alist, act);

                p_match = init_match();
		instructions = init_instruction_list();
		if(test_no >= 200) {
			append_instruction(instructions, create_instruction_apply_actions(alist));
		} else {
			append_instruction(instructions, create_instruction_write_actions(alist));
		}
		entry = create_flow_entry(p_match, instructions, 1, 0, 0, 0, 0);
		break;
	case 115:
	case 215:
		alist = init_action_list();
		act = create_action_push_pbb(1);
		append_action(alist, act);

                p_match = init_match();
		instructions = init_instruction_list();
		if(test_no >= 200) {
			append_instruction(instructions, create_instruction_apply_actions(alist));
		} else {
			append_instruction(instructions, create_instruction_write_actions(alist));
		}
		entry = create_flow_entry(p_match, instructions, 1, 0, 0, 0, 0);
		break;
	case 116:
	case 216:
		alist = init_action_list();
		act = create_action_pop_pbb();
		append_action(alist, act);

                p_match = init_match();
		instructions = init_instruction_list();
		if(test_no >= 200) {
			append_instruction(instructions, create_instruction_apply_actions(alist));
		} else {
			append_instruction(instructions, create_instruction_write_actions(alist));
		}
		entry = create_flow_entry(p_match, instructions, 1, 0, 0, 0, 0);
		break;
	}

	return entry;
}

static OFDPE mock_execute_action_list(action_list *list, buffer *packet) {
	exec_action_list = 0;

	(void)packet;

	if(list == NULL) {
		return OFDPE_SUCCESS;
	}

	  for ( action_list *element = list; element != NULL; element = element->next ) {
		  action *action = element->node;
		  if(action!= NULL) {
			  exec_action_list = action->type;
		  }
	  }

		return OFDPE_SUCCESS;
}

static OFDPE mock_execute_action_set(action_set *set, buffer *packet) {
	exec_action_set = 0;

	if(set == NULL) {
		return OFDPE_SUCCESS;
	}
	(void)packet;

	if(set->copy_ttl_in != NULL) {
		exec_action_set = set->copy_ttl_in->type;
	}
	if(set->copy_ttl_out != NULL) {
		exec_action_set = set->copy_ttl_out->type;
	}
	if(set->dec_mpls_ttl != NULL) {
		exec_action_set = set->dec_mpls_ttl->type;
	}
	if(set->dec_nw_ttl != NULL) {
		exec_action_set = set->dec_nw_ttl->type;
	}
	if(set->group != NULL) {
		exec_action_set = set->group->type;
	}
	if(set->output != NULL) {
		exec_action_set = set->output->type;
	}
	if(set->pop_mpls != NULL) {
		exec_action_set = set->pop_mpls->type;
	}
	if(set->pop_pbb != NULL) {
		exec_action_set = set->pop_pbb->type;
	}
	if(set->pop_vlan != NULL) {
		exec_action_set = set->pop_vlan->type;
	}
	if(set->push_mpls != NULL) {
		exec_action_set = set->push_mpls->type;
	}
	if(set->push_pbb != NULL) {
		exec_action_set = set->push_pbb->type;
	}
	if(set->push_vlan != NULL) {
		exec_action_set = set->push_vlan->type;
	}
	if(set->set_field != NULL) {
		exec_action_set = set->set_field->type;
	}
	if(set->set_mpls_ttl != NULL) {
		exec_action_set = set->set_mpls_ttl->type;
	}
	if(set->set_nw_ttl != NULL) {
		exec_action_set = set->set_nw_ttl->type;
	}
	if(set->set_queue != NULL) {
		exec_action_set = set->set_queue->type;
	}

	return OFDPE_SUCCESS;
}

/********************************************************************************
 * Tests.
 ********************************************************************************/

static void
test_init_processing_engine() {
	assert_true( init_processing_engine() == OFDPE_SUCCESS );
	finalize_processing_engine();
}

static void
test_finalize_processing_engine() {
	init_processing_engine();
	assert_true( finalize_processing_engine() == OFDPE_SUCCESS );
}

static void
test_execute_processing() {
	init_processing_engine();
	init_packet_buffer_pool(POOL_SIZE, ALLOC_SIZE);
	init_table_manager();
	init_port_manager(SELECT_TIMEOUT, MAX_SEND_QUEUE, MAX_RECV_QUEUE);


	match_entry_fetcher = mock_match_entry_fetcher;
	execute_action_set = mock_execute_action_set;

	switch_port port;
	buffer *buf = NULL;


	test_no = 1;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	buf->user_data = xcalloc(1, sizeof(packet_info));
	execute_processing(&port, buf);
	assert_true(entry == NULL);

	if(entry != NULL) delete_flow_entry(&entry);
	xfree(buf->user_data);
	free_packet_buffer_pool_entry(buf);


	test_no = 2;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	buf->user_data = xcalloc(1, sizeof(packet_info));
	((packet_info *)buf->user_data)->metadata = 0;
	execute_processing(&port, buf);
	assert_true(((packet_info *)buf->user_data)->metadata == 1);

	if(entry != NULL) delete_flow_entry(&entry);
	xfree(buf->user_data);
	free_packet_buffer_pool_entry(buf);


	test_no = 3;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == 0);
	assert_true(exec_action_set == 0);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 4;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == 0);
	assert_true(exec_action_set == 0);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	finalize_port_manager();
	finalize_packet_buffer_pool();
	finalize_table_manager();
	finalize_processing_engine();
}

static void
test_execute_processing_write_action() {
	init_processing_engine();
	init_packet_buffer_pool(POOL_SIZE, ALLOC_SIZE);
	init_table_manager();
	init_port_manager(SELECT_TIMEOUT, MAX_SEND_QUEUE, MAX_RECV_QUEUE);


	match_entry_fetcher = mock_match_entry_fetcher;
	execute_action_set = mock_execute_action_set;

	switch_port port;
	buffer *buf = NULL;


	test_no = 101;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == 0);
	assert_true(exec_action_set == OFPAT_OUTPUT);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 102;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == 0);
	assert_true(exec_action_set == OFPAT_COPY_TTL_OUT);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 103;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == 0);
	assert_true(exec_action_set == OFPAT_COPY_TTL_IN);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 104;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == 0);
	assert_true(exec_action_set == OFPAT_SET_MPLS_TTL);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 105;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == 0);
	assert_true(exec_action_set == OFPAT_DEC_MPLS_TTL);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 106;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == 0);
	assert_true(exec_action_set == OFPAT_PUSH_VLAN);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 107;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == 0);
	assert_true(exec_action_set == OFPAT_POP_VLAN);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 108;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == 0);
	assert_true(exec_action_set == OFPAT_PUSH_MPLS);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 109;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == 0);
	assert_true(exec_action_set == OFPAT_POP_MPLS);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 110;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == 0);
	assert_true(exec_action_set == OFPAT_SET_QUEUE);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 111;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	init_group_table();
	execute_processing(&port, buf);
	assert_true(exec_action_list == 0);
	assert_true(exec_action_set == OFPAT_GROUP);

	if(entry != NULL) delete_flow_entry(&entry);
	finalize_group_table();
	free_packet_buffer_pool_entry(buf);


	test_no = 112;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == 0);
	assert_true(exec_action_set == OFPAT_SET_NW_TTL);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 113;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == 0);
	assert_true(exec_action_set == OFPAT_DEC_NW_TTL);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 114;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == 0);
	assert_true(exec_action_set == OFPAT_SET_FIELD);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 115;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == 0);
	assert_true(exec_action_set == OFPAT_PUSH_PBB);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 116;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == 0);
	assert_true(exec_action_set == OFPAT_POP_PBB);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	finalize_port_manager();
	finalize_packet_buffer_pool();
	finalize_table_manager();
	finalize_processing_engine();
}

static void
test_execute_processing_apply_action() {
	init_processing_engine();
	init_packet_buffer_pool(POOL_SIZE, ALLOC_SIZE);
	init_table_manager();
	init_port_manager(SELECT_TIMEOUT, MAX_SEND_QUEUE, MAX_RECV_QUEUE);

	match_entry_fetcher = mock_match_entry_fetcher;
	execute_action_list = mock_execute_action_list;

	switch_port port;
	buffer *buf = NULL;


	test_no = 201;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == OFPAT_OUTPUT);
	assert_true(exec_action_set == 0);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 202;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == OFPAT_COPY_TTL_OUT);
	assert_true(exec_action_set == 0);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 203;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == OFPAT_COPY_TTL_IN);
	assert_true(exec_action_set == 0);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 204;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == OFPAT_SET_MPLS_TTL);
	assert_true(exec_action_set == 0);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 205;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == OFPAT_DEC_MPLS_TTL);
	assert_true(exec_action_set == 0);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 206;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == OFPAT_PUSH_VLAN);
	assert_true(exec_action_set == 0);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 207;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == OFPAT_POP_VLAN);
	assert_true(exec_action_set == 0);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 208;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == OFPAT_PUSH_MPLS);
	assert_true(exec_action_set == 0);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 209;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == OFPAT_POP_MPLS);
	assert_true(exec_action_set == 0);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 210;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == OFPAT_SET_QUEUE);
	assert_true(exec_action_set == 0);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 211;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	init_group_table();
	execute_processing(&port, buf);
	assert_true(exec_action_list == OFPAT_GROUP);
	assert_true(exec_action_set == 0);

	if(entry != NULL) delete_flow_entry(&entry);
	finalize_group_table();
	free_packet_buffer_pool_entry(buf);


	test_no = 212;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == OFPAT_SET_NW_TTL);
	assert_true(exec_action_set == 0);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 213;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == OFPAT_DEC_NW_TTL);
	assert_true(exec_action_set == 0);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 214;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == OFPAT_SET_FIELD);
	assert_true(exec_action_set == 0);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 215;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == OFPAT_PUSH_PBB);
	assert_true(exec_action_set == 0);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	test_no = 216;
	port.port_no = test_no;
	buf = allocate_packet_buffer();
	execute_processing(&port, buf);
	assert_true(exec_action_list == OFPAT_POP_PBB);
	assert_true(exec_action_set == 0);

	if(entry != NULL) delete_flow_entry(&entry);
	free_packet_buffer_pool_entry(buf);


	finalize_port_manager();
	finalize_packet_buffer_pool();
	finalize_table_manager();
	finalize_processing_engine();
}

/********************************************************************************
 * Run tests.
 ********************************************************************************/

int
processing_engine_main() {
  const UnitTest tests[] = {
		    unit_test( test_init_processing_engine ),
		    unit_test( test_finalize_processing_engine ),
		    unit_test( test_execute_processing ),
		    unit_test( test_execute_processing_write_action ),
		    unit_test( test_execute_processing_apply_action ),
  };
  setup_leak_detector();
  return run_tests( tests );
}
