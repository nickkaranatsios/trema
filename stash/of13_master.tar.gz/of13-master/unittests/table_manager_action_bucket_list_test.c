/*
 * Unit tests for Table Manager Action List methods.
 *
 *  Created on: 2012/08/17
 *      Author: kitajima
 */


#include <setjmp.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cmockery_trema.h"
#include "table_manager.h"
#include "test_util.h"
#include "log.h"
#include "trema_wrapper.h"

/********************************************************************************
 * Setup and teardown
 ********************************************************************************/

static void ( *original_critical )( const char *format, ... );

static void
mock_critical( const char *format, ... ) {
  char output[ 256 ];
  va_list args;
  va_start( args, format );
  vsprintf( output, format, args );
  va_end( args );
  check_expected( output );
}


static void ( *original_abort )( void );

static void
stub_abort() {
  // Do nothing.
}


static void
setup() {
  original_critical = critical;
  critical = mock_critical;

  original_abort = abort;
  trema_abort = stub_abort;
  init_group_table();
}


static void
teardown() {
  critical = original_critical;
  trema_abort = original_abort;
  finalize_group_table();
}


/********************************************************************************
 * Tests.
 ********************************************************************************/


static void
test_action_bucket_list() {

  action_list * p_action_list[3];
  action * p_action[12];
  bucket * bucket[3];
  bucket_list * p_bucket_list;
  bucket_list * first_node;
  uint16_t weight[3];
  uint32_t watch_port[3];
  uint32_t watch_group[3];

  p_bucket_list = create_action_bucket_list();

  for(int i=0; i<3; i++){
      p_action_list[i] = init_action_list();
      for(int j = 0; j<4; j++){
      p_action[4 * i + j] = create_action_group(4 * i + j);
      append_action(p_action_list[i], p_action[4 * i + j]);
      }
    weight[i] = uint16_rand();
    watch_port[i] = uint16_rand();
    watch_group[i] = uint32_rand();
    bucket[i] = create_action_bucket( weight[i], watch_port[i], watch_group[i], p_action_list[i]);
  }
  assert_true(append_action_bucket(p_bucket_list, bucket[0]) == OFDPE_SUCCESS);
  assert_true(append_action_bucket(p_bucket_list, bucket[1]) == OFDPE_SUCCESS);
  assert_true(append_action_bucket(p_bucket_list, bucket[2]) == OFDPE_SUCCESS);

  first_node = p_bucket_list->next;
  assert_true(first_node->node == bucket[2]);
  assert_true(first_node->next->node == bucket[1]);
  assert_true(first_node->next->next->node == bucket[0]);

  assert_true(remove_action_bucket(p_bucket_list, bucket[2]) == OFDPE_SUCCESS);
  first_node = p_bucket_list->next;
  assert_true(first_node->node == bucket[1]);

  assert_true(remove_action_bucket(p_bucket_list, bucket[1]) == OFDPE_SUCCESS);
  first_node = p_bucket_list->next;
  assert_true(first_node->node == bucket[0]);

  assert_true(remove_action_bucket(p_bucket_list, bucket[1]) == ERROR_NOT_FOUND);
  assert_true(remove_action_bucket(p_bucket_list, bucket[0]) == OFDPE_SUCCESS);
  first_node = p_bucket_list->next;
  assert_true(first_node == NULL);

  delete_action_bucket_list(&p_bucket_list);

}


/********************************************************************************
 * Run tests.
 ********************************************************************************/

int
table_manager_action_bucket_list_main() {
  const UnitTest tests[] = {
      unit_test_setup_teardown( test_action_bucket_list , setup, teardown),
  };
  setup_leak_detector();
  return run_tests( tests );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
