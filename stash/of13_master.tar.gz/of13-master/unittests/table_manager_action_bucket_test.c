/*
 * Unit tests for Table Manager Action methods.
 * 
 *  Created on: 2012/08/17
 *      Author: kitajima
 */


#include <setjmp.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cmockery_trema.h"
#include "table_manager.h"
#include "test_util.h"
#include "log.h"
#include "trema_wrapper.h"
#include "port_manager.h"

/********************************************************************************
 * Setup and teardown
 ********************************************************************************/

static void ( *original_critical )( const char *format, ... );

static void
mock_critical( const char *format, ... ) {
  char output[ 256 ];
  va_list args;
  va_start( args, format );
  vsprintf( output, format, args );
  va_end( args );
  check_expected( output );
}


static void ( *original_abort )( void );

static void
stub_abort() {
  // Do nothing.
}


static void
setup() {
  original_critical = critical;
  critical = mock_critical;

  original_abort = abort;
  trema_abort = stub_abort;
  init_group_table();
  init_port_manager( 1000000, 2000, 2000);
}


static void
teardown() {
  critical = original_critical;
  trema_abort = original_abort;
  finalize_port_manager();
  finalize_group_table();
}


/********************************************************************************
 * Tests.
 ********************************************************************************/


static void
test_action_bucket() {


  bucket * p_bucket;
  uint16_t weight;
  uint32_t watch_port;
  uint32_t watch_group;

  action * p_action;
  uint32_t port;
  uint16_t max_len;

  action_list * p_action_list;


  for(int i = 0; i < 100; i++){

    port = uint32_rand();
    max_len = uint16_rand();
    p_action = create_action_output( port, max_len );
    p_action_list = init_action_list();
    append_action(p_action_list, p_action);

    weight = uint16_rand();
    watch_port = uint16_rand();
    watch_group = uint32_rand();
    p_bucket = create_action_bucket( weight, watch_port, watch_group, p_action_list);

    assert_true(p_bucket->actions == p_action_list);
    assert_true(p_bucket->weight == weight);
    assert_true(p_bucket->watch_port == watch_port);
    assert_true(p_bucket->watch_group == watch_group);

    delete_action_bucket(&p_bucket);
  }
}

/********************************************************************************
 * Run tests.
 ********************************************************************************/

int
table_manager_action_bucket_main() {
  const UnitTest tests[] = {
      unit_test_setup_teardown( test_action_bucket, setup, teardown ),
  };
  setup_leak_detector();
  return run_tests( tests );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
