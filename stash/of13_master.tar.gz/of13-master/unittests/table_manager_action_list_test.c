/*
 * Unit tests for Table Manager Action List methods.
 *
 *  Created on: 2012/08/17
 *      Author: kitajima
 */


#include <setjmp.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cmockery_trema.h"
#include "table_manager.h"
#include "test_util.h"
#include "log.h"
#include "trema_wrapper.h"

/********************************************************************************
 * Setup and teardown
 ********************************************************************************/

static void ( *original_critical )( const char *format, ... );

static void
mock_critical( const char *format, ... ) {
  char output[ 256 ];
  va_list args;
  va_start( args, format );
  vsprintf( output, format, args );
  va_end( args );
  check_expected( output );
}


static void ( *original_abort )( void );

static void
stub_abort() {
  // Do nothing.
}


static void
setup() {
  original_critical = critical;
  critical = mock_critical;

  original_abort = abort;
  trema_abort = stub_abort;
  init_group_table();
}


static void
teardown() {
  critical = original_critical;
  trema_abort = original_abort;
  finalize_group_table();
}

static action *
test_helper_action_output() {
  action * p_action;
  uint16_t port = uint16_rand();
  uint16_t max_len = uint16_rand();
  p_action = create_action_output( port, max_len );
  return(p_action);
}

static action *
test_helper_action_group() {
  action * p_action;
  uint16_t group = uint16_rand();

  p_action = create_action_group( group );
  return(p_action);
}

static action *
test_helper_action_set_queue() {
  action * p_action;
  uint32_t queue_id = uint32_rand();

  p_action = create_action_set_queue( queue_id );
  return(p_action);
}

static action *
test_helper_action_set_mpls_ttl() {
  action * p_action;
  uint8_t mpls_ttl = uint8_rand();

  p_action = create_action_set_mpls_ttl( mpls_ttl );
  return(p_action);
}

static action *
test_helper_action_decr_mpls_ttl() {
  action * p_action;

  p_action = create_action_decr_mpls_ttl();
  return(p_action);
}

static action *
test_helper_action_set_ipv4_ttl() {
  action * p_action;
  uint8_t nw_ttl = uint8_rand();

  p_action = create_action_set_ipv4_ttl( nw_ttl );
  return(p_action);
}

static action *
test_helper_action_decr_ipv4_ttl() {
  action * p_action;

  p_action = create_action_decr_ipv4_ttl();
  return(p_action);
}

static action *
test_helper_action_copy_ttl_out() {
  action * p_action;

  p_action = create_action_copy_ttl_out();
  return(p_action);
}

static action *
test_helper_action_copy_ttl_in() {
  action * p_action;

  p_action = create_action_copy_ttl_in();
  return(p_action);
}

static action *
test_helper_action_push_vlan() {
  action * p_action;
  uint16_t ethertype = uint16_rand();

  p_action = create_action_push_vlan(ethertype);
  return(p_action);
}

static action *
test_helper_action_push_mpls() {
  action * p_action;
  uint16_t ethertype = uint16_rand();

  p_action = create_action_push_mpls(ethertype);
  return(p_action);
}

static action *
test_helper_action_push_pbb() {
  action * p_action;
  uint16_t ethertype = 0x24;

  p_action = create_action_push_pbb(ethertype);
  return(p_action);
}

static action *
test_helper_action_pop_vlan() {
  action * p_action;

  p_action = create_action_pop_vlan();
  return(p_action);
}

static action *
test_helper_action_pop_mpls() {
  action * p_action;
  uint16_t ethertype = uint16_rand();

  p_action = create_action_pop_mpls(ethertype);
  return(p_action);
}

static action *
test_helper_action_pop_pbb() {
  action * p_action;

  p_action = create_action_pop_pbb();
  return(p_action);
}

static action *
test_helper_action_set_field() {
  action * p_action;
  match * p_match;

  p_match = init_match();
  if (p_match == NULL){
      assert_true(false);
  }
  p_action = create_action_set_field(p_match);

  return(p_action);
}


/********************************************************************************
 * Tests.
 ********************************************************************************/


static void
test_action_list() {

  action_list * list;
  action_list * first_node;

  action * p_action;
  list = init_action_list();

  p_action = create_action_group(1);
  append_action(list, p_action);

  p_action = create_action_group(3);
  append_action(list, p_action);

  p_action = create_action_group(2);
  append_action(list, p_action);

  first_node = list->next;

  assert_false(first_node == NULL);
  assert_false(first_node->next == NULL);
  assert_false(first_node->next->next == NULL);
  assert_true(first_node->node->type = OFPAT_GROUP);
  assert_true(first_node->next->node->type = OFPAT_GROUP);
  assert_true(first_node->next->next->node->type = OFPAT_GROUP);

  assert_true(first_node->node->group_id = 1);
  assert_true(first_node->next->node->group_id = 2);
  assert_true(first_node->next->next->node->group_id = 3);

  remove_action(list, first_node->next->node);

  assert_true(first_node->node->type = OFPAT_GROUP);
  assert_true(first_node->next->node->type = OFPAT_GROUP);
  assert_true(first_node->node->group_id = 1);
  assert_true(first_node->next->node->group_id = 3);

  finalize_action_list(&list);

}


static void
test_action_validate()
{
  action * action_output ;
  action * action_group ;
  action * action_set_queue ;
  action * action_set_mpls_ttl ;
  action * action_decr_mpls_ttl ;
  action * action_set_ipv4_ttl ;
  action * action_decr_ipv4_ttl ;
  action * action_copy_ttl_out ;
  action * action_copy_ttl_in ;
  action * action_push_vlan ;
  action * action_push_mpls ;
  action * action_push_pbb ;
  action * action_pop_vlan ;
  action * action_pop_mpls ;
  action * action_pop_pbb ;
  action * action_set_field ;


  action_output = test_helper_action_output();
  action_group = test_helper_action_group();
  action_set_queue = test_helper_action_set_queue();
//  action_set_mpls_ttl = test_helper_action_set_mpls_ttl();
//  action_set_ipv4_ttl = test_helper_action_set_ipv4_ttl();
  action_decr_ipv4_ttl = test_helper_action_decr_ipv4_ttl();
  action_copy_ttl_out = test_helper_action_copy_ttl_out();
  action_copy_ttl_in = test_helper_action_copy_ttl_in();
  action_push_vlan = test_helper_action_push_vlan();
  action_push_mpls = test_helper_action_push_mpls();
  action_push_pbb = test_helper_action_push_pbb();
  action_pop_mpls = test_helper_action_pop_mpls();
  action_set_field = test_helper_action_set_field();

  action_list * action_valid_set;
  action_valid_set = init_action_list();

  append_action(action_valid_set, action_copy_ttl_in);
  append_action(action_valid_set, action_pop_mpls);
  append_action(action_valid_set, action_push_mpls);
  append_action(action_valid_set, action_push_pbb);
  append_action(action_valid_set, action_push_vlan);
  append_action(action_valid_set, action_copy_ttl_out);
  append_action(action_valid_set, action_decr_ipv4_ttl);
  append_action(action_valid_set, action_set_field);
  append_action(action_valid_set, action_set_queue);
  append_action(action_valid_set, action_group);
  append_action(action_valid_set, action_output);

  assert_true(validate_action_set(action_valid_set));

  finalize_action_list(&action_valid_set);

}



/********************************************************************************
 * Run tests.
 ********************************************************************************/

int
table_manager_action_list_main() {
  const UnitTest tests[] = {
      unit_test_setup_teardown( test_action_list, setup, teardown ),
      unit_test_setup_teardown( test_action_validate, setup, teardown )
  };
  setup_leak_detector();
  return run_tests( tests );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
