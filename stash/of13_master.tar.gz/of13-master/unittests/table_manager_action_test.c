/*
 * Unit tests for Table Manager Action methods.
 * 
 *  Created on: 2012/08/17
 *      Author: kitajima
 */


#include <setjmp.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cmockery_trema.h"
#include "table_manager.h"
#include "log.h"
#include "trema_wrapper.h"

/********************************************************************************
 * Setup and teardown
 ********************************************************************************/

static void ( *original_critical )( const char *format, ... );

static void
mock_critical( const char *format, ... ) {
  char output[ 256 ];
  va_list args;
  va_start( args, format );
  vsprintf( output, format, args );
  va_end( args );
  check_expected( output );
}


static void ( *original_abort )( void );

static void
stub_abort() {
  // Do nothing.
}


static void
setup() {
  original_critical = critical;
  critical = mock_critical;

  original_abort = abort;
  trema_abort = stub_abort;
  init_group_table();
}


static void
teardown() {
  critical = original_critical;
  trema_abort = original_abort;
  finalize_group_table();
}


/********************************************************************************
 * Tests.
 ********************************************************************************/

static void
test_action_output() {
  action * p_action;
  uint16_t port = 16;
  uint16_t max_len = 256;
  p_action = create_action_output( port, max_len );
  assert_true(p_action->port == port);
  assert_true(p_action->max_len == max_len);
  assert_true(p_action->type == OFPAT_OUTPUT);
  delete_action(&p_action);
}

static void
test_action_group() {
  action * p_action;
  uint16_t group = 12;

  p_action = create_action_group( group );
  assert_false(p_action == NULL);
  assert_true(p_action->group_id == group);
  assert_true(p_action->type == OFPAT_GROUP);
  delete_action(&p_action);
}

static void
test_action_set_queue() {
  action * p_action;
  uint32_t queue_id = 255;

  p_action = create_action_set_queue( queue_id );
  assert_true(p_action->queue_id == queue_id);
  assert_true(p_action->type == OFPAT_SET_QUEUE);
  delete_action(&p_action);
}

static void
test_action_set_mpls_ttl() {
  action * p_action;
  uint8_t mpls_ttl = 32;

  p_action = create_action_set_mpls_ttl( mpls_ttl );
  assert_true(p_action->mpls_ttl == mpls_ttl);
  assert_true(p_action->type == OFPAT_SET_MPLS_TTL);
  delete_action(&p_action);
}

static void
test_action_decr_mpls_ttl() {
  action * p_action;

  p_action = create_action_decr_mpls_ttl();
  assert_true(p_action->type == OFPAT_DEC_MPLS_TTL);
  delete_action(&p_action);
}

static void
test_action_set_ipv4_ttl() {
  action * p_action;
  uint8_t nw_ttl = 32;

  p_action = create_action_set_ipv4_ttl( nw_ttl );
  assert_true(p_action->nw_ttl == nw_ttl);
  assert_true(p_action->type == OFPAT_SET_NW_TTL);
  delete_action(&p_action);
}

static void
test_action_decr_ipv4_ttl() {
  action * p_action;

  p_action = create_action_decr_ipv4_ttl();
  assert_true(p_action->type == OFPAT_DEC_NW_TTL);
  delete_action(&p_action);
}

static void
test_action_copy_ttl_out() {
  action * p_action;

  p_action = create_action_copy_ttl_out();
  assert_true(p_action->type == OFPAT_COPY_TTL_OUT);
  delete_action(&p_action);
}

static void
test_action_copy_ttl_in() {
  action * p_action;

  p_action = create_action_copy_ttl_in();
  assert_true(p_action->type == OFPAT_COPY_TTL_IN);
  delete_action(&p_action);
}

static void
test_action_push_vlan() {
  action * p_action;
  uint16_t ethertype = 0x24;

  p_action = create_action_push_vlan(ethertype);
  assert_true(p_action->type == OFPAT_PUSH_VLAN);
  assert_true(p_action->ethertype == ethertype);
  delete_action(&p_action);
}

static void
test_action_push_mpls() {
  action * p_action;
  uint16_t ethertype = 0x24;

  p_action = create_action_push_mpls(ethertype);
  assert_true(p_action->type == OFPAT_PUSH_MPLS);
  assert_true(p_action->ethertype == ethertype);
  delete_action(&p_action);
}

static void
test_action_push_pbb() {
  action * p_action;
  uint16_t ethertype = 0x24;

  p_action = create_action_push_pbb(ethertype);
  assert_true(p_action->type == OFPAT_PUSH_PBB);
  assert_true(p_action->ethertype == ethertype);
  delete_action(&p_action);
}

static void
test_action_pop_vlan() {
  action * p_action;

  p_action = create_action_pop_vlan();
  assert_true(p_action->type == OFPAT_POP_VLAN);
  delete_action(&p_action);
}

static void
test_action_pop_mpls() {
  action * p_action;
  uint16_t ethertype = 0x24;

  p_action = create_action_pop_mpls(ethertype);
  assert_true(p_action->type == OFPAT_POP_MPLS);
  assert_true(p_action->ethertype == ethertype);
  delete_action(&p_action);
}

static void
test_action_pop_pbb() {
  action * p_action;

  p_action = create_action_pop_pbb();
  assert_true(p_action->type == OFPAT_POP_PBB);
  delete_action(&p_action);
}

static void
test_action_set_field() {
  action * p_action;
  match * p_match;

  p_match = init_match();
  if (p_match == NULL){
      assert_true(false);
  }
  p_action = create_action_set_field(p_match);
  assert_true(p_action->type == OFPAT_SET_FIELD);
  assert_true(p_action->p_match == p_match);

  delete_action(&p_action);
}



/********************************************************************************
 * Run tests.
 ********************************************************************************/

int
table_manager_action_main() {
  const UnitTest tests[] = {
      unit_test( test_action_output ),
      unit_test_setup_teardown( test_action_group , setup, teardown),
      unit_test( test_action_set_queue ),
      unit_test( test_action_set_mpls_ttl ),
      unit_test( test_action_decr_mpls_ttl ),
      unit_test( test_action_set_ipv4_ttl ),
      unit_test( test_action_decr_ipv4_ttl ),
      unit_test( test_action_copy_ttl_out ),
      unit_test( test_action_copy_ttl_in ),
      unit_test( test_action_push_vlan ),
      unit_test( test_action_push_mpls ),
      unit_test( test_action_push_pbb ),
      unit_test( test_action_pop_vlan ),
      unit_test( test_action_pop_mpls ),
      unit_test( test_action_pop_pbb ),
      unit_test( test_action_set_field ),
  };
  setup_leak_detector();
  return run_tests( tests );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
