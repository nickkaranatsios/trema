/*
 * Unit tests for Table Manager Flow Table methods.
 *
 *  Created on: 2012/08/17
 *      Author: kitajima
 */


#include <setjmp.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cmockery_trema.h"
#include "table_manager.h"
#include "log.h"
#include "trema_wrapper.h"

/********************************************************************************
 * Setup and teardown
 ********************************************************************************/

static void ( *original_critical )( const char *format, ... );

static void
mock_critical( const char *format, ... ) {
  char output[ 256 ];
  va_list args;
  va_start( args, format );
  vsprintf( output, format, args );
  va_end( args );
  check_expected( output );
}


static void ( *original_abort )( void );

static void
stub_abort() {
  // Do nothing.
}


static void
setup() {
  original_critical = critical;
  critical = mock_critical;

  original_abort = abort;
  trema_abort = stub_abort;
}


static void
teardown() {
  critical = original_critical;
  trema_abort = original_abort;
}


/********************************************************************************
 * Tests.
 ********************************************************************************/

static void
test_flow_table() {

//  no valid test in flow_table_test.c
//  use match_table_test.c

}

static void
test_create_flow_entry() {
    match *p_match = init_match();

    action_list *action_list1 = init_action_list();
    action *action1 = create_action_decr_mpls_ttl();
    action *action2 = create_action_decr_mpls_ttl();
    append_action(action_list1, action1);
    append_action(action_list1, action2);
    instruction *instruction1 = create_instruction_write_actions(action_list1);

    action_list *action_list2 = init_action_list();
    action *action3 = create_action_decr_mpls_ttl();
    action *action4 = create_action_decr_mpls_ttl();
    append_action(action_list2, action3);
    append_action(action_list2, action4);

    instruction *instruction2 = create_instruction_apply_actions(action_list2);

    instruction_list *instructions = init_instruction_list();
    append_instruction(instructions, instruction1);
    append_instruction(instructions, instruction2);

    uint16_t priority = 0x1;
    uint16_t idle_timeout = 0x2;
    uint16_t hard_timeout = 0x3;
    uint16_t flags = 0x4;
    uint64_t cookie = 0x5;

    flow_entry *entry = create_flow_entry(p_match, instructions, priority, idle_timeout, hard_timeout, flags, cookie);
    assert_true(action1->entry == entry);
    assert_true(action2->entry == entry);
    assert_true(action3->entry == entry);
    assert_true(action4->entry == entry);

    delete_flow_entry(&entry);
}

/********************************************************************************
 * Run tests.
 ********************************************************************************/

int
table_manager_flow_list_main() {
  const UnitTest tests[] = {
      unit_test( test_flow_table ),
      unit_test( test_create_flow_entry ),
  };
  setup_leak_detector();
  return run_tests( tests );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
