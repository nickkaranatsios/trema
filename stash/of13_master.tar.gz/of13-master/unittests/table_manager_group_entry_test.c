/*
 * Unit tests for Table Manager Group Entry methods.
 * 
 *  Created on: 2012/08/17
 *      Author: kitajima
 */


#include <setjmp.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cmockery_trema.h"
#include "ofdp_common.h"
#include "trema_wrapper.h"
#include "wrapper.h"

#include "log.h"
#include "table_manager.h"
#include "test_util.h"

/********************************************************************************
 * Setup and teardown
 ********************************************************************************/

static void ( *original_critical )( const char *format, ... );

static void
mock_critical( const char *format, ... ) {
  char output[ 256 ];
  va_list args;
  va_start( args, format );
  vsprintf( output, format, args );
  va_end( args );
  check_expected( output );
}


static void ( *original_abort )( void );

static void
stub_abort() {
  // Do nothing.
}


static void
setup() {
  original_critical = critical;
  critical = mock_critical;

  original_abort = abort;
  trema_abort = stub_abort;
  init_group_table();
}


static void
teardown() {
  critical = original_critical;
  trema_abort = original_abort;
  finalize_group_table();
}


/********************************************************************************
 * Tests.
 ********************************************************************************/


static void
test_group_entry() {
  group_entry * group;
  uint8_t type;

  action_list * p_action_list[3];
  action * p_action[12];
  bucket * p_bucket[3];
  bucket_list * p_bucket_list;
  uint16_t weight[3];
  uint32_t watch_port[3];
  uint32_t watch_group[3];

  p_bucket_list = create_action_bucket_list();

  for(int i=0; i<3; i++){
      p_action_list[i] = init_action_list();
      for(int j = 0; j<4; j++){
      p_action[4 * i + j] = create_action_group(4 * i + j);
      append_action(p_action_list[i], p_action[4 * i + j]);
      }
    weight[i] = uint16_rand();
    watch_port[i] = uint16_rand();
    watch_group[i] = uint32_rand();
    p_bucket[i] = create_action_bucket( weight[i], watch_port[i], watch_group[i], p_action_list[i]);
  }
  append_action_bucket(p_bucket_list, p_bucket[0]);
  append_action_bucket(p_bucket_list, p_bucket[1]);
  append_action_bucket(p_bucket_list, p_bucket[2]);

  type = uint8_rand();

  group = create_group_entry(type, p_bucket_list);

  assert_true(group->p_bucket == p_bucket_list);
  assert_true(group->byte_count == 0);
  assert_true(group->ref_count == 0);
  assert_true(group->packet_count == 0);
  assert_true(group->group_id == 0);
  assert_true(group->type == type);

  delete_group_entry(&group);
  assert_true(group == NULL);
}

/********************************************************************************
 * Run tests.
 ********************************************************************************/

int
table_manager_group_entry_main() {
  const UnitTest tests[] = {
      unit_test_setup_teardown( test_group_entry, setup, teardown ),
  };
  setup_leak_detector();
  return run_tests( tests );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
