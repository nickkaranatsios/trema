/*
 * Unit tests for Table Manager Instruction List methods.
 *
 *  Created on: 2012/08/17
 *      Author: kitajima
 */


#include <setjmp.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cmockery_trema.h"
#include "table_manager.h"
#include "test_util.h"
#include "log.h"
#include "trema_wrapper.h"

/********************************************************************************
 * Setup and teardown
 ********************************************************************************/

static void ( *original_critical )( const char *format, ... );

static void
mock_critical( const char *format, ... ) {
  char output[ 256 ];
  va_list args;
  va_start( args, format );
  vsprintf( output, format, args );
  va_end( args );
  check_expected( output );
}


static void ( *original_abort )( void );

static void
stub_abort() {
  // Do nothing.
}


static void
setup() {
  original_critical = critical;
  critical = mock_critical;

  original_abort = abort;
  trema_abort = stub_abort;
}


static void
teardown() {
  critical = original_critical;
  trema_abort = original_abort;
}

enum index_instruction_type {
    INDEX_GOTO_TABLE     ,
    INDEX_WRITE_METADATA ,
    INDEX_WRITE_ACTIONS  ,
    INDEX_APPLY_ACTIONS  ,
    INDEX_CLEAR_ACTIONS  ,
    INDEX_METER          ,
};

static bool
test_helper_instruction_count( instruction_list * list){
  uint8_t count[6] = {0, 0, 0, 0, 0, 0};
  instruction_list * node = list->next;
  uint16_t type;

  while(node != NULL){
      type = node->node->type;
      count[type - 1] ++;
      node = node->next;
  }
  for(int i = 0; i < 6; i++){
      if (count[i] > 1){
          return false;
      }
  }
  return true;
}

static bool
test_helper_instruction_sequence( instruction_list * list ){
  instruction_list * node = list->next;
  uint16_t type;
  uint8_t mask_type = 0;
   // METER, APPLY, CLEAR, WRITE-Action, WRITE-Metadata, Goto
  enum{
    MASK_METER          = 0x01,
    MASK_APPLY_ACTIONS  = 0x02,
    MASK_CLEAR_ACTIONS  = 0x04,
    MASK_WRITE_ACTIONS  = 0x08,
    MASK_WRITE_METADATA = 0x10,
    MASK_GOTO_TABLE     = 0x20
  };

  for(;node->next != NULL; node = node->next){
      type = node->node->type;
      if (type == OFPIT_METER){
          mask_type |= MASK_METER;
          if ((mask_type & (MASK_APPLY_ACTIONS | MASK_CLEAR_ACTIONS | MASK_WRITE_ACTIONS
                            | MASK_WRITE_METADATA | MASK_GOTO_TABLE)) != 0){
              return false;
          }
      }
      if (type == OFPIT_APPLY_ACTIONS){
          mask_type |= MASK_APPLY_ACTIONS;
          if ((mask_type & ( MASK_CLEAR_ACTIONS | MASK_WRITE_ACTIONS
                            | MASK_WRITE_METADATA | MASK_GOTO_TABLE)) != 0){
              return false;
          }
      }
      if (type == OFPIT_CLEAR_ACTIONS){
          mask_type |= MASK_CLEAR_ACTIONS;
          if ((mask_type & (  MASK_WRITE_ACTIONS | MASK_WRITE_METADATA | MASK_GOTO_TABLE)) != 0){
              return false;
          }
      }
      if (type == OFPIT_WRITE_ACTIONS){
          mask_type |= MASK_WRITE_ACTIONS;
          if ((mask_type & (  MASK_WRITE_METADATA | MASK_GOTO_TABLE)) != 0){
              return false;
          }
      }
      if (type == OFPIT_WRITE_METADATA){
          mask_type |= MASK_WRITE_METADATA;
          if ((mask_type &  MASK_GOTO_TABLE) != 0){
              return false;
          }
      }
  }

  return true;
}


/********************************************************************************
 * Tests.
 ********************************************************************************/

static void
test_instruction_list() {

  instruction * p_instruction[6];
  init_group_table();
  for(int i = 0; i < 100; i++){
  // listを生成する
    uint8_t table_id = uint8_rand();
    p_instruction[INDEX_GOTO_TABLE]= create_instruction_goto_table(table_id);
    uint64_t metadata = uint64_rand();
    uint64_t metadata_mask = uint64_rand();
    p_instruction[INDEX_WRITE_METADATA] = create_instruction_write_metadata(metadata, metadata_mask);

    action_list * action_list1 = init_action_list();
    action_list * action_list2 = init_action_list();
    action * p_action;

    p_action = create_action_group(1);
    append_action(action_list1, p_action);
    p_action = create_action_group(2);
    append_action(action_list1, p_action);
    p_action = create_action_group(3);
    append_action(action_list1, p_action);

    p_action = create_action_group(4);
    append_action(action_list2, p_action);
    p_action = create_action_group(5);
    append_action(action_list2, p_action);
    p_action = create_action_group(6);
    append_action(action_list2, p_action);

    p_instruction[INDEX_WRITE_ACTIONS] = create_instruction_write_actions(action_list1);
    p_instruction[INDEX_APPLY_ACTIONS] = create_instruction_apply_actions(action_list2);
    p_instruction[INDEX_CLEAR_ACTIONS] = create_instruction_clear_actions();
    uint16_t meter = uint16_rand();
    p_instruction[INDEX_METER] = create_instruction_meter(meter);

    instruction_list * list = init_instruction_list();

    // listにinstructionを登録する
    for(int j = 0; j < 10; j++){
        uint8_t n = uint8_rand() % 6;
        append_instruction(list, p_instruction[n]);
        // 登録順序が正しく、重複がないか？
        assert_true(test_helper_instruction_count(list));
        assert_true(test_helper_instruction_sequence(list));
    }
    for(int j = 0; j < 6; j++){
        append_instruction(list, p_instruction[j]);
    }
    finalize_instruction_list(&list);
  }
  finalize_group_table();


}


/********************************************************************************
 * Run tests.
 ********************************************************************************/

int
table_manager_instruction_list_main() {
  const UnitTest tests[] = {
      unit_test( test_instruction_list ),
  };
  setup_leak_detector();
  return run_tests( tests );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
