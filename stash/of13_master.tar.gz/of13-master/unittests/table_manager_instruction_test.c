/*
 * Unit tests for Table Manager Instruction methods.
 * 
 *  Created on: 2012/08/17
 *      Author: kitajima
 */


#include <setjmp.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "cmockery_trema.h"
#include "table_manager_instruction.h"
#include "log.h"
#include "trema_wrapper.h"

/********************************************************************************
 * Setup and teardown
 ********************************************************************************/

static void ( *original_critical )( const char *format, ... );

static void
mock_critical( const char *format, ... ) {
  char output[ 256 ];
  va_list args;
  va_start( args, format );
  vsprintf( output, format, args );
  va_end( args );
  check_expected( output );
}


static void ( *original_abort )( void );

static void
stub_abort() {
  // Do nothing.
}


static void
setup() {
  original_critical = critical;
  critical = mock_critical;

  original_abort = abort;
  trema_abort = stub_abort;
}


static void
teardown() {
  critical = original_critical;
  trema_abort = original_abort;
}


/********************************************************************************
 * Tests.
 ********************************************************************************/


static void
test_instruction_goto_table() {
  instruction * instruction;
  instruction = create_instruction_goto_table( 1 );

  assert_true(instruction->table_id == 1);
  assert_true(instruction->type == OFPIT_GOTO_TABLE);
  delete_instruction(&instruction);
}

static void
test_instruction_write_metadata() {
  srand((unsigned)time(NULL));

  for(int i = 0; i < 5 ; i++){
  uint64_t metadata = rand() * rand() * rand();
  uint64_t metadata_mask = rand() * rand() * rand();

  instruction * instruction;
  instruction = create_instruction_write_metadata( metadata, metadata_mask );

  assert_true(instruction->metadata == metadata);
  assert_true(instruction->metadata_mask == metadata_mask);
  assert_true(instruction->type == OFPIT_WRITE_METADATA);
  delete_instruction(&instruction);
  }
}

static void
test_instruction_write_actions() {
  instruction * instruction;
  instruction = create_instruction_write_actions(NULL);

  assert_true(instruction->p_action_list == NULL);
  assert_true(instruction->type == OFPIT_WRITE_ACTIONS);

  instruction->p_action_list = NULL;
  delete_instruction(&instruction);
}

static void
test_instruction_apply_actions() {
  instruction * instruction;
  instruction = create_instruction_apply_actions(NULL);

  assert_true(instruction->p_action_list == NULL);
  assert_true(instruction->type == OFPIT_APPLY_ACTIONS);

  instruction->p_action_list = NULL;
  delete_instruction(&instruction);
}

static void
test_instruction_clear_actions() {

  instruction * instruction;
  instruction = create_instruction_clear_actions();

  assert_true(instruction->type == OFPIT_CLEAR_ACTIONS);

  delete_instruction(&instruction);
}

static void
test_instruction_meter() {
  instruction * instruction;
  instruction = create_instruction_meter( 1 );
  assert_true(instruction->meter_id == 1);
  assert_true(instruction->type == OFPIT_METER);
  delete_instruction(&instruction);
}

/********************************************************************************
 * Run tests.
 ********************************************************************************/

int
table_manager_instruction_main() {
  const UnitTest tests[] = {
    unit_test( test_instruction_goto_table ),
    unit_test( test_instruction_write_metadata ),
    unit_test( test_instruction_write_actions ),
    unit_test( test_instruction_apply_actions ),
    unit_test( test_instruction_clear_actions ),
    unit_test( test_instruction_meter ),
  };
  setup_leak_detector();
  return run_tests( tests );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
