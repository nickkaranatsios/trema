#include <stdio.h>
#include <stdarg.h>
#include <setjmp.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <google/cmockery.h>
#include "checks.h"
#include "bool.h"

#define static

void
mock_error( const char *format, ... ) {
  UNUSED( format );
}

void
mock_debug( const char *format, ... ) {
  UNUSED( format );
}


void
mock_warn( const char *format, ... ) {
  UNUSED( format );
}

void
mock_info( const char *format, ... ) {
  va_list args;
  va_start( args, format );
  char message[ 1000 ];
  vsprintf( message, format, args );
  va_end( args );

  check_expected( message );
}

int
mock_chdir( char *path ) {
  UNUSED( path );
  return ( int ) mock();
}


void
mock_exit( int status ) {
  check_expected( status );
}


pid_t
mock_fork() {
  return ( pid_t ) mock();
}


pid_t
mock_setsid() {
  return ( pid_t ) mock();
}


mode_t
mock_umask( mode_t mode ) {
  check_expected( mode );
  return mode;
}


int
mock_close( int fd ) {
  check_expected( fd );
  return 0;
}


int
mock_open( char *pathname, int flags, mode_t mode ) {
  check_expected( pathname );
  check_expected( flags );
  check_expected( mode );
  return ( int ) mock();
}


int
mock_lockf( int fd, int cmd, off_t len ) {
  check_expected( fd );
  check_expected( cmd );
  check_expected( len );
  return ( int ) mock();
}


pid_t
mock_getpid() {
  return 1234;
}


ssize_t
mock_write( int fd, void *buf, size_t count ) {
  check_expected( fd );
  check_expected( buf );
  check_expected( count );
  return ( ssize_t ) count;
}


int
mock_unlink( char *pathname ) {
  check_expected( pathname );
  return ( int ) mock();
}


int
mock_access( char *pathname, int mode) {
  check_expected( pathname );
  check_expected( mode );
  return ( int ) mock();
}


static size_t read_length = 0;
static char *read_buffer = NULL;

ssize_t
mock_read( int fd, void *buf, size_t count ) {
  check_expected( fd );
  check_expected( buf );
  check_expected( count );
  if ( read_length > 0 ) {
    memcpy( buf, read_buffer, read_length );
  }
  return ( int ) mock();
}


int
mock_kill( pid_t pid, int sig ) {
  check_expected( pid );
  check_expected( sig );
  return ( int ) mock();
}


int
mock_rename( char *oldpath, char *newpath ) {
  check_expected( oldpath );
  check_expected( newpath );
  return ( int ) mock();
}

void
mock_execute_timer_events() {
  // Do nothing.
}

bool
mock_add_periodic_event_callback( const time_t seconds, void ( *callback )( void *user_data ), v\
oid *user_data ) {
  UNUSED( seconds );
  UNUSED( callback );
  UNUSED( user_data );
  return true;
}


int
mock_clock_gettime( clockid_t clk_id, struct timespec *tp ) {
  UNUSED( clk_id );
  UNUSED( tp );

  return ( int ) mock();
}


bool
mock_set_external_callback( void ( *callback ) ( void ) ) {
  UNUSED( callback );
  return true;
}

void
mock_dump_stats() {
  // do nothing
}


bool
mock_init_timer() {
  // Do nothing.
  return true;
}


bool
mock_finalize_timer() {
  // Do nothing.
  return true;
}


bool
mock_finalize_packetin_filter_interface() {
  // Do nothing.
  return true;
}

static bool fail_mock_socket = false;
int
mock_socket( int domain, int type, int protocol ) {
  return fail_mock_socket ? -1  : socket( domain, type, protocol );
}


static bool fail_mock_bind = false;
int
mock_bind( int sockfd, const struct sockaddr *addr, socklen_t addrlen ) {
  return fail_mock_bind ? -1 : bind( sockfd, addr, addrlen );
}


static bool fail_mock_listen = false;
int
mock_listen( int sockfd, int backlog ) {
  return fail_mock_listen ? -1 :listen( sockfd, backlog );
}

static bool fail_mock_connect = false;
int
mock_connect( int sockfd, const struct sockaddr *addr, socklen_t addrlen ) {
  return fail_mock_connect ? -1 : connect( sockfd, addr, addrlen );
}

static bool fail_mock_select = false;
int
mock_select( int nfds, fd_set *readfds, fd_set *writefds, fd_set *exceptfds, struct timeval *tim\
eout ) {
  return fail_mock_select ? -1 : select( nfds, readfds, writefds, exceptfds, timeout );
}


static bool fail_mock_accept = false;
int
mock_accept( int sockfd, struct sockaddr *addr, socklen_t *addrlen ) {
  return fail_mock_accept ? -1 : accept( sockfd, addr, addrlen );
}


static bool fail_mock_recv = false;
ssize_t
mock_recv( int sockfd, void *buf, size_t len, int flags ) {
  return fail_mock_recv ? -1 : recv( sockfd, buf, len, flags );
}


static bool fail_mock_send = false;
ssize_t
mock_send( int sockfd, const void *buf, size_t len, int flags ) {
  return fail_mock_send ? -1 : send( sockfd, buf, len, flags );
}


int
mock_setsockopt( int s, int level, int optname, const void *optval, socklen_t optlen ) {
  UNUSED( s );
  UNUSED( level );
  UNUSED( optname );
  UNUSED( optval );
  UNUSED( optlen );
  return 0;
}

void*
mock_error_malloc(size_t size) {
	return (void*)NULL;
}

void
mock_die( const char *format, ... ) {
  char output[ 256 ];
  va_list args;
  va_start( args, format );
  vsprintf( output, format, args );
  va_end( args );
  check_expected( output );

  mock_assert( false, "mock_die", __FILE__, __LINE__ ); } // Hoaxes gcov.

#if 0

bool
mock_set_logging_level( char *level ) {
  check_expected( level );
  return true;
}


void
mock_daemonize() {
  assert_true( logger_initialized );

  daemonized = true;
}


void
mock_write_pid( const char *directory, const char *name ) {
  UNUSED( directory );
  UNUSED( name );

  assert_true( logger_initialized );

  pid_file_created = true;
}


void
mock_unlink_pid( char *directory, char *name ) {
  UNUSED( directory );
  UNUSED( name );
}


void
mock_rename_pid( char *directory, char *old, char *new ) {
  check_expected( directory );
  check_expected( old );
  check_expected( new );
}


pid_t
mock_read_pid( char *directory, char *name ) {
  check_expected( directory );
  check_expected( name );

  return ( pid_t ) mock();
}


int
mock_kill( pid_t pid, int sig ) {
  check_expected( pid );
  check_expected( sig );

  return ( int ) mock();
}


unsigned int
mock_sleep( unsigned int seconds ) {
  check_expected( seconds );
  return ( unsigned int ) mock();
}


void
mock_init_event_handler( void ) {
  assert_true( logger_initialized );
  assert_true( !messenger_initialized );

  event_handler_initialized = true;
}


void
mock_start_event_handler() {
  event_handler_started = true;
}


void
mock_stop_event_handler() {
  event_handler_started = false;
}


void
mock_init_messenger( const char *working_directory ) {
  UNUSED( working_directory );

  assert_true( logger_initialized );
  assert_true( !messenger_initialized );

  assert_true( !daemonized );
  assert_true( !pid_file_created );
  assert_true( !messenger_started );

  messenger_initialized = true;
}


void
mock_start_messenger() {
  messenger_started = true;
}


void
mock_flush_messenger() {
  messenger_flushed = true;
}


void
mock_stop_messenger() {
  messenger_started = false;
}


void
mock_finalize_messenger() {
  messenger_initialized = false;
}


void
mock_start_messenger_dump( const char *dump_app_name, const char *dump_service_name ) {
  UNUSED( dump_app_name );
  UNUSED( dump_service_name );
  messenger_dump_started = true;
}


void
mock_stop_messenger_dump() {
  messenger_dump_started = false;
}


bool
mock_messenger_dump_enabled() {
  return messenger_dump_started;
}


void
mock_die( char *format, ... ) {
  va_list args;
  va_start( args, format );
  char message[ 1000 ];
  vsprintf( message, format, args );
  va_end( args );

  check_expected( message );
  mock_assert( false, "mock_die", __FILE__, __LINE__ ); } // This hoaxes gcov.


void
mock_exit( int status ) {
  check_expected( status );
}


bool
mock_openflow_application_interface_is_initialized() {
  return true;
}


bool
mock_finalize_openflow_application_interface() {
  return true;
}


int
mock_printf( char *format, ... ) {
  check_expected( format );
  return 0;
}


int
mock_stat( const char *path, struct stat *buf ) {
  UNUSED( path );
  UNUSED( buf );

  // Set errno to fail with ENOENT when mock() returns non-zero.
  errno = ENOENT;
  return ( int ) mock();
}


#endif
