#include "test_util.h"
#include "stdlib.h"


uint8_t
uint8_rand(void)
{
  return ((uint8_t) rand() % 0xFE + 1);
}

 uint16_t
uint16_rand(void)
{
  return ((uint16_t) rand() % 0xFFFE + 1);
}

 uint32_t
uint32_rand(void)
{
  return ((uint32_t) rand() + (uint32_t) rand() * 0x10000u) % 0xFFFFFFFE + 1;
}

 uint64_t
uint64_rand(void)
{
  return ((uint64_t) uint32_rand() + (uint64_t) uint32_rand() * 0x100000000u) % 0xFFFFFFFFFFFFFFFE + 1;
}

 buffer *
 copy_packet_to_buffer( const char *filename ) {
   assert( filename != NULL );

   FILE *fp = fopen( filename, "r" );
   if ( fp == NULL ) {
     // "Can't open a file of test data."
     return NULL;
   }

   // Skip
   if ( fseek( fp, sizeof( struct pcap_file_header ) + sizeof( uint32_t ) * 2,
               SEEK_CUR ) != 0 ) {
     fclose( fp );
     return NULL;
   }

   uint32_t length[ 2 ];
   size_t size = fread( &length, 1, sizeof( length ), fp );
   if ( size < sizeof( length ) ) {
     fclose( fp );
     return NULL;
   }

   buffer *buffer = allocate_packet_buffer();
   if ( buffer == NULL ) {
     fclose( fp );
     return NULL;
   }
   size = fread( append_back_buffer_pool_entry( buffer, length[ 0 ] ), 1, length[ 0 ], fp );
   if ( size < buffer->length ) {
   free_packet_buffer_pool_entry( buffer );
     fclose( fp );
     return NULL;
   }

   fclose( fp );
   return buffer;
 }
