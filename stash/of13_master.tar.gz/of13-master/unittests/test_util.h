/*
 * test_util.h
 *
 *  Created on: 2012/08/21
 *      Author: kitajima
 */

#ifndef TEST_UTIL_H_
#define TEST_UTIL_H_

#include <pcap.h>
#include "openflow.h"
#include "packet_buffer_pool.h"
#include "stdio.h"

uint8_t uint8_rand(void);

uint16_t uint16_rand(void);

uint32_t uint32_rand(void);

uint64_t uint64_rand(void);

buffer* copy_packet_to_buffer( const char *filename );

#endif /* TEST_UTIL_H_ */
