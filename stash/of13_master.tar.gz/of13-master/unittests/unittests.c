/*
 * unittests.c
 *
 *  Created on: 2012/08/17
 *      Author: kitajima
 */

#include "unittests.h"

int main(void){

// Table Manager Unit Test

  table_manager_instruction_main();
  table_manager_instruction_list_main();
  table_manager_action_main();
  table_manager_action_list_main();
  table_manager_action_bucket_main();
  table_manager_action_bucket_list_main();
  table_manager_group_entry_main();
  table_manager_group_list_main();

  packet_matcher_main();
  match_table_main();


//  Other Modules Unit Test

  packet_buffer_pool_main();
  packet_forwarder_main();
  packet_parser_main();
  action_executor_main();
  controller_manager_main();
  port_manager_main();
  processing_engine_main();


// Utility Code Unit Test

  wrapper_main();


  return 0;
}
