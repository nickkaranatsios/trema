/*
 * unittests.h
 *
 *  Created on: 2012/08/17
 *      Author: kitajima
 */

#ifndef UNITTESTS_H_
#define UNITTESTS_H_

#include "cmockery_trema.h"

extern int dlist_main(void);
extern int hash_main(void);
extern int list_main(void);
extern int table_manager_action_list_main(void);
extern int table_manager_action_main(void);
extern int table_manager_instruction_list_main(void);
extern int table_manager_instruction_main(void);
extern int table_manager_action_bucket_main(void);
extern int table_manager_action_bucket_list_main(void);
extern int table_manager_group_entry_main(void);
extern int table_manager_group_list_main(void);

extern int timer_main(void);
//extern int utility_main(void);
extern int wrapper_main(void);
extern int packet_parser_main(void);
extern int packet_matcher_main(void);
extern int match_table_main(void);
extern int table_manager_tlv_main(void);
extern int packet_buffer_pool_main(void);
extern int port_manager_main(void);
extern int packet_forwarder_main(void);
extern int processing_engine_main(void);
extern int controller_manager_main(void);
extern int action_executor_main(void);

#endif /* UNITTESTS_H_ */
