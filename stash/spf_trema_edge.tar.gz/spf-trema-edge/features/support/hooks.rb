Before do
  run "./trema killall"
end


After do
  run "./trema killall"
end
