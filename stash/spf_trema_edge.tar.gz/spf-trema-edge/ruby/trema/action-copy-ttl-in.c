/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include "trema.h"
#include "ruby.h"


extern VALUE mTrema;
VALUE cActionCopyTtlIn;


/*
 * An action that copies the TTL from outermost to next-to-outermost header with TTL.
 * The copy applies to IP-to-IP, MPLS-to-MPLS, and IP-to-MPLS packets.
 *
 * @overload initialize()
 *
 * @return [ActionCopyTtlIn] an object that encapsulates this action.
 */
static VALUE
action_copy_ttl_in_init( VALUE self ) {
  return self;
}


/*
 * Appends its action(copy TTL IN) to the list of actions.
 *
 * @return [ActionCopyTtlIn] self
 */
static VALUE
action_copy_ttl_in_append( VALUE self, VALUE action_ptr ) {
  openflow_actions *actions;
  Data_Get_Struct( action_ptr, openflow_actions, actions );
  append_action_copy_ttl_in( actions );
  return self;
}


/*
 * (see ActionEnqueue#inspect)
 */
static VALUE
action_copy_ttl_in_inspect( VALUE self ) {
  char str[ 64 ];
  sprintf( str, "#<%s>", rb_obj_classname( self ) );
  return rb_str_new2( str );
}


void
Init_action_copy_ttl_out() {
  cActionCopyTtlIn = rb_define_class_under( mTrema, "ActionCopyTtlIn", rb_cObject );
  rb_define_method( cActionCopyTtlIn, "initialize", action_copy_ttl_in_init, 0 );
  rb_define_method( cActionCopyTtlIn, "append", action_copy_ttl_in_append, 1 );
  rb_define_method( cActionCopyTtlIn, "inspect", action_copy_ttl_in_inspect, 0 );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
