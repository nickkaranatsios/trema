/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include "trema.h"
#include "ruby.h"


extern VALUE mTrema;
VALUE cActionDecNwTtl;


/*
 * An action that decrements the IP TTL.
 * The action only applies to IPv4 packets.
 *
 * @overload initialize()
 *
 * @return [ActionDecNwTll] an object that encapsulates this action.
 */
static VALUE
action_dec_nw_ttl_init( VALUE self ) {
  return self;
}


/*
 * Appends its action(decrement IP TTL) to the list of actions.
 *
 * @return [ActionDecNwTtl] self
 */
static VALUE
action_dec_nw_ttl_append( VALUE self, VALUE action_ptr ) {
  openflow_actions *actions;
  Data_Get_Struct( action_ptr, openflow_actions, actions );
  append_action_dec_nw_ttl( actions );
  return self;
}


/*
 * (see ActionEnqueue#inspect)
 */
static VALUE
action_dec_nw_ttl_inspect( VALUE self ) {
  char str[ 64 ];
  sprintf( str, "#<%s>", rb_obj_classname( self ) );
  return rb_str_new2( str );
}


void
Init_action_dec_nw_ttl() {
  cActionDecNwTtl = rb_define_class_under( mTrema, "ActionDecNwTtl", rb_cObject );
  rb_define_method( cActionDecNwTtl, "initialize", action_dec_nw_ttl_init, 0 );
  rb_define_method( cActionDecNwTtl, "append", action_dec_nw_ttl_append, 1 );
  rb_define_method( cActionDecNwTtl, "inspect", action_dec_nw_ttl_inspect, 0 );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
