/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include "trema.h"
#include "ruby.h"


extern VALUE mTrema;
VALUE cActionGroup;


/*
 * An action that sets the group id that uniquely identifies a group table
 * entry instance. A group table entry contains the group type, counters and
 * action buckets that modify the flow pipeline processing.
 *
 * @overload initialize(options={})
 *
 *   @example
 *     ActionGroup.new( :group_id => GROUP_ID )
 *   @param [Number] group_id
 *     the group id this action refers to.
 *
 *   @raise [ArgumentError] if group_id argument is not supplied.
 *   @raise [ArgumentError] if group_id is not an unsigned 32-bit integer.
 *
 *   @return [ActionGroup] 
 *     an object that encapsulates this action.
 */
static VALUE
action_group_init( VALUE self, VALUE options ) {
  if ( !NIL_P( options ) ) {
    Check_Type( options, T_FIXNUM );
  }
  if ( rb_funcall( options, rb_intern( "unsigned_32bit?" ), 0 ) == Qfalse ) {
    rb_raise( rb_eArgError, "Group id must be an unsigned 32-bit integer" );
  }
  rb_iv_set( self, "@group_id", options );
  return self;
}


/*
 * The group_id associated with a group table entry.
 *
 * @return [Number] the value of group_id
 */
static VALUE
action_group_group_id( VALUE self ) {
  return rb_iv_get( self, "@group_id" );
}


/*
 * Appends its action(group_id) to the list of actions.
 *
 * @return [ActionGroup] self
 */
static VALUE
action_group_append( VALUE self, VALUE action_ptr ) {
  const uint32_t group_id = NUM2UINT( action_group_group_id( self ) );

  openflow_actions *actions;
  Data_Get_Struct( action_ptr, openflow_actions, actions );

  append_action_group( actions, group_id );
  return self;
}


/*
 * (see ActionEnqueue#inspect)
 */
static VALUE
action_group_inspect( VALUE self ) {
  const uint32_t group_id = NUM2UINT( action_group_group_id( self ) );

  char str[ 64 ];
  sprintf( str, "#<%s group_id=%u>", rb_obj_classname( self ), group_id );
  return rb_str_new2( str );
}


void
Init_action_group() {
  cActionGroup = rb_define_class_under( mTrema, "ActionGroup", rb_cObject );
  rb_define_method( cActionGroup, "initialize", action_group_init, 1 );
  rb_define_method( cActionGroup, "group_id", action_group_group_id, 0 );
  rb_define_method( cActionGroup, "append", action_group_append, 1 );
  rb_define_method( cActionGroup, "inspect", action_group_inspect, 0 );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
