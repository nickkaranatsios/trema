/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include "trema.h"
#include "ruby.h"


extern VALUE mTrema;
VALUE cActionPopPbb;


/*
 * An action that pops the outermost PBB header from the packet.
 *
 * @overload initialize()
 *
 * @return [ActionPopPbb] an object that encapsulates this action.
 */
static VALUE
action_pop_pbb_init( VALUE self ) {
  return self;
}


/*
 * Appends its action(pop pbb) to the list of actions.
 *
 * @return [ActionPopPbb] self
 */
static VALUE
action_pop_pbb_append( VALUE self, VALUE action_ptr ) {
  openflow_actions *actions;
  Data_Get_Struct( action_ptr, openflow_actions, actions );
  append_action_pop_pbb( actions );
  return self;
}


/*
 * (see ActionEnqueue#inspect)
 */
static VALUE
action_pop_pbb_inspect( VALUE self ) {
  char str[ 64 ];
  sprintf( str, "#<%s>", rb_obj_classname( self ) );
  return rb_str_new2( str );
}


void
Init_action_pop_pbb() {
  cActionPopPbb = rb_define_class_under( mTrema, "ActionPopPbb", rb_cObject );
  rb_define_method( cActionPopPbb, "initialize", action_pop_pbb_init, 0 );
  rb_define_method( cActionPopPbb, "append", action_pop_pbb_append, 1 );
  rb_define_method( cActionPopPbb, "inspect", action_pop_pbb_inspect, 0 );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
