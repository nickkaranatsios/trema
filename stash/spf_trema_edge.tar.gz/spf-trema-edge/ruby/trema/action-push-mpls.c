/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include "trema.h"
#include "ruby.h"


extern VALUE mTrema;
VALUE cActionPushMpls;


/*
 * An action that pushes a new MPLS shim header header onto the packet.
 *
 * @overload initialize(options={})
 *
 *   @example
 *     ActionPushMpls.new( :ethertype => ethernet type )
 *   @param [Number] ethertype
 *     the ethernet type this action refers to.
 *
 *   @raise [ArgumentError] if ethernet type argument is not supplied.
 *   @raise [ArgumentError] if ethernet type is not an unsigned 16-bit integer.
 *
 *   @return [ActionPushMpls] 
 *     an object that encapsulates this action.
 */
static VALUE
action_push_mpls_init( VALUE self, VALUE options ) {
  if ( !NIL_P( options ) ) {
    Check_Type( options, T_FIXNUM );
  }
  if ( rb_funcall( options, rb_intern( "unsigned_16bit?" ), 0 ) == Qfalse ) {
    rb_raise( rb_eArgError, "Ethernet type must be an unsigned 16-bit integer" );
  }
  rb_iv_set( self, "@ethertype", options );
  return self;
}


/*
 * The ethertype that is used as the ethernet type for the tag.
 * Only 0x8847 and 0x8848 should be used.
 *
 * @return [Number] the value of ethernet type
 */
static VALUE
action_push_mpls_ethertype( VALUE self ) {
  return rb_iv_get( self, "@ethertype" );
}


/*
 * Appends its action(push MPLS) to the list of actions.
 *
 * @return [ActionPushMpls] self
 */
static VALUE
action_push_mpls_append( VALUE self, VALUE action_ptr ) {
  const uint16_t ethertype = ( const uint16_t ) NUM2UINT( action_push_mpls_ethertype( self ) );

  openflow_actions *actions;
  Data_Get_Struct( action_ptr, openflow_actions, actions );

  append_action_push_mpls( actions, ethertype );
  return self;
}


/*
 * (see ActionEnqueue#inspect)
 */
static VALUE
action_push_mpls_inspect( VALUE self ) {
  const uint16_t ethertype = ( const uint16_t ) NUM2UINT( action_push_mpls_ethertype( self ) );

  char str[ 64 ];
  sprintf( str, "#<%s ethernet type=%u>", rb_obj_classname( self ), ethertype );
  return rb_str_new2( str );
}


void
Init_action_push_mpls() {
  cActionPushMpls = rb_define_class_under( mTrema, "ActionPushMpls", rb_cObject );
  rb_define_method( cActionPushMpls, "initialize", action_push_mpls_init, 1 );
  rb_define_method( cActionPushMpls, "ethertype", action_push_mpls_ethertype, 0 );
  rb_define_method( cActionPushMpls, "append", action_push_mpls_append, 1 );
  rb_define_method( cActionPushMpls, "inspect", action_push_mpls_inspect, 0 );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
