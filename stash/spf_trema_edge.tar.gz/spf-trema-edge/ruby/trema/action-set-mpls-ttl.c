/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include "trema.h"
#include "ruby.h"


extern VALUE mTrema;
VALUE cActionSetMplsTtl;


/*
 * An action that replaces an existing MPLS TTL. This action applies
 * to packets with an existing MPLS shim header.
 *
 * @overload initialize(options={})
 *
 *   @example
 *     ActionGroup.new( :mpls_ttl => mpls_ttl )
 *   @param [Number] mpls_ttl
 *     the mpls_ttl field this action refers to.
 *
 *   @raise [ArgumentError] if mpls_ttl argument is not supplied.
 *   @raise [ArgumentError] if mpls_ttl is not an unsigned 8-bit integer.
 *
 *   @return [ActionSetMplsTtl]] 
 *     an object that encapsulates this action.
 */
static VALUE
action_set_mpls_ttl_init( VALUE self, VALUE options ) {
  if ( !NIL_P( options ) ) {
    Check_Type( options, T_FIXNUM );
  }
  if ( rb_funcall( options, rb_intern( "unsigned_8bit?" ), 0 ) == Qfalse ) {
    rb_raise( rb_eArgError, "Mpls ttl must be an unsigned 8-bit integer" );
  }
  rb_iv_set( self, "@mpls_ttl", options );
  return self;
}


/*
 * The new mpls_ttl value to use to replace an existing MPLS TTL.
 *
 * @return [Number] the value of mpls_ttl
 */
static VALUE
action_mpls_ttl( VALUE self ) {
  return rb_iv_get( self, "@mpls_ttl" );
}


/*
 * Appends its action(set MPLS TTL) to the list of actions.
 *
 * @return [ActionSetMplsTtl] self
 */
static VALUE
action_set_mpls_ttl_append( VALUE self, VALUE action_ptr ) {
  const uint8_t mpls_ttl = ( const uint8_t ) NUM2UINT( action_mpls_ttl( self ) );

  openflow_actions *actions;
  Data_Get_Struct( action_ptr, openflow_actions, actions );

  append_action_set_mpls_ttl( actions, mpls_ttl );
  return self;
}


/*
 * (see ActionEnqueue#inspect)
 */
static VALUE
action_set_mpls_ttl_inspect( VALUE self ) {
  const uint8_t mpls_ttl = ( const uint8_t ) NUM2UINT( action_mpls_ttl( self ) );

  char str[ 64 ];
  sprintf( str, "#<%s MPLS TTL=%u>", rb_obj_classname( self ), mpls_ttl );
  return rb_str_new2( str );
}


void
Init_action_set_mpls_ttl() {
  cActionSetMplsTtl = rb_define_class_under( mTrema, "ActionSetMplsTtl", rb_cObject );
  rb_define_method( cActionSetMplsTtl, "initialize", action_set_mpls_ttl_init, 1 );
  rb_define_method( cActionSetMplsTtl, "mpls_ttl", action_mpls_ttl, 0 );
  rb_define_method( cActionSetMplsTtl, "append", action_set_mpls_ttl_append, 1 );
  rb_define_method( cActionSetMplsTtl, "inspect", action_set_mpls_ttl_inspect, 0 );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
