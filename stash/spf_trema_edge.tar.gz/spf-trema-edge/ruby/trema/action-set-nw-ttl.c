/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include "trema.h"
#include "ruby.h"


extern VALUE mTrema;
VALUE cActionSetNwTtl;


/*
 * An action that replaces an existing IP TTL. This action only
 * applies to IPv4 packets.
 *
 * @overload initialize(options={})
 *
 *   @example
 *     ActionSetNwTtl.new( :nw_ttl => nw_ttl )
 *   @param [Number] nw_ttl
 *     the nw_ttl field this action refers to.
 *
 *   @raise [ArgumentError] if nw_ttl argument is not supplied.
 *   @raise [ArgumentError] if nw_ttl is not an unsigned 8-bit integer.
 *
 *   @return [ActionSetNwTtl]] 
 *     an object that encapsulates this action.
 */
static VALUE
action_set_nw_ttl_init( VALUE self, VALUE options ) {
  if ( !NIL_P( options ) ) {
    Check_Type( options, T_FIXNUM );
  }
  if ( rb_funcall( options, rb_intern( "unsigned_8bit?" ), 0 ) == Qfalse ) {
    rb_raise( rb_eArgError, "Nw ttl must be an unsigned 8-bit integer" );
  }
  rb_iv_set( self, "@nw_ttl", options );
  return self;
}


/*
 * The new nw_ttl value to use to replace an existing IP TTL.
 *
 * @return [Number] the value of nw_ttl
 */
static VALUE
action_nw_ttl( VALUE self ) {
  return rb_iv_get( self, "@nw_ttl" );
}


/*
 * Appends its action(set IP TTL) to the list of actions.
 *
 * @return [ActionSetNwTtl] self
 */
static VALUE
action_set_nw_ttl_append( VALUE self, VALUE action_ptr ) {
  const uint8_t nw_ttl = ( const uint8_t ) NUM2UINT( action_nw_ttl( self ) );

  openflow_actions *actions;
  Data_Get_Struct( action_ptr, openflow_actions, actions );

  append_action_set_nw_ttl( actions, nw_ttl );
  return self;
}


/*
 * (see ActionEnqueue#inspect)
 */
static VALUE
action_set_nw_ttl_inspect( VALUE self ) {
  const uint8_t nw_ttl = ( const uint8_t ) NUM2UINT( action_nw_ttl( self ) );

  char str[ 64 ];
  sprintf( str, "#<%s IP TTL=%u>", rb_obj_classname( self ), nw_ttl );
  return rb_str_new2( str );
}


void
Init_action_set_nw_ttl() {
  cActionSetNwTtl = rb_define_class_under( mTrema, "ActionSetNwTtl", rb_cObject );
  rb_define_method( cActionSetNwTtl, "initialize", action_set_nw_ttl_init, 1 );
  rb_define_method( cActionSetNwTtl, "nw_ttl", action_nw_ttl, 0 );
  rb_define_method( cActionSetNwTtl, "append", action_set_nw_ttl_append, 1 );
  rb_define_method( cActionSetNwTtl, "inspect", action_set_nw_ttl_inspect, 0 );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
