/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include "trema.h"
#include "ruby.h"


extern VALUE mTrema;
VALUE cActionSetQueue;


/*
 * An action that sets the queue id for the packet.
 *
 * @overload initialize(options={})
 *
 *   @example
 *     ActionSetQueue.new( :queue_id => queue_id )
 *   @param [Number] queue_id
 *     the queue id this action refers to.
 *
 *   @raise [ArgumentError] if queue_id argument is not supplied.
 *   @raise [ArgumentError] if queue_id is not an unsigned 32-bit integer.
 *
 *   @return [ActionSetQueue] 
 *     an object that encapsulates this action.
 */
static VALUE
action_set_queue_init( VALUE self, VALUE options ) {
  if ( !NIL_P( options ) ) {
    Check_Type( options, T_FIXNUM );
  }
  if ( rb_funcall( options, rb_intern( "unsigned_32bit?" ), 0 ) == Qfalse ) {
    rb_raise( rb_eArgError, "Queue id must be an unsigned 32-bit integer" );
  }
  rb_iv_set( self, "@queue_id", options );
  return self;
}

/*
 * The queue_id associated with a queue table entry.
 *
 * @return [Number] the value of queue_id
 */
static VALUE
action_set_queue_queue_id( VALUE self ) {
  return rb_iv_get( self, "@queue_id" );
}


/*
 * Appends its action(set queue) to the list of actions.
 *
 * @return [ActionSetQueue] self
 */
static VALUE
action_set_queue_append( VALUE self, VALUE action_ptr ) {
  const uint32_t queue_id = NUM2UINT( action_output_port( self ) );

  openflow_actions *actions;
  Data_Get_Struct( action_ptr, openflow_actions, actions );

  append_action_set_queue( actions, queue_id );
  return self;
}


/*
 * (see ActionEnqueue#inspect)
 */
static VALUE
action_set_queue_inspect( VALUE self ) {
  const uint32_t queue_id = NUM2UINT( action_output_port( self ) );

  char str[ 64 ];
  sprintf( str, "#<%s queue id=%u>", rb_obj_classname( self ), queue_id );
  return rb_str_new2( str );
}


void
Init_action_set_queue() {
  cActionSetQueue = rb_define_class_under( mTrema, "ActionSetQueue", rb_cObject );
  rb_define_method( cActionSetQueue, "initialize", action_set_queue_init, 1 );
  rb_define_method( cActionSetQueue, "queue_id", action_set_queue_queue_id, 0 );
  rb_define_method( cActionSetQueue, "append", action_set_queue_append, 1 );
  rb_define_method( cActionSetQueue, "inspect", action_set_queue_inspect, 0 );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
