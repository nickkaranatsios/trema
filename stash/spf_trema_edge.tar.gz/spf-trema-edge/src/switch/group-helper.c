/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "openflow_switch_interface.h"
#include "log.h"
#include "ofdp/lib/table_manager_action_bucket.h"
#include "ofdp/lib/table_manager_group.h"
#include "action-helper.h"


static void
_handle_group_add( const uint32_t transaction_id, 
        const uint8_t type, 
        const uint32_t group_id, 
        const list_element *buckets ) {
  group_entry *group_entry = lookup_group_entry( group_id );
  if ( group_entry != NULL ) {
    send_error_message( transaction_id, OFPET_GROUP_MOD_FAILED, OFPGMFC_GROUP_EXISTS );
    return;
  }
  bucket_list *bucket_list;
  
  bucket_list = create_action_bucket_list();
  action_list *action_list = init_action_list();
  for ( const list_element *e = buckets; e != NULL; e = e->next ) {
    struct ofp_bucket *ofp_bucket = e->data;
    uint16_t offset = ( uint16_t ) offsetof( struct ofp_bucket, actions );
    if ( ofp_bucket->len > offset ) {
      struct ofp_action_header *ac_hdr = ofp_bucket->actions;
      action_list = assign_actions( ac_hdr, ac_hdr->len, action_list );
      bucket *bucket = create_action_bucket( ofp_bucket->weight, ofp_bucket->watch_port, ofp_bucket->watch_group, action_list );
      if ( bucket != NULL ) {
        append_action_bucket( bucket_list, bucket );
      }
    }
  }
  if ( create_group_entry( type, bucket_list ) !== NULL ) {
    warn( "Failed to create a group entry for group type %u, group id %u", type, group_id );
  }
}
void ( *handle_group_add )( const uint32_t transaction_id,
        const uint8_t type,
        const uint32_t group_id,
        const list_element *buckets ) = _handle_group_add;



/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */

