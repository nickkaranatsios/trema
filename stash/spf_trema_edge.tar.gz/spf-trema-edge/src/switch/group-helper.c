/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include "openflow_switch_interface.h"
#include "log.h"
#include "table_manager_action_bucket.h"
#include "table_manager_group.h"
#include "action-helper.h"


static bucket_list *
construct_bucket_list( const list_element *buckets ) {
  bucket_list *bkt_list = create_action_bucket_list();

  for ( const list_element *e = buckets; e != NULL; e = e->next ) {
    const struct ofp_bucket *ofp_bucket = e->data;
    uint16_t offset = ( uint16_t ) offsetof( struct ofp_bucket, actions );
    if ( ofp_bucket->len > offset ) {
      action_list *ac_list = init_action_list();
      const struct ofp_action_header *ac_hdr = ofp_bucket->actions;
      ac_list = assign_actions( ac_list, ac_hdr, ac_hdr->len );
      bucket *bucket = create_action_bucket( ofp_bucket->weight, ofp_bucket->watch_port, ofp_bucket->watch_group, ac_list );
      if ( bucket != NULL ) {
        append_action_bucket( bkt_list, bucket );
      }
    }
  }
  return bkt_list;
}

static void
_handle_group_add( const uint32_t transaction_id,
        const uint8_t type,
        const uint32_t group_id,
        const list_element *buckets ) {
  group_entry *found_entry = lookup_group_entry( group_id );
  if ( found_entry != NULL ) {
    send_error_message( transaction_id, OFPET_GROUP_MOD_FAILED, OFPGMFC_GROUP_EXISTS );
    return;
  }
  bucket_list *bkt_list = construct_bucket_list( buckets );
  group_entry *entry = create_group_entry( type, group_id, bkt_list );
  if ( entry != NULL ) {
    append_group_entry( entry );
  } else {
    send_error_message( transaction_id, OFPET_GROUP_MOD_FAILED, OFPGMFC_BAD_TYPE );
  }
}
void ( *handle_group_add )( const uint32_t transaction_id,
        const uint8_t type,
        const uint32_t group_id,
        const list_element *buckets ) = _handle_group_add;


static void
_handle_group_mod_mod( const uint32_t transaction_id,
        const uint8_t type,
        const uint32_t group_id,
        const list_element *buckets ) {
  group_entry *group_entry = lookup_group_entry( group_id );
  if ( group_entry == NULL ) {
    send_error_message( transaction_id, OFPET_GROUP_MOD_FAILED, OFPGMFC_UNKNOWN_GROUP );
    return;
  }
  /*
   * TODO There is no update group entry call therefore modify directly.
   * If one wishes to delete yet leave in flow entries using it, that gorup
   * can be cleared by sending a modify with no buckets specified
   */
  delete_action_bucket_list( &group_entry->p_bucket );
  /*
   * group entry found update its type and action buckets if specified
   */
  group_entry->type = type;
  if ( list_length_of( buckets ) ) {
    group_entry->p_bucket = construct_bucket_list( buckets );
  }
}
void ( *handle_group_mod_mod )( const uint32_t transaction_id,
        const uint8_t type,
        const uint32_t group_id,
        const list_element *buckets ) = _handle_group_mod_mod;


static void
_handle_group_mod_delete( const uint32_t transaction_id,
        const uint32_t group_id ) {
  if ( is_valid_group_no( group_id ) ) {
    remove_group_entry( group_id );
  } else {
    send_error_message( transaction_id, OFPET_GROUP_MOD_FAILED, OFPGMFC_UNKNOWN_GROUP );
  }
}
void ( *handle_group_mod_delete )( const uint32_t transaction_id,
        const uint32_t group_id ) = _handle_group_mod_delete;


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */

