/*
 * Functions for sending/receving Openflow controller message.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include <sys/time.h>
#include "ofdp.h"
#include "ofdp_common.h"
#include "controller_manager.h"
#include "mutex_lock.h"
#include "linked_list.h"
#include "wrapper.h"
#include "port_manager.h"
#include "packet_buffer_pool.h"


/***************************************
  for unit test
***************************************/
#ifdef UNIT_TESTING
#include "test_mocks.h"

#ifdef send_for_notify_port_config
#undef send_for_notify_port_config
#endif
#define send_for_notify_port_config mock_send_for_notify_port_config
OFDPE mock_send_for_notify_port_config( uint32_t port_no, uint8_t reason );

#endif /* UNIT_TESTING */


typedef enum {
  external_message_type_port_add = 0,
  external_message_type_port_delete,
  external_message_type_port_conf
} external_message_type;


typedef struct {
  handler_notify_to_controller notify_packet_in;
  handler_notify_to_controller notify_flow_removed;
  handler_notify_to_controller notify_port_status;
  handler_notify_to_controller notify_errors;
  void *user_data;
} controller_handlers;


typedef struct {
  buffer *packet;
  uint32_t buffer_id;
  struct timespec saved_at;
}  packet_in_buffer_element;


typedef struct {
  external_message_type type;
  void *parameter;
} external_message;


typedef struct {
  argument_device_info device_info;
} external_message_add_port;


typedef struct {
  uint32_t port_no;
} external_message_delete_port;

typedef struct {
  uint32_t max;
  list_element *list;
  pthread_mutex_t mutex;
} data_list;


typedef struct {
  controller_handlers handlers;
  data_list packet_in_buffer;
  data_list external;
} controller_manager;


static controller_manager controller;


static uint32_t
get_packet_in_buffer_id( data_list *list ) {
  if ( list->max == 0 ) {
    return UINT32_MAX;
  }

  uint32_t id = list_length_of( list->list ) % list->max;
  list_element *element = list->list;
  packet_in_buffer_element *entry = NULL;

  while ( element != NULL ) {
    entry = ( packet_in_buffer_element * ) element->data;
    if ( id == entry->buffer_id ) {
      struct timespec diff;
      struct timespec tnow;
      time_now( &tnow );
      timespec_diff( entry->saved_at, tnow, &diff );
      if ( diff.tv_sec > 0 ) {
        debug( "packet in buffer(id = %u) is expired.", id );
        if ( entry->packet != NULL ) {
          free_packet_buffer_pool_entry( entry->packet );
        }
        delete_element( &list->list, entry );
      }
      else {
        id = UINT32_MAX;
      }
      break;
    }
    element = element->next;
  }

  return id;
}


static packet_in_buffer_element *
create_packet_in_buffer_element( buffer *packet, uint32_t buffer_id ) {
  assert( packet != NULL );

  packet_in_buffer_element *element = ( packet_in_buffer_element * ) xmalloc( sizeof( packet_in_buffer_element ) );
  if ( element == NULL ) {
    return NULL;
  }

  element->packet = duplicate_packet_buffer_pool_entry( packet );
  element->buffer_id = buffer_id;
  time_now( &element->saved_at );

  return element;
}


static uint32_t
append_packet_in_buffer( data_list *list, buffer *packet ) {
  assert( list != NULL );
  assert( packet != NULL );

  if ( !lock_mutex( &list->mutex ) ) {
    return UINT32_MAX;
  }

  uint32_t buffer_id = get_packet_in_buffer_id( list );

  if ( buffer_id == UINT32_MAX ) {
    unlock_mutex( &list->mutex );
    debug( "can not append to packet_in_buffer. id = %u.", buffer_id );
    return UINT32_MAX;
  }

  packet_in_buffer_element *element = create_packet_in_buffer_element( packet, buffer_id );
  if ( element == NULL ) {
    error( "can not allocate packet_in_buffer element." );
    unlock_mutex( &list->mutex );
    return UINT32_MAX;
  }

  if ( !append_to_tail( &list->list, element ) ) {
    error( "can not append to packet_in_buffer." );
    free_packet_buffer_pool_entry( element->packet );
    xfree( element );
    unlock_mutex( &list->mutex );
    return UINT32_MAX;
  }

  if ( !unlock_mutex( &list->mutex ) ) {
    return UINT32_MAX;
  }

  return buffer_id;
}


static void *
duplicate_parameter_memory( const void *parameter, size_t size ) {
  assert( parameter != NULL );

  void *ret = xmalloc( size );
  memcpy( ret, parameter, size );
  return ret;
}


static void *
duplicate_parameter( notify_type type, void *original ) {
  assert( original != NULL );

  void *ret = NULL;

  switch ( type ) {
  case NOTIFY_TYPE_PACKET_IN:
    ret = duplicate_parameter_memory( original, sizeof( notify_parameter_packet_in ) );
    if ( ret != NULL ) {
      if ( ( ( notify_parameter_packet_in * ) original )->packet != NULL ) {
        buffer *packet = duplicate_buffer( ( ( notify_parameter_packet_in * ) original )->packet );
        if ( packet == NULL ) {
          error( "can not allocate buffer(%d).", NOTIFY_TYPE_PACKET_IN );
          xfree( ret );
        }
        else {
          packet->user_data = NULL;
          ( ( notify_parameter_packet_in * ) ret )->packet = packet;
        }
      }
    }
    break;

  case NOTIFY_TYPE_FLOW_REMOVED:
    ret = duplicate_parameter_memory( original, sizeof( notify_parameter_flow_removed ) );
    break;

  case NOTIFY_TYPE_PORT_STATUS:
    ret = duplicate_parameter_memory( original, sizeof( notify_parameter_port_status ) );
    break;

  case NOTIFY_TYPE_ERROR:
    ret = duplicate_parameter_memory( original, sizeof( notify_parameter_error ) );
    if ( ret != NULL ) {
      if ( ( ( notify_parameter_error * ) original )->packet != NULL ) {
        buffer *packet = duplicate_buffer( ( ( notify_parameter_error * ) original )->packet );
        if ( packet == NULL ) {
          error( "can not allocate buffer(%d).", NOTIFY_TYPE_PACKET_IN );
          xfree( ret );
        }
        else {
          ( ( notify_parameter_error * ) ret )->packet = packet;
        }
      }
    }
    break;

  default:
    error( "type = %d is not supported.", type );
    return ret;

    break;
  }

  if ( ret == NULL ) {
    error( "can not allocate parameter(%d).", type );
  }

  return ret;
}


static OFDPE
init_data_list( data_list *list, uint32_t max ) {
  assert( list != NULL );

  if ( !init_mutex( &list->mutex ) ) {
    return ERROR_INIT_MUTEX;
  }

  create_list( &list->list );

  list->max = max;

  return OFDPE_SUCCESS;
}


static void
finalize_packet_in_buffer_data_list( data_list *list ) {
  list_element *element = list->list;

  while ( element != NULL ) {
    list_element *next = element->next;
    packet_in_buffer_element *buffer_element = ( packet_in_buffer_element * ) element->data;
    delete_element( &element, buffer_element );
    free_packet_buffer_pool_entry( buffer_element->packet );
    xfree( buffer_element );
    element = next;
  }

  finalize_mutex( &list->mutex );

  return;
}


static void
finalize_external_data_list( data_list *list ) {
  list_element *element = list->list;

  while ( element != NULL ) {
    list_element *next = element->next;
    external_message *buffer_element = ( external_message * ) element->data;
    delete_element( &element, buffer_element );
    xfree( buffer_element->parameter );
    xfree( buffer_element );
    element = next;
  }

  finalize_mutex( &list->mutex );

  return;
}


/**
 * initialize controller manager
 *
 * param number of packet_in buffer
 * return success/failed
 */
static OFDPE
_init_controller_manager( uint32_t buffer_list_max ) {
  OFDPE ret = 0;

  controller.handlers.notify_packet_in = NULL;
  controller.handlers.notify_flow_removed = NULL;
  controller.handlers.notify_port_status = NULL;
  controller.handlers.notify_errors = NULL;

  ret = init_data_list( &controller.packet_in_buffer, buffer_list_max );
  if ( ret != OFDPE_SUCCESS ) {
    error( "can not initialize packet_in_buffer." );
    return OFDPE_FAILED;
  }

  init_data_list( &controller.external, buffer_list_max );
  if ( ret != OFDPE_SUCCESS ) {
    error( "can not initialize external_message_buffer." );
    return OFDPE_FAILED;
  }

  return OFDPE_SUCCESS;
}
OFDPE ( *init_controller_manager )( uint32_t buffer_list_max ) = _init_controller_manager;


/**
 * finalize controller manager
 *
 * param nothing
 * return success/failed
 */
static OFDPE
_finalize_controller_manager() {
  finalize_packet_in_buffer_data_list( &controller.packet_in_buffer );
  finalize_external_data_list( &controller.external );

  return OFDPE_SUCCESS;
}
OFDPE ( *finalize_controller_manager )() = _finalize_controller_manager;


/**
 * notify packet in message
 *
 * param packet in parameter
 * return success/failed
 */
static OFDPE
_notify_packet_in( notify_parameter_packet_in *parameter ) {
  assert( parameter != NULL );

  handler_notify_to_controller handler = controller.handlers.notify_packet_in;

  if ( handler == NULL ) {
    warn( "function:notify_packet_in is not set." );
    return OFDPE_SUCCESS;
  }

  uint32_t buffer_id = append_packet_in_buffer( &controller.packet_in_buffer, parameter->packet );
  notify_parameter_packet_in *new = duplicate_parameter( NOTIFY_TYPE_PACKET_IN, parameter );
  if ( new == NULL ) {
    error( "can not duplicate packet in parameter." );
    return OFDPE_FAILED;
  }

  new->buffer_id = buffer_id;
  debug( "notify_packet_in: %p(%p) -> %p(%p)", parameter->packet, parameter->packet->user_data,
          new->packet, new->packet->user_data );
  handler( new, controller.handlers.user_data );

  return OFDPE_SUCCESS;
}
OFDPE ( *notify_packet_in )( notify_parameter_packet_in *parameter ) = _notify_packet_in;


/**
 * notify flow removed message
 *
 * param flow removed parameter
 * return success/failed
 */
static OFDPE
_notify_flow_removed( notify_parameter_flow_removed *parameter ) {
  assert( parameter != NULL );

  handler_notify_to_controller handler = controller.handlers.notify_flow_removed;

  if ( handler == NULL ) {
    warn( "function:notify_packet_flow_removed is not set." );
    return OFDPE_SUCCESS;
  }

  notify_parameter_flow_removed *new = duplicate_parameter( NOTIFY_TYPE_FLOW_REMOVED, parameter );
  if ( new == NULL ) {
    error( "can not duplicate flow removed parameter." );
    return OFDPE_FAILED;
  }

  handler( new, controller.handlers.user_data );

  return OFDPE_SUCCESS;
}
OFDPE ( *notify_flow_removed )( notify_parameter_flow_removed *parameter ) = _notify_flow_removed;


/**
 * notify port status message
 *
 * param port status parameter
 * return success/failed
 */
static OFDPE
_notify_port_status( notify_parameter_port_status *parameter ) {
  assert( parameter != NULL );

  handler_notify_to_controller handler = controller.handlers.notify_port_status;

  if ( handler == NULL ) {
    warn( "function:notify_packet_port_status is not set." );
    return OFDPE_SUCCESS;
  }

  notify_parameter_port_status *new = duplicate_parameter( NOTIFY_TYPE_PORT_STATUS, parameter );
  if ( new == NULL ) {
    error( "can not duplicate port status parameter." );
    return OFDPE_FAILED;
  }

  handler( new, controller.handlers.user_data );

  return OFDPE_SUCCESS;
}
OFDPE ( *notify_port_status )( notify_parameter_port_status *parameter ) = _notify_port_status;


/**
 * notify error message
 *
 * param error parameter
 * return success/failed
 */
static OFDPE
_notify_error( notify_parameter_error *parameter ) {
  assert( parameter != NULL );

  handler_notify_to_controller handler = controller.handlers.notify_errors;

  if ( handler == NULL ) {
    warn( "function:notify_packet_errors is not set." );
    return OFDPE_SUCCESS;
  }

  notify_parameter_error *new = duplicate_parameter( NOTIFY_TYPE_ERROR, parameter );
  if ( new == NULL ) {
    error( "can not duplicate error parameter." );
    return OFDPE_FAILED;
  }

  handler( new, controller.handlers.user_data );

  return OFDPE_SUCCESS;
}
OFDPE ( *notify_error )( notify_parameter_error *parameter ) = _notify_error;


/**
 * register notify handler to controller
 *
 * param notify type
 * param register function handler
 * return success/failed
 */
static OFDPE
_register_notify_handler_to_controller( notify_type type,
        handler_notify_to_controller handler, void *data ) {
  OFDPE ret = OFDPE_SUCCESS;

  controller.handlers.user_data = data;
  switch ( type ) {
  case NOTIFY_TYPE_PACKET_IN:
    controller.handlers.notify_packet_in = handler;
    break;

  case NOTIFY_TYPE_FLOW_REMOVED:
    controller.handlers.notify_flow_removed = handler;
    break;

  case NOTIFY_TYPE_PORT_STATUS:
    controller.handlers.notify_port_status = handler;
    break;

  case NOTIFY_TYPE_ERROR:
    controller.handlers.notify_errors = handler;
    break;

  default:
    ret = OFDPE_FAILED;
    break;
  }

  return ret;
}
OFDPE ( *register_notify_handler_to_controller )( notify_type type,  handler_notify_to_controller handler, void *data ) = _register_notify_handler_to_controller;


/**
 * get packet_in buffer
 *
 * param packet_in buffer id
 * param set pointer buffer structure
 * return success/failed
 */
static OFDPE
_get_packet_buffer( uint32_t buffer_id, buffer **buffer ) {
  data_list *list = &controller.packet_in_buffer;

  if ( !lock_mutex( &list->mutex ) ) {
    return OFDPE_FAILED;
  }

  *buffer = NULL;
  list_element *element = list->list;
  while ( element != NULL ) {
    packet_in_buffer_element *buffer_element = ( packet_in_buffer_element * ) element->data;
    if ( buffer_element->buffer_id == buffer_id ) {
      delete_element( &list->list, element->data );
      *buffer = buffer_element->packet;
      xfree( buffer_element );
      break;
    }
    element = element->next;
  }
  if ( !unlock_mutex( &list->mutex ) ) {
    return OFDPE_FAILED;
  }

  return *buffer == NULL ? OFDPE_FAILED : OFDPE_SUCCESS;
}
OFDPE ( *get_packet_buffer )( uint32_t buffer_id, buffer **buffer ) = _get_packet_buffer;


static OFDPE
append_external_message( void *message ) {
  data_list *list = &controller.external;

  if ( !lock_mutex( &list->mutex ) ) {
    return ERROR_LOCK;
  }

  if ( !append_to_tail( &list->list, message ) ) {
    error( "can not append to external message" );
    return ERROR_APPEND_TO_LIST;
  }

  if ( !unlock_mutex( &list->mutex ) ) {
    return ERROR_UNLOCK;
  }

  return OFDPE_SUCCESS;
}


/**
 * add switch port
 *
 * param switch port number
 * param device name
 * return success/failed
 */
static OFDPE
_add_port( uint32_t port_no, const char *device_name ) {
  if ( get_library_status() == STARTED ) {
    external_message *message = xmalloc( sizeof( external_message ) );

    if ( message == NULL ) {
      return ERROR_NO_MEMORY;
    }
    external_message_add_port *message_add_port = xmalloc( sizeof( external_message_add_port ) );
    if ( message_add_port == NULL ) {
      xfree( message );
      return ERROR_NO_MEMORY;
    }

    message_add_port->device_info.port_no = port_no;
    memcpy( message_add_port->device_info.device_name,
            device_name,
            sizeof( message_add_port->device_info.device_name ) - 1 );
    message->parameter = message_add_port;
    message->type = external_message_type_port_add;

    OFDPE ret = append_external_message( message );
    if ( ret != OFDPE_SUCCESS ) {
      xfree( message_add_port );
      xfree( message );
      return OFDPE_FAILED;
    }
  }
  else {
    OFDPE libret = OFDPE_SUCCESS;
    argument_device_info device_info;
    device_info.port_no = port_no;
    memcpy( device_info.device_name, device_name,
            sizeof( device_info.device_name ) - 1 );

    libret = init_device( &device_info );
    if ( libret != OFDPE_SUCCESS ) {
      error( "init_device failed. ret = %d, portno = %d, name = %s",
              libret, device_info.port_no, device_info.device_name );
      if ( libret >= ERROR_OFDPE_ERROR_START ) {
        send_for_notify_error( libret, NULL );
      }
    }

    send_for_notify_port_config( device_info.port_no, OFPPR_ADD );
  }

  return OFDPE_SUCCESS;
}
OFDPE ( *add_port )( uint32_t port_no, const char *device_name ) = _add_port;


/**
 * delete switch port
 *
 * param switch port number
 * return success/failed
 */
static OFDPE
_delete_port( uint32_t port_no ) {
  external_message *message = xmalloc( sizeof( external_message ) );

  if ( message == NULL ) {
    return ERROR_NO_MEMORY;
  }
  external_message_delete_port *message_delete_port = xmalloc( sizeof( external_message_delete_port ) );
  if ( message_delete_port == NULL ) {
    xfree( message );
    return ERROR_NO_MEMORY;
  }

  message_delete_port->port_no = port_no;
  message->parameter = message_delete_port;
  message->type = external_message_type_port_delete;

  OFDPE ret = append_external_message( message );
  if ( ret != OFDPE_SUCCESS ) {
    xfree( message_delete_port );
    xfree( message );
    return OFDPE_FAILED;
  }

  return OFDPE_SUCCESS;
}
OFDPE ( *delete_port )( uint32_t port_no ) = _delete_port;


/**
 * execute external message (port_add, port_delete)
 *
 * param nothing
 * return success/failed
 */
static void
_execute_external_message() {
  data_list *list = &controller.external;

  if ( !lock_mutex( &list->mutex ) ) {
    return;
  }

  list_element *element = list->list;

  while ( element != NULL ) {
    OFDPE libret = OFDPE_SUCCESS;
    external_message *message = ( external_message * ) element->data;

    list_element *next = element->next;
    delete_element( &list->list, message );

    argument_device_info *device_info = NULL;
    uint32_t port_no = 0;

    switch ( message->type ) {
    case external_message_type_port_add:
      device_info = &( ( external_message_add_port * ) message->parameter )->device_info;
      libret = init_device( device_info );
      if ( libret != OFDPE_SUCCESS ) {
        error( "init_device failed. ret = %d, portno = %d, name = %s",
          libret, device_info->port_no, device_info->device_name );
        if ( libret >= ERROR_OFDPE_ERROR_START ) {
          send_for_notify_error( libret, NULL );
        }
      }
      else {
        send_for_notify_port_config( device_info->port_no, OFPPR_ADD );
      }
      break;

    case external_message_type_port_delete:
      port_no = ( ( external_message_delete_port * ) message->parameter )->port_no;

      libret = finalize_device( port_no );
      if ( libret != OFDPE_SUCCESS ) {
        error( "finalize_device failed. ret = %d, portno = %d", libret, port_no );
        if ( libret >= ERROR_OFDPE_ERROR_START ) {
          send_for_notify_error( libret, NULL );
        }
      }
      else {
        send_for_notify_port_config( port_no, OFPPR_DELETE );
      }
      break;

    default:
      error( "type %d is not supported.", message->type );
      break;
    }

    xfree( message->parameter );
    xfree( message );

    element = next;
  }

  if ( !unlock_mutex( &list->mutex ) ) {
    return;
  }

  return;
}


void ( *execute_external_message )() = _execute_external_message;


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
