/*
 * Author: Kazushi SUGYO
 *
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <assert.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include "openflow_wrapper.h"
#include "ofdp_common.h"
#include "checks.h"
#include "match_table.h"
#include "log.h"
#include "wrapper.h"
#include "table_manager.h"

#define VLAN_VID_MASK 0x0fff // 12 bits
#define VLAN_PCP_MASK 0x07 // 3 bits
#define NW_TOS_MASK 0x3f // 6 bits


typedef struct {
  hash_table *exact_table; // no wildcards are set
  list_element *wildcards_table; // wildcards flags are set
  pthread_mutex_t *mutex;
} match_table;


typedef struct {
  match *p_match;
  void
  (*function )( match *, uint16_t, void *, void * );
  void *user_data;
} match_walker;


static inline bool
exact_match( match *p_match ) {
  assert( p_match != NULL );

  if ( ( p_match->arp_op.valid == true ) && ( p_match->arp_op.mask != ( uint16_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->arp_op.valid == false ) {
    p_match->arp_op.value = 0;
    p_match->arp_op.mask = ( uint16_t ) ~0;
  }
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    if ( ( p_match->arp_sha[0].valid == true )
            && ( p_match->arp_sha[i].mask != ( uint8_t ) ~0 ) ) {
      return false;
    }
  }
  if ( p_match->arp_sha[0].valid == false ) {
    for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
      p_match->arp_sha[i].value = 0;
      p_match->arp_sha[i].mask = ( uint8_t ) ~0;
      p_match->arp_sha[i].valid = false;
    }
  }
  if ( ( p_match->arp_spa.valid == true ) && ( p_match->arp_spa.mask != ( uint32_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->arp_spa.valid == false ) {
    p_match->arp_spa.value = 0;
    p_match->arp_spa.mask = ( uint32_t ) ~0;
  }
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    if ( ( p_match->arp_tha[0].valid == true )
            && ( p_match->arp_tha[i].mask != ( uint8_t ) ~0 ) ) {
      return false;
    }
  }
  if ( p_match->arp_tha[0].valid == false ) {
    for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
      p_match->arp_tha[i].value = 0;
      p_match->arp_tha[i].mask = ( uint8_t ) ~0;
      p_match->arp_tha[i].valid = false;
    }
  }
  if ( ( p_match->arp_tpa.valid == true ) && ( p_match->arp_tpa.mask != ( uint32_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->arp_tpa.valid == false ) {
    p_match->arp_tpa.value = 0;
    p_match->arp_tpa.mask = ( uint32_t ) ~0;
  }
  if ( ( p_match->in_phy_port.valid == true )
          && ( p_match->in_phy_port.mask != ( uint32_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->in_phy_port.valid == false ) {
    p_match->in_phy_port.value = 0;
    p_match->in_phy_port.mask = ( uint32_t ) ~0;
  }
  if ( ( p_match->in_port.valid == true ) && ( p_match->in_port.mask != ( uint32_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->in_port.valid == false ) {
    p_match->in_port.value = 0;
    p_match->in_port.mask = ( uint32_t ) ~0;
  }
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    if ( ( p_match->eth_dst[0].valid == true )
            && ( p_match->eth_dst[i].mask != ( uint8_t ) ~0 ) ) {
      return false;
    }
  }
  if ( p_match->eth_dst[0].valid == false ) {
    for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
      p_match->eth_dst[i].value = 0;
      p_match->eth_dst[i].mask = ( uint8_t ) ~0;
      p_match->eth_dst[i].valid = false;
    }
  }
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    if ( ( p_match->eth_src[0].valid == true )
            && ( p_match->eth_src[i].mask != ( uint8_t ) ~0 ) ) {
      return false;
    }
  }
  if ( p_match->eth_src[0].valid == false ) {
    for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
      p_match->eth_src[i].value = 0;
      p_match->eth_src[i].mask = ( uint8_t ) ~0;
      p_match->eth_src[i].valid = false;
    }
  }
  if ( ( p_match->eth_type.valid == true )
          && ( p_match->eth_type.mask != ( uint16_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->eth_type.valid == false ) {
    p_match->eth_type.value = 0;
    p_match->eth_type.mask = ( uint16_t ) ~0;
  }
  if ( ( p_match->icmpv4_code.valid == true )
          && ( p_match->icmpv4_code.mask != ( uint8_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->icmpv4_code.valid == false ) {
    p_match->icmpv4_code.value = 0;
    p_match->icmpv4_code.mask = ( uint8_t ) ~0;
  }
  if ( ( p_match->icmpv4_type.valid == true )
          && ( p_match->icmpv4_type.mask != ( uint8_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->icmpv4_type.valid == false ) {
    p_match->icmpv4_type.value = 0;
    p_match->icmpv4_type.mask = ( uint8_t ) ~0;
  }
  if ( ( p_match->icmpv6_code.valid == true )
          && ( p_match->icmpv6_code.mask != ( uint8_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->icmpv6_code.valid == false ) {
    p_match->icmpv6_code.value = 0;
    p_match->icmpv6_code.mask = ( uint8_t ) ~0;
  }
  if ( ( p_match->icmpv6_type.valid == true )
          && ( p_match->icmpv6_type.mask != ( uint8_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->icmpv6_type.valid == false ) {
    p_match->icmpv6_type.value = 0;
    p_match->icmpv6_type.mask = ( uint8_t ) ~0;
  }
  if ( ( p_match->ip_dscp.valid == true ) && ( p_match->ip_dscp.mask != ( uint8_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->ip_dscp.valid == false ) {
    p_match->ip_dscp.value = 0;
    p_match->ip_dscp.mask = ( uint8_t ) ~0;
  }
  if ( ( p_match->ip_ecn.valid == true ) && ( p_match->ip_ecn.mask != ( uint8_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->ip_ecn.valid == false ) {
    p_match->ip_ecn.value = 0;
    p_match->ip_ecn.mask = ( uint8_t ) ~0;
  }
  if ( ( p_match->ip_proto.valid == true ) && ( p_match->ip_proto.mask != ( uint8_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->ip_proto.valid == false ) {
    p_match->ip_proto.value = 0;
    p_match->ip_proto.mask = ( uint8_t ) ~0;
  }
  if ( ( p_match->ipv4_dst.valid == true )
          && ( p_match->ipv4_dst.mask != ( uint32_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->ipv4_dst.valid == false ) {
    p_match->ipv4_dst.value = 0;
    p_match->ipv4_dst.mask = ( uint32_t ) ~0;
  }
  if ( ( p_match->ipv4_src.valid == true )
          && ( p_match->ipv4_src.mask != ( uint32_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->ipv4_src.valid == false ) {
    p_match->ipv4_src.value = 0;
    p_match->ipv4_src.mask = ( uint32_t ) ~0;
  }
  for ( int i = 0; i < IPV6_ADDRLEN; i++ ) {
    if ( ( p_match->ipv6_dst[0].valid == true )
            && ( p_match->ipv6_dst[i].mask != ( uint8_t ) ~0 ) ) {
      return false;
    }
  }
  if ( p_match->ipv6_dst[0].valid == false ) {
    for ( int i = 0; i < IPV6_ADDRLEN; i++ ) {
      p_match->ipv6_dst[i].value = 0;
      p_match->ipv6_dst[i].mask = ( uint8_t ) ~0;
      p_match->ipv6_dst[i].valid = false;
    }
  }
  if ( ( p_match->ipv6_exthdr.valid == true )
          && ( p_match->ipv6_exthdr.mask != ( uint16_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->ipv6_exthdr.valid == false ) {
    p_match->ipv6_exthdr.value = 0;
    p_match->ipv6_exthdr.mask = ( uint16_t ) ~0;
  }
  if ( ( p_match->ipv6_flabel.valid == true )
          && ( p_match->ipv6_flabel.mask != ( uint32_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->ipv6_flabel.valid == false ) {
    p_match->ipv6_flabel.value = 0;
    p_match->ipv6_flabel.mask = ( uint32_t ) ~0;
  }
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    if ( ( p_match->ipv6_nd_sll[0].valid == true )
            && ( p_match->ipv6_nd_sll[i].mask != ( uint8_t ) ~0 ) ) {
      return false;
    }
  }
  if ( p_match->ipv6_nd_sll[0].valid == false ) {
    for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
      p_match->ipv6_nd_sll[i].value = 0;
      p_match->ipv6_nd_sll[i].mask = ( uint8_t ) ~0;
      p_match->ipv6_nd_sll[i].valid = false;
    }
  }
  for ( int i = 0; i < IPV6_ADDRLEN; i++ ) {
    if ( ( p_match->ipv6_nd_target[0].valid == true )
            && ( p_match->ipv6_nd_target[i].mask != ( uint8_t ) ~0 ) ) {
      return false;
    }
  }
  if ( p_match->ipv6_nd_target[0].valid == false ) {
    for ( int i = 0; i < IPV6_ADDRLEN; i++ ) {
      p_match->ipv6_nd_target[i].value = 0;
      p_match->ipv6_nd_target[i].mask = ( uint8_t ) ~0;
      p_match->ipv6_nd_target[i].valid = false;
    }
  }
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    if ( ( p_match->ipv6_nd_tll[0].valid == true )
            && ( p_match->ipv6_nd_tll[i].mask != ( uint8_t ) ~0 ) ) {
      return false;
    }
  }
  if ( p_match->ipv6_nd_tll[0].valid == false ) {
    for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
      p_match->ipv6_nd_tll[i].value = 0;
      p_match->ipv6_nd_tll[i].mask = ( uint8_t ) ~0;
      p_match->ipv6_nd_tll[i].valid = false;
    }
  }
  for ( int i = 0; i < IPV6_ADDRLEN; i++ ) {
    if ( ( p_match->ipv6_src[0].valid == true )
            && ( p_match->ipv6_src[i].mask != ( uint8_t ) ~0 ) ) {
      return false;
    }
  }
  if ( p_match->ipv6_src[0].valid == false ) {
    for ( int i = 0; i < IPV6_ADDRLEN; i++ ) {
      p_match->ipv6_src[i].value = 0;
      p_match->ipv6_src[i].mask = ( uint8_t ) ~0;
      p_match->ipv6_src[i].valid = false;
    }
  }
  if ( ( p_match->metadata.valid == true )
          && ( p_match->metadata.mask != ( uint64_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->metadata.valid == false ) {
    p_match->metadata.value = 0;
    p_match->metadata.mask = ( uint64_t ) ~0;
  }
  if ( ( p_match->mpls_bos.valid == true ) && ( p_match->mpls_bos.mask != ( uint8_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->mpls_bos.valid == false ) {
    p_match->mpls_bos.value = 0;
    p_match->mpls_bos.mask = ( uint8_t ) ~0;
  }
  if ( ( p_match->mpls_label.valid == true )
          && ( p_match->mpls_label.mask != ( uint32_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->mpls_label.valid == false ) {
    p_match->mpls_label.value = 0;
    p_match->mpls_label.mask = ( uint32_t ) ~0;
  }
  if ( ( p_match->mpls_tc.valid == true ) && ( p_match->mpls_tc.mask != ( uint8_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->mpls_tc.valid == false ) {
    p_match->mpls_tc.value = 0;
    p_match->mpls_tc.mask = ( uint8_t ) ~0;
  }
  if ( ( p_match->sctp_dst.valid == true )
          && ( p_match->sctp_dst.mask != ( uint16_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->sctp_dst.valid == false ) {
    p_match->sctp_dst.value = 0;
    p_match->sctp_dst.mask = ( uint16_t ) ~0;
  }
  if ( ( p_match->sctp_src.valid == true )
          && ( p_match->sctp_src.mask != ( uint16_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->sctp_src.valid == false ) {
    p_match->sctp_src.value = 0;
    p_match->sctp_src.mask = ( uint16_t ) ~0;
  }
  if ( ( p_match->tcp_dst.valid == true ) && ( p_match->tcp_dst.mask != ( uint16_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->tcp_dst.valid == false ) {
    p_match->tcp_dst.value = 0;
    p_match->tcp_dst.mask = ( uint16_t ) ~0;
  }
  if ( ( p_match->tcp_src.valid == true ) && ( p_match->tcp_src.mask != ( uint16_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->tcp_src.valid == false ) {
    p_match->tcp_src.value = 0;
    p_match->tcp_src.mask = ( uint16_t ) ~0;
  }
  if ( ( p_match->tunnel_id.valid == true )
          && ( p_match->tunnel_id.mask != ( uint64_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->tunnel_id.valid == false ) {
    p_match->tunnel_id.value = 0;
    p_match->tunnel_id.mask = ( uint64_t ) ~0;
  }
  if ( ( p_match->udp_dst.valid == true ) && ( p_match->udp_dst.mask != ( uint16_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->udp_dst.valid == false ) {
    p_match->udp_dst.value = 0;
    p_match->udp_dst.mask = ( uint16_t ) ~0;
  }
  if ( ( p_match->udp_src.valid == true ) && ( p_match->udp_src.mask != ( uint16_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->udp_src.valid == false ) {
    p_match->udp_src.value = 0;
    p_match->udp_src.mask = ( uint16_t ) ~0;
  }
  if ( ( p_match->vlan_pcp.valid == true ) && ( p_match->vlan_pcp.mask != ( uint8_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->vlan_pcp.valid == false ) {
    p_match->vlan_pcp.value = 0;
    p_match->vlan_pcp.mask = ( uint8_t ) ~0;
  }
  if ( ( p_match->vlan_vid.valid == true )
          && ( p_match->vlan_vid.mask != ( uint16_t ) ~0 ) ) {
    return false;
  }
  if ( p_match->vlan_vid.valid == false ) {
    p_match->vlan_vid.value = 0;
    p_match->vlan_vid.mask = ( uint16_t ) ~0;
  }

  return true;
}


static match_entry *
allocate_match_entry( match *p_match, uint16_t priority, void *data ) {
  match_entry *new_entry = xmalloc( sizeof( match_entry ) );
  new_entry->p_match = p_match;
  new_entry->priority = priority;
  new_entry->data = data;

  return new_entry;
}


static void
free_match_entry( match_entry *free_entry ) {
  assert( free_entry != NULL );

  xfree( free_entry );
}


static bool
compare_filter_match( match *x, match *y ) {
  return match_packet2match_match( x, y );
}


static bool
compare_exact_match_entry( const void *x, const void *y ) {
  assert( x != NULL );
  assert( y != NULL );

  return compare_match_strict( x, y );
}


// Copy from RFC2083 15. Appendix: sample CRC code

/* Table of CRCs of all 8-bit messages. */
static uint32_t crc_table[256];

/* Flag: has the table been computed? Initially false. */
static int crc_table_computed = 0;

/* Make the table for a fast CRC. */
static void
make_crc_table( void ) {
  uint32_t c;
  int n, k;
  for ( n = 0; n < 256; n++ ) {
    c = ( uint32_t ) n;
    for ( k = 0; k < 8; k++ ) {
      if ( c & 1 )
        c = 0xedb88320L ^ ( c >> 1 );
      else
        c = c >> 1;
    }
    crc_table[n] = c;
  }
  crc_table_computed = 1;
}


/* Update a running CRC with the bytes buf[0..len-1]--the CRC
 should be initialized to all 1's, and the transmitted value
 is the 1's complement of the final running CRC (see the
 crc() routine below)). */
static uint32_t
update_crc( uint32_t crc, const unsigned char *buf, int len ) {
  uint32_t c = crc;
  int n = 0;

  if ( !crc_table_computed )
    make_crc_table( );
  for ( n = 0; n < len; n++ ) {
    c = crc_table[( c ^ buf[n] ) & UCHAR_MAX] ^ ( c >> 8 );
  }
  return c;
}


/* Return the CRC of the bytes buf[0..len-1]. */
static uint32_t
crc(const unsigned char *buf, int len) {
  return update_crc( UINT32_MAX, buf, len ) ^ UINT32_MAX;
}


// Copied from RFC2083 15. Appendix: sample CRC code
static unsigned int
hash_exact_match_entry( const void *key ) {
  assert( key != NULL );

  unsigned int hash = 0;

  hash = crc( key, sizeof( match ) );

  return hash;
}


static void
init_exact_match_table( hash_table **exact_table ) {
  //assert( exact_table != NULL );

  *exact_table = create_hash( compare_exact_match_entry, hash_exact_match_entry );
}


static void
free_exact_match_entry( void *key, void *value, void *user_data ) {
  UNUSED( key );
  assert( value != NULL );
  UNUSED( user_data );

  match_entry *entry = value;

  free_match_entry( entry );
}


static void
finalize_exact_match_table( hash_table *exact_table ) {
  assert( exact_table != NULL );

  foreach_hash( exact_table, free_exact_match_entry, NULL );
  delete_hash( exact_table );
}


static void
init_wildcards_match_table( list_element **wildcards_table ) {
  //assert( wildcards_table != NULL);

  create_list( wildcards_table );
}


static void
finalize_wildcards_match_table( list_element *wildcards_table ) {
  list_element *element;
  for ( element = wildcards_table; element != NULL; element = element->next ) {
    free_match_entry( element->data );
    element->data = NULL;
  }
  delete_list( wildcards_table );
}


static bool
insert_wildcards_match_entry( list_element **wildcards_table, match *match,
        uint16_t priority, void *data ) {
  assert( match != NULL );

  list_element *element;
  for ( element = *wildcards_table; element != NULL; element = element->next ) {
    match_entry *entry = element->data;
    if ( entry->priority <= priority ) {
      break;
    }
    assert( entry != NULL );
    if ( entry->priority == priority
            && compare_match_strict( entry->p_match, match ) ) {
      return false;
    }
  }
  match_entry *new_entry = allocate_match_entry( match, priority, data );
  if ( element == NULL ) {
    // tail
    append_to_tail( wildcards_table, new_entry );
  }
  else if ( element == *wildcards_table ) {
    // head
    insert_in_front( wildcards_table, new_entry );
  }
  else {
    // insert before
    insert_before( wildcards_table, element->data, new_entry );
  }

  return true;
}


static match_entry *
lookup_wildcards_match_strict_entry( list_element *wildcards_table,
        match *p_match, uint16_t priority ) {
  assert( p_match != NULL );

  list_element *element;
  for ( element = wildcards_table; element != NULL; element = element->next ) {
    match_entry *entry = element->data;
    //    if ( entry->priority < priority ) {
    //      break;
    //    }
    if ( entry->priority == priority
            && compare_match_strict( entry->p_match, p_match ) ) {
      return entry;
    }
  }
  return NULL;
}


static match_entry *
lookup_wildcards_match_entry( list_element *wildcards_table, match *p_match ) {
  assert( p_match != NULL );

  list_element *element;
  for ( element = wildcards_table; element != NULL; element = element->next ) {
    match_entry *entry = element->data;
    if ( match_packet2match_match( p_match, entry->p_match ) ) {
      return entry;
    }
  }
  return NULL;
}


static list_element *
lookup_wildcards_match_entries( list_element *wildcards_table, match *p_match ) {
  assert( wildcards_table != NULL );
  assert( p_match != NULL );

  list_element *ret_list = NULL;
  create_list( &ret_list );

  for ( list_element *element = wildcards_table; element != NULL; element = element->next ) {
    match_entry *entry = element->data;
    if ( match_match_match( entry->p_match, p_match ) ) {
      append_to_tail( &ret_list, entry->data );
    }
  }
  return ret_list;
}


static bool
update_wildcards_match_entry( list_element *wildcards_table, match *p_match,
        uint16_t priority, void *data ) {
  assert( p_match != NULL );

  match_entry *entry = lookup_wildcards_match_strict_entry( wildcards_table,
          p_match, priority );
  if ( entry == NULL ) {
    return false;
  }
  entry->data = data;
  return true;
}


static void *
delete_wildcards_match_strict_entry( list_element **wildcards_table,
        match *p_match, uint16_t priority ) {
  assert( p_match != NULL );

  match_entry *entry = lookup_wildcards_match_strict_entry( *wildcards_table,
          p_match, priority );
  if ( entry == NULL ) {
    return NULL;
  }
  void *data = entry->data;
  delete_element( wildcards_table, entry );
  free_match_entry( entry );
  return data;
}


static void
map_wildcards_match_table( list_element *wildcards_table, match *p_match, void
        function( match *, uint16_t, void *, void * ), void *user_data ) {
  assert( function != NULL );

  list_element *element = wildcards_table;
  while ( element != NULL ) {
    match_entry *entry = element->data;
    element = element->next;
    if ( p_match != NULL ) {
      if ( !compare_filter_match( p_match, entry->p_match ) ) {
        continue;
      }
    }
    function( entry->p_match, entry->priority, entry->data, user_data );
  }
}


void
init_match_table( flow_table *_match_table_head ) {
  init_exact_match_table( &( _match_table_head->exact_table ) );
  init_wildcards_match_table( &( _match_table_head->wildcards_table ) );

}


void
finalize_match_table( flow_table *_match_table_head ) {
  if ( _match_table_head == NULL ) {
    die( "match table is not initialized." );
  }

  delete_dlist( ( dlist_element * ) ( _match_table_head->entry ) );
  finalize_exact_match_table( _match_table_head->exact_table );
  finalize_wildcards_match_table( _match_table_head->wildcards_table );
}


bool
insert_match_entry( uint8_t table_id, match *p_match, uint16_t priority,
        void *data ) {
  flow_table * _match_table_head = NULL;

  _match_table_head = _get_flow_table( table_id );
  if ( _match_table_head == NULL ) {
    die( "match table is not initialized." );
  }

  return insert_wildcards_match_entry( &_match_table_head->wildcards_table, p_match, priority, data );
}


void *
lookup_match_strict_entry( uint8_t table_id, match *p_match, uint16_t priority ) {
  flow_table * _match_table_head = NULL;

  _match_table_head = _get_flow_table( table_id );
  if ( _match_table_head == NULL ) {
    die( "match table is not initialized." );
  }

  match_entry *entry = lookup_wildcards_match_strict_entry( _match_table_head->wildcards_table, p_match, priority );
  return (entry != NULL ? entry->data : NULL );
}


void *
lookup_match_entry( uint8_t table_id, match *p_match ) {
  flow_table *_match_table_head = NULL;

  _match_table_head = _get_flow_table( table_id );
  if ( _match_table_head == NULL ) {
    die( "match table is not initialized." );
  }

  match_entry *entry = lookup_wildcards_match_entry( _match_table_head->wildcards_table, p_match );
  return (entry != NULL ? entry->data : NULL );
}


list_element *
lookup_match_entries( uint8_t table_id, match *p_match ) {
  flow_table *_match_table_head = NULL;

  _match_table_head = _get_flow_table( table_id );
  if ( _match_table_head == NULL ) {
    die( "match table %d is not initialized.", table_id );
  }

  return lookup_wildcards_match_entries( _match_table_head->wildcards_table, p_match );
}


bool
update_match_entry( uint8_t table_id, match *p_match, uint16_t priority,
        void *data ) {
  flow_table *_match_table_head = NULL;

  _match_table_head = _get_flow_table( table_id );
  if ( _match_table_head == NULL ) {
    die( "match table is not initialized." );
  }

  return update_wildcards_match_entry( _match_table_head->wildcards_table, p_match, priority, data );
}


void *
delete_match_strict_entry( uint8_t table_id, match *p_match, uint16_t priority ) {
  flow_table *_match_table_head = NULL;

  _match_table_head = _get_flow_table( table_id );
  if ( _match_table_head == NULL ) {
    die( "match table is not initialized." );
  }

  return delete_wildcards_match_strict_entry( &_match_table_head->wildcards_table, p_match, priority );
}


static void
_map_match_table( uint8_t table_id, match *p_match, void
        function( match *p_match, uint16_t priority, void *data, void *user_data ),
        void *user_data ) {
  flow_table *_match_table_head = NULL;

  _match_table_head = _get_flow_table( table_id );
  if ( _match_table_head == NULL ) {
    die( "match table is not initialized." );
  }
  if ( function == NULL ) {
    die( "function must not be NULL" );
  }

  map_wildcards_match_table( _match_table_head->wildcards_table, p_match, function, user_data );
}


void
foreach_match_table( uint8_t table_id, void
        function( match *p_match, uint16_t, void *, void * ), void *user_data ) {
  _map_match_table( table_id, NULL, function, user_data );
}


void
map_match_table( uint8_t table_id, match *p_match, void
        function( match *p_match, uint16_t priority, void *data, void *user_data ),
        void *user_data ) {
  _map_match_table( table_id, p_match, function, user_data );
}


bool
compare_match_strict( const match *x, const match *y ) {
  return match_match_match( x, y );
}

/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
