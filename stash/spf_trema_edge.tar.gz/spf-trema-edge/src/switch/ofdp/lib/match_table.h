/*
 * OpenFlow flow matching library
 *
 * Author: Kazushi SUGYO
 *
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#ifndef MATCH_TABLE_H
#define MATCH_TABLE_H


#include "openflow.h"
#include "hash_table.h"
#include "linked_list.h"
#include "table_manager.h"
#include "packet_matcher.h"

typedef struct
{
  match *p_match; // match data. host byte order
  uint16_t priority;
  void *data;
} match_entry;

void init_match_table(  flow_table *  _match_table_head  );
void finalize_match_table(  flow_table *  _match_table_head  );
bool insert_match_entry( uint8_t table_id,  match * p_match, uint16_t priority, void *data );
void *lookup_match_strict_entry( uint8_t table_id,  match * p_match, uint16_t priority );
void *lookup_match_entry( uint8_t table_id,  match * p_match );
list_element *lookup_match_entries(uint8_t table_id, match * p_match);
bool update_match_entry( uint8_t table_id,  match * p_match, uint16_t priority, void *data );
void *delete_match_strict_entry( uint8_t table_id,  match * p_match, uint16_t priority );
void foreach_match_table( uint8_t table_id,  void function( match * p_match, uint16_t priority, void *data, void *user_data), void *user_data );
void map_match_table( uint8_t table_id,  match * p_match, void function( match * p_match, uint16_t priority, void *data, void *user_data), void *user_data );

bool compare_match_strict( const match * x, const match * y );

#endif // MATCH_TABLE_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
