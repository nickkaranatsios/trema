/*
 * Author: Yasunobu Chiba
 *
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * from trema library
 */


#include <assert.h>
#include "wrapper.h"
#include "packet_buffer_pool.h"
#include "message_queue_datapath.h"


message_queue *
create_message_queue_datapath( void ) {
  return create_message_queue();
}


bool
delete_message_queue_datapath( message_queue *queue ) {
  if ( queue == NULL ) {
    die( "queue must not be NULL" );
  }

  while ( queue->head != NULL ) {
    message_queue_element *element = queue->head;
    if ( queue->head->data != NULL ) {
      free_packet_buffer_pool_entry( element->data );
    }
    queue->head = queue->head->next;
    xfree( element );
  }
  xfree( queue );

  return true;
}


bool
enqueue_message_datapath( message_queue *queue, buffer *message ) {
  return enqueue_message( queue, message );
}


buffer *
dequeue_message_datapath( message_queue *queue ) {
  return dequeue_message( queue );
}


buffer *
peek_message_datapath( message_queue *queue ) {
  return peek_message( queue );
}


void
foreach_message_queue_datapath( message_queue *queue, void function( buffer *message, void *user_data ),     void *user_data ) {
  foreach_message_queue( queue, function, user_data );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
