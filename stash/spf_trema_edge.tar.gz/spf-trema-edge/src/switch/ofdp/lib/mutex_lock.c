/*
 * Functions for lock/unlock Mutex executer.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include "mutex_lock.h"


#define ERROR_STRING_SIZE 128


/**
 * initialize mutex object
 *
 * param mutex
 * return success/failed
 */
bool
init_mutex( pthread_mutex_t *mutex ) {
  int ret = pthread_mutex_init( mutex, NULL );

  if ( ret != 0 ) {
    char error_string[ ERROR_STRING_SIZE ];
    error( "cat not init mutex. ret = %d(%s)", ret, strerror_r( ret, error_string, sizeof( error_string ) ) );
    return false;
  }
  return true;
}


/**
 * finalize mutex object
 *
 * param mutex
 * return success/failed
 */
bool
finalize_mutex( pthread_mutex_t *mutex ) {
  int ret = pthread_mutex_destroy( mutex );

  if ( ret != 0 ) {
    char error_string[ ERROR_STRING_SIZE ];
    error( "cat not finalize mutex. ret = %d(%s)", ret, strerror_r( ret, error_string, sizeof( error_string ) ) );
    return false;
  }
  return true;
}


/**
 * get lock mutex
 *
 * param mutex
 * return can get/can't get
 */
bool
lock_mutex( pthread_mutex_t *mutex ) {
  int ret = pthread_mutex_lock( mutex );

  if ( ret != 0 ) {
    char error_string[ ERROR_STRING_SIZE ];
    error( "cat not lock mutex. ret = %d(%s)", ret, strerror_r( ret, error_string, sizeof( error_string ) ) );
    return false;
  }
  return true;
}


/**
 * release lock mutex
 *
 * param mutex
 * return can release/can't release
 */
bool
unlock_mutex( pthread_mutex_t *mutex ) {
  int ret = pthread_mutex_unlock( mutex );

  if ( ret != 0 ) {
    char error_string[ ERROR_STRING_SIZE ];
    error( "Can not unlock mutex. ret = %d(%s)", ret, strerror_r( ret, error_string, sizeof( error_string ) ) );
    return false;
  }
  return true;
}


/**
 * try and get lock mutex
 *
 * param mutex
 * return can get/can't get
 */
bool
try_lock( pthread_mutex_t *mutex ) {
  int ret = pthread_mutex_trylock( mutex );

  if ( ret != 0 ) {
    char error_string[ ERROR_STRING_SIZE ];
    error( "cat not try lock mutex. ret = %d(%s)", ret, strerror_r( ret, error_string, sizeof( error_string ) ) );
    return false;
  }
  return true;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
