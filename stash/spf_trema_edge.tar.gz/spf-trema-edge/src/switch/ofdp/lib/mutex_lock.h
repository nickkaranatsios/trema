/*
 * Functions for lock/unlock Mutex executer.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef MUTEX_LOCK_H
#define MUTEX_LOCK_H


#include <ofdp_common.h>


bool init_mutex( pthread_mutex_t *mutex );
bool finalize_mutex( pthread_mutex_t *mutex );
bool lock_mutex( pthread_mutex_t *mutex );
bool unlock_mutex( pthread_mutex_t *mutex );
bool try_lock( pthread_mutex_t *mutex );


#endif  // MUTEX_LOCK_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
