/*
 * Functions for Openflow datapath library main.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include <stdlib.h>
#include <inttypes.h>
#include <unistd.h>
#include <time.h>
#include "bool.h"
#include "thread-test.h"
#include "timer-test.h"
#include "ofdp.h"
#include "ofdp_common.h"
#include "daemon.h"
#include "packet_buffer_pool.h"
#include "port_manager.h"
#include "packet_forwarder.h"
#include "processing_engine.h"
#include "table_manager.h"
#include "action_executor.h"
#include "controller_manager.h"


typedef enum datapath_init_sequence {
  INIT_SEQUENCE_NO_INITIALIZE             = 0,
  INIT_SEQUENCE_PACKET_BUFFER_POOL        = ( 1 << 0 ),
  INIT_SEQUENCE_ACTION_EXECUTER           = ( 1 << 1 ),
  INIT_SEQUENCE_TABLE_MANAGER             = ( 1 << 2 ),
  INIT_SEQUENCE_PROCESSING_ENGINE         = ( 1 << 3 ),
  INIT_SEQUENCE_PACKET_FORWARDER          = ( 1 << 4 ),
  INIT_SEQUENCE_PORT_MANAGER              = ( 1 << 5 ),
  INIT_SEQUENCE_CONTROLLER_MANAGER        = ( 1 << 6 ),

  INIT_SEQUENCE_ALL = ( INIT_SEQUENCE_PACKET_BUFFER_POOL | INIT_SEQUENCE_ACTION_EXECUTER
    | INIT_SEQUENCE_TABLE_MANAGER | INIT_SEQUENCE_PROCESSING_ENGINE
    | INIT_SEQUENCE_PACKET_FORWARDER | INIT_SEQUENCE_PORT_MANAGER
    | INIT_SEQUENCE_CONTROLLER_MANAGER )
} datapath_init_sequence;


static datapath_init_sequence init_sequence = INIT_SEQUENCE_NO_INITIALIZE;
static library_status lib_status = NO_INITIALIZED;
static ofp_switch_config switch_config;
static ofp_switch_features switch_features;


const uint16_t MISS_SEND_LEN = 1500;
static const time_t INTERVAL_SECONDS = 1;


static OFDPE
finalize_datapath_execute( void ) {
  OFDPE ret = OFDPE_SUCCESS;

  if ( ( init_sequence & INIT_SEQUENCE_CONTROLLER_MANAGER ) == INIT_SEQUENCE_CONTROLLER_MANAGER ) {
    ret = finalize_controller_manager( );
    if ( ret != OFDPE_SUCCESS ) {
      error( "finalize_controller_manager failed." );
      return ret;
    }
  }

  if ( ( init_sequence & INIT_SEQUENCE_PORT_MANAGER ) == INIT_SEQUENCE_PORT_MANAGER ) {
    ret = finalize_port_manager( );
    if ( ret != OFDPE_SUCCESS ) {
      error( "finalize_port_manager failed." );
      return ret;
    }
  }

  if ( ( init_sequence & INIT_SEQUENCE_PACKET_FORWARDER ) == INIT_SEQUENCE_PACKET_FORWARDER ) {
    ret = finalize_packet_forwarder( );
    if ( ret != OFDPE_SUCCESS ) {
      error( "finalize_packet_forwarder failed." );
      return ret;
    }
  }

  if ( ( init_sequence & INIT_SEQUENCE_PROCESSING_ENGINE ) == INIT_SEQUENCE_PROCESSING_ENGINE ) {
    ret = finalize_processing_engine( );
    if ( ret != OFDPE_SUCCESS ) {
      error( "finalize_processing_engine failed." );
      return ret;
    }
  }

  if ( ( init_sequence & INIT_SEQUENCE_TABLE_MANAGER ) == INIT_SEQUENCE_TABLE_MANAGER ) {
    ret = finalize_table_manager( );
    if ( ret != OFDPE_SUCCESS ) {
      error( "finalize_table_manager failed." );
      return ret;
    }
  }

  if ( ( init_sequence & INIT_SEQUENCE_ACTION_EXECUTER ) == INIT_SEQUENCE_ACTION_EXECUTER ) {
    ret = finalize_action_executor( );
    if ( ret != OFDPE_SUCCESS ) {
      error( "finalize_action_executor failed." );
      return ret;
    }
  }

  if ( ( init_sequence & INIT_SEQUENCE_PACKET_BUFFER_POOL ) == INIT_SEQUENCE_PACKET_BUFFER_POOL ) {
    ret = finalize_packet_buffer_pool( );
    if ( ret != OFDPE_SUCCESS ) {
      error( "finalize_packet_buffer_pool failed." );
      return ret;
    }
  }

  init_sequence = INIT_SEQUENCE_NO_INITIALIZE;

  return ret;
}


/**
 * set library argument parameters
 *
 * param setting structure pointer
 * param setting params
 * return noting
 */
void
set_ofdp_library_argument( ofdp_library_argument *lib_arg, const char *program_name, const char *log_level,
        list_element *devices_info, bool is_daemon, size_t switch_mtu, uint32_t num_pool, uint32_t num_controller_buffer,
        uint32_t select_timeout_usec, size_t max_send_queue, size_t max_recv_queue, uint64_t datapath_id ) {
  memset( lib_arg, 0, sizeof( ofdp_library_argument ) );
  lib_arg->program_name = program_name;
  lib_arg->loglevel = log_level;
  lib_arg->devices_info = devices_info;
  lib_arg->is_daemon = is_daemon;
  lib_arg->switch_mtu = switch_mtu;
  lib_arg->num_pool = num_pool;
  lib_arg->num_controller_buffer = num_controller_buffer;
  lib_arg->select_timeout_usec = select_timeout_usec;
  lib_arg->max_send_queue = max_send_queue;
  lib_arg->max_recv_queue = max_recv_queue;
  lib_arg->datapath_id = datapath_id;

  return;
}


static void
maybe_daemonize( bool is_daemon ) {
  if ( is_daemon ) {
    daemonize( "." );
  }
}


/**
 * initialize openflow datapath library
 *
 * param library argument
 * return success/failed
 */
OFDPE
init_datapath( const ofdp_library_argument *arg ) {
  if ( arg == NULL ) {
    error( "Illegal parameter error.(arg=%x)", arg );
    return ERROR_ILLEGAL_PARAMETER;
  }

  maybe_daemonize( arg->is_daemon );

  init_sequence = INIT_SEQUENCE_NO_INITIALIZE;

  size_t switch_mtu = get_switch_mtu( arg->devices_info );
  if ( switch_mtu < arg->switch_mtu ) {
    switch_mtu = arg->switch_mtu;
  }

  OFDPE ret = OFDPE_SUCCESS;

  ret = init_packet_buffer_pool( arg->num_pool, switch_mtu );
  if ( ret != OFDPE_SUCCESS ) {
    error( "init_packet_buffer_pool failed." );
    finalize_datapath_execute( );
    return ret;
  }
  init_sequence |= INIT_SEQUENCE_PACKET_BUFFER_POOL;

  ret = init_action_executor( );
  if ( ret != OFDPE_SUCCESS ) {
    error( "init_action_executor failed." );
    finalize_datapath_execute( );
    return ret;
  }
  init_sequence |= INIT_SEQUENCE_ACTION_EXECUTER;

  ret = init_table_manager( );
  if ( ret != OFDPE_SUCCESS ) {
    error( "init_table_manager failed." );
    finalize_datapath_execute( );
    return ret;
  }
  init_sequence |= INIT_SEQUENCE_TABLE_MANAGER;

  ret = init_processing_engine( );
  if ( ret != OFDPE_SUCCESS ) {
    error( "init_processing_engine failed." );
    finalize_datapath_execute( );
    return ret;
  }
  init_sequence |= INIT_SEQUENCE_PROCESSING_ENGINE;

  ret = init_packet_forwarder( );
  if ( ret != OFDPE_SUCCESS ) {
    error( "init_packet_forwarder failed." );
    finalize_datapath_execute( );
    return ret;
  }
  init_sequence |= INIT_SEQUENCE_PACKET_FORWARDER;

  ret = init_port_manager( arg->select_timeout_usec, arg->max_send_queue, arg->max_recv_queue );
  if ( ret != OFDPE_SUCCESS ) {
    error( "init_port_manager failed." );
    finalize_datapath_execute( );
    return ret;
  }
  init_sequence |= INIT_SEQUENCE_PORT_MANAGER;

  ret = init_controller_manager( arg->num_controller_buffer );
  if ( ret != OFDPE_SUCCESS ) {
    error( "init_controller_manager failed." );
    finalize_datapath_execute( );
    return ret;
  }
  init_sequence |= INIT_SEQUENCE_CONTROLLER_MANAGER;

  assert( init_sequence == INIT_SEQUENCE_ALL );

  memset( &switch_features, 0, sizeof( ofp_switch_features ) );
  switch_features.datapath_id = arg->datapath_id;
  switch_features.n_buffers = arg->num_pool;
  switch_features.n_tables = MAX_FLOW_TABLE;
  switch_features.auxiliary_id = 0;
  switch_features.capabilities = OFPC_FLOW_STATS | OFPC_TABLE_STATS | OFPC_PORT_STATS | OFPC_GROUP_STATS;

  memset( &switch_config, 0, sizeof( ofp_switch_config ) );
  switch_config.miss_send_len = MISS_SEND_LEN;
  switch_config.flags = OFPC_FRAG_NORMAL;

  lib_status = INITIALIZED;

  return ret;
}


/**
 * finalize openflow datapath library
 *
 * param noting
 * return success/failed
 */
OFDPE
finalize_datapath( void ) {
  if ( init_sequence != INIT_SEQUENCE_ALL ) {
    error( "no initialized." );
    return OFDPE_FAILED;
  }

  OFDPE ret = finalize_datapath_execute();
  if ( ret == OFDPE_SUCCESS ) {
    lib_status = FINALIZED;
  }

  return ret;
}


static void
check_flow_entry_removal( void *user_data ) {
  UNUSED( user_data );

  if ( !lock_pipeline() ) {
    warn( "lock_pipeline() execute error." );
    return;
  }

  for ( uint8_t table_id = 0; table_id < MAX_FLOW_TABLE; table_id++ ) {
    remove_timeout_flow_entry( table_id );
  }

  if ( !unlock_pipeline() ) {
    warn( "unlock_pipeline() execute error." );
  }

  return;
}


static void
calc_curr_speed( void *user_data ) {
  UNUSED( user_data );

  calc_bitrate_all_device();

  return;
}


/**
 * start openflow datapath process
 *
 * param noting
 * return success/failed
 */
OFDPE
start_datapath( void ) {
  if ( init_sequence != INIT_SEQUENCE_ALL ) {
    error( "no initialized." );
    return OFDPE_FAILED;
  }

  new_set_external_callback( execute_external_message );
  new_add_periodic_event_callback( INTERVAL_SECONDS, check_flow_entry_removal, NULL );
  new_add_periodic_event_callback( INTERVAL_SECONDS, calc_curr_speed, NULL );
  lib_status = STARTED;

  return OFDPE_SUCCESS;
}


/**
 * stop openflow datapath process
 *
 * param noting
 * return success/failed
 */
OFDPE
stop_datapath( void ) {
  if ( init_sequence != INIT_SEQUENCE_ALL ) {
    return OFDPE_FAILED;
  }

  new_delete_timer_event( calc_curr_speed, NULL );
  new_delete_timer_event( check_flow_entry_removal, NULL );
  new_set_external_callback( NULL );

  lib_status = STOPED;

  return OFDPE_SUCCESS;
}


/**
 * get openflow switch feature
 *
 * param get switch features
 * return success/failed
 */
OFDPE
get_switch_features( ofp_switch_features *features ) {
  if ( features == NULL ) {
    return OFDPE_FAILED;
  }
  if ( init_sequence != INIT_SEQUENCE_ALL ) {
    return OFDPE_FAILED;
  }
  lock_pipeline();
  memcpy( features, &switch_features, sizeof( ofp_switch_features ) );
  unlock_pipeline();
  return OFDPE_SUCCESS;
}


/**
 * dump openflow switch feature
 *
 * param dump switch features
 * return noting
 */
void
dump_switch_features( const ofp_switch_features *features ) {
  if ( features == NULL ) {
    return;
  }
  debug( "***** switch feature *****" );
  debug( "datapath_id = %u", features->datapath_id );
  debug( "n_buffers = %u", features->n_buffers );
  debug( "n_tables = %u", features->n_tables );
  debug( "auxiliary_id = %u", features->auxiliary_id );
  debug( "capabilities = 0x%x", features->capabilities );
  debug( "reserved = %u", features->reserved );
  return;
}


/**
 * get openflow switch config
 *
 * param get switch config
 * return success/failed
 */
OFDPE
get_switch_config( ofp_switch_config *config ) {
  if ( config == NULL ) {
    return OFDPE_FAILED;
  }
  if ( init_sequence != INIT_SEQUENCE_ALL ) {
    return OFDPE_FAILED;
  }
  lock_pipeline();
  memcpy( config, &switch_config, sizeof( ofp_switch_config ) );
  unlock_pipeline();
  return OFDPE_SUCCESS;
}


/**
 * set openflow switch config
 *
 * param get switch config
 * return success/failed
 */
OFDPE
set_switch_config( ofp_switch_config *config ) {
  if ( config == NULL ) {
    return OFDPE_FAILED;
  }
  if ( init_sequence != INIT_SEQUENCE_ALL ) {
    return OFDPE_FAILED;
  }
  lock_pipeline();
  memcpy( &switch_config, config, sizeof( ofp_switch_config ) );
  unlock_pipeline();
  return OFDPE_SUCCESS;
}


/**
 * dump openflow switch config
 *
 * param dump switch config
 * return nothing
 */
void
dump_switch_config( const ofp_switch_config *config ) {
  if ( config == NULL ) {
    return;
  }
  debug( "***** switch config *****" );
  debug( "flags = 0x%x", config->flags );
  debug( "miss_send_len = %u", config->miss_send_len );
  return;
}


static library_status
_get_library_status() {
  return lib_status;
}
library_status (*get_library_status)() = _get_library_status;


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
