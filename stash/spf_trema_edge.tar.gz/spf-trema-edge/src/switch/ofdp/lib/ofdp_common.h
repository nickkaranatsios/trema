/*
 * Functions for Openflow datapath library common.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef OFDP_COMMON_H
#define OFDP_COMMON_H


#include <assert.h>
#include <time.h>
#include <pthread.h>
#include <limits.h>
#include <errno.h>
#include <string.h>
//#include <stdlib.h>
#include "ofdp_error.h"
#include "bool.h"
#include "log.h"


#define MAX_FLOW_TABLE 0xff


void time_now( struct timespec *tp );
void timespec_diff( struct timespec start, struct timespec end, struct timespec *diff );


#endif  // OFDP_COMMON_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
