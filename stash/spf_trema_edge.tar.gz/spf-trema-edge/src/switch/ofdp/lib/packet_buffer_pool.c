/*
 * Functions for managing buffer structure memory pool.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include "ofdp_common.h"
#include "message_queue.h"
#include "packet_buffer_pool.h"
#include "wrapper.h"
#include "buffer.h"
#include "linked_list.h"
#include "mutex_lock.h"


static list_element *free_buffer_list = NULL;
static size_t buffer_pool_size = 0;
static size_t allocate_byte = 0;
static pthread_mutex_t mutex_packet_buffer_pool;


/**
 * get packet buffer pool free count
 *
 * param nothing
 * return free pool count
 */
uint32_t
get_free_list_count( void ) {
  return list_length_of( free_buffer_list );
}


/**
 * initialize packet buffer pool manager
 *
 * param number of pool
 * param allocate buffer byte per pool
 * return success/failed
 */
OFDPE
init_packet_buffer_pool( const size_t pool_size, const size_t alloc_byte ) {
  if ( ( pool_size == 0 ) || ( alloc_byte == 0 ) ) {
    error( "illegal parameter error.(pool_size=%u, alloc_byte=%u)", pool_size, alloc_byte );
    return ERROR_ILLEGAL_PARAMETER;
  }

  if ( !init_mutex( &mutex_packet_buffer_pool ) ) {
    warn( "init_mutex() execute error." );
    return ERROR_INIT_MUTEX;
  }

  buffer_pool_size = pool_size;
  allocate_byte = alloc_byte;

  for ( size_t i = 0; i < buffer_pool_size; i++ ) {
    buffer *buf = alloc_buffer_with_length( allocate_byte );
    if ( buf == NULL ) {
      error( "buffer allocate error" );

      for ( list_element *p = free_buffer_list; p != NULL; p = p->next ) {
        if ( p->data != NULL ) {
          free_buffer( p->data );
        }
      }
      delete_list( free_buffer_list );

      return ERROR_NO_MEMORY;
    }
    append_to_tail( &free_buffer_list, buf );
  }

  return OFDPE_SUCCESS;
}


/**
 * finalize packet buffer pool manager
 *
 * param nothing
 * return success/failed
 */
OFDPE
finalize_packet_buffer_pool( void ) {
  for ( list_element *p = free_buffer_list; p != NULL; p = p->next ) {
    if ( p->data != NULL ) {
      free_buffer( p->data );
    }
  }
  delete_list( free_buffer_list );
  buffer_pool_size = 0;
  allocate_byte = 0;
  free_buffer_list = NULL;

  if ( !finalize_mutex( &mutex_packet_buffer_pool ) ) {
    warn( "finalize_mutex() execute error." );
    return ERROR_FINALIZE_MUTEX;
  }

  return OFDPE_SUCCESS;
}


/**
 * allocate buffer (length=0)
 *
 * param nothing
 * return allocated buffer memory
 */
buffer *
allocate_packet_buffer( void ) {
  if ( free_buffer_list == NULL ) {
    error( "Memory allocation error" );
    return NULL;
  }

  if ( !lock_mutex( &mutex_packet_buffer_pool ) ) {
    warn( "lock_target() execute error." );
    return NULL;
  }

  list_element *p = free_buffer_list;
  buffer *buf = p->data;
  free_buffer_list = p->next;
  xfree( p );

  debug( "allocate_packet_buffer() free_buffer_list=%u, 0x%x", get_free_list_count(), buf );

  if ( !unlock_mutex( &mutex_packet_buffer_pool ) ) {
    warn( "unlock_target() execute error." );
    return NULL;
  }

  buf->length = 0;

  return buf;
}


/**
 * allocate buffer (length=size)
 *
 * param allocate buffer size
 * return allocated buffer memory
 */
buffer *
allocate_packet_buffer_pool_entry( const size_t size ) {
  if ( ( size == 0 ) || ( size > allocate_byte ) ) {
    error( "illegal parameter error.(size=%u)", size );
    return NULL;
  }

  buffer *buf = allocate_packet_buffer();
  if ( buf == NULL ) {
    error( "Memory allocation error" );
    return NULL;
  }
  buf->length = size;

  return buf;
}


/**
 * duplicate buffer memory
 *
 * param src buffer
 * return duplicate buffer
 */
buffer *
duplicate_packet_buffer_pool_entry( const buffer *src ) {
  if ( src == NULL ) {
    error( "illegal parameter error.(src=%x)", src );
    return NULL;
  }

  buffer *dst = allocate_packet_buffer_pool_entry( src->length );
  if ( dst == NULL ) {
    return NULL;
  }

  memcpy( dst->data, src->data, src->length );

  return dst;
}


/**
 * appending back buffer 
 *
 * param src buffer
 * param append length
 * return appended buffer memory
 */
void *
append_back_buffer_pool_entry( buffer *buf, size_t length ) {
  if ( ( buf == NULL ) || ( ( buf->length + length ) > allocate_byte ) ) {
    error( "illegal parameter error.(buf=%x, length=%u)", buf, length );
    return NULL;
  }

  return append_back_buffer( buf, length );
}


/**
 * remove front buffer 
 *
 * param src buffer
 * param remove length
 * return removed buffer memory
 */
void *
remove_front_buffer_pool_entry( buffer *buf, size_t length ) {
  return remove_front_buffer( buf, length );
}


/**
 * free buffer memory
 *
 * param target buffer
 * return success/failed
 */
OFDPE
free_packet_buffer_pool_entry( buffer *buf ) {
  if ( buf == NULL ) {
    error( "illegal parameter error.(buf=%x)", buf );
    return ERROR_ILLEGAL_PARAMETER;
  }

  if ( !lock_mutex( &mutex_packet_buffer_pool ) ) {
    warn( "lock_target() execute error." );
    return ERROR_LOCK;
  }

  insert_in_front( &free_buffer_list, buf );

  debug( "free_packet_buffer_pool_entry() free_buffer_list=%u, 0x%x", get_free_list_count(), buf );

  if ( !unlock_mutex( &mutex_packet_buffer_pool ) ) {
    warn( "unlock_target() execute error." );
    return ERROR_UNLOCK;
  }

  return OFDPE_SUCCESS;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
