/*
 * Functions for managing buffer structure memory pool.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef PACKET_BUFFER_POOL_H
#define PACKET_BUFFER_POOL_H


#include "ofdp_error.h"
#include "buffer.h"


// List of public library function
OFDPE init_packet_buffer_pool( const size_t pool_size, const size_t alloc_byte );
OFDPE finalize_packet_buffer_pool( void );
buffer *allocate_packet_buffer( void );
buffer *allocate_packet_buffer_pool_entry( const size_t size );
buffer *duplicate_packet_buffer_pool_entry( const buffer *src );
void *append_back_buffer_pool_entry( buffer *buf, size_t length );
void *remove_front_buffer_pool_entry( buffer *buf, size_t length );
OFDPE free_packet_buffer_pool_entry( buffer *buffer );


#endif  // PACKET_BUFFER_POOL_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
