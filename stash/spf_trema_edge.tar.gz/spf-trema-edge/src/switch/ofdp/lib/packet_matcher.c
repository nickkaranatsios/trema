/*
 * Functions for maching packet to flow entry.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include "packet_matcher_private.h"
#include "table_manager_match.h"


bool
match_packet_8_to_match( const uint8_t x, const match8 y ) {
  // step 1
  if ( y.valid == false ) {
    return true;
  }
  // step 2
  // y.valid = true
  if ( x == NULL_VALUE8 ) {
    return false;
  }
  // step 3
  if ( ( x & y.mask ) == ( y.value & y.mask ) ) {
    return true;
  }
  return false;
}


bool
match_packet_16_to_match( const uint16_t x, const match16 y ) {
  // step 1
  if ( y.valid == false ) {
    return true;
  }
  // step 2
  // y.valid = true
  if ( x == NULL_VALUE16 ) {
    return false;
  }
  // step 3
  if ( ( x & y.mask ) == ( y.value & y.mask ) ) {
    return true;
  }
  return false;
}


bool
match_packet_32_to_match( const uint32_t x, const match32 y ) {
  // step 1
  if ( y.valid == false ) {
    return true;
  }
  // step 2
  // y.valid = true
  if ( x == NULL_VALUE32 ) {
    return false;
  }
  // step 3
  if ( ( x & y.mask ) == ( y.value & y.mask ) ) {
    return true;
  }
  return false;
}


bool
match_packet_64_to_match( const uint64_t x, const match64 y ) {
  if ( y.valid == false ) {
    return true;
  }
  // step 2
  // y.valid = true
  if ( x == NULL_VALUE64 ) {
    return false;
  }
  // step 3
  if ( ( x & y.mask ) == ( y.value & y.mask ) ) {
    return true;
  }
  return false;
}


bool
match_match_8_to_match( const match8 x, const match8 y ) {
  // step 1
  if ( ( x.valid == true ) & ( y.valid == false ) ) {
    return true;
  }
  if ( ( x.valid == false ) & ( y.valid == false ) ) {
    return true;
  }
  if ( ( x.valid == false ) & ( y.valid == true ) ) {
    return false;
  }
  // step 2
  // x.valid = true, y.valid = true
  if ( ( ( x.mask & y.mask ) == y.mask )
    & ( ( x.value & y.mask ) == ( y.value & y.mask ) ) ) {
    return true;
  }
  return false;
}


bool
match_match_16_to_match( const match16 x, const match16 y ) {
  // step 1
  if ( ( x.valid == true ) & ( y.valid == false ) ) {
    return true;
  }
  if ( ( x.valid == false ) & ( y.valid == false ) ) {
    return true;
  }
  if ( ( x.valid == false ) & ( y.valid == true ) ) {
    return false;
  }
  // step 2
  // x.valid = true, y.valid = true
  if ( ( ( x.mask & y.mask ) == y.mask )
    & ( ( x.value & y.mask ) == ( y.value & y.mask ) ) ) {
    return true;
  }
  return false;
}


bool
match_match_32_to_match( const match32 x, const match32 y ) {
  // step 1
  if ( ( x.valid == true ) & ( y.valid == false ) ) {
    return true;
  }
  if ( ( x.valid == false ) & ( y.valid == false ) ) {
    return true;
  }
  if ( ( x.valid == false ) & ( y.valid == true ) ) {
    return false;
  }
  // step 2
  // x.valid = true, y.valid = true
  if ( ( ( x.mask & y.mask ) == y.mask )
    & ( ( x.value & y.mask ) == ( y.value & y.mask ) ) ) {
    return true;
  }
  return false;
}


bool
match_match_64_to_match( const match64 x, const match64 y ) {
  // step 1
  if ( ( x.valid == true ) & ( y.valid == false ) ) {
    return true;
  }
  if ( ( x.valid == false ) & ( y.valid == false ) ) {
    return true;
  }
  if ( ( x.valid == false ) & ( y.valid == true ) ) {
    return false;
  }
  // step 2
  // x.valid = true, y.valid = true
  if ( ( ( x.mask & y.mask ) == y.mask )
    & ( ( x.value & y.mask ) == ( y.value & y.mask ) ) ) {
    return true;
  }
  return false;
}


bool
compare_match_8_to_match( const match8 x, const match8 y ) {
  // step 1
  if ( ( x.valid == true ) & ( y.valid == false ) ) {
    return false;
  }
  if ( ( x.valid == false ) & ( y.valid == false ) ) {
    return true;
  }
  if ( ( x.valid == false ) & ( y.valid == true ) ) {
    return false;
  }
  // step 2
  // x.valid = true, y.valid = true
  if ( ( x.mask == y.mask ) & ( ( x.value & x.mask ) == ( y.value & y.mask ) ) ) {
    return true;
  }
  return false;
}


bool
compare_match_16_to_match( const match16 x, const match16 y ) {
  // step 1
  if ( ( x.valid == true ) & ( y.valid == false ) ) {
    return false;
  }
  if ( ( x.valid == false ) & ( y.valid == false ) ) {
    return true;
  }
  if ( ( x.valid == false ) & ( y.valid == true ) ) {
    return false;
  }
  // step 2
  // x.valid = true, y.valid = true
  if ( ( x.mask == y.mask ) & ( ( x.value & x.mask ) == ( y.value & y.mask ) ) ) {
    return true;
  }
  return false;
}


bool
compare_match_32_to_match( const match32 x, const match32 y ) {
  // step 1
  if ( ( x.valid == true ) & ( y.valid == false ) ) {
    return false;
  }
  if ( ( x.valid == false ) & ( y.valid == false ) ) {
    return true;
  }
  if ( ( x.valid == false ) & ( y.valid == true ) ) {
    return false;
  }
  // step 2
  // x.valid = true, y.valid = true
  if ( ( x.mask == y.mask ) & ( ( x.value & x.mask ) == ( y.value & y.mask ) ) ) {
    return true;
  }
  return false;
}


bool
compare_match_64_to_match( const match64 x, const match64 y ) {
  // step 1
  if ( ( x.valid == true ) & ( y.valid == false ) ) {
    return false;
  }
  if ( ( x.valid == false ) & ( y.valid == false ) ) {
    return true;
  }
  if ( ( x.valid == false ) & ( y.valid == true ) ) {
    return false;
  }
  // step 2
  // x.valid = true, y.valid = true
  if ( ( x.mask == y.mask ) & ( ( x.value & x.mask ) == ( y.value & y.mask ) ) ) {
    return true;
  }
  return false;
}


void
match_builder( match *p_match, const packet_info *packet ) {
  assert( packet != NULL );
  assert( p_match != NULL );

  p_match->arp_op.value = packet->arp_ar_op;
  p_match->arp_op.mask = NULL_VALUE16;
  p_match->arp_op.valid = true;
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    p_match->arp_sha[ i ].value = packet->arp_sha[ i ];
    p_match->arp_sha[ i ].mask = NULL_VALUE8;
    p_match->arp_sha[ i ].valid = true;
  }
  p_match->arp_spa.value = packet->arp_spa;
  p_match->arp_spa.mask = NULL_VALUE32;
  p_match->arp_spa.valid = true;
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    p_match->arp_tha[ i ].value = packet->arp_tha[ i ];
    p_match->arp_tha[ i ].mask = NULL_VALUE8;
    p_match->arp_tha[ i ].valid = true;
  }
  p_match->arp_tpa.value = packet->arp_tpa;
  p_match->arp_tpa.mask = NULL_VALUE32;
  p_match->arp_tpa.valid = true;
  p_match->in_phy_port.value = packet->eth_in_phy_port;
  p_match->in_phy_port.mask = NULL_VALUE32;
  p_match->in_phy_port.valid = true;
  p_match->in_port.value = packet->eth_in_port;
  p_match->in_port.mask = NULL_VALUE32;
  p_match->in_port.valid = true;
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    p_match->eth_dst[ i ].value = packet->eth_macda[ i ];
    p_match->eth_dst[ i ].mask = NULL_VALUE8;
    p_match->eth_dst[ i ].valid = true;
  }
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    p_match->eth_src[ i ].value = packet->eth_macsa[ i ];
    p_match->eth_src[ i ].mask = NULL_VALUE8;
    p_match->eth_src[ i ].valid = true;
  }
  p_match->eth_type.value = packet->eth_type;
  p_match->eth_type.mask = NULL_VALUE16;
  p_match->eth_type.valid = true;
  p_match->icmpv4_code.value = packet->icmpv4_code;
  p_match->icmpv4_code.mask = NULL_VALUE8;
  p_match->icmpv4_code.valid = true;
  p_match->icmpv4_type.value = packet->icmpv4_type;
  p_match->icmpv4_type.mask = NULL_VALUE8;
  p_match->icmpv4_type.valid = true;
  p_match->icmpv6_code.value = packet->icmpv6_code;
  p_match->icmpv6_code.mask = NULL_VALUE8;
  p_match->icmpv6_code.valid = true;
  p_match->icmpv6_type.value = packet->icmpv6_type;
  p_match->icmpv6_type.mask = NULL_VALUE8;
  p_match->icmpv6_type.valid = true;
  p_match->ip_dscp.value = packet->ip_dscp;
  p_match->ip_dscp.mask = NULL_VALUE8;
  p_match->ip_dscp.valid = true;
  p_match->ip_ecn.value = packet->ip_ecn;
  p_match->ip_ecn.mask = NULL_VALUE8;
  p_match->ip_ecn.valid = true;
  p_match->ip_proto.value = packet->ip_proto;
  p_match->ip_proto.mask = NULL_VALUE8;
  p_match->ip_proto.valid = true;
  p_match->ipv4_dst.value = packet->ipv4_daddr;
  p_match->ipv4_dst.mask = NULL_VALUE32;
  p_match->ipv4_dst.valid = true;
  p_match->ipv4_src.value = packet->ipv4_saddr;
  p_match->ipv4_src.mask = NULL_VALUE32;
  p_match->ipv4_src.valid = true;
  for ( int i = 0; i < IPV6_ADDRLEN; i++ ) {
    p_match->ipv6_dst[ i ].value = packet->ipv6_daddr.s6_addr[ i ];
    p_match->ipv6_dst[ i ].mask = NULL_VALUE8;
    p_match->ipv6_dst[ i ].valid = true;
  }
  p_match->ipv6_exthdr.value = packet->ipv6_exthdr;
  p_match->ipv6_exthdr.mask = NULL_VALUE16;
  p_match->ipv6_exthdr.valid = true;
  p_match->ipv6_flabel.value = packet->ipv6_flowlabel;
  p_match->ipv6_flabel.mask = NULL_VALUE32;
  p_match->ipv6_flabel.valid = true;
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    p_match->ipv6_nd_sll[ i ].value = packet->icmpv6_nd_sll[ i ];
    p_match->ipv6_nd_sll[ i ].mask = NULL_VALUE8;
    p_match->ipv6_nd_sll[ i ].valid = true;
  }
  for ( int i = 0; i < IPV6_ADDRLEN; i++ ) {
    p_match->ipv6_nd_target[ i ].value = packet->icmpv6_nd_target.s6_addr[ i ];
    p_match->ipv6_nd_target[ i ].mask = NULL_VALUE8;
    p_match->ipv6_nd_target[ i ].valid = true;
  }
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    p_match->ipv6_nd_tll[ i ].value = packet->icmpv6_nd_tll[ i ];
    p_match->ipv6_nd_tll[ i ].mask = NULL_VALUE8;
    p_match->ipv6_nd_tll[ i ].valid = true;
  }
  for ( int i = 0; i < IPV6_ADDRLEN; i++ ) {
    p_match->ipv6_src[ i ].value = packet->ipv6_saddr.s6_addr[ i ];
    p_match->ipv6_src[ i ].mask = NULL_VALUE8;
    p_match->ipv6_src[ i ].valid = true;
  }
  p_match->metadata.value = packet->metadata;
  p_match->metadata.mask = NULL_VALUE64;
  p_match->metadata.valid = true;
  p_match->mpls_bos.value = packet->mpls_bos;
  p_match->mpls_bos.mask = NULL_VALUE8;
  p_match->mpls_bos.valid = true;
  p_match->mpls_label.value = packet->mpls_label;
  p_match->mpls_label.mask = NULL_VALUE32;
  p_match->mpls_label.valid = true;
  p_match->mpls_tc.value = packet->mpls_tc;
  p_match->mpls_tc.mask = NULL_VALUE8;
  p_match->mpls_tc.valid = true;
  p_match->sctp_dst.value = packet->sctp_dst_port;
  p_match->sctp_dst.mask = NULL_VALUE16;
  p_match->sctp_dst.valid = true;
  p_match->sctp_src.value = packet->sctp_src_port;
  p_match->sctp_src.mask = NULL_VALUE16;
  p_match->sctp_src.valid = true;
  p_match->tcp_dst.value = packet->tcp_dst_port;
  p_match->tcp_dst.mask = NULL_VALUE16;
  p_match->tcp_dst.valid = true;
  p_match->tcp_src.value = packet->tcp_src_port;
  p_match->tcp_src.mask = NULL_VALUE16;
  p_match->tcp_src.valid = true;
  p_match->tunnel_id.value = packet->tunnel_id;
  p_match->tunnel_id.mask = NULL_VALUE64;
  p_match->tunnel_id.valid = true;
  p_match->udp_dst.value = packet->udp_dst_port;
  p_match->udp_dst.mask = NULL_VALUE16;
  p_match->udp_dst.valid = true;
  p_match->udp_src.value = packet->udp_src_port;
  p_match->udp_src.mask = NULL_VALUE16;
  p_match->udp_src.valid = true;
  p_match->vlan_pcp.value = packet->vlan_pcp;
  p_match->vlan_pcp.mask = NULL_VALUE8;
  p_match->vlan_pcp.valid = true;
  p_match->vlan_vid.value = packet->vlan_vid;
  p_match->vlan_vid.mask = NULL_VALUE16;
  p_match->vlan_vid.valid = true;
}


bool
match_packet2match_match( const match *packet, match *p_match ) {
  assert( packet != NULL );
  assert( p_match != NULL );

  if ( match_packet_16_to_match( packet->arp_op.value, p_match->arp_op ) == false ) {
    return false;
  }
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    p_match->arp_sha[ i ].valid = p_match->arp_sha[ 0 ].valid;
    if ( match_packet_8_to_match( packet->arp_sha[ i ].value,
        p_match->arp_sha[ i ] ) == false ) {
      return false;
    }
  }
  if ( match_packet_32_to_match( packet->arp_spa.value, p_match->arp_spa ) == false ) {
    return false;
  }
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    p_match->arp_tha[ i ].valid = p_match->arp_tha[ 0 ].valid;
    if ( match_packet_8_to_match( packet->arp_tha[ i ].value,
        p_match->arp_tha[ i ] ) == false ) {
      return false;
    }
  }
  if ( match_packet_32_to_match( packet->arp_spa.value, p_match->arp_spa ) == false ) {
    return false;
  }

  if ( match_packet_32_to_match( packet->arp_tpa.value, p_match->arp_tpa ) == false ) {
    return false;
  }
  if ( match_packet_32_to_match( packet->in_phy_port.value,
      p_match->in_phy_port ) == false ) {
    return false;
  }
  if ( match_packet_32_to_match( packet->in_port.value, p_match->in_port ) == false ) {
    return false;
  }

  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    p_match->eth_dst[ i ].valid = p_match->eth_dst[ 0 ].valid;
    if ( match_packet_8_to_match( packet->eth_dst[ i ].value,
        p_match->eth_dst[ i ] ) == false ) {
      return false;
    }
  }
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    p_match->eth_src[ i ].valid = p_match->eth_src[ 0 ].valid;
    if ( match_packet_8_to_match( packet->eth_src[ i ].value,
        p_match->eth_src[ i ] ) == false ) {
      return false;
    }
  }

  if ( match_packet_16_to_match( packet->eth_type.value, p_match->eth_type ) == false ) {
    return false;
  }
  if ( match_packet_8_to_match( packet->icmpv4_code.value,
      p_match->icmpv4_code ) == false ) {
    return false;
  }
  if ( match_packet_8_to_match( packet->icmpv4_type.value,
      p_match->icmpv4_type ) == false ) {
    return false;
  }
  if ( match_packet_8_to_match( packet->icmpv6_code.value,
      p_match->icmpv6_code ) == false ) {
    return false;
  }
  if ( match_packet_8_to_match( packet->icmpv6_type.value,
      p_match->icmpv6_type ) == false ) {
    return false;
  }
  if ( match_packet_8_to_match( packet->ip_dscp.value, p_match->ip_dscp ) == false ) {
    return false;
  }
  if ( match_packet_8_to_match( packet->ip_ecn.value, p_match->ip_ecn ) == false ) {
    return false;
  }
  if ( match_packet_8_to_match( packet->ip_proto.value, p_match->ip_proto ) == false ) {
    return false;
  }
  if ( match_packet_32_to_match( packet->ipv4_dst.value, p_match->ipv4_dst ) == false ) {
    return false;
  }
  if ( match_packet_32_to_match( packet->ipv4_src.value, p_match->ipv4_src ) == false ) {
    return false;
  }

  for ( int i = 0; i < IPV6_ADDRLEN; i++ ) {
    p_match->ipv6_dst[ i ].valid = p_match->ipv6_dst[ 0 ].valid;
    if ( match_packet_8_to_match( packet->ipv6_dst[ i ].value,
        p_match->ipv6_dst[ i ] ) == false ) {
      return false;
    }
  }
  // printf ("ipv6_daddr match: true\n");
  if ( match_packet_16_to_match( packet->ipv6_exthdr.value,
      p_match->ipv6_exthdr ) == false ) {
    return false;
  }
  if ( match_packet_32_to_match( packet->ipv6_flabel.value,
      p_match->ipv6_flabel ) == false ) {
    return false;
  }

  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    p_match->ipv6_nd_sll[ i ].valid = p_match->ipv6_nd_sll[ 0 ].valid;
    if ( match_packet_8_to_match( packet->ipv6_nd_sll[ i ].value,
        p_match->ipv6_nd_sll[ i ] ) == false ) {
      return false;
    }
  }
  for ( int i = 0; i < IPV6_ADDRLEN; i++ ) {
    p_match->ipv6_nd_target[ i ].valid = p_match->ipv6_nd_target[ 0 ].valid;
    if ( match_packet_8_to_match( packet->ipv6_nd_target[ i ].value,
        p_match->ipv6_nd_target[ i ] ) == false ) {
      return false;
    }
  }
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    p_match->ipv6_nd_tll[ i ].valid = p_match->ipv6_nd_tll[ 0 ].valid;
    if ( match_packet_8_to_match( packet->ipv6_nd_tll[ i ].value,
        p_match->ipv6_nd_tll[ i ] ) == false ) {
      return false;
    }
  }
  for ( int i = 0; i < IPV6_ADDRLEN; i++ ) {
    p_match->ipv6_src[ i ].valid = p_match->ipv6_src[ 0 ].valid;
    if ( match_packet_8_to_match( packet->ipv6_src[ i ].value,
        p_match->ipv6_src[ i ] ) == false ) {
      return false;
    }
  }

  if ( match_packet_64_to_match( packet->metadata.value, p_match->metadata ) == false ) {
    return false;
  }
  if ( match_packet_8_to_match( packet->mpls_bos.value, p_match->mpls_bos ) == false ) {
    return false;
  }
  if ( match_packet_32_to_match( packet->mpls_label.value,
      p_match->mpls_label ) == false ) {
    return false;
  }
  if ( match_packet_8_to_match( packet->mpls_tc.value, p_match->mpls_tc ) == false ) {
    return false;
  }
  if ( match_packet_16_to_match( packet->sctp_dst.value, p_match->sctp_dst ) == false ) {
    return false;
  }
  if ( match_packet_16_to_match( packet->sctp_src.value, p_match->sctp_src ) == false ) {
    return false;
  }
  if ( match_packet_16_to_match( packet->tcp_dst.value, p_match->tcp_dst ) == false ) {
    return false;
  }
  if ( match_packet_16_to_match( packet->tcp_src.value, p_match->tcp_src ) == false ) {
    return false;
  }
  if ( match_packet_64_to_match( packet->tunnel_id.value,
      p_match->tunnel_id ) == false ) {
    return false;
  }
  if ( match_packet_16_to_match( packet->udp_dst.value, p_match->udp_dst ) == false ) {
    return false;
  }
  if ( match_packet_16_to_match( packet->udp_src.value, p_match->udp_src ) == false ) {
    return false;
  }
  if ( match_packet_8_to_match( packet->vlan_pcp.value, p_match->vlan_pcp ) == false ) {
    return false;
  }
  if ( match_packet_16_to_match( packet->vlan_vid.value, p_match->vlan_vid ) == false ) {
    return false;
  }

  return true;
}

/**
 * Match Packet structure to match structure
 * param packet
 * param p_match
 * return
 */
bool
match_packet_match( packet_info *packet, match *p_match ) {
  assert( packet != NULL );
  assert( p_match != NULL );

  match _packet;

  match_builder( &_packet, packet );
  return match_packet2match_match( &_packet, p_match );
}


/**
 * Match match structure to match structure
 * param x
 * param y
 * return
 */
bool
match_match_match( const match *x, const match *y ) {
  assert( x != NULL );
  assert( y != NULL );


  if ( match_match_16_to_match( x->arp_op, y->arp_op ) == false ) {
    return false;
  }
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    /*
     *If the match x match y are const no mods allowed.
     * There was a logic here to set the arp_sha.valid[ 0..ETH_ADDRLEN - 1 ] to
     * arp_sha.valid[ 0 ] which has been removed
     */
    if ( match_match_8_to_match( x->arp_sha[ i ],
        y->arp_sha[ i ] ) == false ) {
      return false;
    }
  }
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    if ( match_match_8_to_match( x->arp_tha[ i ],
        y->arp_tha[ i ] ) == false ) {
      return false;
    }
  }
  if ( match_match_32_to_match( x->arp_tpa, y->arp_tpa ) == false ) {
    return false;
  }
  if ( match_match_32_to_match( x->in_phy_port,
      y->in_phy_port ) == false ) {
    return false;
  }
  if ( match_match_32_to_match( x->in_port, y->in_port ) == false ) {
    return false;
  }

  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    if ( match_match_8_to_match( x->eth_dst[ i ],
        y->eth_dst[ i ] ) == false ) {
      return false;
    }
  }
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    if ( match_match_8_to_match( x->eth_src[ i ],
        y->eth_src[ i ] ) == false ) {
      return false;
    }
  }

  if ( match_match_16_to_match( x->eth_type, y->eth_type ) == false ) {
    return false;
  }
  if ( match_match_8_to_match( x->icmpv4_code,
      y->icmpv4_code ) == false ) {
    return false;
  }
  if ( match_match_8_to_match( x->icmpv4_type,
      y->icmpv4_type ) == false ) {
    return false;
  }
  if ( match_match_8_to_match( x->icmpv6_code,
      y->icmpv6_code ) == false ) {
    return false;
  }
  if ( match_match_8_to_match( x->icmpv6_type,
      y->icmpv6_type ) == false ) {
    return false;
  }
  if ( match_match_8_to_match( x->ip_dscp, y->ip_dscp ) == false ) {
    return false;
  }
  if ( match_match_8_to_match( x->ip_ecn, y->ip_ecn ) == false ) {
    return false;
  }
  if ( match_match_8_to_match( x->ip_proto, y->ip_proto ) == false ) {
    return false;
  }
  if ( match_match_32_to_match( x->ipv4_dst, y->ipv4_dst ) == false ) {
    return false;
  }
  if ( match_match_32_to_match( x->ipv4_src, y->ipv4_src ) == false ) {
    return false;
  }

  for ( int i = 0; i < IPV6_ADDRLEN; i++ ) {
    if ( match_match_8_to_match( x->ipv6_dst[ i ],
        y->ipv6_dst[ i ] ) == false ) {
      return false;
    }
  }
  if ( match_match_16_to_match( x->ipv6_exthdr,
      y->ipv6_exthdr ) == false ) {
    return false;
  }
  if ( match_match_32_to_match( x->ipv6_flabel,
      y->ipv6_flabel ) == false ) {
    return false;
  }

  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    if ( match_match_8_to_match( x->ipv6_nd_sll[ i ],
        y->ipv6_nd_sll[ i ] ) == false ) {
      return false;
    }
  }
  for ( int i = 0; i < IPV6_ADDRLEN; i++ ) {
    if ( match_match_8_to_match( x->ipv6_nd_target[ i ],
        y->ipv6_nd_target[ i ] ) == false ) {
      return false;
    }
  }
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    if ( match_match_8_to_match( x->ipv6_nd_tll[ i ],
        y->ipv6_nd_tll[ i ] ) == false ) {
      return false;
    }
  }
  for ( int i = 0; i < IPV6_ADDRLEN; i++ ) {
    if ( match_match_8_to_match( x->ipv6_src[ i ],
        y->ipv6_src[ i ] ) == false ) {
      return false;
    }
  }

  if ( match_match_64_to_match( x->metadata, y->metadata ) == false ) {
    return false;
  }
  if ( match_match_8_to_match( x->mpls_bos, y->mpls_bos ) == false ) {
    return false;
  }
  if ( match_match_32_to_match( x->mpls_label,
      y->mpls_label ) == false ) {
    return false;
  }
  if ( match_match_8_to_match( x->mpls_tc, y->mpls_tc ) == false ) {
    return false;
  }
  if ( match_match_16_to_match( x->sctp_dst, y->sctp_dst ) == false ) {
    return false;
  }
  if ( match_match_16_to_match( x->sctp_src, y->sctp_src ) == false ) {
    return false;
  }
  if ( match_match_16_to_match( x->tcp_dst, y->tcp_dst ) == false ) {
    return false;
  }
  if ( match_match_16_to_match( x->tcp_src, y->tcp_src ) == false ) {
    return false;
  }
  if ( match_match_64_to_match( x->tunnel_id,
      y->tunnel_id ) == false ) {
    return false;
  }
  if ( match_match_16_to_match( x->udp_dst, y->udp_dst ) == false ) {
    return false;
  }
  if ( match_match_16_to_match( x->udp_src, y->udp_src ) == false ) {
    return false;
  }
  if ( match_match_8_to_match( x->vlan_pcp, y->vlan_pcp ) == false ) {
    return false;
  }
  if ( match_match_16_to_match( x->vlan_vid, y->vlan_vid ) == false ) {
    return false;
  }

  return true;
}


/**
 * Compare match structure to match structure
 * param x
 * param y
 * return
 */
bool
compare_match_match( match *x, match *y ) {
  assert( x != NULL );
  assert( y != NULL );

  if ( compare_match_16_to_match( x->arp_op, y->arp_op ) == false ) {
    return false;
  }
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    x->arp_sha[ i ].valid = x->arp_sha[ 0 ].valid;
    y->arp_sha[ i ].valid = y->arp_sha[ 0 ].valid;
    if ( compare_match_8_to_match( x->arp_sha[ i ],
        y->arp_sha[ i ] ) == false ) {
      return false;
    }
  }
  if ( compare_match_32_to_match( x->arp_spa, y->arp_spa ) == false ) {
    return false;
  }
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    x->arp_tha[ i ].valid = x->arp_tha[ 0 ].valid;
    y->arp_tha[ i ].valid = y->arp_tha[ 0 ].valid;
    if ( compare_match_8_to_match( x->arp_tha[ i ],
        y->arp_tha[ i ] ) == false ) {
      return false;
    }
  }
  if ( compare_match_32_to_match( x->arp_spa, y->arp_spa ) == false ) {
    return false;
  }

  if ( compare_match_32_to_match( x->arp_tpa, y->arp_tpa ) == false ) {
    return false;
  }
  if ( compare_match_32_to_match( x->in_phy_port,
      y->in_phy_port ) == false ) {
    return false;
  }
  if ( compare_match_32_to_match( x->in_port, y->in_port ) == false ) {
    return false;
  }

  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    x->eth_dst[ i ].valid = x->eth_dst[ 0 ].valid;
    y->eth_dst[ i ].valid = y->eth_dst[ 0 ].valid;
    if ( compare_match_8_to_match( x->eth_dst[ i ],
        y->eth_dst[ i ] ) == false ) {
      return false;
    }
  }
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    y->eth_src[ i ].valid = y->eth_src[ 0 ].valid;
    if ( compare_match_8_to_match( x->eth_src[ i ],
        y->eth_src[ i ] ) == false ) {
      return false;
    }
  }

  if ( compare_match_16_to_match( x->eth_type, y->eth_type ) == false ) {
    return false;
  }
  if ( compare_match_8_to_match( x->icmpv4_code,
      y->icmpv4_code ) == false ) {
    return false;
  }
  if ( compare_match_8_to_match( x->icmpv4_type,
      y->icmpv4_type ) == false ) {
    return false;
  }
  if ( compare_match_8_to_match( x->icmpv6_code,
      y->icmpv6_code ) == false ) {
    return false;
  }
  if ( compare_match_8_to_match( x->icmpv6_type,
      y->icmpv6_type ) == false ) {
    return false;
  }
  if ( compare_match_8_to_match( x->ip_dscp, y->ip_dscp ) == false ) {
    return false;
  }
  if ( compare_match_8_to_match( x->ip_ecn, y->ip_ecn ) == false ) {
    return false;
  }
  if ( compare_match_8_to_match( x->ip_proto, y->ip_proto ) == false ) {
    return false;
  }
  if ( compare_match_32_to_match( x->ipv4_dst, y->ipv4_dst ) == false ) {
    return false;
  }
  if ( compare_match_32_to_match( x->ipv4_src, y->ipv4_src ) == false ) {
    return false;
  }

  for ( int i = 0; i < IPV6_ADDRLEN; i++ ) {
    x->ipv6_dst[ i ].valid = x->ipv6_dst[ 0 ].valid;
    y->ipv6_dst[ i ].valid = y->ipv6_dst[ 0 ].valid;
    if ( compare_match_8_to_match( x->ipv6_dst[ i ],
        y->ipv6_dst[ i ] ) == false ) {
      return false;
    }
  }
  if ( compare_match_16_to_match( x->ipv6_exthdr,
      y->ipv6_exthdr ) == false ) {
    return false;
  }
  if ( compare_match_32_to_match( x->ipv6_flabel,
      y->ipv6_flabel ) == false ) {
    return false;
  }

  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    x->ipv6_nd_sll[ i ].valid = x->ipv6_nd_sll[ 0 ].valid;
    y->ipv6_nd_sll[ i ].valid = y->ipv6_nd_sll[ 0 ].valid;
    if ( compare_match_8_to_match( x->ipv6_nd_sll[ i ],
        y->ipv6_nd_sll[ i ] ) == false ) {
      return false;
    }
  }
  for ( int i = 0; i < IPV6_ADDRLEN; i++ ) {
    x->ipv6_nd_target[ i ].valid = x->ipv6_nd_target[ 0 ].valid;
    y->ipv6_nd_target[ i ].valid = y->ipv6_nd_target[ 0 ].valid;
    if ( compare_match_8_to_match( x->ipv6_nd_target[ i ],
        y->ipv6_nd_target[ i ] ) == false ) {
      return false;
    }
  }
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    x->ipv6_nd_tll[ i ].valid = x->ipv6_nd_tll[ 0 ].valid;
    y->ipv6_nd_tll[ i ].valid = y->ipv6_nd_tll[ 0 ].valid;
    if ( compare_match_8_to_match( x->ipv6_nd_tll[ i ],
        y->ipv6_nd_tll[ i ] ) == false ) {
      return false;
    }
  }
  for ( int i = 0; i < IPV6_ADDRLEN; i++ ) {
    x->ipv6_src[ i ].valid = x->ipv6_src[ 0 ].valid;
    y->ipv6_src[ i ].valid = y->ipv6_src[ 0 ].valid;
    if ( compare_match_8_to_match( x->ipv6_src[ i ],
        y->ipv6_src[ i ] ) == false ) {
      return false;
    }
  }

  if ( compare_match_64_to_match( x->metadata, y->metadata ) == false ) {
    return false;
  }
  if ( compare_match_8_to_match( x->mpls_bos, y->mpls_bos ) == false ) {
    return false;
  }
  if ( compare_match_32_to_match( x->mpls_label,
      y->mpls_label ) == false ) {
    return false;
  }
  if ( compare_match_8_to_match( x->mpls_tc, y->mpls_tc ) == false ) {
    return false;
  }
  if ( compare_match_16_to_match( x->sctp_dst, y->sctp_dst ) == false ) {
    return false;
  }
  if ( compare_match_16_to_match( x->sctp_src, y->sctp_src ) == false ) {
    return false;
  }
  if ( compare_match_16_to_match( x->tcp_dst, y->tcp_dst ) == false ) {
    return false;
  }
  if ( compare_match_16_to_match( x->tcp_src, y->tcp_src ) == false ) {
    return false;
  }
  if ( compare_match_64_to_match( x->tunnel_id,
      y->tunnel_id ) == false ) {
    return false;
  }
  if ( compare_match_16_to_match( x->udp_dst, y->udp_dst ) == false ) {
    return false;
  }
  if ( compare_match_16_to_match( x->udp_src, y->udp_src ) == false ) {
    return false;
  }
  if ( compare_match_8_to_match( x->vlan_pcp, y->vlan_pcp ) == false ) {
    return false;
  }
  if ( compare_match_16_to_match( x->vlan_vid, y->vlan_vid ) == false ) {
    return false;
  }

  return true;
}

/**
 * Initialize Packet Matcher
 * return
 */
OFDPE
initialize_packet_matcher( void ) {
  return OFDPE_SUCCESS;
}

/**
 * Finalize Packet Matcher
 * return
 */
OFDPE
finalize_packet_matcher( void ) {
  return OFDPE_SUCCESS;
}


static flow_entry *
_match_entry_fetcher( buffer *parsed_buffer, uint8_t table_id ) {
  assert( parsed_buffer != NULL );

  packet_info *packet = parsed_buffer->user_data;
  assert( packet != NULL );

  match p_match;
  match_builder( &p_match, packet );

  flow_entry *entry = lookup_flow_entry( table_id, &p_match );
  if ( entry != NULL ) {
    entry->packet_count++;
    entry->byte_count += parsed_buffer->length;
  }

  return entry;
}
flow_entry *(*match_entry_fetcher)( buffer *parsed_buffer, uint8_t table_id ) = _match_entry_fetcher;

/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
