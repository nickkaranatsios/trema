/*
 * Functions for managing ports.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include <inttypes.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include "ofdp_common.h"
#include "port_manager.h"
#include "packet_forwarder.h"
#include "packet_buffer_pool.h"
#include "controller_manager.h"
#include "switch_port.h"
#include "ether_device.h"
#include "mutex_lock.h"
#include "linked_list.h"
#include "wrapper.h"
#include "buffer.h"


typedef struct {
  uint32_t select_timeout_usec;
  size_t max_send_queue_size;
  size_t max_recv_queue_size;
  pthread_mutex_t mutex_port_manager;
} port_manager;


static const char DEVICE_STAT_FILE[] = "/proc/net/dev";
static port_manager manager_config;


/**
 * initialize port manager
 *
 * param select timeout value (microseconds)
 * param maximum send queue size
 * param maximum receive queue size
 * return success/failed
 */
OFDPE
init_port_manager( const uint32_t timeout_usec, const size_t max_send_queue, const size_t max_recv_queue ) {
  if ( ( timeout_usec == 0 ) || ( max_send_queue == 0 ) || ( max_recv_queue == 0 ) ) {
    error( "Illegal parameter error.(timeout_usec=%u, max_send_queue=%u, max_recv_queue=%u)", timeout_usec, max_send_queue, max_recv_queue );
    return ERROR_ILLEGAL_PARAMETER;
  }

  manager_config.select_timeout_usec = timeout_usec;
  manager_config.max_send_queue_size = max_send_queue;
  manager_config.max_recv_queue_size = max_recv_queue;

  if ( !init_mutex( &( manager_config.mutex_port_manager ) ) ) {
    warn( "init_mutex() execute error." );
    return ERROR_INIT_MUTEX;
  }

  init_switch_port();

  return OFDPE_SUCCESS;
}


/**
 * finalize port manager
 *
 * param nothing
 * return success/failed
 */
OFDPE
finalize_port_manager( void ) {
  finalize_switch_port();

  if ( !finalize_mutex( &( manager_config.mutex_port_manager ) ) ) {
    warn( "finalize_mutex() execute error." );
    return ERROR_FINALIZE_MUTEX;
  }

  return OFDPE_SUCCESS;
}


static void
recv_data( buffer *frame, void *user_data ) {
  assert( frame != NULL );
  assert( user_data != NULL );

  switch_port *port = user_data;

  if ( !lock_mutex( &( manager_config.mutex_port_manager ) ) ) {
    warn( "lock_target() execute error." );
    increment_port_tx_dropped( port->port_no );
    free_packet_buffer_pool_entry( frame );
    return;
  }

  if ( port->config & ( OFPPC_PORT_DOWN | OFPPC_NO_RECV ) ) {
    if ( !unlock_mutex( &( manager_config.mutex_port_manager ) ) ) {
      warn( "unlock_target() execute error." );
      return;
    }
    increment_port_tx_dropped( port->port_no );
    free_packet_buffer_pool_entry( frame );
    return;
  }

  if ( !unlock_mutex( &( manager_config.mutex_port_manager ) ) ) {
    warn( "unlock_target() execute error." );
    increment_port_tx_dropped( port->port_no );
    free_packet_buffer_pool_entry( frame );
    return;
  }

  if ( frame->length + ETH_FCS_LENGTH < ETH_MINIMUM_LENGTH ) {
    fill_ether_padding( frame );
  }

  OFDPE ret = OFDPE_SUCCESS;
  ret = accept_recv_data( port, frame );
  if ( ret != OFDPE_SUCCESS ) {
    //	  warn("accept_recv_data() failed.");
    return;
  }

  return;
}


typedef struct {
  uint32_t in_port;
  list_element *list;
} ports_data;


static void
append_switch_port_list( switch_port *port, void *user_data ) {
  assert( port != NULL );
  assert( user_data != NULL );

  ports_data *ports = ( ports_data * ) user_data;

  if ( ports->in_port == port->port_no ) {
    return;
   }

   append_to_tail( &( ports->list ), port );

   return;
}


static list_element *
get_switch_port_list( const uint32_t port_no, const packet_info *packet ) {
  switch_port *port = NULL;
  ports_data ports;
  ports.in_port = OFPP_ANY;
  create_list( &ports.list );

  switch ( port_no ) {
  case OFPP_MAX:
    break;

  case OFPP_IN_PORT:
    if ( packet == NULL ) {
      warn( "Don't find in_port port_no(=OFPP_IN_PORT). Because no packet data." );
      break;
    }
    else {
      port = lookup_switch_port( packet->eth_in_port );
      if ( port != NULL ) {
        append_switch_port_list( port, &ports );
      }
      break;
    }

  case OFPP_TABLE:
    warn( "Don't supported port_no(=OFPP_TABLE)" );
    break;

  case OFPP_NORMAL:
    warn( "Don't supported port_no(=OFPP_NORMAL)" );
    break;

  case OFPP_FLOOD:
    warn( "Don't supported port_no(=OFPP_FLOOD)" );
    break;

  case OFPP_ALL:
    ports.in_port = packet->eth_in_port;
    foreach_switch_port( append_switch_port_list, &ports );
    break;

  case OFPP_CONTROLLER:
    warn( "Can't operation port_no(=OFPP_CONTROLLER)" );
    break;

  case OFPP_LOCAL:
    warn( "Don't supported port_no(=OFPP_LOCAL)" );
    break;

  case OFPP_ANY:
    foreach_switch_port( append_switch_port_list, &ports );
    break;

  default:
    port = lookup_switch_port( port_no );
    if ( port != NULL ) {
      append_switch_port_list( port, &ports );
    }
    break;
  }

  return ports.list;
}


static uint32_t
get_max_port_no() {
  uint32_t max_port_no = 0;

  list_element *ports = ports = get_switch_port_list( OFPP_ALL, NULL );

  if ( ports == NULL ) {
    return max_port_no;
  }

  for ( list_element *p = ports; p != NULL; p = p->next ) {
    switch_port *port = ( switch_port * ) p->data;
    if ( max_port_no < port->port_no ) {
      max_port_no = port->port_no;
    }
  }

  delete_list( ports );

  return max_port_no;
}


/**
 * initialize device
 *
 * param device infomation
 * return success/failed
 */
static OFDPE
_init_device( argument_device_info *device_info ) {
  if ( device_info == NULL ) {
    error( "Illegal parameter error.(device_info=%x)", device_info );
    return ERROR_ILLEGAL_PARAMETER;
  }

  if ( device_info->port_no >= OFPP_MAX ) {
    error( "Illegal port_no.(port_no=%x)", device_info->port_no );
    return ERROR_OFDPE_PORT_MOD_FAILED_BAD_PORT;
  }

  if ( !lock_mutex( &( manager_config.mutex_port_manager ) ) ) {
    warn( "lock_target() execute error." );
    return ERROR_LOCK;
  }

  uint32_t port_no = device_info->port_no;
  if ( port_no == 0 ) {
    port_no = get_max_port_no() + 1;
  }

  if ( is_valid_port_no( port_no ) ) {
    error( "Illegal port_no.(port_no=%x)", device_info->port_no );
    if ( !unlock_mutex( &( manager_config.mutex_port_manager ) ) ) {
      warn( "unlock_target() execute error." );
      return ERROR_UNLOCK;
    }
    return ERROR_OFDPE_PORT_MOD_FAILED_BAD_PORT;
  }
  device_info->port_no = port_no;

  info( "Adding an Ethernet port as a switch port ( %s ).",
    device_info->device_name );
  switch_port *port = add_switch_port( device_info->device_name, device_info->port_no,
    manager_config.max_send_queue_size, manager_config.max_recv_queue_size );
  if ( ( port == NULL ) || ( port->device == NULL ) ) {
    error( "Don't find device error.(device->name:%s, device->port_no=%u)", device_info->device_name, device_info->port_no );
    if ( !unlock_mutex( &( manager_config.mutex_port_manager ) ) ) {
      warn( "unlock_target() execute error." );
      return ERROR_UNLOCK;
    }
    return ERROR_OFDPE_PORT_MOD_FAILED_EPERM;
  }

  time_now( &port->device->stats.init_time );
  set_frame_received_handler( port->device, recv_data, port );

  if ( !unlock_mutex( &( manager_config.mutex_port_manager ) ) ) {
    warn( "unlock_target() execute error." );
    return ERROR_UNLOCK;
  }

  return OFDPE_SUCCESS;
}
OFDPE ( *init_device )( argument_device_info *device_info ) = _init_device;


/**
 * finalize device
 *
 * param device infomation
 * return success/failed
 */
static OFDPE
_finalize_device( const uint32_t port_no ) {
  if ( !lock_mutex( &( manager_config.mutex_port_manager ) ) ) {
    warn( "lock_target() execute error." );
    return ERROR_LOCK;
  }

  switch_port *port = delete_switch_port( port_no );
  if ( port == NULL ) {
    if ( !unlock_mutex( &( manager_config.mutex_port_manager ) ) ) {
      warn( "unlock_target() execute error." );
      return ERROR_UNLOCK;
    }
    return ERROR_ILLEGAL_PARAMETER;
  }

  if ( port->device != NULL ) {
    delete_ether_device( port->device );
  }
  xfree( port );

  if ( !unlock_mutex( &( manager_config.mutex_port_manager ) ) ) {
    warn( "unlock_target() execute error." );
    return ERROR_UNLOCK;
  }

  return OFDPE_SUCCESS;
}
OFDPE ( *finalize_device )( const uint32_t port_no ) = _finalize_device;


/**
 * sending data
 *  enqueue send queue and up write flag
 *
 * param switch port number
 * param send buffer data
 * return success/failed
 */
static OFDPE
_send_data( const uint32_t port_no, buffer *send_buffer ) {
  if ( send_buffer == NULL ) {
    warn( "Illegal parameter error.(send_buffer=%x)", send_buffer );
    return ERROR_ILLEGAL_PARAMETER;
  }

  if ( send_buffer->user_data == NULL ) {
    warn( "Illegal parameter error.(send_buffer->user_data=%x)", send_buffer->user_data );
    return ERROR_ILLEGAL_PARAMETER;
  }

  if ( port_no == OFPP_TABLE ) {
    OFDPE ret = OFDPE_SUCCESS;
    buffer *copy = duplicate_packet_buffer_pool_entry( send_buffer );
    if ( copy == NULL ) {
      warn( "can't duplicate packet buffer for output table" );
      return ERROR_NO_MEMORY;
    }

    copy->user_data = NULL;
    if ( !parse_packet( copy ) ) {
      error( "parse packet failed for out put table." );
      return OFDPE_FAILED;
    }

      ( ( packet_info * ) copy->user_data )->metadata = ( ( packet_info * ) send_buffer->user_data )->metadata;
      ( ( packet_info * ) copy->user_data )->eth_in_port = ( ( packet_info * ) send_buffer->user_data )->eth_in_port;

    ret = enqueue_head_recv_data( lookup_switch_port( ( ( packet_info * ) copy->user_data )->eth_in_port ), copy );
    if ( ret != OFDPE_SUCCESS ) {
      error( "enqueue recv data failed for put put table." );
      return ret;
    }
    return ret;
  }

  list_element *ports = NULL;

  ports = get_switch_port_list( port_no, ( packet_info * ) send_buffer->user_data );
  if ( ports == NULL ) {
    warn( "can't get port. Because illegal port_no(%d)", port_no );
    return ERROR_ILLEGAL_PARAMETER;
  }

  for ( list_element *p = ports; p != NULL; p = p->next ) {
    switch_port *port = ( switch_port * ) p->data;

    if ( !lock_mutex( &( manager_config.mutex_port_manager ) ) ) {
      warn( "lock_target() execute error." );
      increment_port_tx_dropped( port->port_no );
      delete_list( ports );
      return ERROR_LOCK;
    }

    if ( port->config & ( OFPPC_PORT_DOWN | OFPPC_NO_FWD ) ) {
      if ( !unlock_mutex( &( manager_config.mutex_port_manager ) ) ) {
        warn( "unlock_target() execute error." );
        return ERROR_UNLOCK;
      }
      increment_port_tx_dropped( port->port_no );
      return OFDPE_FAILED;
    }

    if ( !unlock_mutex( &( manager_config.mutex_port_manager ) ) ) {
      warn( "unlock_target() execute error." );
      increment_port_tx_dropped( port->port_no );
      return ERROR_UNLOCK;
    }

    if ( port->device != NULL ) {
      buffer *buf = duplicate_packet_buffer_pool_entry( send_buffer );

      if ( !send_frame( port->device, buf ) ) {
        free_packet_buffer_pool_entry( buf );
        warn( "failed to send_frame()" );
        increment_port_tx_dropped( port->port_no );
        delete_list( ports );
        return OFDPE_FAILED;
      }
    }
    else {
      warn( "can't find port -> device. port_no(%d)", port->port_no );
    }
  }

  delete_list( ports );

  return OFDPE_SUCCESS;
}
OFDPE ( *send_data )( const uint32_t port_no, buffer *send_buffer ) = _send_data;


/**
 * check device linkup
 *
 * param switch port number
 * return up/down
 */
static bool
_is_device_linkup( const uint32_t port_no ) {
  bool flag_up = false;

  list_element *ports = NULL;

  ports = get_switch_port_list( port_no, NULL );
  if ( ports == NULL ) {
    warn( "can't get port. Because illegal port_no(%d)", port_no );
    return false;
  }

  for ( list_element *p = ports; p != NULL; p = p->next ) {
    switch_port *port = ( switch_port * ) p->data;

    if ( port->device != NULL ) {
      short int flags = get_device_flags( port->device->name );
      if ( ( flags & IFF_UP ) == IFF_UP ) {
        flag_up = true;
      }
      else {
        flag_up = false;
        break;
      }
    }
    else {
      warn( "can't find port -> device. port_no(%d)", port->port_no );
      flag_up = false;
      break;
    }
  }

  delete_list( ports );

  return flag_up;
}
bool ( *is_device_linkup )( const uint32_t port_no ) = _is_device_linkup;


static bool
allocate_stats_array( list_element *ports, ofp_port_stats *stats[], int *num_stats ) {
  assert( ports != NULL );
  assert( stats != NULL );

  *num_stats = 0;

  for ( list_element *p = ports; p != NULL; p = p->next ) {
    switch_port *port = ( switch_port * ) p->data;

    if ( port->device != NULL ) {
        ( *num_stats )++;
    }
  }

  *stats = xcalloc( ( size_t ) *num_stats, sizeof( ofp_port_stats ) );
  if ( *stats == NULL ) {
    warn( "memory allocate error." );
    return false;
  }

  return true;
}


static bool
get_statistics_from_line( char *line, ofp_port_stats *stat, const ether_device *device ) {
  assert( line != NULL );
  assert( stat != NULL );
  assert( device != NULL );

  char *head = line + strlen( device->name ) + 1;       // skip "  eth0:"
  uint64_t trash;
  int ret = sscanf( head, "%" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64
    " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64
    " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64,
    &( stat->rx_bytes ),
    &( stat->rx_packets ),
    &( stat->rx_errors ),
    &( stat->rx_dropped ),
    &( stat->rx_over_err ),
    &( stat->rx_frame_err ),
    &trash, &trash,
    &( stat->tx_bytes ),
    &( stat->tx_packets ),
    &( stat->tx_errors ),
    &( stat->tx_dropped ),
    &trash,
    &( stat->collisions ),
    &trash, &trash );

  if ( ret != 16 ) {
    error( "Failed to retrieve interface statistics ( ret = %d, device = %s ).", ret, device->name );
    return false;
  }

  return true;
}


static void
calc_duration( const struct timespec init_time, uint32_t *d_sec, uint32_t *d_nsec ) {
  assert( d_sec != NULL );
  assert( d_nsec != NULL );

  struct timespec now_time;
  struct timespec diff;

  time_now( &now_time );
  timespec_diff( init_time, now_time, &diff );
  *d_sec = ( uint32_t ) diff.tv_sec;
  *d_nsec = ( uint32_t ) diff.tv_nsec;

  return;
}


/**
 * get device statistics
 *
 * param switch port number
 * param set pointer statistics data
 * param set pointer number of statistics
 * return success/failed
 */
OFDPE
get_device_statistics( const uint32_t port_no, ofp_port_stats *stats[], int *num_stats ) {
  if ( ( stats == NULL ) || ( num_stats == NULL ) ) {
    warn( "Illegal parameter error.(stats=%x, num_stats=%x)", stats, num_stats );
    return ERROR_ILLEGAL_PARAMETER;
  }

  if ( port_no == OFPP_TABLE ) {
    warn( "Don't support port_no(%d)", port_no );
    return ERROR_NO_SUPPORTED;
  }

  if ( !lock_mutex( &( manager_config.mutex_port_manager ) ) ) {
    warn( "lock_target() execute error." );
    return ERROR_LOCK;
  }

  list_element *ports = NULL;

  ports = get_switch_port_list( port_no, NULL );
  if ( ports == NULL ) {
    warn( "can't get port. Because illegal port_no(%d)", port_no );
    if ( !unlock_mutex( &( manager_config.mutex_port_manager ) ) ) {
      warn( "unlock_target() execute error." );
      return ERROR_UNLOCK;
    }
    return ERROR_ILLEGAL_PARAMETER;
  }

  if ( !allocate_stats_array( ports, stats, num_stats ) ) {
    warn( "allocate_stats_array() error." );
    delete_list( ports );
    if ( !unlock_mutex( &( manager_config.mutex_port_manager ) ) ) {
      warn( "unlock_target() execute error." );
      return ERROR_UNLOCK;
    }
    return ERROR_NO_MEMORY;
  }

  FILE *fh = fopen( DEVICE_STAT_FILE, "r" );
  if ( fh == NULL ) {
    error( "Failed to open %s.", DEVICE_STAT_FILE );
    delete_list( ports );
    xfree( stats );
    if ( !unlock_mutex( &( manager_config.mutex_port_manager ) ) ) {
      warn( "unlock_target() execute error." );
      return ERROR_UNLOCK;
    }
    return ERROR_ILLEGAL_PARAMETER;
  }

  int index = 0;

  for (;; ) {
    char buf[ 256 ];
    char *line = fgets( buf, sizeof( buf ), fh );
    if ( line == NULL ) {
      break;
    }

    switch_port *port = NULL;
    char *head = NULL;
    for ( list_element *p = ports; p != NULL; p = p->next ) {
      port = ( switch_port * ) p->data;

      if ( port->device != NULL ) {
        head = strstr( line, port->device->name );
        if ( head != NULL ) {
          break;
        }
      }
    }
    if ( head != NULL ) {
      ofp_port_stats *stat = &( ( *stats )[ index ] );

      if ( !get_statistics_from_line( head, stat, port->device ) ) {
        warn( "execute _get_statistics_from_line() function error." );
        break;
      }

      stat->port_no = port->port_no;
      calc_duration( port->device->stats.init_time, &stat->duration_sec, &stat->duration_nsec );

      stat->tx_dropped += port->device->stats.tx_dropped;

      index++;
      if ( index >= ( *num_stats ) ) {
        break;
      }
    }
  }

  fclose( fh );
  delete_list( ports );

  if ( !unlock_mutex( &( manager_config.mutex_port_manager ) ) ) {
    warn( "unlock_target() execute error." );
    return ERROR_UNLOCK;
  }

  return OFDPE_SUCCESS;
}


/**
 * dump device statistics
 *
 * param statistics data
 * return success/failed
 */
void
dump_port_stats( ofp_port_stats *stats ) {
  debug( "***** start port stats *****" );
  debug( "port_no = %u", stats->port_no );
  debug( "rx_packets = %u", stats->rx_packets );
  debug( "tx_packets = %u", stats->tx_packets );
  debug( "rx_bytes = %u", stats->rx_bytes );
  debug( "tx_bytes = %u", stats->tx_bytes );
  debug( "rx_dropped = %u", stats->rx_dropped );
  debug( "tx_dropped = %u", stats->tx_dropped );
  debug( "rx_errors = %u", stats->rx_errors );
  debug( "tx_errors = %u", stats->tx_errors );
  debug( "tx_errors = %u", stats->tx_errors );
  debug( "rx_over_err = %u", stats->rx_over_err );
  debug( "rx_crc_err = %u", stats->rx_crc_err );
  debug( "collisions = %u", stats->collisions );
  debug( "duration_sec = %u", stats->duration_sec );
  debug( "duration_nsec = %u", stats->duration_nsec );
  debug( "***** end port stats *****" );

  return;
}


/**
 * incliment device tx_dropped counter
 *
 * param switch port number
 * return success/failed
 */
OFDPE
increment_port_tx_dropped( const uint32_t port_no ) {
  if ( !lock_mutex( &( manager_config.mutex_port_manager ) ) ) {
    warn( "lock_target() execute error." );
    return ERROR_LOCK;
  }

  list_element *ports = NULL;

  ports = get_switch_port_list( port_no, NULL );
  if ( ports == NULL ) {
    warn( "can't get port. Because illegal port_no(%d)", port_no );
    if ( !unlock_mutex( &( manager_config.mutex_port_manager ) ) ) {
      warn( "unlock_target() execute error." );
      return ERROR_UNLOCK;
    }
    return ERROR_ILLEGAL_PARAMETER;
  }

  for ( list_element *p = ports; p != NULL; p = p->next ) {
    switch_port *port = ( switch_port * ) p->data;

    if ( port->device == NULL ) {
      warn( "can't find port -> device. port_no(%d)", port->port_no );
      delete_list( ports );
      if ( !unlock_mutex( &( manager_config.mutex_port_manager ) ) ) {
        warn( "unlock_target() execute error." );
        return ERROR_UNLOCK;
      }
      return ERROR_ILLEGAL_PARAMETER;
    }
  }

  for ( list_element *p = ports; p != NULL; p = p->next ) {
    switch_port *port = ( switch_port * ) p->data;

    if ( port->device != NULL ) {
      port->device->stats.tx_dropped++;
    }
  }

  delete_list( ports );

  if ( !unlock_mutex( &( manager_config.mutex_port_manager ) ) ) {
    warn( "unlock_target() execute error." );
    return ERROR_UNLOCK;
  }

  return OFDPE_SUCCESS;
}


/**
 * updateing port configure
 *
 * param switch port number
 * param port config value
 * param port config mask value
 * return success/failed
 */
OFDPE
update_port_config( const uint32_t port_no, const uint32_t config, const uint32_t mask ) {
  if ( !lock_mutex( &( manager_config.mutex_port_manager ) ) ) {
    warn( "lock_target() execute error." );
    return ERROR_LOCK;
  }

  list_element *ports = NULL;

  ports = get_switch_port_list( port_no, NULL );
  if ( ports == NULL ) {
    warn( "can't get port. Because illegal port_no(%d)", port_no );
    if ( !unlock_mutex( &( manager_config.mutex_port_manager ) ) ) {
      warn( "unlock_target() execute error." );
      return ERROR_UNLOCK;
    }
    return ERROR_ILLEGAL_PARAMETER;
  }

  for ( list_element *p = ports; p != NULL; p = p->next ) {
    switch_port *port = ( switch_port * ) p->data;

    if ( !update_switch_port_config( port, config, mask ) ) {
      warn( "execute update_switch_port_config() function error." );
      delete_list( ports );
      if ( !unlock_mutex( &( manager_config.mutex_port_manager ) ) ) {
        warn( "unlock_target() execute error." );
        return ERROR_UNLOCK;
      }
      return ERROR_OFDPE_PORT_MOD_FAILED_BAD_CONFIG;
    }

    send_for_notify_port_config( port->port_no, OFPPR_MODIFY );
  }

  delete_list( ports );

  if ( !unlock_mutex( &( manager_config.mutex_port_manager ) ) ) {
    warn( "unlock_target() execute error." );
    return ERROR_UNLOCK;
  }

  return OFDPE_SUCCESS;
}


static size_t
get_device_mtu( const char *device_name ) {
  assert( device_name != NULL );

  int fd = socket( AF_INET, SOCK_DGRAM, 0 );

  struct ifreq ifr;
  strncpy( ifr.ifr_name, device_name, IFNAMSIZ - 1 );
  if ( ioctl( fd, SIOCGIFMTU, &ifr ) != 0 ) {
    warn( "failed to ioctl(SIOCGIFMTU)" );
    close( fd );
    return 0;
  }

  close( fd );

  return ( size_t ) ifr.ifr_mtu;
}


/**
 * get maximum device mtu for all devices
 *
 * param device infomation list
 * return maximum device mtu
 */
size_t
get_switch_mtu( list_element *devices_info ) {
  if ( devices_info == NULL ) {
    warn( "Illegal parameter error.(devices_info=%s)", devices_info );
    return 0;
  }

  size_t temp_switch_mtu = 0;

  for ( list_element *p = devices_info; p != NULL; p = p->next ) {
    argument_device_info *device_info = ( argument_device_info * ) p->data;

    size_t mtu = get_device_mtu( device_info->device_name );
    debug("device(%s) mtu=%u", device_info->device_name, mtu);
    if ( temp_switch_mtu < mtu ) {
      temp_switch_mtu = mtu;
    }
  }

  return temp_switch_mtu;
}


static OFDPE
get_ofp_port_structure( uint32_t port_no, ofp_port *out_port ) {
  if ( out_port == NULL ) {
    warn( "Illegal parameter error.(out_port=%x)", out_port );
    return ERROR_ILLEGAL_PARAMETER;
  }

  switch_port *port = lookup_switch_port( port_no );
  if ( port == NULL ) {
    warn( "Illegal parameter error.(port_no=%u)", port_no );
    return ERROR_ILLEGAL_PARAMETER;
  }
  if ( port->device == NULL ) {
    warn( "Illegal parameter error.(port_no=%u)", port_no );
    return ERROR_ILLEGAL_PARAMETER;
  }

  out_port->port_no = port_no;
  memcpy( out_port->hw_addr, port->device->hw_addr, ETH_ADDRLEN );
  strncpy( out_port->name, port->device->name, IFNAMSIZ );
  out_port->name[ IFNAMSIZ - 1 ] = '\0';
  out_port->config = port->config;
  out_port->state = 0;  // how get value?

  out_port->curr = port->device->status.curr;
  out_port->advertised = port->device->status.advertised;
  out_port->supported = port->device->status.supported;
  out_port->peer = port->device->status.peer;

  out_port->curr_speed = port->device->status.curr_speed;
  out_port->max_speed = port->device->status.max_speed;

  return OFDPE_SUCCESS;
}


/**
 * get port descriptions
 *
 * param switch port number
 * param set pointer descriptions data
 * param set pointer number of descriptions
 * return maximum device mtu
 */
OFDPE
get_port_description( const uint32_t port_no, ofp_port **descriptions, uint32_t *num ) {
  if ( ( descriptions == NULL ) || ( num == NULL ) ) {
    warn( "Illegal parameter error.(descriptions=%x, num=%x)", descriptions, num );
    return ERROR_ILLEGAL_PARAMETER;
  }

  list_element *ports = NULL;

  ports = get_switch_port_list( port_no, NULL );
  if ( ports == NULL ) {
    warn( "can't get port. Because illegal port_no(%d)", port_no );
    return ERROR_ILLEGAL_PARAMETER;
  }

  *num = list_length_of( ports );
  *descriptions = xcalloc( *num, sizeof( ofp_port ) );
  if ( *descriptions == NULL ) {
    warn( "memory allocation error." );
    return ERROR_NO_MEMORY;
  }

  int index = 0;
  for ( list_element *p = ports; p != NULL; p = p->next ) {
    switch_port *port = ( switch_port * ) p->data;
    ofp_port *desc = &( *descriptions )[ index++ ];

    OFDPE ret = get_ofp_port_structure( port->port_no, desc );
    if ( ret != OFDPE_SUCCESS ) {
      xfree( *descriptions );
      *num = 0;
      delete_list( ports );
      return ret;
    }
  }

  delete_list( ports );

  return OFDPE_SUCCESS;
}


/**
 * send for notify port configure message
 *
 * param switch port number
 * param port configure reason
 * return success/failed
 */
static OFDPE
_send_for_notify_port_config( uint32_t port_no, uint8_t reason ) {
  notify_parameter_port_status parameter;

  parameter.reason = reason;
  get_ofp_port_structure( port_no, &parameter.desc );
  notify_port_status( &parameter );

  return OFDPE_SUCCESS;
}
OFDPE ( *send_for_notify_port_config )( uint32_t port_no, uint8_t reason ) = _send_for_notify_port_config;


static void
calc_bitrate_device( switch_port *port, void *user_data ) {
  UNUSED( user_data );
  assert( port != NULL );
  assert( port->device != NULL );

  ether_device *device = port->device;

  struct timespec now_time;
  struct timespec diff;
  time_now( &now_time );
  timespec_diff( device->status.pre_calc, now_time, &diff );

  uint64_t tx_bits = device->status.tx_bytes * 8;
  double diff_sec = ( double ) diff.tv_sec + ( ( double ) diff.tv_nsec / 1000000000.0 );
  double bitrate = ( double ) tx_bits / diff_sec / 1024.0;

  device->status.curr_speed = ( uint32_t ) bitrate;
  if ( device->status.max_speed < ( uint32_t ) bitrate ) {
    device->status.max_speed = ( uint32_t ) bitrate;
  }

  //  debug ("diff_sec=%f", diff_sec);
  //  debug ("tx_bits=%u", tx_bits);
  //  debug ("bitrate=%f", bitrate);
  //  debug ("curr_speed=%u", device->status.curr_speed);
  //  debug ("max_speed=%u", device->status.max_speed);

  device->status.tx_bytes = 0;
  time_now( &device->status.pre_calc );

  return;
}


/**
 * calculate all devices bitrate 
 *
 * param nothing
 * return success/failed
 */
OFDPE
calc_bitrate_all_device( void ) {
  foreach_switch_port( calc_bitrate_device, NULL );

  return OFDPE_SUCCESS;
}


/**
 * check for registerd switch port number
 *
 * param switch port number
 * return registerd/no registerd
 */
static bool
_is_valid_port_no( const uint32_t port_no ) {
  if ( port_no > OFPP_MAX ) {
    return true;
  }

  if ( lookup_switch_port( port_no ) != NULL ) {
    return true;
  }
  else {
    return false;
  }
}
bool ( *is_valid_port_no )( const uint32_t port_no ) = _is_valid_port_no;


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
