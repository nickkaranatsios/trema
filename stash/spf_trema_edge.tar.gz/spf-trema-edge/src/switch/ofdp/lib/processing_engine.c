/*
 * Functions for pipline processing.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include "processing_engine.h"
#include "packet_forwarder.h"
#include "table_manager.h"
#include "action_executor.h"
#include "packet_matcher.h"
#include "port_manager.h"
#include "controller_manager.h"
#include "packet_info.h"
#include "wrapper.h"
#include "ofdp.h"


/***************************************
 static
 ***************************************/
static void
clear_action_set( action_set *set ) {
  set->copy_ttl_in = NULL;
  set->copy_ttl_out = NULL;
  set->dec_mpls_ttl = NULL;
  set->dec_nw_ttl = NULL;
  set->group = NULL;
  set->output = NULL;
  set->pop_mpls = NULL;
  set->pop_pbb = NULL;
  set->pop_vlan = NULL;
  set->push_mpls = NULL;
  set->push_pbb = NULL;
  set->push_vlan = NULL;
  set->set_field = NULL;
  set->set_mpls_ttl = NULL;
  set->set_nw_ttl = NULL;
  set->set_queue = NULL;
}


static OFDPE
write_action_set( action_list *p_action_list, action_set *set ) {
  assert( p_action_list != NULL );
  assert( set != NULL );

  for ( action_list *element = p_action_list; element != NULL; element = element->next ) {
    action *act = element->node;
    if ( act == NULL ) {
      continue;
    }

    debug( "write_action_set: action type = %d", act->type );

    switch ( act->type ) {
    case OFPAT_OUTPUT:
      set->output = act;
      break;

    case OFPAT_COPY_TTL_OUT:
      set->copy_ttl_out = act;
      break;

    case OFPAT_COPY_TTL_IN:
      set->copy_ttl_in = act;
      break;

    case OFPAT_SET_MPLS_TTL:
      set->set_mpls_ttl = act;
      break;

    case OFPAT_DEC_MPLS_TTL:
      set->dec_mpls_ttl = act;
      break;

    case OFPAT_PUSH_VLAN:
      set->push_vlan = act;
      break;

    case OFPAT_POP_VLAN:
      set->pop_vlan = act;
      break;

    case OFPAT_PUSH_MPLS:
      set->push_mpls = act;
      break;

    case OFPAT_POP_MPLS:
      set->pop_mpls = act;
      break;

    case OFPAT_SET_QUEUE:
      set->set_queue = act;
      break;

    case OFPAT_GROUP:
      set->group = act;
      break;

    case OFPAT_SET_NW_TTL:
      set->set_nw_ttl = act;
      break;

    case OFPAT_DEC_NW_TTL:
      set->dec_nw_ttl = act;
      break;

    case OFPAT_SET_FIELD:
      set->set_field = act;
      break;

    case OFPAT_PUSH_PBB:
      set->push_pbb = act;
      break;

    case OFPAT_POP_PBB:
      set->pop_pbb = act;
      break;

    case OFPAT_EXPERIMENTER:
      warn( "Don't supported action type(=OFPAT_SET_QUEUE)" );
      return ERROR_NO_SUPPORTED;

    default:
      warn( "Illegal action type(=%04x)", act->type );
      return ERROR_ILLEGAL_PARAMETER;
    }
  }

  return OFDPE_SUCCESS;
}


static OFDPE
apply_instructions( flow_entry *entry, buffer *parsed_packet, action_set *set, uint8_t *next_table_id ) {
  OFDPE ret = OFDPE_SUCCESS;

  for ( instruction_list *element = entry->instructions; element != NULL; element = element->next ) {
    instruction *inst = element->node;

    if ( inst == NULL ) {
      continue;
    }


    switch ( inst->type ) {
    case OFPIT_GOTO_TABLE:
      debug( "execute apply instructions(OFPIT_GOTO_TABLE)" );
      *next_table_id = inst->table_id;
      break;

    case OFPIT_WRITE_METADATA:
      debug( "execute apply instructions(OFPIT_WRITE_METADATA)" );
      ( ( packet_info * ) parsed_packet->user_data )->metadata = ( inst->metadata & inst->metadata_mask );
      break;

    case OFPIT_WRITE_ACTIONS:
      debug( "execute apply instructions(OFPIT_WRITE_ACTIONS)" );
      ret = write_action_set( inst->p_action_list, set );
      if ( ret != OFDPE_SUCCESS ) {
        warn( "write action set is failed." );
        return ret;
      }
      break;

    case OFPIT_APPLY_ACTIONS:
      debug( "execute apply instructions(OFPIT_APPLY_ACTIONS)" );
      ret = execute_action_list( inst->p_action_list, parsed_packet );
      if ( ret != OFDPE_SUCCESS ) {
        warn( "apply action is failed." );
        return ret;
      }
      break;

    case OFPIT_CLEAR_ACTIONS:
      debug( "execute apply instructions(OFPIT_CLEAR_ACTIONS)" );
      clear_action_set( set );
      break;

    case OFPIT_METER:
      debug( "execute apply instructions(OFPIT_METER)" );
      warn( "Unsupported instruction type(=OFPIT_METER)" );
      return ERROR_NO_SUPPORTED;

    case OFPIT_EXPERIMENTER:
      debug( "execute apply instructions(OFPIT_EXPERIMENTER)" );
      warn( "Unsupported instruction type(=OFPIT_EXPERIMENTER)" );
      return ERROR_NO_SUPPORTED;

    default:
      warn( "Illegal inst type(=%04x)", inst->type );
      return ERROR_ILLEGAL_PARAMETER;
    }
  }

  return ret;
}


/**
 * initialize processing engine
 *
 * param nothing
 * return success/failed
 */
OFDPE
init_processing_engine( void ) {
  return OFDPE_SUCCESS;
}


/**
 * finalize processing engine
 *
 * param nothing
 * return success/failed
 */
OFDPE
finalize_processing_engine( void ) {
  return OFDPE_SUCCESS;
}


/**
 * execute pipeline processing
 *
 * param recveive switch port number
 * param recveive buffer data (must operated packet parsing) 
 * return nothing
 */
static void
_execute_processing( switch_port *port, buffer *parsed_buf ) {
  assert( port != NULL );
  assert( parsed_buf != NULL );
  assert( match_entry_fetcher != NULL );
  assert( execute_action_set != NULL );

  uint8_t table_id = 0;
  uint8_t next_table_id = MAX_FLOW_TABLE;
  action_set set;
  clear_action_set( &set );

  OFDPE ret = OFDPE_SUCCESS;

  for ( ;; ) {
    flow_entry *entry = match_entry_fetcher( parsed_buf, table_id );
    if ( entry == NULL ) {
      debug( "table missed. table id = %d", table_id );

      notify_parameter_packet_in parameter;
      parameter.buffer_id = 0;
      parameter.cookie = 0;
      parameter.max_len = MISS_SEND_LEN;
      parameter.packet = parsed_buf;
      parameter.reason = OFPR_NO_MATCH;
      parameter.table_id = table_id;
      uint32_t eth_in_port = ( ( packet_info * ) parsed_buf->user_data )->eth_in_port;
      uint32_t eth_in_phy_port = ( ( packet_info * ) parsed_buf->user_data )->eth_in_phy_port;
      parameter.match.in_port.value = eth_in_port;
      parameter.match.in_port.valid = true;
      if ( eth_in_port != eth_in_phy_port ) {
        parameter.match.in_phy_port.value = eth_in_phy_port;
        parameter.match.in_phy_port.valid = true;
      }
      notify_packet_in( &parameter );

      increment_port_tx_dropped( ( ( packet_info * ) parsed_buf->user_data )->eth_in_port );
      return;
    }
    debug( "match packet. table id=%d", table_id );

    next_table_id = MAX_FLOW_TABLE;
    ret = apply_instructions( entry, parsed_buf, &set, &next_table_id );
    if ( ret != OFDPE_SUCCESS ) {
      warn( "apply instructions failed." );

      if ( ret >= ERROR_OFDPE_ERROR_START ) {
        send_for_notify_error( ret, parsed_buf );
      }

      increment_port_tx_dropped( ( ( packet_info * ) parsed_buf->user_data )->eth_in_port );
      return;
    }

    if ( next_table_id == MAX_FLOW_TABLE ) {
      debug( "finish pipeline processing." );
      break;
    }

    if ( table_id >= next_table_id ) {
      warn( "goto-table-id is smaller(%d->%d)", table_id, next_table_id );
      return;
    }

    table_id = next_table_id;
  }

  ret = execute_action_set( &set, parsed_buf );
  if ( ret != OFDPE_SUCCESS ) {
    warn( "apply instructions failed." );

    if ( ret >= ERROR_OFDPE_ERROR_START ) {
      send_for_notify_error( ret, parsed_buf );
    }

    increment_port_tx_dropped( ( ( packet_info * ) parsed_buf->user_data )->eth_in_port );
    return;
  }

  return;
}
void ( *execute_processing )( switch_port *port, buffer *parsed_buf ) = _execute_processing;


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
