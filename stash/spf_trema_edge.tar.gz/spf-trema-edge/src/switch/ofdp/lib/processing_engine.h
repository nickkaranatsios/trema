/*
 * Functions for pipline processing.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef PROCESSING_ENGINE_H
#define PROCESSING_ENGINE_H


#include "ofdp_common.h"
#include "buffer.h"
#include "switch_port.h"


OFDPE init_processing_engine( void );
OFDPE finalize_processing_engine( void );
void ( *execute_processing )( switch_port *port, buffer *frame );


#endif  // PROCESSING_ENGINE_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
