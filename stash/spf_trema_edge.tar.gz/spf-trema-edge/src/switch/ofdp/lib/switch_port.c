/*
 * Functions for managing switch ports.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include <assert.h>
#include <inttypes.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include "ether_device.h"
#include "switch_port.h"
#include "openflow.h"
#include "hash_table.h"
#include "log.h"
#include "wrapper.h"


#ifdef UNIT_TESTING


#define static
#ifdef create_ether_device
#undef create_ether_device
#endif
#define create_ether_device mock_create_ether_device
ether_device * mock_create_ether_device( const char *name, const size_t max_send_queue, const size_t max_recv_queue );


#endif // UNIT_TESTING


static hash_table *switch_ports = NULL;


static bool
compare_switch_port( const void *x, const void *y ) {
  return ( *( const uint16_t * ) x  == *( const uint16_t * ) y ) ? true : false;
}


static unsigned int
hash_switch_port( const void *key ) {
  return *( const uint16_t * ) key;
}


void
init_switch_port() {
  assert( switch_ports == NULL );

  switch_ports = create_hash_with_size( compare_switch_port, hash_switch_port, 64 );
}


void
finalize_switch_port() {
  assert( switch_ports != NULL );

  hash_iterator iter;
  hash_entry *e;
  init_hash_iterator( switch_ports, &iter );
  while ( ( e = iterate_hash_next( &iter ) ) != NULL ) {
    switch_port *port = delete_hash_entry( switch_ports, e->key );
    if ( port == NULL ) {
      continue;
    }

    if ( port->device != NULL ) {
      delete_ether_device( port->device );
    }
    xfree( port );
  }
  delete_hash( switch_ports );
  switch_ports = NULL;
}


switch_port *
lookup_switch_port( uint32_t port_no ) {
  assert( switch_ports != NULL );

  return lookup_hash_entry( switch_ports, &port_no );
}


switch_port *
delete_switch_port( uint32_t port_no ) {
  assert( switch_ports != NULL );

  return delete_hash_entry( switch_ports, &port_no );
}


void
foreach_switch_port( switch_port_walker callback, void *user_data ) {
  hash_iterator iter;
  hash_entry *e;

  init_hash_iterator( switch_ports, &iter );
  while ( ( e = iterate_hash_next( &iter ) ) != NULL ) {
    if ( e->value != NULL ) {
      callback( e->value, user_data );
    }
  }
}


switch_port *
add_switch_port( const char *interface, uint32_t port_no, const size_t max_send_queue, const size_t max_recv_queue ) {
  assert( interface != NULL );
  assert( switch_ports != NULL );

  switch_port *port = ( switch_port * ) xmalloc( sizeof( switch_port ) );
  memset( port, 0, sizeof( switch_port ) );
  port->port_no = port_no;
  port->device = create_ether_device( interface, max_send_queue, max_recv_queue );
  if ( port->device == NULL ) {
    xfree( port );
    return NULL;
  }

  insert_hash_entry( switch_ports, port, port );

  return port;
}


bool
update_switch_port_status( switch_port *port ) {
  assert( port != NULL );
  assert( port->device != NULL );

  bool ret = update_device_status( port->device );
  if ( ret == false ) {
    return false;
  }

  bool updated = false;
  if ( ( ( port->status.state & OFPPS_LINK_DOWN ) != 0 ) && ( port->device->status.up == true ) ) {
    updated = true;
    port->status.state &= ~( ( uint32_t ) OFPPS_LINK_DOWN );
  }
  else if ( ( ( port->status.state & OFPPS_LINK_DOWN ) == 0 ) && ( port->device->status.up == false ) ) {
    updated = true;
    port->status.state |= OFPPS_LINK_DOWN;
  }
  if ( port->status.curr != port->device->status.curr ) {
    updated = true;
    port->status.curr = port->device->status.curr;
  }
  if ( port->status.advertised != port->device->status.advertised ) {
    updated = true;
    port->status.advertised = port->device->status.advertised;
  }
  if ( port->status.supported != port->device->status.supported ) {
    updated = true;
    port->status.supported = port->device->status.supported;
  }
  if ( port->status.peer != port->device->status.peer ) {
    updated = true;
    port->status.peer = port->device->status.peer;
  }

  return updated;
}


bool
update_switch_port_config( switch_port *port, uint32_t config, uint32_t mask ) {
  assert( port != NULL );

  if ( !( mask & ( OFPPC_PORT_DOWN | OFPPC_NO_RECV |  OFPPC_NO_FWD | OFPPC_NO_PACKET_IN ) ) ) {
    error( "Unsupported config flags ( port_no = %u, config = %#x, mask = %#x ).",
      port->port_no, config, mask );
    return false;
  }

  mask = mask & ( config ^ port->config );

  if ( mask & OFPPC_PORT_DOWN ) {
    if ( config & OFPPC_PORT_DOWN ) {
      if ( down_ether_device( port->device ) ) {
        port->config |= OFPPC_PORT_DOWN;
      }
      else {
        error( "Failed to down a switch port ( port_no = %u ).", port->port_no );
        return false;
      }
    }
    else {
      if ( up_ether_device( port->device ) ) {
        port->config &= ( uint32_t ) ~OFPPC_PORT_DOWN;
      }
      else {
        error( "Failed to up a switch port ( port_no = %u ).", port->port_no );
        return false;
      }
    }
  }

  if ( mask & OFPPC_NO_RECV ) {
    if ( config & OFPPC_NO_RECV ) {
      port->config |= OFPPC_NO_RECV;
    }
    else {
      port->config &= ( uint32_t ) ~OFPPC_NO_RECV;
    }
  }

  if ( mask & OFPPC_NO_FWD ) {
    if ( config & OFPPC_NO_FWD ) {
      port->config |= OFPPC_NO_FWD;
    }
    else {
      port->config &= ( uint32_t ) ~OFPPC_NO_FWD;
    }
  }

  if ( mask & OFPPC_NO_PACKET_IN ) {
    if ( config & OFPPC_NO_PACKET_IN ) {
      port->config |= OFPPC_NO_PACKET_IN;
    }
    else {
      port->config &= ( uint32_t ) ~OFPPC_NO_PACKET_IN;
    }
  }

  return true;
}


void
switch_port_to_ofp_phy_port( struct ofp_port *phy_port, const switch_port *port ) {
  assert( port != NULL );
  assert( port->device != NULL );
  assert( phy_port != NULL );

  memset( phy_port, 0, sizeof( struct ofp_port ) );

  phy_port->port_no = port->port_no;
  memcpy( phy_port->hw_addr, port->device->hw_addr, OFP_ETH_ALEN );
  strncpy( phy_port->name, port->device->name, OFP_MAX_PORT_NAME_LEN );
  phy_port->name[ OFP_MAX_PORT_NAME_LEN - 1 ] = '\0';
  phy_port->state = port->status.state;
  phy_port->config = port->config;
  phy_port->curr = port->status.curr;
  phy_port->advertised = port->status.advertised;
  phy_port->supported = port->status.supported;
  phy_port->peer = port->status.peer;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
