/*
 * Functions for managing flow tables.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include "ofdp_common.h"
#include "table_manager_flow.h"
#include "table_manager_group.h"
#include "wrapper.h"


static pthread_mutex_t pipeline_mutex;


/***************************************
  for unit test
***************************************/
#ifdef UNIT_TESTING
#include "test_mocks.h"
#endif /* UNIT_TESTING */


static OFDPE
init_pipeline( void ) {
  for ( uint8_t i = 0; i < MAX_FLOW_TABLE; i++ ) {
    init_flow_table( i );
  }
  return OFDPE_SUCCESS;
}


static OFDPE
finalize_pipeline( void ) {
  for ( uint8_t i = 0; i < MAX_FLOW_TABLE; i++ ) {
    finalize_flow_table( i );
  }
  return OFDPE_SUCCESS;
}


/**
 * Initialize Table Manager
 * return OFDPE type information
 */
OFDPE
init_table_manager( void ) {
  init_pipeline();
  init_group_table();
  return OFDPE_SUCCESS;
}


/**
 * finalize Table Manager
 * return OFDPE type information
 */
OFDPE
finalize_table_manager( void ) {
  finalize_group_table();
  finalize_pipeline();
  return OFDPE_SUCCESS;
}


/**
 * Append Instruction to Pipeline
 * param table_id Flow Table Id
 * param entry to the entry to be appended instruction
 * param p_instruction pointer for Instruction List to be appended to flow entry
 * return
 */
OFDPE
append_instruction_to_pipeline( const uint8_t table_id, flow_entry *entry, instruction *p_instruction ) {
  flow_entry *target;

  target = lookup_flow_entry( table_id, entry->p_match );
  if ( target == NULL ) {
    return false;
  }
  bool retval = append_instruction( target->instructions, p_instruction );
  return retval;
}


/**
 * Apoend Action to Pipeline
 * param table_id Flow Table ID
 * param entry to the entry to be appended instruction
 * param instruction_type pointer for Instruction List
 * param p_action pointer for Action  List to be appended to flow entry
 * return
 */
OFDPE
append_action_to_pipeline( const uint8_t table_id, flow_entry *entry, const uint8_t instruction_type, action *action ) {
  flow_entry *target;

  target = lookup_flow_entry( table_id, entry->p_match );
  if ( target == NULL ) {
    return OFDPE_FAILED;
  }
  dlist_element *element;
  instruction *instruction = NULL;
  for( element = target->instructions; element != NULL; element = element->next ) {
    instruction = element->data;
    if ( instruction == NULL ) {
      return OFDPE_FAILED;
    }
    if ( instruction->type == instruction_type ) {
      break;
    }
  }
  if ( instruction != NULL ) {
    dlist_element *action_element = instruction->action_list;
    if ( action_element == NULL ) {
      return OFDPE_FAILED;
    }
    append_action( action_element, action );
  }
  return OFDPE_SUCCESS;
}


/**
 * Create Flow entry and append to pipeline
 * param table_id table ID
 * param p_match pointer for match structure
 * param instructions pointer for instructions list
 * param priority flow entry priority
 * param idle_timeout flow entry timeout
 * param hard_timeout flow entry timeout
 * param flags flags of flow entry
 * param cookie cookie of flow entry
 * return
 */
OFDPE
create_flow_entry_to_pipeline( const uint8_t table_id, match *p_match,
  instruction_list *instructions, const uint16_t priority,
  const uint16_t idle_timeout, const uint16_t hard_timeout, const uint16_t flags,
  const uint64_t cookie ) {
  if ( !validate_match( p_match ) ) {
    return OFDPE_FAILED;
  }

  flow_entry *entry = NULL;
  entry = create_flow_entry( p_match, instructions, priority, idle_timeout, hard_timeout, flags, cookie );

  return append_flow_entry( table_id, entry );
}


bool
init_pipeline_lock( void ) {
  pthread_mutex_init( &pipeline_mutex, NULL );
  return true;
}


bool
finalize_pipeline_lock( void ) {
  int retval = pthread_mutex_destroy( &pipeline_mutex );

  if ( retval == 0 ) { // succeed
    return true;
  }
  return false;
}


bool
lock_pipeline( void ) {
  int retval = pthread_mutex_lock( &pipeline_mutex );

  if ( retval == 0 ) { // succeed
    return true;
  }
  return false;
}


bool
unlock_pipeline( void ) {
  int retval = pthread_mutex_unlock( &pipeline_mutex );

  if ( retval == 0 ) { // succeed
    return true;
  }
  return false;
}


bool
trylock_pipeline( void ) {
  int retval = pthread_mutex_trylock( &pipeline_mutex );

  if ( retval == 0 ) { // succeed
    return true;
  }
  return false;
}

/**
 * Get Flow Table features
 * param table_id Table ID
 * param stats Pointer for save flow table features
 * return
 */
OFDPE
get_table_features( const uint8_t table_id, table_features **stats ) {
  if ( stats == NULL ) {
    return ERROR_ILLEGAL_PARAMETER;
  }
  *stats = NULL;
  table_features *retval = xmalloc( sizeof( table_features ) );
  if ( retval == NULL ) {
    return ERROR_NO_MEMORY;
  }

  flow_table *table = _get_flow_table( table_id );
  if ( table == NULL ) {
    xfree( retval );
    return ERROR_OFDPE_BAD_REQUEST_BAD_TABLE_ID;
  }

  memcpy( retval, &( table->features ), sizeof( table_features ) );
  *stats = retval;
  return OFDPE_SUCCESS;
}


OFDPE
set_table_features( const table_features *features ) {
  if ( features == NULL ) {
    return ERROR_ILLEGAL_PARAMETER;
  }
  return ERROR_NO_SUPPORTED;
  //  uint8_t table_id = features->table_id;
  //  memcpy(&(flow_pipeline[table_id].features), features, sizeof(table_features));
  //  return OFDPE_SUCCESS;
}


static const char*
get_bool_string( bool b ) {
  return b ? "true" : "false";
}


static void
dump_instructions_capabilities( const char* name, const instructions_capabilities *capabilities ) {
  assert( name != NULL );
  assert( capabilities != NULL );

  debug( "----- %s -----", name );
  debug( "meter = %s", get_bool_string( capabilities->meter ) );
  debug( "apply_actions = %s", get_bool_string( capabilities->apply_actions ) );
  debug( "clear_actions = %s", get_bool_string( capabilities->clear_actions ) );
  debug( "write_actions = %s", get_bool_string( capabilities->write_actions ) );
  debug( "write_metadata = %s", get_bool_string( capabilities->write_metadata ) );
  debug( "goto_table = %s", get_bool_string( capabilities->goto_table ) );
  return;
}


static void
dump_actions_capabilities( const char* name, const actions_capabilities *capabilities ) {
  assert( name != NULL );
  assert( capabilities != NULL );

  debug( "----- %s -----", name );
  debug( "output = %s", get_bool_string( capabilities->output ) );
  debug( "set_queue = %s", get_bool_string( capabilities->set_queue ) );
  debug( "drop = %s", get_bool_string( capabilities->drop ) );
  debug( "group = %s", get_bool_string( capabilities->group ) );
  debug( "push_vlan = %s", get_bool_string( capabilities->push_vlan ) );
  debug( "push_mpls = %s", get_bool_string( capabilities->push_mpls ) );
  debug( "pop_mpls = %s", get_bool_string( capabilities->pop_mpls ) );
  debug( "push_pbb = %s", get_bool_string( capabilities->push_pbb ) );
  debug( "pop_pbb = %s", get_bool_string( capabilities->pop_pbb ) );
  return;
}


static void
dump_match_capabilities( const char* name, const match_capabilities *capabilities ) {
  assert( name != NULL );
  assert( capabilities != NULL );

  debug( "----- %s -----", name );
  debug( "in_port = %s", get_bool_string( capabilities->in_port ) );
  debug( "in_phy_port = %s", get_bool_string( capabilities->in_phy_port ) );
  debug( "metadata = %s", get_bool_string( capabilities->metadata ) );

  debug( "eth_dst = %s", get_bool_string( capabilities->eth_dst ) );
  debug( "eth_src = %s", get_bool_string( capabilities->eth_src ) );
  debug( "eth_type = %s", get_bool_string( capabilities->eth_type ) );

  debug( "vlan_vid = %s", get_bool_string( capabilities->vlan_vid ) );
  debug( "vlan_pcp = %s", get_bool_string( capabilities->vlan_pcp ) );

  debug( "ip_dscp = %s", get_bool_string( capabilities->ip_dscp ) );
  debug( "ip_ecn = %s", get_bool_string( capabilities->ip_ecn ) );
  debug( "ip_proto = %s", get_bool_string( capabilities->ip_proto ) );
  debug( "ipv4_src = %s", get_bool_string( capabilities->ipv4_src ) );
  debug( "ipv4_dst = %s", get_bool_string( capabilities->ipv4_dst ) );

  debug( "tcp_src = %s", get_bool_string( capabilities->tcp_src ) );
  debug( "tcp_dst = %s", get_bool_string( capabilities->tcp_dst ) );

  debug( "udp_src = %s", get_bool_string( capabilities->udp_src ) );
  debug( "udp_dst = %s", get_bool_string( capabilities->udp_dst ) );

  debug( "sctp_src = %s", get_bool_string( capabilities->sctp_src ) );
  debug( "sctp_dst = %s", get_bool_string( capabilities->sctp_dst ) );

  debug( "icmpv4_type = %s", get_bool_string( capabilities->icmpv4_type ) );
  debug( "icmpv4_code = %s", get_bool_string( capabilities->icmpv4_code ) );
  debug( "arp_op = %s", get_bool_string( capabilities->arp_op ) );
  debug( "arp_spa = %s", get_bool_string( capabilities->arp_spa ) );
  debug( "arp_tpa = %s", get_bool_string( capabilities->arp_tpa ) );
  debug( "arp_sha = %s", get_bool_string( capabilities->arp_sha ) );
  debug( "arp_tha = %s", get_bool_string( capabilities->arp_tha ) );

  debug( "ipv6_src = %s", get_bool_string( capabilities->ipv6_src ) );
  debug( "ipv6_dst = %s", get_bool_string( capabilities->ipv6_dst ) );
  debug( "ipv6_flabel = %s", get_bool_string( capabilities->ipv6_flabel ) );

  debug( "icmpv6_type = %s", get_bool_string( capabilities->icmpv6_type ) );
  debug( "icmpv6_code = %s", get_bool_string( capabilities->icmpv6_code ) );

  debug( "ipv6_nd_target = %s", get_bool_string( capabilities->ipv6_nd_target ) );
  debug( "ipv6_nd_sll = %s", get_bool_string( capabilities->ipv6_nd_sll ) );
  debug( "ipv6_nd_tll = %s", get_bool_string( capabilities->ipv6_nd_tll ) );

  debug( "mpls_label = %s", get_bool_string( capabilities->mpls_label ) );
  debug( "mpls_tc = %s", get_bool_string( capabilities->mpls_tc ) );
  debug( "mpls_bos = %s", get_bool_string( capabilities->mpls_bos ) );

  debug( "pbb_isid = %s", get_bool_string( capabilities->pbb_isid ) );
  debug( "tunnel_id = %s", get_bool_string( capabilities->tunnel_id ) );
  debug( "ipv6_exthdr = %s", get_bool_string( capabilities->ipv6_exthdr ) );
  return;
}


void
dump_table_features( const table_features *features ) {
  if ( features == NULL ) {
    return;
  }
  debug( "***** table features *****" );
  debug( "table_id = %u", features->table_id );
  debug( "name = %s", features->name );
  debug( "metadata_match = %zu", features->metadata_match );
  debug( "metadata_write = %zu", features->metadata_write );
  debug( "config = %x", features->config );
  debug( "max_entries = %u", features->max_entries );

  dump_instructions_capabilities( "instructions", &features->instructions );
  dump_instructions_capabilities( "instructions_miss", &features->instructions_miss );

  debug( "min_next_table_ids = %x", features->min_next_table_ids );
  debug( "min_next_table_ids_miss = %u", features->min_next_table_ids_miss );

  dump_actions_capabilities( "write_actions", &features->write_actions );
  dump_actions_capabilities( "write_actions_miss", &features->write_actions_miss );
  dump_actions_capabilities( "apply_actions", &features->apply_actions );
  dump_actions_capabilities( "apply_actions_miss", &features->apply_actions_miss );

  dump_match_capabilities( "matches", &features->matches );
  dump_match_capabilities( "wildcards", &features->wildcards );
  dump_match_capabilities( "write_setfield", &features->write_setfield );
  dump_match_capabilities( "write_setfield_miss", &features->write_setfield_miss );
  dump_match_capabilities( "apply_setfield", &features->apply_setfield );
  dump_match_capabilities( "apply_setfield_miss", &features->apply_setfield_miss );
  return;
}


/**
 * Get Flow table configuration
 * param table_id Table ID
 * param config pointer for save flow table configuration
 * return
 */
OFDPE
get_table_configuration( const uint8_t table_id, ofp_table_mod **config ) {
  ofp_table_mod *retval = xmalloc( sizeof( ofp_table_mod ) );

  if ( retval == NULL ) {
    return ERROR_NO_MEMORY;
  }
  retval->header.length = sizeof( ofp_table_mod );
  retval->header.type = OFPT_TABLE_MOD;
  retval->header.version = OFP_VERSION;
  retval->header.xid = 0;
  retval->table_id = table_id;
  retval->config = 0;

  *config = retval;

  return OFDPE_SUCCESS;
}


static OFDPE
set_one_table_configuration( const uint8_t table_id, const ofp_table_mod *config ) {
  UNUSED( table_id );
  UNUSED( config );
  return ERROR_NO_SUPPORTED;
}


OFDPE
set_table_configuration( const ofp_table_mod *config ) {
  if ( config->table_id == OFPTT_ALL ) {
    for ( uint8_t i = 0; i < MAX_FLOW_TABLE; i++ ) {
      OFDPE retval = set_one_table_configuration( i, config );
      if ( retval != OFDPE_SUCCESS ) {
        return retval;
      }
    }
    return OFDPE_SUCCESS;
  }
  else {
    OFDPE retval = set_one_table_configuration( config->table_id, config );
    return retval;
  }
}

void
dump_table_configuration( const ofp_table_mod *config ) {
  if ( config == NULL ) {
    return;
  }
  debug( "***** table config *****" );
  debug( "table_id = %u", config->table_id );
  debug( "config = 0x%x", config->config );
  return;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
