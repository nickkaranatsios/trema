/*
 * Functions for managing flow tables.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef TABLEMANAGER_H
#define TABLEMANAGER_H


#include "ofdp_common.h"
#include "wrapper.h"
#include "table_manager_group.h"
#include "table_manager_flow.h"

// Manipulate Table Manager & Flow Pipeline
OFDPE init_table_manager( void );
OFDPE finalize_table_manager( void );


// Manipulate Pipeline ( append / create entry/instruction/action to pipeline )
#define append_entry_to_pipeline( table_id, entry ) append_flow_entry( table_id, entry )
OFDPE create_flow_entry_to_pipeline( const uint8_t table_id, match *p_match,
  instruction_list *instructions, const uint16_t priority,
  const uint16_t idle_timeout, const uint16_t hard_timeout, const uint16_t flags,
  const uint64_t cookie );
OFDPE append_instruction_to_pipeline( const uint8_t table_id, flow_entry *entry, instruction *p_instruction );
OFDPE append_action_to_pipeline( const uint8_t table_id, flow_entry *entry, const uint8_t instruction_type, action *p_action );


// Get Features & Configurations
OFDPE get_table_features( const uint8_t table_id, table_features **stats );
OFDPE set_table_features( const table_features *features );
void dump_table_features( const table_features *features );
OFDPE get_table_configuration( const uint8_t table_id, ofp_table_mod **config );
OFDPE set_table_configuration( const ofp_table_mod *config );
void dump_table_configuration( const ofp_table_mod *config );


// Pipeline Read/Write Lock (sync)
bool init_pipeline_lock( void );
bool finalize_pipeline_lock( void );
bool lock_pipeline( void );
bool unlock_pipeline( void );
bool trylock_pipeline( void );


#endif // TABLEMANAGER_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
