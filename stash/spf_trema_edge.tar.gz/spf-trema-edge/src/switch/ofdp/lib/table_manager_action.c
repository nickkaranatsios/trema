/*
 * Functions for managing flow entry actions.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include "table_manager_action.h"
#include "table_manager_group.h"
#include "log.h"
#include "openflow.h"
#include "port_manager.h"
#include "wrapper.h"


#ifdef UNIT_TESTING


#define static
#ifdef is_valid_port_no
#undef is_valid_port_no
#endif
#define is_valid_port_no mock_is_valid_port_no
bool mock_is_valid_port_no( const uint32_t port_no );


#endif // UNIT_TESTING


static action *
malloc_action_memory() {
  action *p_action = ( struct _action * ) ( xcalloc( 1, sizeof( struct _action ) ) );

  if ( p_action == NULL ) {
    critical( "failed malloc at File: __FILE__, Line: __LINE__\n" );
    return NULL;
  }
  return p_action;
}


/**
 * create OUTPUT action
 *
 * param port port number of OUTPUT Action
 * param max_len maximum output length of output
 * return poitner for action
 */
action *
create_action_output( const uint32_t port, const uint16_t max_len ) {
  action *p_action = malloc_action_memory();

  if ( p_action == NULL ) {
    return NULL;
  }
#ifndef UNIT_TESTING
  if ( !is_valid_port_no( port ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_ACTION_BAD_OUT_PORT, NULL );
    return NULL;
  }
#endif

  p_action->type = OFPAT_OUTPUT;
  p_action->port = port;
  p_action->max_len = max_len;

  return p_action;
}

/**
 * create GROUP action
 *
 * param group_id group number of GROUP action
 * return pointer for action
 */
action *
create_action_group( const uint32_t group_id ) {
  action *p_action = malloc_action_memory();

  if ( p_action == NULL ) {
    return NULL;
  }

#ifndef UNIT_TESTING
  if ( !is_valid_group_no( group_id ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_ACTION_BAD_OUT_GROUP, NULL );
    return NULL;
  }
#endif

  p_action->type = OFPAT_GROUP;
  p_action->group_id = group_id;
  group_reference_count_inc( group_id );

  return p_action;
}

/**
 * create SET QUEUE Action
 *
 * param queue_id queue id for SET QUEUE
 * return pointer for action
 */
action *
create_action_set_queue( const uint32_t queue_id ) {
  action *p_action = malloc_action_memory();

  if ( p_action == NULL ) {
    return NULL;
  }

  //  send_for_notify_error(ERROR_OFDPE_BAD_ACTION_BAD_QUEUE, NULL);
  //  return NULL;

  p_action->type = OFPAT_SET_QUEUE;
  p_action->queue_id = queue_id;

  return p_action;
}

/**
 * Create SET MPLS TTL Action
 *
 * param mpls_ttl MPLS TTL Value
 * return pointer for action
 */action *
create_action_set_mpls_ttl( const uint8_t mpls_ttl ) {
  action *p_action = malloc_action_memory();

  if ( p_action == NULL ) {
    return NULL;
  }

  p_action->type = OFPAT_SET_MPLS_TTL;
  p_action->mpls_ttl = mpls_ttl;

  return p_action;
}

/**
 * Create DECREMENT MPLS TTL Action
 * param none
 * return pointer for action
 */
action *
create_action_decr_mpls_ttl( void ) {
  action *p_action = malloc_action_memory();

  if ( p_action == NULL ) {
    return NULL;
  }

  p_action->type = OFPAT_DEC_MPLS_TTL;

  return p_action;
}


/**
 * create SET IPv4 TTL Action
 *
 * param nw_ttl IPv4 TTL value
 * return pointer for action
 */
action *
create_action_set_ipv4_ttl( const uint8_t nw_ttl ) {
  action *p_action = malloc_action_memory();

  if ( p_action == NULL ) {
    return NULL;
  }

  p_action->type = OFPAT_SET_NW_TTL;
  p_action->nw_ttl = nw_ttl;

  return p_action;
}

/**
 * create Decrement IPv4 TTL Action
 *
 * param none
 * return pointer for action
 */
action *
create_action_decr_ipv4_ttl( void ) {
  action *p_action = malloc_action_memory();

  if ( p_action == NULL ) {
    return NULL;
  }

  p_action->type = OFPAT_DEC_NW_TTL;

  return p_action;
}

/**
 * create COPY TTL OUTWARDS Action
 *
 * param none
 * return pointer for action
 */
action *
create_action_copy_ttl_out( void ) {
  action *p_action = malloc_action_memory();

  if ( p_action == NULL ) {
    return NULL;
  }

  p_action->type = OFPAT_COPY_TTL_OUT;

  return p_action;
}

/**
 * create COPY TTL INWARDS ACtion
 *
 * param none
 * return pointer for action
 */
action *
create_action_copy_ttl_in( void ) {
  action *p_action = malloc_action_memory();

  if ( p_action == NULL ) {
    return NULL;
  }

  p_action->type = OFPAT_COPY_TTL_IN;

  return p_action;
}

/**
 * create PUSH VLAN Action
 *
 * param ethertype VLAN ether protocol type
 * return pointer for action
 */
action *
create_action_push_vlan( const uint16_t ethertype ) {
  action *p_action = malloc_action_memory();

  if ( p_action == NULL ) {
    return NULL;
  }

  p_action->type = OFPAT_PUSH_VLAN;
  p_action->ethertype = ethertype;
  return p_action;
}

/**
 * Create PUSH MPLS Action
 *
 * param ethertype MPLS ether protocol type
 * return pointer for action
 */
action *
create_action_push_mpls( const uint16_t ethertype ) {
  action *p_action = malloc_action_memory();

  if ( p_action == NULL ) {
    return NULL;
  }

  p_action->type = OFPAT_PUSH_MPLS;
  p_action->ethertype = ethertype;
  return p_action;
}

/**
 * Create PUSH PBB Action
 *
 * param ethertype MPLS ether protocol type
 * return pointer for action
 */
action *
create_action_push_pbb( const uint16_t ethertype ) {
  action *p_action = malloc_action_memory();

  if ( p_action == NULL ) {
    return NULL;
  }

  p_action->type = OFPAT_PUSH_PBB;
  p_action->ethertype = ethertype;
  return p_action;
}

/**
 * Create POP VLAN Action
 *
 * param none
 * return pointer for action
 */
action *
create_action_pop_vlan( void ) {
  action *p_action = malloc_action_memory();

  if ( p_action == NULL ) {
    return NULL;
  }

  p_action->type = OFPAT_POP_VLAN;

  return p_action;
}

/**
 * Create POP MPLS Action
 * param ethertype new ethertype value
 * return pointer for action
 */
action *
create_action_pop_mpls( const uint16_t ethertype ) {
  action *p_action = malloc_action_memory();

  if ( p_action == NULL ) {
    return NULL;
  }

  p_action->type = OFPAT_POP_MPLS;
  p_action->ethertype = ethertype;
  return p_action;
}

/**
 * create POP PBB Action
 *
 * param none
 * return pointer for action
 */
action *
create_action_pop_pbb( void ) {
  action *p_action = malloc_action_memory();

  if ( p_action == NULL ) {
    return NULL;
  }

  p_action->type = OFPAT_POP_PBB;

  return p_action;
}

/**
 * Create SET FIELD Action
 *
 * param p_match Set Field key and value (match structure)
 * return pointer for action
 */
action *
create_action_set_field( match *p_match ) {
  action *p_action = malloc_action_memory();

  if ( p_action == NULL ) {
    return NULL;
  }
  p_action->type = OFPAT_SET_FIELD;
  p_action->p_match = p_match;
  return p_action;
}

/**
 * Delete Action structure from system
 *
 * param act action to delete(free)
 */
void
delete_action( action **act ) {
  if ( ( *act )->type == OFPAT_GROUP ) {
    group_reference_count_dec( ( *act )->group_id );
  }

  if ( ( *act )->p_match != NULL ) {
    delete_match( &( ( *act )->p_match ) );
  }
  xfree( *act );
  *act = NULL;
}


/**
 * Append action to action list/set
 * param list pointer for action list/set
 * param p_action pointer for action
 * return
 */
OFDPE
append_action( action_list *list, action *p_action ) {
#ifndef UNIT_TESTING
  if ( p_action->type == OFPAT_GROUP ) {
    if ( !is_valid_group_no( p_action->group_id ) ) {
      send_for_notify_error( ERROR_OFDPE_BAD_ACTION_BAD_OUT_GROUP, NULL );
      return OFDPE_FAILED;
    }
  }
  if ( p_action->type == OFPAT_OUTPUT ) {
    if ( !is_valid_port_no( p_action->port ) ) {
      send_for_notify_error( ERROR_OFDPE_BAD_ACTION_BAD_OUT_PORT, NULL );
      return OFDPE_FAILED;
    }
  }
#endif
  switch ( p_action->type ) {
  case OFPAT_OUTPUT:
  case OFPAT_COPY_TTL_OUT:
  case OFPAT_COPY_TTL_IN:
  case OFPAT_SET_MPLS_TTL:
  case OFPAT_DEC_MPLS_TTL:
  case OFPAT_PUSH_VLAN:
  case OFPAT_POP_VLAN:
  case OFPAT_PUSH_MPLS:
  case OFPAT_POP_MPLS:
  case OFPAT_SET_QUEUE:
  case OFPAT_GROUP:
  case OFPAT_SET_NW_TTL:
  case OFPAT_DEC_NW_TTL:
  case OFPAT_SET_FIELD:
  case OFPAT_PUSH_PBB:
  case OFPAT_POP_PBB:
    break;

  default:
    send_for_notify_error( ERROR_OFDPE_BAD_ACTION_BAD_TYPE, NULL );
    return OFDPE_FAILED;

    break;
  }

  dlist_element *retval = insert_after_dlist( ( dlist_element * ) list,
      ( void * ) p_action );
  if ( retval == NULL ) {
    return ERROR_APPEND_TO_LIST;
  }
  return OFDPE_SUCCESS;
}

/**
 * Finalize action list/set
 *
 * param list action list/set for finalize
 */
void
finalize_action_list( action_list **list ) {
  if ( *list == NULL ) {
    return;
  }

  action_list *node = ( action_list * ) get_first_element(
      ( dlist_element * ) ( *list ) );

  action *action;
  while ( node != NULL ) {
    action = node->node;
    if ( action != NULL ) {
      delete_action( &action );
    }
    node = node->next;
  }

  delete_dlist( ( dlist_element * ) ( *list ) );
  *list = NULL;
}

/**
 * remove action from action list/set
 *
 * param list pointer for action list/set
 * param p_action action to be removed ( and freed/deleted )
 * return
 */
OFDPE
remove_action( action_list *list, action *p_action ) {
  action_list *node = ( action_list * ) find_element( ( dlist_element * ) list,
      ( void * ) p_action );

  if ( node == NULL ) {
    return ERROR_NOT_FOUND;
  }

  delete_action( &( node->node ) );
  delete_dlist_element( ( dlist_element * ) node );

  return OFDPE_SUCCESS;
}

/**
 * Validate action list as action set
 *
 * param list action list/set for validate
 * return if action set is valid, return true
 */
bool
validate_action_set( action_list *list ) {
  bool copy_ttl_inwards = false;
  bool pop = false;
  bool push_mpls = false;
  bool push_pbb = false;
  bool push_vlan = false;
  bool copy_ttl_outwards = false;
  bool decrement_ttl = false;
  bool set = false;
  bool qos = false;
  bool group = false;
  bool output = false;

  bool retval = true;

  action_list *node = ( action_list * ) get_first_element(
      ( dlist_element * ) ( list ) );

  node = node->next;

  while ( node != NULL ) {
    switch ( node->node->type ) {
    case OFPAT_OUTPUT:
      if ( output ) {
        retval = false;
      }
      else {
        output = true;
      }
      break;

    case OFPAT_COPY_TTL_OUT:
      if ( copy_ttl_outwards ) {
        retval = false;
      }
      else {
        copy_ttl_outwards = true;
      }
      break;

    case OFPAT_COPY_TTL_IN:
      if ( copy_ttl_inwards ) {
        retval = false;
      }
      else {
        copy_ttl_inwards = true;
      }
      break;

    case OFPAT_SET_MPLS_TTL:
    case OFPAT_SET_NW_TTL:
      retval = false;
      break;

    case OFPAT_PUSH_VLAN:
      if ( push_vlan ) {
        retval = false;
      }
      else {
        push_vlan = true;
      }
      break;

    case OFPAT_PUSH_MPLS:
      if ( push_mpls ) {
        retval = false;
      }
      else {
        push_mpls = true;
      }
      break;

    case OFPAT_PUSH_PBB:
      if ( push_pbb ) {
        retval = false;
      }
      else {
        push_pbb = true;
      }
      break;

    case OFPAT_POP_VLAN:
    case OFPAT_POP_MPLS:
    case OFPAT_POP_PBB:
      if ( pop ) {
        retval = false;
      }
      else {
        pop = true;
      }
      break;

    case OFPAT_DEC_MPLS_TTL:
    case OFPAT_DEC_NW_TTL:
      if ( decrement_ttl ) {
        retval = false;
      }
      else {
        decrement_ttl = true;
      }
      break;

    case OFPAT_SET_QUEUE:
      if ( qos ) {
        retval = false;
      }
      else {
        qos = true;
      }
      break;

    case OFPAT_SET_FIELD:
      if ( set ) {
        retval = false;
      }
      else {
        set = true;
      }
      break;

    case OFPAT_GROUP:
      if ( group ) {
        retval = false;
      }
      else {
        group = true;
      }
      break;

    case OFPAT_EXPERIMENTER:
      retval = false;
      break;
    }
    if ( !retval ) {
      return false;
    }
    node = node->next;
  }

  return retval;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
