/*
 * Functions for managing flow entry actions.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef TABLE_MANAGER_ACTION_H
#define TABLE_MANAGER_ACTION_H


#include "ofdp_common.h"
#include "doubly_linked_list.h"
#include "table_manager_match.h"


struct _flow_entry;
typedef struct _action {
  uint16_t type;
  uint32_t port;
  uint16_t max_len;
  uint32_t group_id;
  uint32_t queue_id;
  uint8_t mpls_ttl;
  uint8_t nw_ttl;
  uint16_t ethertype;
  match *p_match;
  struct _flow_entry *entry;
} action;


action *create_action_output( const uint32_t port, const uint16_t max_len );
action *create_action_group( const uint32_t group_id );
action *create_action_set_queue( const uint32_t queue_id );
action *create_action_set_mpls_ttl( const uint8_t mpls_ttl );
action *create_action_dec_mpls_ttl( void );
action *create_action_set_ipv4_ttl( const uint8_t nw_ttl );
action *create_action_dec_ipv4_ttl( void );
action *create_action_copy_ttl_out( void );
action *create_action_copy_ttl_in( void );
action *create_action_push_vlan( const uint16_t ethertype );
action *create_action_push_mpls( const uint16_t ethertype );
action *create_action_push_pbb( const uint16_t ethertype );
action *create_action_pop_vlan( void );
action *create_action_pop_mpls( const uint16_t ethertype );
action *create_action_pop_pbb( void );
action *create_action_set_field( match *match );
void delete_action( action **action );


typedef dlist_element action_list;
#define init_action_list() create_dlist()
void finalize_action_list( action_list **list );
OFDPE append_action( action_list *list, action *action );
OFDPE remove_action( action_list *list, action *action );
action_list *copy_action_list( action_list *list );
bool validate_action_set( action_list *list );
bool validate_action_list( action_list *list );

#endif // TABLE_MANAGER_ACTION_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
