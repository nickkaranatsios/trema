/*
 * Functions for managing flow entry action buckets.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include "table_manager_action_bucket.h"
#include "wrapper.h"
#include "port_manager.h"
#include "table_manager_group.h"


#ifdef UNIT_TESTING


#define static
#ifdef is_valid_port_no
#undef is_valid_port_no
#endif
#define is_valid_port_no mock_is_valid_port_no
bool mock_is_valid_port_no( const uint32_t port_no );


#endif // UNIT_TESTING


bool
validate_action_bucket( bucket_list *list ) {
  assert( list != NULL );

  dlist_element *element = get_first_element( list );

  while ( element != NULL ) {
    bucket *bkt = element->data;
    if ( bkt != NULL ) {
      if ( !validate_action_list( bkt->actions ) ) {
        return false;
      }
    }
    element = element->next;
  }

  return true;
}


/***
 * Create Action Bucket structure
 *
 * param weight action bucket weight
 * param watch_port action bucket watch port
 * param watch_group action bucket watch group
 * param actions pointer for action list
 * return pointer for action buckets
 */
bucket *
create_action_bucket( const uint16_t weight, const uint32_t watch_port, const uint32_t watch_group,
  void *actions ) {
  bucket *bucket = ( struct bucket * ) xmalloc( sizeof( *bucket ) );

  bucket->weight = weight;
  bucket->watch_port = watch_port;
  bucket->watch_group = watch_group;
  bucket->actions = actions;
  bucket->packet_count = 0;
  bucket->byte_count = 0;

  return bucket;
}


/**
 * delete(free) action bucket
 *
 * param bucket pointer for action bucket to be deleted/freed
 */
void
delete_action_bucket( bucket **bucket ) {
  if ( bucket == NULL ) {
    return;
  }
  if ( *bucket == NULL ) {
    return;
  }
  finalize_action_list( &( ( *bucket )->actions ) );
  xfree( *bucket );
  *bucket = NULL;
}


/***
 * Append action bucket to action bucket list
 *
 * param list pointer for action bucket list
 * param bucket pointer for action bucket
 * return
 */
OFDPE
append_action_bucket( bucket_list *list, bucket *bucket ) {
  list = insert_after_dlist( list, ( void * ) bucket );

  if ( list == NULL ) {
    return ERROR_NO_MEMORY;
  }
  return OFDPE_SUCCESS;
}


/**
 * delete(finalize) action bucket list
 *
 * param list pointer for action bucket list to be deleted
 */
void
delete_action_bucket_list( bucket_list **list ) {
  dlist_element *node = get_first_element( *list );

  while ( node != NULL ) {
    bucket *bkt = node->data;
    if ( bkt != NULL ) {
      delete_action_bucket( &bkt );
    }
    node = node->next;
  }
  delete_dlist( *list );
  *list = NULL;
}


/**
 * remove action bucket from action bucket list
 * param list pointer for action bucket list
 * param bucket pointer for action bucket
 * return
 */
OFDPE
remove_action_bucket( bucket_list *list, bucket *bkt ) {
  dlist_element *node = find_element( list, ( void * ) bkt );

  if ( node == NULL ) {
    return ERROR_NOT_FOUND;
  }

  bucket *del_bkt = node->data;
  delete_action_bucket( &del_bkt );
  delete_dlist_element( node );

  return OFDPE_SUCCESS;
}


uint32_t
get_bucket_count( bucket_list *list ) {
  uint32_t count = 0;

  dlist_element *element = get_first_element ( list );
  while ( element != NULL ) {
    count++;
    element = element->next;
  }

  return count;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
