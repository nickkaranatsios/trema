/*
 * Functions for managing flow entries.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include "table_manager.h"
#include "match_table.h"
#include "log.h"
#include "timer.h"
#include "ofdp_common.h"
#include "wrapper.h"
#include "controller_manager.h"


static const instructions_capabilities init_bool_instruction = { false, true, true, true, true, true };
static const actions_capabilities init_bool_action = { true, false, true, true, true, true, true, true, false, false };
static const match_capabilities init_bool_match = {
  true, false, true, true, true, true, true, true, true, true,
  true, true, true, true, true, true, true, false, false, true,
  true, true, true, true, true, true, true, true, true, true,
  true, true, true, true, true, true, true, true, false, true,
};
static const match_capabilities init_bool_set_field = {
  false, false, false, true, true, true, true, true, true, true,
  true, true, true, true, true, true, true, false, false, true,
  true, true, true, true, true, true, true, true, true, true,
  true, true, true, true, true, true, true, false, false, false,
};


/**
 * Create Flow entry structure
 * param p_match pointer for match structure
 * param instructions pointer for instruction list
 * param priority match priority
 * param idle_timeout flow entry idle timeout value
 * param hard_timeout flow entry hard timeout value
 * param flags flags for flow entry
 * param cookie flow entry cookie
 * return pointer for flow entry
 */
flow_entry *
create_flow_entry( match *p_match, instruction_list *instructions,
  const uint16_t priority, const uint16_t idle_timeout, const uint16_t hard_timeout,
  const uint16_t flags, const uint64_t cookie ) {
  if ( !validate_match( p_match ) ) {
    return NULL;
  }

  flow_entry *entry = ( flow_entry * ) xcalloc( 1, sizeof( flow_entry ) );
  if ( entry == NULL ) {
    return NULL;
  }
  struct timespec t;
  //  clock_gettime(CLOCK_MONOTONIC_RAW, &t);
  time_now( &t );
  entry->cookie = cookie;
  entry->duration_nsec = ( uint32_t ) t.tv_nsec;
  entry->duration_sec = ( uint32_t ) t.tv_sec;
  entry->flags = flags;
  entry->priority = priority;
  entry->hard_timeout = hard_timeout;
  entry->idle_timeout = idle_timeout;
  entry->instructions = instructions;
  entry->p_match = p_match;

  entry->byte_count = 0;
  entry->packet_count = 0;

  // set entry pointer to action
  instruction_list *instruction_node = ( instruction_list * ) get_last_element( ( dlist_element * ) ( instructions ) );
  instruction *p_instruction = NULL;
  while ( instruction_node != NULL ) {
    p_instruction = instruction_node->node;
    if ( ( p_instruction != NULL ) && ( p_instruction->p_action_list != NULL ) ) {
      action_list *action_node = ( action_list * ) get_last_element( ( dlist_element * ) ( p_instruction->p_action_list ) );
      action *action = NULL;
      while ( action_node != NULL ) {
        action = action_node->node;
        if ( action != NULL ) {
          action->entry = entry;
        }
        action_node = action_node->prev;
      }
    }
    instruction_node = instruction_node->prev;
  }


  time_now( &entry->created_at );
  entry->last_seen = entry->created_at;

  return entry;
}


/**
 * Delete(finaliaze) flow entry from system
 * param entry pointer for flow entry to be deleted
 */
void
delete_flow_entry( flow_entry **entry ) {
  instruction_list *instructions = ( *entry )->instructions;

  finalize_instruction_list( &instructions );
  match *p_match = ( *entry )->p_match;
  delete_match( &p_match );

  xfree( *entry );
  *entry = NULL;
}


/**
 * Append flow entry to flow table
 *
 * param table_id flow table id to append flow entry
 * param entry pointer flow entry
 * return
 */
OFDPE
append_flow_entry( const uint8_t table_id, flow_entry *entry ) {
  if ( entry == NULL ) {
    return ERROR_ILLEGAL_PARAMETER;
  }

  if ( !lock_pipeline() ) {
    warn( "lock_pipeline() execute error." );
    return ERROR_LOCK;
  }

  OFDPE ret = true;

  uint64_t metadata_range = ( _get_flow_table( table_id ) )->features.metadata_write;
  ret = validate_datapath_instructions( entry->instructions, metadata_range );
  if ( ret ) {
    ret = insert_match_entry( table_id, entry->p_match, entry->priority, entry );
    if ( ret ) {
      flow_table_active_count_inc( table_id );
      update_group_reference_counter( entry->instructions, update_group_reference_increment );
    }
  }

  if ( !unlock_pipeline() ) {
    warn( "unlock_pipeline() execute error." );
  }

  return ret ? OFDPE_SUCCESS : OFDPE_FAILED;
}


/**
 * Lookup flow entry with match structure
 * param table_id flow table id
 * param p_match with the match to be looked up
 * return
 */
flow_entry *
lookup_flow_entry( const uint8_t table_id, match *p_match ) {
  flow_table_lookup_count_inc( table_id );
  flow_entry *entry = lookup_match_entry( table_id, p_match );
  if ( entry != NULL ) {
    flow_table_matched_count_inc( table_id );
  }

  return entry;
}


/**
 * Lookup flow entry with match structure and priority
 * param table_id flow table id
 * param p_match with the match to be looked up
 * param priority with the priority to be looked up
 * return
 */
flow_entry *
lookup_flow_entry_strict( const uint8_t table_id, match *p_match, uint16_t priority ) {
  flow_table_lookup_count_inc( table_id );
  flow_entry *entry = lookup_match_strict_entry( table_id, p_match, priority );
  if ( entry != NULL ) {
    flow_table_matched_count_inc( table_id );
  }

  return entry;
}


/**
 * Update flow entry
 * param cookie
 * param entry flow entry
 * return
 */
OFDPE
update_flow_entry( const uint64_t cookie, const uint64_t cookie_mask, const uint8_t table_id, const bool strict,
                   const uint16_t priority, const uint16_t flags, match *p_match, instruction_list *instructions ) {

  if ( p_match == NULL ) {
    error( "match is invalid(NULL)." );
    return ERROR_ILLEGAL_PARAMETER;
  }

  if ( instructions == NULL ) {
    error( "instruction list is invalid(NULL)." );
    return ERROR_ILLEGAL_PARAMETER;
  }

  OFDPE ret = OFDPE_SUCCESS;
  list_element *list = NULL;

  if ( !lock_pipeline() ) {
    warn( "lock_pipeline() execute error." );
    return ERROR_LOCK;
  }

  uint64_t metadata_range = ( _get_flow_table( table_id ) )->features.metadata_write;
  if ( !validate_datapath_instructions( instructions, metadata_range ) ) {
    error( "invalid instruction list" );
    ret = ERROR_ILLEGAL_PARAMETER;
  }
  else {
    if ( strict ) {
      flow_entry *p_flow_entry = lookup_match_strict_entry( table_id, p_match, priority );
      if ( p_flow_entry != NULL ) {
        create_list( &list );
        append_to_tail( &list, p_flow_entry );
      }
    }
    else {
      list = ( list_element * ) lookup_match_entries( table_id, p_match );
    }

    list_element *element = list;
    bool update = false;

    while ( element != NULL ) {
      flow_entry *p_flow_entry = ( flow_entry * ) element->data;
      //      if ( ( p_flow_entry->cookie & cookie_mask ) == cookie ) {
      UNUSED( cookie_mask );
      if ( p_flow_entry->cookie == cookie ) {
        update_group_reference_counter( p_flow_entry->instructions, update_group_reference_decrement );
        finalize_instruction_list( &p_flow_entry->instructions );
        p_flow_entry->instructions = copy_instruction_list( instructions );
        update_group_reference_counter( p_flow_entry->instructions, update_group_reference_increment );
        if ( flags == OFPFF_RESET_COUNTS ) {
          p_flow_entry->packet_count = 0;
          p_flow_entry->byte_count = 0;
        }
        update = true;
      }
      element = element->next;
    }
    if ( update ) {
      finalize_instruction_list( &instructions );
    }
  }

  if ( !unlock_pipeline() ) {
    warn( "unlock_pipeline() execute error." );
  }

  if ( list != NULL ) {
    delete_list( list );
  }

  return ret;
}


/**
 * remove flow entry from flow table
 * param table_id table ID
 * param entry flow entry
 * return
 */

OFDPE
remove_flow_entry( const uint8_t table_id, flow_entry *entry ) {
  if ( entry == NULL ) {
    return ERROR_ILLEGAL_PARAMETER;
  }

  if ( !lock_pipeline() ) {
    warn( "lock_pipeline() execute error." );
    return ERROR_LOCK;
  }

  flow_entry *deleted = delete_match_strict_entry( table_id, entry->p_match,
    entry->priority );

  OFDPE ret = OFDPE_SUCCESS;

  if ( deleted == NULL ) {
    ret = ERROR_NOT_FOUND;
  }
  else {

    flow_table_active_count_dec( table_id );
    update_group_reference_counter( deleted->instructions, update_group_reference_decrement );
    delete_flow_entry( &deleted );

    if ( ( entry->flags & OFPFF_SEND_FLOW_REM ) != 0 ) {
      notify_parameter_flow_removed *parameter = xmalloc( sizeof( notify_parameter_flow_removed ) );
      if ( parameter == NULL ) {
        warn( "can not allocate memory." );
        ret = ERROR_NO_MEMORY;
      }
      else {
        parameter->cookie = entry->cookie;
        parameter->priority = entry->priority;
        parameter->table_id = table_id;
        parameter->duration_sec = entry->duration_sec;
        parameter->duration_nsec = entry->duration_nsec;
        parameter->idle_timeout = entry->idle_timeout;
        parameter->hard_timeout = entry->hard_timeout;
        parameter->packet_count = entry->packet_count;
        parameter->byte_count = entry->byte_count;
        parameter->match = *( entry->p_match );

        parameter->reason = OFPRR_DELETE;
        notify_flow_removed( parameter );
      }
    }
  }

  if ( !unlock_pipeline() ) {
    warn( "unlock_pipeline() execute error." );
  }

  return ret;
}


typedef struct {
  flow_entry_handler callback;
  void *user_data;
  uint8_t table_id;
} flow_entry_walker_data;


static void
flow_entry_walker( match *p_match, uint16_t priority, void *data,
  void *user_data ) {
  UNUSED( p_match );
  UNUSED( priority );

  flow_entry_walker_data *wd = user_data;

  wd->callback( data, wd->user_data, wd->table_id );
}


void
foreach_flow_entry( const uint8_t table_id, flow_entry_handler callback,
  void *user_data ) {
  flow_entry_walker_data wd ={ callback, user_data, table_id };

  foreach_match_table( table_id, flow_entry_walker, &wd );
}


static void
age_flow_entries_walker( flow_entry *entry, void *user_data, uint8_t table_id ) {
  const struct timespec *current_time = user_data;
  struct timespec diff ={ 0, 0 };

  if ( entry == NULL ) {
    return;
  }

  notify_parameter_flow_removed *parameter = xmalloc( sizeof( notify_parameter_flow_removed ) );
  if ( parameter == NULL ) {
    return;
  }
  parameter->cookie = entry->cookie;
  parameter->priority = entry->priority;
  parameter->table_id = table_id;
  parameter->duration_sec = entry->duration_sec;
  parameter->duration_nsec = entry->duration_nsec;
  parameter->idle_timeout = entry->idle_timeout;
  parameter->hard_timeout = entry->hard_timeout;
  parameter->packet_count = entry->packet_count;
  parameter->byte_count = entry->byte_count;
  parameter->match = *( entry->p_match );

  if ( entry->hard_timeout > 0 ) {
    timespec_diff( entry->created_at, *current_time, &diff );
    if ( diff.tv_sec >= entry->hard_timeout ) {
      if ( ( entry->flags & OFPFF_SEND_FLOW_REM ) != 0 ) {
        parameter->reason = OFPRR_HARD_TIMEOUT;
        notify_flow_removed( parameter );
        // send_flow_removed( entry, OFPRR_HARD_TIMEOUT );
      }
      flow_entry *deleted = delete_match_strict_entry( table_id, entry->p_match,
        entry->priority );
      //          delete_flow_entry(&entry);

      if ( deleted != NULL ) {
        flow_table_active_count_dec( table_id );
      }
    }
  }
  else if ( entry->idle_timeout > 0 ) {
    timespec_diff( entry->last_seen, *current_time, &diff );
    if ( diff.tv_sec >= entry->idle_timeout ) {
      if ( ( entry->flags & OFPFF_SEND_FLOW_REM ) != 0 ) {
        parameter->reason = OFPRR_IDLE_TIMEOUT;
        notify_flow_removed( parameter );
        // send_flow_removed( entry, OFPRR_IDLE_TIMEOUT );
      }
      flow_entry *deleted = delete_match_strict_entry( table_id, entry->p_match,
        entry->priority );
      //          delete_flow_entry(&entry);

      if ( deleted != NULL ) {
        flow_table_active_count_dec( table_id );
      }
    }
  }
  xfree( parameter );
}


/**
 * Remove flow entry which is elder than timeout age.
 * param table_id table ID
 */
void
remove_timeout_flow_entry( const uint8_t table_id ) {
  struct timespec current_time;

  time_now( &current_time );
  foreach_flow_entry( table_id, age_flow_entries_walker, &current_time );
}


static flow_table flow_pipeline[ MAX_FLOW_TABLE ];


/**
 * Get Flow Table from Flow Pipeline
 * param table_id
 * return pointer for flow table
 */
flow_table *
_get_flow_table( const uint8_t table_id ) {
  if ( flow_pipeline[ table_id ].valid ) {
    return &( flow_pipeline[ table_id ] );
  }
  else {
    return NULL;
  }
}


static void
set_default_features( const uint8_t table_id, table_features *features ) {
  assert( features != NULL );

  features->table_id = table_id;
  memset( &features->name[0], 0, sizeof( features->name ) );
  snprintf( features->name, sizeof( features->name ) - 1, "table%d", table_id );
  features->metadata_match = ULLONG_MAX;
  features->metadata_write = ULLONG_MAX;
  features->config = UINT_MAX;
  features->max_entries = UINT_MAX;
  features->instructions = init_bool_instruction;
  features->instructions_miss = init_bool_instruction;
  features->min_next_table_ids = ( uint8_t ) ( table_id + 1 );
  features->min_next_table_ids_miss = ( uint8_t ) ( table_id + 1 );
  features->write_actions = init_bool_action;
  features->write_actions_miss = init_bool_action;
  features->apply_actions = init_bool_action;
  features->apply_actions_miss = init_bool_action;
  features->matches = init_bool_match;
  features->wildcards = init_bool_match;
  features->write_setfield = init_bool_set_field;
  features->write_setfield_miss = init_bool_set_field;
  features->apply_setfield = init_bool_set_field;
  features->apply_setfield_miss = init_bool_set_field;
  return;
}


/**
 * Initialize flow table
 * param table_id flow table id
 * return
 */
OFDPE
init_flow_table( const uint8_t table_id ) {
  flow_table *flow_table = &( flow_pipeline[ table_id ] ); // Force Get Memory

  if ( flow_table == NULL ) {
    return ERROR_NOT_INITIALIZED;
  }

  flow_table->counters.active_count = 0;
  flow_table->counters.lookup_count = 0;
  flow_table->counters.matched_count = 0;
  flow_table->entry = ( flow_table_list * ) create_dlist();
  init_match_table( flow_table );
  flow_table->valid = true;

  set_default_features( table_id, &flow_table->features );
  return OFDPE_SUCCESS;
}


/**
 * Finalize flow table
 * param table_id flow table ID
 * return
 */
OFDPE
finalize_flow_table( const uint8_t table_id ) {
  flow_table *flow_table = _get_flow_table( table_id );

  flow_table_list *node;

  node = flow_table->entry;
  while ( node->data != NULL ) {
    delete_flow_entry( &( node->data ) );
    node = node->next;
    if ( node->next == NULL ) {
      break;
    }
  }

  finalize_match_table( flow_table );

  flow_table->valid = false;
  flow_table->exact_table = NULL;
  flow_table->wildcards_table = NULL;
  flow_table->entry = NULL;
  flow_table->counters.active_count = 0;
  flow_table->counters.lookup_count = 0;
  flow_table->counters.matched_count = 0;
  return OFDPE_SUCCESS;
}


uint32_t
flow_table_active_count_inc( const uint8_t table_id ) {
  if ( flow_pipeline[ table_id ].valid != true ) {
    return 0;
  }
  flow_pipeline[ table_id ].counters.active_count++;
  return flow_pipeline[ table_id ].counters.active_count;
}


uint32_t
flow_table_active_count_dec( const uint8_t table_id ) {
  if ( flow_pipeline[ table_id ].valid != true ) {
    return 0;
  }
  flow_pipeline[ table_id ].counters.active_count--;
  return flow_pipeline[ table_id ].counters.active_count;
}


uint32_t
flow_table_get_active_count( const uint8_t table_id ) {
  if ( flow_pipeline[ table_id ].valid != true ) {
    return 0;
  }
  return flow_pipeline[ table_id ].counters.active_count;
}


uint64_t
flow_table_lookup_count_inc( const uint8_t table_id ) {
  if ( flow_pipeline[ table_id ].valid != true ) {
    return 0;
  }
  flow_pipeline[ table_id ].counters.lookup_count++;
  return flow_pipeline[ table_id ].counters.lookup_count;
}


uint64_t
flow_table_get_lookup_count( const uint8_t table_id ) {
  if ( flow_pipeline[ table_id ].valid != true ) {
    return 0;
  }
  return flow_pipeline[ table_id ].counters.lookup_count;
}


uint64_t
flow_table_matched_count_inc( const uint8_t table_id ) {
  if ( flow_pipeline[ table_id ].valid != true ) {
    return 0;
  }
  flow_pipeline[ table_id ].counters.matched_count++;
  return flow_pipeline[ table_id ].counters.matched_count;
}


uint64_t
flow_table_get_matched_count( uint8_t table_id ) {
  if ( flow_pipeline[ table_id ].valid != true ) {
    return 0;
  }
  return flow_pipeline[ table_id ].counters.matched_count;
}


/**
 * Get Statistics of Flow Table
 * param statistics
 * param num
 * return
 */
OFDPE
get_statistics_table( ofp_table_stats **statistics, const uint8_t num ) {
  ofp_table_stats *retval;

  retval = xmalloc( sizeof( ofp_table_stats ) );
  if ( retval == NULL ) {
    warn( "can not allocate memory." );
    *statistics = NULL;
    return OFDPE_FAILED;
  }

  if ( !lock_pipeline() ) {
    warn( "lock_pipeline() execute error." );
    return ERROR_LOCK;
  }

  retval->active_count = flow_pipeline[ num ].counters.active_count;
  retval->lookup_count = flow_pipeline[ num ].counters.lookup_count;
  retval->matched_count = flow_pipeline[ num ].counters.matched_count;

  if ( !unlock_pipeline() ) {
    warn( "unlock_pipeline() execute error." );
  }

  retval->table_id = num;

  *statistics = retval;
  return OFDPE_SUCCESS;
}


#define OFPG_ANY ~0


static OFDPE
get_statistics_flow_table( const flow_stats_request request,
  flow_stats **statistics, uint32_t *num ) {
  uint8_t table_id = request.table_id;
  flow_table *p_flow_table = _get_flow_table( table_id );
  list_element *p_flow_entry = p_flow_table->wildcards_table;

  if ( p_flow_entry == NULL ) {
    return OFDPE_FAILED;
  }

  flow_entry *node = NULL;
  *num = 0;
  flow_stats *buffer = NULL;
  *statistics = NULL;

  bool ismatch;
  while ( p_flow_entry != NULL ) {
    node = ( flow_entry * ) ( ( match_entry * ) ( p_flow_entry->data ) )->data;
    ismatch = true;

    if ( ( request.out_port != ( uint32_t ) OFPP_ANY ) && ( request.out_group != ( uint32_t ) OFPG_ANY ) ) {
      uint32_t output_port = ( uint32_t ) ~0;
      uint32_t output_group = ( uint32_t ) ~0;

      for ( instruction_list *p_instruction = node->instructions;
        p_instruction->next != NULL; p_instruction = p_instruction->next ) {
        if ( p_instruction->node == NULL ) {
          continue;
        }
        if ( ( p_instruction->node->type == OFPIT_WRITE_ACTIONS )
          || ( p_instruction->node->type == OFPIT_APPLY_ACTIONS ) ) {
          for ( action_list *p_action
            = p_instruction->node->p_action_list;
            p_action->next != NULL; p_action = p_action->next ) {
            if ( p_action->node->type == OFPAT_OUTPUT ) {
              output_port = p_action->node->port;
              if ( ( request.out_port != OFPP_ANY )
                && ( output_port != request.out_port ) ) {
                ismatch = false;
                break;
              }
            }
            if ( p_action->node->type == OFPAT_GROUP ) {
              output_group = p_action->node->group_id;
              if ( ( request.out_group != ( uint32_t ) OFPG_ANY )
                && ( output_group != request.out_group ) ) {
                ismatch = false;
                break;
              }
            }
          }
        }
      }
    }
    if ( ( request.cookie & request.cookie_mask ) != ( node->cookie
      & request.cookie_mask ) ) {
      ismatch = false;
    }
    if ( ( request.p_match != NULL ) & ( node->p_match != NULL ) ) {
      if ( match_match_match( request.p_match, node->p_match ) == false ) {
        ismatch = false;
      }
    }
    if ( ismatch == true ) {
      ( *num )++;
      buffer = xmalloc( sizeof( flow_stats ) * *num );
      if ( buffer == NULL ) {
        xfree( *statistics );
        return OFDPE_FAILED;
      }
      if ( *num > 1 ) {
        memcpy( buffer, *statistics, sizeof( flow_stats ) * ( *num - 1 ) );
        xfree( *statistics );
      }
      struct timespec t;
      //          clock_gettime( CLOCK_MONOTONIC_RAW, &t );
      time_now( &t );

      buffer[ *num - 1 ].table_id = table_id;
      buffer[ *num - 1 ].duration_sec = ( uint32_t ) t.tv_sec - node->duration_sec;
      buffer[ *num - 1 ].duration_nsec = ( uint32_t ) t.tv_nsec - node->duration_nsec;

      buffer[ *num - 1 ].priority = node->priority;
      buffer[ *num - 1 ].idle_timeout = node->idle_timeout;
      buffer[ *num - 1 ].hard_timeout = node->hard_timeout;

      buffer[ *num - 1 ].flags = node->flags;
      buffer[ *num - 1 ].cookie = node->cookie;

      buffer[ *num - 1 ].p_match = node->p_match;
      buffer[ *num - 1 ].packet_count = node->packet_count;
      buffer[ *num - 1 ].byte_count = node->byte_count;

      *statistics = buffer;
    }
    p_flow_entry = p_flow_entry->next;
  }

  return OFDPE_SUCCESS;
}


/**
 * Get Statistics of Flow entry
 * param request request structure of getting statistics
 * param statistics pointer for save statistics memory pointer
 * param num pointer for save statistics num
 * return
 */
OFDPE
get_statistics_flow( const flow_stats_request request, flow_stats **statistics,
  uint32_t *num ) {
  *statistics = NULL;

  if ( !lock_pipeline() ) {
    warn( "lock_pipeline() execute error." );
    return ERROR_LOCK;
  }

  OFDPE ret = OFDPE_SUCCESS;

  if ( request.table_id != OFPTT_ALL ) {
    ret = get_statistics_flow_table( request, statistics, num );
  }
  else {
    flow_stats *buffer;
    uint32_t num_i;
    *num = 0;
    for ( int i = 0; i < 255; i++ ) {
      flow_stats *retval;
      get_statistics_flow_table( request, &retval, &num_i );
      *num += num_i;
      buffer = *statistics;
      *statistics = xmalloc( sizeof( flow_stats ) * *num );
      if ( *statistics == NULL ) {
        warn( "can not allocate memory." );
        xfree( buffer );
        ret = ERROR_NO_MEMORY;
        break;
      }
      memcpy( *statistics, buffer, sizeof( flow_stats ) * ( *num - num_i ) );
      memcpy( ( *statistics + ( *num - num_i ) ), retval, num_i );
      xfree( buffer );
    }
  }

  if ( !unlock_pipeline() ) {
    warn( "unlock_pipeline() execute error." );
  }

  return ret;
}


void
dump_flow_table_stats( ofp_table_stats *stats ) {
  debug( "***** start flow table stats *****" );
  debug( "table_id = %u", stats->table_id );
  debug( "active_count = %u", stats->active_count );
  debug( "lookup_count = %u", stats->lookup_count );
  debug( "matched_count = %u", stats->matched_count );
  debug( "***** end flow table stats *****" );

  return;
}


void
dump_flow_stats( flow_stats *stats ) {
  debug( "***** start flow stats *****" );
  debug( "length = %u", stats->length );
  debug( "table_id = %u", stats->table_id );
  debug( "duration_sec = %u", stats->duration_sec );
  debug( "duration_nsec = %u", stats->duration_nsec );
  debug( "priority = %u", stats->priority );
  debug( "idle_timeout = %u", stats->idle_timeout );
  debug( "hard_timeout = %u", stats->hard_timeout );
  debug( "flags = %u", stats->flags );
  debug( "cookie = %u", stats->cookie );
  debug( "packet_count = %u", stats->packet_count );
  debug( "byte_count = %u", stats->byte_count );
  debug( "***** end flow stats *****" );

  return;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
