/*
 * Functions for managing group tables.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include "ofdp_common.h"
#include "wrapper.h"
#include "table_manager.h"
#include "port_manager.h"


#ifdef UNIT_TESTING


#define static
#ifdef is_valid_port_no
#undef is_valid_port_no
#endif
#define is_valid_port_no mock_is_valid_port_no
bool mock_is_valid_port_no( const uint32_t port_no );


#endif // UNIT_TESTING


// static variables
static uint32_t group_types = 0;
static uint32_t group_capabilities = 0;
static uint32_t group_max_groups[ 4 ] = { 0, 0, 0, 0 };
static uint32_t group_actions[ 4 ] = { 0, 0, 0, 0 };


/**
 * Create Group entry structure
 * param type group entry type
 * param list pointer for action bucket list
 * return pointer for group entry
 */
group_entry *
create_group_entry( const uint8_t type, const uint32_t group_id, bucket_list *list ) {
  group_entry *entry = xmalloc( sizeof( group_entry ) );

  switch ( type ) {
  case OFPGT_ALL:
    break;

  case OFPGT_SELECT:
    break;

  case OFPGT_INDIRECT:
    break;

  default:
    xfree( entry );
    entry = NULL;
    break;
  }
  if ( entry == NULL ) {
    return entry;
  }

  memset( entry, 0, sizeof( *entry ) );

  entry->type = type;
  entry->group_id = group_id;
  entry->bucket_list = list;

  struct timespec t;
  time_now( &t );
  entry->duration_sec = ( uint32_t ) t.tv_sec;
  entry->duration_nsec = ( uint32_t ) t.tv_nsec;

  return entry;
}


/**
 * Delete/free group entry
 * param entry pointer for group entry to be deleted
 */
void
delete_group_entry( group_entry **entry ) {
  if ( entry == NULL ) {
    return;
  }
  if ( *entry == NULL ) {
    return;
  }

  if ( ( *entry )->bucket_list == NULL ) {
    return;
  }

  delete_action_bucket_list( &( ( *entry )->bucket_list ) );
  xfree( *entry );
  *entry = NULL;
}


static group_list *group_table = NULL;


/**
 * Initialize Group Table.
 */
void
init_group_table( void ) {
  if ( group_table != NULL ) {
    return;
  }
  group_table = create_dlist();

  group_types = 0x00000001;
  group_capabilities = 0x00000000;
  group_max_groups[ 0 ] = ( ( uint32_t ) ULONG_MAX );
  group_max_groups[ 1 ] = 0x00000000;
  group_max_groups[ 2 ] = 0x00000000;
  group_max_groups[ 3 ] = 0x00000000;
  group_actions[ 0 ] = ( ( uint32_t ) ULONG_MAX );
  group_actions[ 1 ] = 0x00000000;
  group_actions[ 2 ] = 0x00000000;
  group_actions[ 3 ] = 0x00000000;
}


/**
 * Finalize group Table
 */
void
finalize_group_table( void ) {
  if ( group_table == NULL ) {
    return;
  }

  dlist_element *node = get_first_element( group_table );

  group_entry *entry;
  while ( node != NULL ) {
    entry = node->data;
    if ( entry != NULL ) {
      delete_group_entry( &entry );
      assert( entry == NULL );
    }
    node = node->next;
  }

  delete_dlist( group_table );
  group_table = NULL;

  group_types = 0;
  group_capabilities = 0;
  group_max_groups[ 0 ] = 0;
  group_max_groups[ 1 ] = 0;
  group_max_groups[ 2 ] = 0;
  group_max_groups[ 3 ] = 0;
  group_actions[ 0 ] = 0;
  group_actions[ 1 ] = 0;
  group_actions[ 2 ] = 0;
  group_actions[ 3 ] = 0;
}


static dlist_element *
lookup_group_node( const uint32_t group_id ) {
  if ( group_table == NULL ) {
    return NULL;
  }
  dlist_element *node = get_first_element( group_table );
  while ( node != NULL ) {
    group_entry *entry = node->data;
    if ( entry != NULL && entry->group_id == group_id ) {
      return node;
    }
    node = node->next;
  }
  return node;
}


bool
is_valid_group_no( const uint32_t group_id ) {
  if ( group_table == NULL ) {
    return false;
  }
  group_list *retval = lookup_group_node( group_id );
  if ( retval == NULL ) {
    return false;
  }
  return true;
}


static bool
validate_group_entry( group_entry *entry ) {

  dlist_element *element = get_first_element( entry->bucket_list );

  bucket *bkt = NULL;

  while ( element != NULL ) {
    bkt = element->data;
    if ( bkt != NULL ) {
      if ( !is_valid_port_no( bkt->watch_port ) ) {
        warn( "watch port %d is invalid.", bkt->watch_port );
        send_for_notify_error( ERROR_OFDPE_BAD_ACTION_BAD_OUT_PORT, NULL );
        return false;
      }
      if ( ( bkt->watch_group != 0 ) && is_valid_group_no( bkt->watch_group ) ) {
        warn( "watch group %d is invalid.", bkt->watch_group );
        send_for_notify_error( ERROR_OFDPE_BAD_ACTION_BAD_OUT_GROUP, NULL );
        return false;
      }

      if ( !validate_action_bucket( entry->bucket_list ) ) {
        return false;
      }
    }
    element = element->next;
  }

  return true;
}


/**
 * Append Group entry to group table
 * param entry pointer for group entry to be appended
 * return
 */
OFDPE
append_group_entry( group_entry *entry ) {
  if ( entry == NULL ) {
    return ERROR_ILLEGAL_PARAMETER;
  }

  if ( group_table == NULL ) {
    return ERROR_NOT_INITIALIZED;
  }

  if ( !lock_pipeline() ) {
    warn( "lock_pipeline() execute error." );
    return ERROR_LOCK;
  }

  if ( !validate_group_entry( entry ) ) {
    return OFDPE_FAILED;
  }
  insert_before_dlist( group_table, entry );

  if ( !unlock_pipeline() ) {
    warn( "unlock_pipeline() execute error." );
  }

  return OFDPE_SUCCESS;
}


/**
 * remove Group entry to group table
 * param group_id id of group entry to be appended
 * return
 */
OFDPE
remove_group_entry( const uint32_t group_id ) {
  if ( group_table == NULL ) {
    return ERROR_NOT_INITIALIZED;
  }

  if ( !lock_pipeline() ) {
    warn( "lock_pipeline() execute error." );
    return ERROR_LOCK;
  }

  OFDPE ret = OFDPE_SUCCESS;

  dlist_element *node = lookup_group_node( group_id );
  if ( node != NULL ) {
    group_entry *entry = node->data;
    delete_group_entry( &entry );
    delete_dlist_element( node );
  }
  else {
    ret = ERROR_NOT_FOUND;
  }

  if ( !unlock_pipeline() ) {
    warn( "unlock_pipeline() execute error." );
  }

  return ret;
}


/**
 * Lookup group entry from group ID
 * param group_id
 * return pointer for group entry
 */
group_entry *
lookup_group_entry( const uint32_t group_id ) {
  if ( group_table == NULL ) {
    return NULL;
  }

  dlist_element *node = lookup_group_node( group_id );
  if ( node == NULL ) {
    return NULL;
  }
  group_entry *entry = node->data;
  return entry;
}


/**
 * Lookup action bucket list from group ID
 * param group_id
 * return pointer for action bucket list
 */
bucket_list *
lookup_action_bucket( const uint32_t group_id ) {
  if ( group_table == NULL ) {
    return NULL;
  }

  dlist_element *node = lookup_group_node( group_id );
  if ( node == NULL ) {
    return NULL;
  }
  group_entry *entry = node->data;
  return entry->bucket_list;
}


uint32_t
group_reference_count_inc( const uint32_t table_id ) {
  if ( group_table == NULL ) {
    return 0;
  }

  dlist_element *node = lookup_group_node( table_id );
  if ( node == NULL ) {
    return ( uint32_t ) ~0;
  }
  group_entry *entry = node->data;
  entry->ref_count += 1;
  return entry->ref_count;
}


uint32_t
group_reference_count_dec( const uint32_t table_id ) {
  if ( group_table == NULL ) {
    return 0;
  }
  dlist_element *node = lookup_group_node( table_id );
  if ( node == NULL ) {
    return ( uint32_t ) ~0;
  }
  group_entry *entry = node->data;
  entry->ref_count -= 1;
  return entry->ref_count;
}


uint32_t
group_get_reference_count( const uint32_t table_id ) {
  if ( group_table == NULL ) {
    return 0;
  }
  dlist_element *node = lookup_group_node( table_id );
  if ( node == NULL ) {
    return ( uint32_t ) ~0;
  }
  group_entry *entry = node->data;
  return entry->ref_count;
}


/**
 * Get Statistics of group
 * param group_id id of requesting
 * param statistics pointer for save statistics memory pointer
 * param num poitner for save statistics structure count
 * return
 */
OFDPE
get_statistics_group( const uint32_t group_id, ofp_group_stats **statistics, uint32_t *num ) {
  if ( group_table == NULL ) {
    return ERROR_NOT_INITIALIZED;
  }

  if ( !lock_pipeline() ) {
    warn( "lock_pipeline() execute error." );
    return ERROR_LOCK;
  }

  OFDPE ret = OFDPE_SUCCESS;

  dlist_element *node = lookup_group_node( group_id );
  if ( node == NULL ) {
    ret = OFDPE_FAILED;
  }
  else {
    group_entry *entry = node->data;
    *num = get_bucket_count( entry->bucket_list );

    size_t size = ( sizeof( ofp_group_stats ) ) + ( sizeof( ofp_bucket_counter ) * ( *num ) );
    if ( size > SHRT_MAX ) {
      ret = ERROR_ILLEGAL_PARAMETER;
    }
    else {
      ofp_group_stats *retval = ( ofp_group_stats * ) xmalloc( size );
      ofp_bucket_counter *bucket_stats = ( ofp_bucket_counter * ) ( retval + 1 );
      dlist_element *bkt_element = entry->bucket_list;
      for ( uint8_t i = 0; i < *num; i++ ) {
        bucket *bkt = bkt_element->data;
        bucket_stats->byte_count = bkt->byte_count;
        bucket_stats->packet_count = bkt->packet_count;
        bucket_stats++;
        bkt_element = bkt_element->next;
      }
      retval->length = ( uint16_t ) size;
      retval->group_id = group_id;
      retval->packet_count = entry->packet_count;
      retval->byte_count = entry->byte_count;
      retval->ref_count = entry->ref_count;

      struct timespec t;
      time_now( &t );
      retval->duration_sec = ( uint32_t ) t.tv_sec - entry->duration_sec;
      retval->duration_nsec = ( uint32_t ) t.tv_nsec - entry->duration_nsec;

      *statistics = retval;
    }
  }

  if ( !unlock_pipeline() ) {
    warn( "unlock_pipeline() execute error." );
  }

  return ret;
}


void
dump_group_stats( ofp_group_stats *stats ) {
  debug( "***** start group stats *****" );
  debug( "length = %u", stats->length );
  debug( "group_id = %u", stats->group_id );
  debug( "ref_count = %u", stats->ref_count );
  debug( "packet_count = %u", stats->packet_count );
  debug( "byte_count = %u", stats->byte_count );
  debug( "duration_sec = %u", stats->duration_sec );
  debug( "duration_nsec = %u", stats->duration_nsec );

  dlist_element *node = lookup_group_node( stats->group_id );
  group_entry *entry = node->data;
  uint32_t num = get_bucket_count( entry->bucket_list );
  for ( uint32_t i = 0; i < num; i++ ) {
    debug( "bucket_stats[%d].byte_count = %u", i, stats->bucket_stats[ i ].byte_count );
    debug( "bucket_stats[%d].packet_count = %u", i, stats->bucket_stats[ i ].packet_count );
  }
  debug( "***** end group stats *****" );

  return;
}


/**
 * Get Group Features
 * param features pointer for save group features structure
 * return
 */
OFDPE
get_group_features( ofp_group_features *features ) {
  if ( group_table == NULL ) {
    return ERROR_NOT_INITIALIZED;
  }

  features->types = group_types;
  features->capabilities = group_capabilities;
  memcpy( features->max_groups, group_max_groups, sizeof( features->max_groups ) );
  memcpy( features->actions, group_actions, sizeof( features->actions ) );

  return OFDPE_SUCCESS;
}


void
dump_group_features( ofp_group_features *features ) {
  debug( "***** start group features *****" );
  debug( "types = %u", features->types );
  debug( "capabilities = %u", features->capabilities );
  for ( uint32_t i = 0; i < 4; i++ ) {
    debug( "max_groups[%u] = 0x%08x", i, features->max_groups[i] );
    debug( "actions[%u] = 0x%08x", i, features->actions[i] );
  }
  debug( "***** end group features *****" );
}


OFDPE
set_group_features( ofp_group_features *features ) {
  if ( group_table == NULL ) {
    return ERROR_NOT_INITIALIZED;
  }
  group_types = features->types;
  group_capabilities = features->capabilities;
  memcpy( group_max_groups, features->max_groups, sizeof( uint32_t ) * 4 );
  memcpy( group_actions, features->actions, sizeof( uint32_t ) * 4 );
  return OFDPE_SUCCESS;
}


/**
 * Get Group Description status
 * param stats Pointer for save group description status
 * param num pointer for save num of group description
 * return
 */
OFDPE
get_group_desc_status( group_desc_stats **stats, uint16_t *num ) {
  if ( group_table == NULL ) {
    return ERROR_NOT_INITIALIZED;
  }

  if ( !lock_pipeline() ) {
    warn( "lock_pipeline() execute error." );
    return ERROR_LOCK;
  }

  dlist_element *node = get_first_element( group_table );
  uint16_t i = 0;
  while ( node != NULL ) {
    i++;
    node = node->next;
  }
  OFDPE ret = OFDPE_SUCCESS;

  if ( i == 0 ) {
    ret = OFDPE_FAILED;
  }
  else {
    group_desc_stats *retval = ( group_desc_stats * ) xmalloc( sizeof( group_desc_stats ) * i );
    node = get_first_element( group_table );
    uint16_t j = 0;
    while ( node != NULL ) {
      group_entry *entry = node->data;
      retval[ j ].group_id = entry->group_id;
      retval[ j ].type = entry->type;
      retval[ j++ ].bucket_list = entry->bucket_list;
      node = node->next;
    }
    *num = j;
    *stats = retval;
  }

  if ( !unlock_pipeline() ) {
    warn( "unlock_pipeline() execute error." );
  }

  return ret;
}


void
dump_group_desc_status( group_desc_stats *status, uint16_t num ) {
  debug( "***** start group desc status *****" );
  debug( "type[%u] = %u", num, status[num].type );
  debug( "group_id[%u] = %u", num, status[num].group_id );
  debug( "p_bucket[%u] = 0x%08x", num, status[num].bucket_list );
  debug( "***** start group desc status *****" );

}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
