/*
 * Functions for managing group tables.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include "ofdp_common.h"
#include "wrapper.h"
#include "table_manager.h"


// static variables
static uint32_t group_types = 0;
static uint32_t group_capabilities = 0;
static uint32_t group_max_groups[ 4 ] = { 0, 0, 0, 0 };
static uint32_t group_actions[ 4 ] = { 0, 0, 0, 0 };

/**
 * Create Group entry structure
 * param type group entry type
 * param list pointer for action bucket list
 * return pointer for group entry
 */
group_entry *
create_group_entry(  const uint8_t type, const uint32_t group_id, bucket_list *list ) {
  group_entry *group = xmalloc( sizeof( group_entry ) );

  switch ( type ) {
  case OFPGT_ALL:
    break;

  case OFPGT_SELECT:
    break;

  case OFPGT_INDIRECT:
    break;

  default:
#ifndef UNIT_TESTING
    return NULL;
#endif
    break;
  }

  memset( group, 0, sizeof( group_entry ) );

  group->type = type;
  group->group_id = group_id;
  group->p_bucket = list;

  struct timespec t;
  time_now( &t );
  group->duration_sec = ( uint32_t ) t.tv_sec;
  group->duration_nsec = ( uint32_t ) t.tv_nsec;

  return group;
}

/**
 * Delete/free group entry
 * param entry pointer for group entry to be deleted
 */
void
delete_group_entry( group_entry **entry ) {
  if ( entry == NULL ) {
    return;
  }
  if ( *entry == NULL ) {
    return;
  }

  if ( ( *entry )->p_bucket == NULL ) {
    return;
  }
  delete_action_bucket_list( &( ( *entry )->p_bucket ) );

  xfree( *entry );
  *entry = NULL;
}


static group_list *group_table = NULL;

/**
 * Initialize Group Table.
 */
void
init_group_table( void ) {
  if ( group_table != NULL ) {
    return;
  }
  group_table = ( group_list * ) ( create_dlist() );

  group_types = 0x00000001;
  group_capabilities = 0x00000000;
  group_max_groups[ 0 ] = ( ( uint32_t ) ULONG_MAX );
  group_max_groups[ 1 ] = 0x00000000;
  group_max_groups[ 2 ] = 0x00000000;
  group_max_groups[ 3 ] = 0x00000000;
  group_actions[ 0 ] = ( ( uint32_t ) ULONG_MAX );
  group_actions[ 1 ] = 0x00000000;
  group_actions[ 2 ] = 0x00000000;
  group_actions[ 3 ] = 0x00000000;
}

/**
 * Finalize group Table
 */
void
finalize_group_table( void ) {
  if ( group_table == NULL ) {
    return;
  }

  group_list *node = ( group_list * ) get_first_element(
      ( dlist_element * ) ( group_table ) );

  group_entry *group;
  while ( node != NULL ) {
    group = node->node;
    if ( group != NULL ) {
      delete_group_entry( &group );
      assert( group == NULL );
    }
    node = node->next;
  }

  delete_dlist( ( dlist_element * ) ( group_table ) );
  group_table = NULL;

  group_types = 0;
  group_capabilities = 0;
  group_max_groups[ 0 ] = 0;
  group_max_groups[ 1 ] = 0;
  group_max_groups[ 2 ] = 0;
  group_max_groups[ 3 ] = 0;
  group_actions[ 0 ] = 0;
  group_actions[ 1 ] = 0;
  group_actions[ 2 ] = 0;
  group_actions[ 3 ] = 0;
}


static group_list *
lookup_group_node(  const uint32_t group_id ) {
  if ( group_table == NULL ) {
    return NULL;
  }
  group_list *node = ( group_list * ) get_first_element(
      ( dlist_element * ) ( group_table ) );
  for ( ;; ) {
    if ( node->node != NULL ) {
      if ( node->node->group_id == group_id ) {
        return node;
      }
    }
    if ( node->next == NULL ) {
      return NULL;
    }
    node = node->next;
  }
  return NULL;
}


bool
is_valid_group_no( uint32_t group_id ) {
  if ( group_table == NULL ) {
    return false;
  }
  group_list *retval = lookup_group_node( group_id );
  if ( retval == NULL ) {
    return false;
  }
  return true;
}

/**
 * Append Group entry to group table
 * param entry pointer for group entry to be appended
 * return
 */
OFDPE
append_group_entry(  group_entry *entry ) {
  if ( entry == NULL ) {
    return ERROR_ILLEGAL_PARAMETER;
  }

  if ( group_table == NULL ) {
    return ERROR_NOT_INITIALIZED;
  }

  if ( !lock_pipeline() ) {
    warn( "lock_pipeline() execute error." );
    return ERROR_LOCK;
  }

  insert_after_dlist( ( dlist_element * ) group_table, entry );

  if ( !unlock_pipeline() ) {
    warn( "unlock_pipeline() execute error." );
  }

  return OFDPE_SUCCESS;
}

/**
 * remove Group entry to group table
 * param group_id id of group entry to be appended
 * return
 */
OFDPE
remove_group_entry( const uint32_t group_id ) {
  if ( group_table == NULL ) {
    return ERROR_NOT_INITIALIZED;
  }

  if ( !lock_pipeline() ) {
    warn( "lock_pipeline() execute error." );
    return ERROR_LOCK;
  }

  OFDPE ret = OFDPE_SUCCESS;

  group_list *node = lookup_group_node( group_id );
  if ( node == NULL ) {
    ret = ERROR_NOT_FOUND;
  } else {
    delete_group_entry( &( node->node ) );
    delete_dlist_element( ( dlist_element * ) node );
  }

  if ( !unlock_pipeline() ) {
    warn( "unlock_pipeline() execute error." );
  }

  return ret;
}

/**
 * Lookup group entry from group ID
 * param group_id
 * return pointer for group entry
 */
group_entry *
lookup_group_entry( const uint32_t group_id ) {
  if ( group_table == NULL ) {
    return NULL;
  }

  group_list *node = lookup_group_node( group_id );
  if ( node == NULL ) {
    return NULL;
  }
  return node->node;
}

/**
 * Lookup action bucket list from group ID
 * param group_id
 * return pointer for action bucket list
 */
bucket_list *
lookup_action_bucket( const uint32_t group_id ) {
  if ( group_table == NULL ) {
    return NULL;
  }

  group_list *node = lookup_group_node( group_id );
  if ( node == NULL ) {
    return NULL;
  }
  return node->node->p_bucket;
}


uint32_t
group_reference_count_inc( const uint32_t table_id ) {
  if ( group_table == NULL ) {
    return 0;
  }

  group_list *node = lookup_group_node( table_id );
  if ( node == NULL ) {
    return ( uint32_t )~0;
  }

  node->node->ref_count += 1;
  return node->node->ref_count;
}


uint32_t
group_reference_count_dec( const uint32_t table_id ) {
  if ( group_table == NULL ) {
    return 0;
  }
  group_list *node;
  node = lookup_group_node( table_id );
  if ( node == NULL ) {
    return ( uint32_t )~0;
  }

  node->node->ref_count -= 1;
  return node->node->ref_count;
}


uint32_t
group_get_reference_count( const uint32_t table_id ) {
  if ( group_table == NULL ) {
    return 0;
  }
  group_list *node;
  node = lookup_group_node( table_id );
  if ( node == NULL ) {
    return ( uint32_t )~0;
  }

  return node->node->ref_count;
}

/**
 * Get Statistics of group
 * param group_id id of requesting
 * param statistics pointer for save statistics memory pointer
 * param num poitner for save statistics structure count
 * return
 */
OFDPE
get_statistics_group( const uint32_t group_id, ofp_group_stats **statistics, uint32_t *num ) {
  if ( group_table == NULL ) {
    return ERROR_NOT_INITIALIZED;
  }

  if ( !lock_pipeline() ) {
    warn( "lock_pipeline() execute error." );
    return ERROR_LOCK;
  }

  OFDPE ret = OFDPE_SUCCESS;

  group_list *node = lookup_group_node( group_id );
  if ( node == NULL ) {
    ret = OFDPE_FAILED;
  } else {
    *num = get_bucket_count( node->node->p_bucket );

    size_t size = ( sizeof( ofp_group_stats ) ) + ( sizeof( ofp_bucket_counter ) * ( *num ) );
    if ( size > SHRT_MAX ) {
      ret = ERROR_ILLEGAL_PARAMETER;
    } else {
      ofp_group_stats *retval = ( ofp_group_stats * ) xmalloc( size );
      if ( retval == NULL ) {
        warn( "can not allocate memory." );
        *statistics = NULL;
        ret = ERROR_NO_MEMORY;
      } else {
        ofp_bucket_counter *bucket_stats = ( ofp_bucket_counter * ) ( retval + 1 );
        bucket_list *p_bucket = node->node->p_bucket->next;
        for ( uint8_t i = 0; i < *num; i++ ) {
          bucket_stats->byte_count = p_bucket->node->byte_count;
          bucket_stats->packet_count = p_bucket->node->packet_count;
          bucket_stats++;
          p_bucket = p_bucket->next;
        }
        retval->length = ( uint16_t ) size;
        retval->group_id = group_id;
        retval->packet_count = node->node->packet_count;
        retval->byte_count = node->node->byte_count;
        retval->ref_count = node->node->ref_count;

        struct timespec t;
        time_now( &t );
        retval->duration_sec = ( uint32_t )t.tv_sec - node->node->duration_sec;
        retval->duration_nsec = ( uint32_t )t.tv_nsec - node->node->duration_nsec;

        *statistics = retval;
      }
    }
  }

  if ( !unlock_pipeline() ) {
    warn( "unlock_pipeline() execute error." );
  }

  return ret;
}


void
dump_group_stats( ofp_group_stats *stats ) {
  debug( "***** start group stats *****" );
  debug( "length = %u", stats->length );
  debug( "group_id = %u", stats->group_id );
  debug( "ref_count = %u", stats->ref_count );
  debug( "packet_count = %u", stats->packet_count );
  debug( "byte_count = %u", stats->byte_count );
  debug( "duration_sec = %u", stats->duration_sec );
  debug( "duration_nsec = %u", stats->duration_nsec );

  group_list *node = lookup_group_node( stats->group_id );
  uint32_t num = get_bucket_count( node->node->p_bucket );
  for ( uint32_t i = 0; i < num; i++ ) {
    debug( "bucket_stats[%d].byte_count = %u", i, stats->bucket_stats[ i ].byte_count );
    debug( "bucket_stats[%d].packet_count = %u", i, stats->bucket_stats[ i ].packet_count );
  }
  debug( "***** end group stats *****" );

  return;
}

/**
 * Get Group Features
 * param features pointer for save group features structure
 * return
 */
OFDPE
get_group_features( ofp_group_features *features ) {
  if ( group_table == NULL ) {
    return ERROR_NOT_INITIALIZED;
  }

  features->types = group_types;
  features->capabilities = group_capabilities;
  memcpy( features->max_groups, group_max_groups, sizeof( features->max_groups ) );
  memcpy( features->actions, group_actions, sizeof( features->actions ) );

  return OFDPE_SUCCESS;
}

void
dump_group_features( ofp_group_features *features ){
  debug( "***** start group features *****" );
  debug( "types = %u", features->types );
  debug( "capabilities = %u", features->capabilities );
  for( uint32_t i = 0; i < 4 ; i++ ) {
      debug( "max_groups[%u] = 0x%08x", i, features->max_groups[i] );
      debug( "actions[%u] = 0x%08x", i, features->actions[i] );
  }
  debug( "***** end group features *****" );
}


OFDPE
set_group_features( ofp_group_features *features ) {
  if ( group_table == NULL ) {
    return ERROR_NOT_INITIALIZED;
  }
  group_types = features->types;
  group_capabilities = features->capabilities;
  memcpy( group_max_groups, features->max_groups, sizeof( uint32_t ) * 4 );
  memcpy( group_actions, features->actions, sizeof( uint32_t ) * 4 );
  return OFDPE_SUCCESS;
}

/**
 * Get Group Description status
 * param stats Pointer for save group description status
 * param num pointer for save num of group description
 * return
 */
OFDPE
get_group_desc_status( group_desc_stats **stats, uint16_t *num ) {
  if ( group_table == NULL ) {
    return ERROR_NOT_INITIALIZED;
  }
  group_list *node = ( group_list * ) get_first_element(
      ( dlist_element * ) ( group_table ) );
  uint16_t i = 0;
  for (; node->next != NULL; i++ ) {
    node = node->next;
  }

  if ( i == 0 ){
      return OFDPE_FAILED;
  }

  group_desc_stats *retval = ( group_desc_stats * ) xmalloc( sizeof( group_desc_stats ) * i );
  if ( retval == NULL ) {
    return OFDPE_FAILED;
  }
  node = ( group_list * ) get_first_element( ( dlist_element * ) ( group_table ) );
  node = node->next;

  uint16_t j = 0;
  for ( ; j < i; j++ ) {
    retval[ j ].type = node->node->type;
    retval[ j ].p_bucket = node->node->p_bucket;
    retval[ j ].group_id = node->node->group_id;
    node = node->next;
  }


  *num = j;
  *stats = retval;
  return OFDPE_SUCCESS;
}

void
dump_group_desc_status( group_desc_stats *status , uint16_t num){
  debug( "***** start group desc status *****" );
  debug( "type[%u] = %u", num, status[num].type );
  debug( "group_id[%u] = %u", num, status[num].group_id );
  debug( "p_bucket[%u] = 0x%08x", num, status[num].p_bucket );
  debug( "***** start group desc status *****" );

}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
