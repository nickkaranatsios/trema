/*
 * Functions for managing group tables.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef table_manager_group_H
#define table_manager_group_H


#include "openflow_wrapper.h"
#include "table_manager_action_bucket.h"


typedef struct _group_entry {
  uint8_t type;
  uint32_t group_id;
  uint32_t ref_count;
  uint64_t packet_count;
  uint64_t byte_count;
  uint32_t duration_sec;
  uint32_t duration_nsec;
  bucket_list *bucket_list;
} group_entry;


group_entry *create_group_entry( const uint8_t type, const uint32_t group_id, bucket_list *list );
void delete_group_entry( group_entry **entry );


typedef dlist_element group_list;

typedef struct _group_desc_stats {
  uint8_t type;
  uint32_t group_id;
  bucket_list *bucket_list;
} group_desc_stats;


void init_group_table( void );
void finalize_group_table( void );
bool is_valid_group_no( const uint32_t group_id );
OFDPE append_group_entry(  group_entry *entry );
OFDPE remove_group_entry( const uint32_t group_id );
group_entry *lookup_group_entry( const uint32_t group_id );
bucket_list *lookup_action_bucket( const uint32_t group_id );
uint32_t group_reference_count_inc( const uint32_t table_id );
uint32_t group_reference_count_dec( const uint32_t table_id );
uint32_t group_get_reference_count( const uint32_t table_id );
OFDPE get_statistics_group( const uint32_t group_id, ofp_group_stats **statistics, uint32_t *num );
void dump_group_stats( ofp_group_stats *stats );

OFDPE get_group_features( ofp_group_features *features );
OFDPE set_group_features( ofp_group_features *features );
void dump_group_features( ofp_group_features *features );

OFDPE get_group_desc_status( group_desc_stats **stats, uint16_t *num );
void dump_group_desc_status( group_desc_stats *status , uint16_t num);



#endif // table_manager_group_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
