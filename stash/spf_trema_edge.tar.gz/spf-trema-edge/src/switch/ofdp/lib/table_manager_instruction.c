/*
 * Functions for managing flow entry instructions.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include "table_manager_instruction.h"
#include "table_manager_group.h"
#include "openflow.h"
#include "wrapper.h"


void
update_group_reference_counter( instruction_list *list, update_group_reference update ) {
  if ( list == NULL ) {
    return;
  }

  dlist_element *element = get_first_element( list );
  if ( element->data == NULL ) {
    element = element->next;
  }
  while ( element != NULL ) {
    instruction *instruction = element->data;
    dlist_element *action_element = NULL;
    if ( instruction->action_list != NULL ) {
      action_element = get_first_element( instruction->action_list );
    }
    while ( action_element != NULL ) {
      action *action = action_element->data;
      if ( action != NULL ) {
        if ( action->type == OFPAT_GROUP ) {
          if ( update == update_group_reference_increment ) {
            group_reference_count_inc( action->group_id );
          }
          else if ( update == update_group_reference_decrement ) {
            group_reference_count_dec( action->group_id );
          }
          else {
            warn( "group reference is not update. update type %d is not defined.", update );
          }
        }
      }
      action_element = action_element->next;
    }
    element = element->next;
  }
}


static instruction *
malloc_instruction_memory( void ) {
  instruction *ins = ( instruction * ) xcalloc( 1, sizeof( *ins ) );
  return ins;
}


/**
 * Create GOTO TABLE Instruction
 * param table_id table id of GOTO TABLE Instruction
 * return pointer for instruction
 */
instruction *
create_instruction_goto_table( const uint8_t table_id ) {
  instruction *instruction = malloc_instruction_memory();

  if ( instruction == NULL ) {
    return NULL;
  }

  instruction->type = OFPIT_GOTO_TABLE;
  instruction->table_id = table_id;

  return instruction;
}


/**
 * Create WRITE METADATA Instruction
 * param metadata value of metadata
 * param metadata_mask mask of metadata
 * return pointer for instruction
 */
instruction *
create_instruction_write_metadata( const uint64_t metadata, const uint64_t metadata_mask ) {
  instruction *instruction = malloc_instruction_memory();

  instruction->type = OFPIT_WRITE_METADATA;
  instruction->metadata = metadata;
  instruction->metadata_mask = metadata_mask;

  return instruction;
}


/**
 * Create WRITE ACTIONS Instruction
 *
 * param action pointer for action list to be saved to instruction
 * return pointer for instruction
 */
instruction *
create_instruction_write_actions( action_list *action ) {
  instruction *instruction = malloc_instruction_memory();

  instruction->type = OFPIT_WRITE_ACTIONS;
  instruction->action_list = action;

  return instruction;
}


/**
 * Create APPLY ACTIONS Instruction
 *
 * param action pointer for action list to be saved to instruction
 * return pointer for instruction
 */
instruction *
create_instruction_apply_actions( action_list *action ) {
  instruction *instruction = malloc_instruction_memory();

  instruction->type = OFPIT_APPLY_ACTIONS;
  instruction->action_list = action;

  return instruction;
}


/**
 * Create CLEAR ACTIONS Instruction
 * return pointer for instruction
 */
instruction *
create_instruction_clear_actions( void ) {
  instruction *instruction = malloc_instruction_memory();

  instruction->type = OFPIT_CLEAR_ACTIONS;

  return instruction;
}


/**
 * Create METER Instruction
 * param meter_id id of meter to be saved to instruction
 * return pointer for instruction
 */
instruction *
create_instruction_meter( const uint32_t meter_id ) {
  instruction *instruction = malloc_instruction_memory();

  instruction->type = OFPIT_METER;
  instruction->meter_id = meter_id;

  return instruction;
}


instruction_list *
copy_instruction_list( instruction_list *instructions ) {
  if ( instructions == NULL ) {
    return NULL;
  }

  dlist_element *src_instructions = get_first_element( instructions );
  if ( src_instructions->data == NULL ) {
    src_instructions = src_instructions->next;
  }
  dlist_element *dst_instructions = init_instruction_list();
  
  while ( src_instructions != NULL ) {
    instruction *src_instruction = src_instructions->data;
    if ( src_instruction != NULL ) {
      instruction *dst_instruction = malloc_instruction_memory();
      memcpy( dst_instruction, src_instruction, sizeof( *src_instruction ) );
      dst_instruction->action_list = copy_action_list( src_instruction->action_list );
      append_instruction( dst_instructions, dst_instruction );
    }
    src_instructions = src_instructions->next;
  }

  return dst_instructions;
}


/**
 * Delete/free instruction structure
 * param p_instruction pointer for infstruction to be deleted/freed.
 */
void
delete_instruction( instruction **instruction ) {
  if ( ( *instruction )->action_list != NULL ) {
    action_list *action_list = ( *instruction )->action_list;
    finalize_action_list( &action_list );
  }
  xfree( *instruction );
  *instruction = NULL;
}


static void
append_instruction_type( dlist_element *list, instruction *ins, uint16_t type ) {
  dlist_element *element;
  dlist_element *last = list;

  if ( list->next != NULL ) {
    element = list->next;
  }
  else if ( list->prev != NULL ) {
    element = list->prev;
  }
  else {
    element = list;
  }
  while ( element != NULL ) {
    if ( element->data != NULL ) {
      instruction *instruction = element->data;
      if ( type > instruction->type ) {
        insert_before_dlist( element, ins );
        return;
      }
    }
    last = element;
    element = element->next;
  }
  insert_after_dlist( last, ins );
}


/**
 * Append Instruction to instruction list
 * param list Pointer for Instruction list
 * param p_instruction  Pointer for Instruction to be appended
 * return
 */
OFDPE
append_instruction( instruction_list *list, instruction *instruction ) {
  /*
   * The instruction set associated with a flow entry contains a maximum of
   * one instruction of each type.
   */
  dlist_element *element = get_first_element( list );
  if ( element->data == NULL ) {
    element = element->next;
  }
  while ( element != NULL ) {
    if ( element->data != NULL ) {
      struct _instruction *item = element->data;
      if ( item->type == instruction->type ) {
        return ERROR_ILLEGAL_PARAMETER;
      }
    }
    element = element->next;
  }

  switch( instruction->type ) {
  case OFPIT_METER:
    append_instruction_type( list, instruction, OFPIT_METER );
    break;

  case OFPIT_APPLY_ACTIONS:
    append_instruction_type( list, instruction, OFPIT_APPLY_ACTIONS );
    break;

  case OFPIT_CLEAR_ACTIONS:
    append_instruction_type( list, instruction, OFPIT_CLEAR_ACTIONS );
    break;

  case OFPIT_WRITE_ACTIONS:
    append_instruction_type( list, instruction, OFPIT_WRITE_ACTIONS );
    break;

  case OFPIT_WRITE_METADATA:
    append_instruction_type( list, instruction, OFPIT_WRITE_METADATA );
    break;

  case OFPIT_GOTO_TABLE:
    append_instruction_type( list, instruction, OFPIT_GOTO_TABLE );
    break;

  default:
    warn( "invalid instruction type %u", instruction->type );
    break;
  }
  if ( list == NULL ) {
    return ERROR_ILLEGAL_PARAMETER;
  }

  return OFDPE_SUCCESS;
}


/**
 * Finalize/freed instruction list
 * param list pointer for instruction list to be finalized
 */
void
finalize_instruction_list( instruction_list **list ) {
  dlist_element *element = get_first_element( *list );
  if ( element->data == NULL ) {
    element = element->next;
  }
  instruction *instruction = NULL;

  while ( element != NULL ) {
    instruction = element->data;
    if ( instruction != NULL ) {
      delete_instruction( &instruction );
    }
    element = element->next;
  }
  delete_dlist( *list );
  *list = NULL;
}


/**
 * remove instruction from instruction list
 * param list pointer for Instruction List
 * param p_instruction pointer for instruction
 * return
 */
OFDPE
remove_instruction( instruction_list *list, instruction *ins ) {
  
  dlist_element *item = find_element( list, ins );
  if ( item == NULL ) {
    return ERROR_NOT_FOUND;
  }
  delete_instruction( &ins );
  delete_dlist_element( item );

  return OFDPE_SUCCESS;
}


#ifdef LATER


void
remove_instructions( instruction_list **list ) {
  dlist_element *node = ( *list )->next;
  instruction *instruction;
  while ( node != NULL ) {
    instruction = node->data;
    if ( instruction ) {
      remove_instruction( *list, instruction );
    }
    node = node->next;
  }
}
#endif


bool
validate_instruction_goto_table( instruction *instruction ) {
  UNUSED( instruction );
  return true;
}


bool
validate_instruction_write_metadata( instruction *instruction, uint64_t metadata_range ) {
  if ( ( instruction->metadata & metadata_range ) != instruction->metadata ) {
    send_for_notify_error( ERROR_OFDPE_BAD_INSTRUCTION_UNSUP_METADATA, NULL );
    return false;
  }
  if ( ( instruction->metadata_mask & metadata_range ) != instruction->metadata_mask ) {
    send_for_notify_error( ERROR_OFDPE_BAD_INSTRUCTION_UNSUP_METADATA_MASK, NULL );
    return false;
  }
  return true;
}


bool
validate_instruction_write_actions( instruction *instruction ) {
  UNUSED( instruction );
  return true;
}


bool
validate_instruction_apply_actions( instruction *instruction ) {
  UNUSED( instruction );
  return true;
}


bool
validate_instruction_clear_actions( instruction *instruction ) {
  UNUSED( instruction );
  return true;
}


bool
validate_instruction_meter( instruction *instruction ) {
  UNUSED( instruction );
  return true;
}


bool
validate_datapath_instructions( instruction_list *list, uint64_t metadata_range ) {

  if ( list == NULL ) {
    error( "instruction list is not set." );
    return false;
  }

  dlist_element *element = get_first_element( list );
  if ( element->data == NULL ) {
    element = element->next;
  }
  while ( element != NULL ) {
    if ( element->data != NULL ) {
      instruction *instruction = element->data;
      switch ( instruction->type ) {
      case OFPIT_GOTO_TABLE:
        if ( !validate_instruction_goto_table( instruction ) ) {
          return false;
        }
        break;

      case OFPIT_WRITE_METADATA:
        if ( !validate_instruction_write_metadata( instruction, metadata_range ) ) {
          return false;
        }
        break;

      case OFPIT_APPLY_ACTIONS:
        if ( !validate_instruction_apply_actions( instruction ) ) {
          return false;
        }
        break;

      case OFPIT_CLEAR_ACTIONS:
        if ( !validate_instruction_clear_actions( instruction ) ) {
          return false;
        }
        break;

      case OFPIT_METER:
        if ( !validate_instruction_meter( instruction ) ) {
          return false;
        }
        break;

      default:
        send_for_notify_error( ERROR_OFDPE_BAD_INSTRUCTION_UNKNOWN_INST, NULL );
        return false;

        break;
      }

      if ( !validate_action_list( instruction->action_list ) ) {
        return false;
      }
    }
    element = element->next;
  }

  return true;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
