/*
 * Functions for managing flow entry instructions.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include "table_manager_instruction.h"
#include "table_manager_group.h"
#include "openflow.h"
#include "wrapper.h"


void
update_group_reference_counter( instruction_list *list, update_group_reference update ) {
  if ( list == NULL ) {
    return;
  }

  instruction_list *instruction_element = ( instruction_list * ) get_first_element( ( dlist_element * ) ( list ) );

  while ( instruction_element != NULL ) {
    instruction *p_instruction = instruction_element->node;
    if ( p_instruction != NULL && p_instruction->p_action_list != NULL ) {
      action_list *action_element = ( action_list * ) get_first_element( ( dlist_element * ) ( p_instruction->p_action_list ) );
      action *p_action;
      while ( action_element != NULL ) {
        p_action = action_element->node;
        if ( p_action != NULL ) {
          if ( p_action->type == OFPAT_GROUP ) {
            if ( update == update_group_reference_increment ) {
              group_reference_count_inc( p_action->group_id );
            }
            else if ( update == update_group_reference_decrement ) {
              group_reference_count_dec( p_action->group_id );
            }
            else {
              warn( "group reference is not update. update type %d is not defined.", update );
            }
          }
        }
        action_element = action_element->next;
      }
    }
    instruction_element = instruction_element->next;
  }
  return;
}


static instruction *
malloc_instruction_memory( void ) {
  instruction *p_instruction = ( instruction * ) xcalloc( 1, sizeof( instruction ) );

  if ( p_instruction == NULL ) {
    critical( "failed malloc at File: __FILE__, Line: __LINE__\n" );
    return NULL;
  }
  return p_instruction;
}


/**
 * Create GOTO TABLE Instruction
 * param table_id table id of GOTO TABLE Instruction
 * return pointer for instruction
 */
instruction *
create_instruction_goto_table( const uint8_t table_id ) {
  instruction *p_instruction = malloc_instruction_memory();

  if ( p_instruction == NULL ) {
    return NULL;
  }

  p_instruction->type = OFPIT_GOTO_TABLE;
  p_instruction->table_id = table_id;
  return p_instruction;
}


/**
 * Create WRITE METADATA Instruction
 * param metadata value of metadata
 * param metadata_mask mask of metadata
 * return pointer for instruction
 */
instruction *
create_instruction_write_metadata( const uint64_t metadata, const uint64_t metadata_mask ) {
  instruction *p_instruction = malloc_instruction_memory();

  if ( p_instruction == NULL ) {
    return NULL;
  }

  p_instruction->type = OFPIT_WRITE_METADATA;
  p_instruction->metadata = metadata;
  p_instruction->metadata_mask = metadata_mask;
  return p_instruction;
}


/**
 * Create WRITE ACTIONS Instruction
 *
 * param action pointer for action list to be saved to instruction
 * return pointer for instruction
 */
instruction *
create_instruction_write_actions( action_list *action ) {
  instruction *p_instruction = malloc_instruction_memory();

  if ( p_instruction == NULL ) {
    return NULL;
  }

  p_instruction->type = OFPIT_WRITE_ACTIONS;
  p_instruction->p_action_list = action;
  return p_instruction;
}


/**
 * Create APPLY ACTIONS Instruction
 *
 * param action pointer for action list to be saved to instruction
 * return pointer for instruction
 */
instruction *
create_instruction_apply_actions( action_list *action ) {
  instruction *p_instruction = malloc_instruction_memory();

  if ( p_instruction == NULL ) {
    return NULL;
  }

  p_instruction->type = OFPIT_APPLY_ACTIONS;
  p_instruction->p_action_list = action;
  return p_instruction;
}


/**
 * Create CLEAR ACTIONS Instruction
 * return pointer for instruction
 */
instruction *
create_instruction_clear_actions( void ) {
  instruction *p_instruction = malloc_instruction_memory();

  if ( p_instruction == NULL ) {
    return NULL;
  }

  p_instruction->type = OFPIT_CLEAR_ACTIONS;
  return p_instruction;
}


/**
 * Create METER Instruction
 * param meter_id id of meter to be saved to instruction
 * return pointer for instruction
 */
instruction *
create_instruction_meter( const uint32_t meter_id ) {
  instruction *p_instruction = malloc_instruction_memory();

  if ( p_instruction == NULL ) {
    return NULL;
  }

  p_instruction->type = OFPIT_METER;
  p_instruction->meter_id = meter_id;
  return p_instruction;
}


instruction_list *
copy_instruction_list( instruction_list *instructions ) {
  if ( instructions == NULL ) {
    return NULL;
  }

  instruction_list *src_instructions = ( instruction_list * ) get_first_element( ( dlist_element * ) ( instructions ) );
  instruction_list *dst_instructions = init_instruction_list();

  while ( src_instructions != NULL ) {
    instruction *src_instruction = src_instructions->node;
    if ( src_instruction != NULL ) {
      instruction *dst_instruction = malloc_instruction_memory();
      memcpy( dst_instruction, src_instruction, sizeof( instruction ) );
      dst_instruction->p_action_list = copy_action_list( src_instruction->p_action_list );
      append_instruction( dst_instructions, dst_instruction );
    }
    src_instructions = src_instructions->next;
  }

  return dst_instructions;
}


/**
 * Delete/free instruction structure
 * param p_instruction pointer for infstruction to be deleted/freed.
 */
void
delete_instruction( instruction **p_instruction ) {
  // delete_action_set_list(instruction->action_list);
  if ( ( *p_instruction )->p_action_list != NULL ) {
    action_list *p_action_list = ( *p_instruction )->p_action_list;
    finalize_action_list( &p_action_list );
  }
  xfree( *p_instruction );
}


/**
 * Append Instruction to instruction list
 * param list Pointer for Instruction list
 * param p_instruction  Pointer for Instruction to be appended
 * return
 */
OFDPE
append_instruction( instruction_list *list, instruction *p_instruction ) {
  dlist_element *retval = NULL;

  instruction_list *first_node = ( instruction_list * ) get_first_element( ( dlist_element * ) list );

  if ( first_node->next == NULL ) {
    retval = insert_after_dlist( ( dlist_element * ) first_node, ( void * ) p_instruction );
    if ( retval == NULL ) {
      return ERROR_ILLEGAL_PARAMETER;
    }
    return OFDPE_SUCCESS;
  }

  first_node = first_node->next;
  uint16_t type = p_instruction->type;

  instruction_list *cursor_node = first_node;
  for (;; ) {
    if ( cursor_node == NULL ) {
      break;
    }
    if ( cursor_node->node->type == type ) {
      return ERROR_ILLEGAL_PARAMETER;
    }
    cursor_node = cursor_node->next;
  }

  cursor_node = first_node;

  switch ( type ) {
  case ( OFPIT_METER ): // OFPIT_METER
    ;
    retval = insert_before_dlist( ( dlist_element * ) first_node, ( void * ) p_instruction );
    break;

  case ( OFPIT_APPLY_ACTIONS ): // OFPIT_APPLY_ACTIONS
    ;
    if ( cursor_node->node->type == OFPIT_METER ) {
      if ( cursor_node->next == NULL ) {
        retval = insert_after_dlist( ( dlist_element * ) cursor_node, ( void * ) p_instruction );
        break;
      }
      cursor_node = cursor_node->next;
    }
    retval = insert_before_dlist( ( dlist_element * ) cursor_node, ( void * ) p_instruction );
    break;

  case ( OFPIT_CLEAR_ACTIONS ): // OFPIT_APPLY_ACTIONS
    ;
    if ( cursor_node->node->type == OFPIT_METER ) {
      if ( cursor_node->next == NULL ) {
        retval = insert_after_dlist( ( dlist_element * ) cursor_node, ( void * ) p_instruction );
        break;
      }
      cursor_node = cursor_node->next;
    }
    if ( cursor_node->node->type == OFPIT_APPLY_ACTIONS ) {
      if ( cursor_node->next == NULL ) {
        retval = insert_after_dlist( ( dlist_element * ) cursor_node, ( void * ) p_instruction );
        break;
      }
      cursor_node = cursor_node->next;
    }
    retval = insert_before_dlist( ( dlist_element * ) cursor_node, ( void * ) p_instruction );
    break;

  case ( OFPIT_WRITE_ACTIONS ): // OFPIT_APPLY_ACTIONS
    ;
    if ( cursor_node->node->type == OFPIT_METER ) {
      if ( cursor_node->next == NULL ) {
        retval = insert_after_dlist( ( dlist_element * ) cursor_node, ( void * ) p_instruction );
        break;
      }
      cursor_node = cursor_node->next;
    }
    if ( cursor_node->node->type == OFPIT_APPLY_ACTIONS ) {
      if ( cursor_node->next == NULL ) {
        retval = insert_after_dlist( ( dlist_element * ) cursor_node, ( void * ) p_instruction );
        break;
      }
      cursor_node = cursor_node->next;
    }
    if ( cursor_node->node->type == OFPIT_CLEAR_ACTIONS ) {
      if ( cursor_node->next == NULL ) {
        retval = insert_after_dlist( ( dlist_element * ) cursor_node, ( void * ) p_instruction );
        break;
      }
      cursor_node = cursor_node->next;
    }
    retval = insert_before_dlist( ( dlist_element * ) cursor_node, ( void * ) p_instruction );
    break;

  case ( OFPIT_WRITE_METADATA ): // OFPIT_APPLY_ACTIONS
    ;
    if ( cursor_node->node->type == OFPIT_METER ) {
      if ( cursor_node->next == NULL ) {
        retval = insert_after_dlist( ( dlist_element * ) cursor_node, ( void * ) p_instruction );
        break;
      }
      cursor_node = cursor_node->next;
    }
    if ( cursor_node->node->type == OFPIT_APPLY_ACTIONS ) {
      if ( cursor_node->next == NULL ) {
        retval = insert_after_dlist( ( dlist_element * ) cursor_node, ( void * ) p_instruction );
        break;
      }
      cursor_node = cursor_node->next;
    }
    if ( cursor_node->node->type == OFPIT_CLEAR_ACTIONS ) {
      if ( cursor_node->next == NULL ) {
        retval = insert_after_dlist( ( dlist_element * ) cursor_node, ( void * ) p_instruction );
        break;
      }
      cursor_node = cursor_node->next;
    }
    if ( cursor_node->node->type == OFPIT_WRITE_ACTIONS ) {
      if ( cursor_node->next == NULL ) {
        retval = insert_after_dlist( ( dlist_element * ) cursor_node, ( void * ) p_instruction );
        break;
      }
      cursor_node = cursor_node->next;
    }
    retval = insert_before_dlist( ( dlist_element * ) cursor_node, ( void * ) p_instruction );
    break;

  case ( OFPIT_GOTO_TABLE ): // OFPIT_GOTO_TABLE
    ;
    instruction_list *last_node = ( instruction_list * ) get_last_element( ( dlist_element * ) list );
    retval = insert_after_dlist( ( dlist_element * ) last_node, ( void * ) p_instruction );
    break;
  }
  if ( retval == NULL ) {
    return ERROR_ILLEGAL_PARAMETER;
  }

  return OFDPE_FAILED;
}


/**
 * Finalize/freed instruction list
 * param list pointer for instruction list to be finalized
 */
void
finalize_instruction_list( instruction_list **list ) {
  instruction_list *node = ( instruction_list * ) get_first_element(
    ( dlist_element * ) ( *list ) );

  instruction *p_instruction;

  while ( node != NULL ) {
    p_instruction = node->node;
    if ( p_instruction != NULL ) {
      delete_instruction( &p_instruction );
    }
    node = node->next;
  }

  delete_dlist( ( dlist_element * ) ( *list ) );
  *list = NULL;
}


/**
 * remove instruction from instruction list
 * param list pointer for Instruction List
 * param p_instruction pointer for instruction
 * return
 */
OFDPE
remove_instruction( instruction_list *list, instruction *p_instruction ) {
  instruction_list *node = ( instruction_list * ) find_element( ( dlist_element * ) list,
    ( void * ) p_instruction );

  if ( node == NULL ) {
    return ERROR_NOT_FOUND;
  }

  delete_instruction( &( node->node ) );
  delete_dlist_element( ( dlist_element * ) node );

  return OFDPE_SUCCESS;
}


#ifdef LATER


void
remove_instructions( instruction_list **list ) {
  instruction_list *node = ( instruction_list * ) get_first_element(
    ( dlist_element * ) ( *list ) );
  instruction *ins;

  while ( node != NULL ) {
    ins = node->node;
    if ( ins != NULL ) {
      remove_instruction( *list, ins );
    }
    node = node->next;
  }
}
#endif


bool
validate_instruction_goto_table( instruction *p_instruction ) {
  UNUSED( p_instruction );
  return true;
}


bool
validate_instruction_write_metadata( instruction *p_instruction, uint64_t metadata_range ) {
  if ( ( p_instruction->metadata & metadata_range ) != p_instruction->metadata ) {
    send_for_notify_error( ERROR_OFDPE_BAD_INSTRUCTION_UNSUP_METADATA, NULL );
    return false;
  }
  if ( ( p_instruction->metadata_mask & metadata_range ) != p_instruction->metadata_mask ) {
    send_for_notify_error( ERROR_OFDPE_BAD_INSTRUCTION_UNSUP_METADATA_MASK, NULL );
    return false;
  }
  return true;
}


bool
validate_instruction_write_actions( instruction *p_instruction ) {
  UNUSED( p_instruction );
  return true;
}


bool
validate_instruction_apply_actions( instruction *p_instruction ) {
  UNUSED( p_instruction );
  return true;
}


bool
validate_instruction_clear_actions( instruction *p_instruction ) {
  UNUSED( p_instruction );
  return true;
}


bool
validate_instruction_meter( instruction *p_instruction ) {
  UNUSED( p_instruction );
  return true;
}


bool
validate_datapath_instructions( instruction_list *list, uint64_t metadata_range ) {

  if ( list == NULL ) {
    error( "instruction list is not set." );
    return false;
  }

  instruction_list *node = ( instruction_list * ) get_first_element(
    ( dlist_element * ) ( list ) );

  for (; node->next != NULL; node = node->next ) {
    instruction *p_inst = node->next->node;
    switch ( p_inst->type ) {
    case OFPIT_GOTO_TABLE:
      if ( !validate_instruction_goto_table( p_inst ) ) {
        return false;
      }
      break;

    case OFPIT_WRITE_METADATA:
      if ( !validate_instruction_write_metadata( p_inst, metadata_range ) ) {
        return false;
      }
      break;

    case OFPIT_WRITE_ACTIONS:
      if ( !validate_instruction_write_actions( p_inst ) ) {
        return false;
      }
      break;

    case OFPIT_APPLY_ACTIONS:
      if ( !validate_instruction_apply_actions( p_inst ) ) {
        return false;
      }
      break;

    case OFPIT_CLEAR_ACTIONS:
      if ( !validate_instruction_clear_actions( p_inst ) ) {
        return false;
      }
      break;

    case OFPIT_METER:
      if ( !validate_instruction_meter( p_inst ) ) {
        return false;
      }
      break;

    default:
      send_for_notify_error( ERROR_OFDPE_BAD_INSTRUCTION_UNKNOWN_INST, NULL );
      return false;

      break;
    }

    if ( !validate_action_list( p_inst->p_action_list ) ) {
      return false;
    }
  }
  return true;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
