/*
 * Functions for managing flow entry instructions.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef TABLEMANAGER_INSTRUCTION_H
#define TABLEMANAGER_INSTRUCTION_H


#include "doubly_linked_list.h"
#include "table_manager_action.h"


typedef struct _instruction {
  uint16_t type;
  uint8_t table_id;
  uint64_t metadata;
  uint64_t metadata_mask;
  action_list *p_action_list;
  uint32_t meter_id;
} instruction;


instruction *create_instruction_goto_table( const uint8_t table_id );
instruction *create_instruction_write_metadata( const uint64_t metadata, const uint64_t metadata_mask );
instruction *create_instruction_write_actions( action_list *action );
instruction *create_instruction_apply_actions( action_list *action );
instruction *create_instruction_clear_actions( void );
instruction *create_instruction_meter( const uint32_t meter_id );
void delete_instruction( instruction **p_instruction );


typedef struct _instruction_dlist_element {
  instruction *node;
  struct _instruction_dlist_element *prev;
  struct _instruction_dlist_element *next;
} instruction_list;


OFDPE append_instruction( instruction_list *list, instruction *p_instruction );
OFDPE remove_instruction( instruction_list *list, instruction *p_instruction );
#define init_instruction_list() ( instruction_list * ) ( create_dlist() )
void finalize_instruction_list( instruction_list **list );
instruction_list * copy_instruction_list( instruction_list *list );
bool validate_instruction_goto_table( instruction *p_instruction );
bool validate_instruction_write_metadata( instruction *p_instruction, uint64_t metadata_range );
bool validate_instruction_write_actions( instruction *p_instruction );
bool validate_instruction_apply_actions( instruction *p_instruction );
bool validate_instruction_clear_actions( instruction *p_instruction );
bool validate_instruction_meter( instruction *p_instruction );
// rename validate_instructions => validate_datapath_instructions to avoid name clash with libtrema.
bool validate_datapath_instructions( instruction_list *list, uint64_t metadata_range );


typedef enum {
  update_group_reference_increment,
  update_group_reference_decrement
} update_group_reference;
void update_group_reference_counter( instruction_list *list, update_group_reference update );


#endif // TABLEMANAGER_INSTRUCTION_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
