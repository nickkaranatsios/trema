/*
 * Functions for managing flow entry match fields.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include "table_manager_match.h"
#include "wrapper.h"


#define NULL_VALUE ~0
const uint8_t NULL_VALUE8 = (uint8_t)~0;
const uint16_t NULL_VALUE16 = (uint16_t)~0;
const uint32_t NULL_VALUE32 = (uint32_t)~0;
const uint64_t NULL_VALUE64 = (uint64_t)~0;


/**
 * Create initialized match structure
 * return match structure
 */
match *
init_match( void ) {
  match8 init_match8 = { 0, NULL_VALUE8, false };
  match16 init_match16 = { 0, NULL_VALUE16, false };
  match32 init_match32 = { 0, NULL_VALUE32, false };
  match64 init_match64 = { 0, NULL_VALUE64, false };

  match *p_match = ( match * ) xmalloc( sizeof( match ) );

  if ( p_match == NULL ) {
    return NULL;
  }

  p_match->arp_op = init_match16;
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    p_match->arp_sha[ i ] = init_match8;
  }
  p_match->arp_spa = init_match32;
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    p_match->arp_tha[ i ] = init_match8;
  }
  p_match->arp_tpa = init_match32;
  p_match->in_phy_port = init_match32;
  p_match->in_port = init_match32;
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    p_match->eth_dst[ i ] = init_match8;
  }
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    p_match->eth_src[ i ] = init_match8;
  }
  p_match->eth_type = init_match16;
  p_match->icmpv4_code = init_match8;
  p_match->icmpv4_type = init_match8;
  p_match->icmpv6_code = init_match8;
  p_match->icmpv6_type = init_match8;
  p_match->ip_dscp = init_match8;
  p_match->ip_ecn = init_match8;
  p_match->ip_proto = init_match8;
  p_match->ipv4_dst = init_match32;
  p_match->ipv4_src = init_match32;
  for ( int i = 0; i < IPV6_ADDRLEN; i++ ) {
    p_match->ipv6_dst[ i ] = init_match8;
  }
  p_match->ipv6_exthdr = init_match16;
  p_match->ipv6_flabel = init_match32;
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    p_match->ipv6_nd_sll[ i ] = init_match8;
  }
  for ( int i = 0; i < IPV6_ADDRLEN; i++ ) {
    p_match->ipv6_nd_target[ i ] = init_match8;
  }
  for ( int i = 0; i < ETH_ADDRLEN; i++ ) {
    p_match->ipv6_nd_tll[ i ] = init_match8;
  }
  for ( int i = 0; i < IPV6_ADDRLEN; i++ ) {
    p_match->ipv6_src[ i ] = init_match8;
  }
  p_match->metadata = init_match64;
  p_match->mpls_bos = init_match8;
  p_match->mpls_label = init_match32;
  p_match->mpls_tc = init_match8;
  p_match->sctp_dst = init_match16;
  p_match->sctp_src = init_match16;
  p_match->tcp_dst = init_match16;
  p_match->tcp_src = init_match16;
  p_match->tunnel_id = init_match64;
  p_match->udp_dst = init_match16;
  p_match->udp_src = init_match16;
  p_match->vlan_pcp = init_match8;
  p_match->vlan_vid = init_match16;
  p_match->pbb_isid = init_match32;

  return p_match;
}

/**
 * Delete/Free match structure
 * param p_match
 */
void
delete_match( match **p_match ) {
  if ( *p_match == NULL ) {
    return;
  }

  xfree( *p_match );
  *p_match = NULL;
}


bool
validate_match( match *p_match ) {
  if ( p_match == NULL ) {
    return false;
  }

  // Bad PreRequisite Check
  if ( ( p_match->in_phy_port.valid == true ) & ( p_match->in_port.valid != true ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->vlan_pcp.valid == true ) & ( p_match->vlan_vid.valid != true ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->ip_dscp.valid == true )
    & ( ( p_match->eth_type.valid != true ) | ( ( p_match->eth_type.value != 0x0800 ) & ( p_match->eth_type.value != 0x86dd ) ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->ip_ecn.valid == true )
    & ( ( p_match->eth_type.valid != true ) | ( ( p_match->eth_type.value != 0x0800 ) & ( p_match->eth_type.value != 0x86dd ) ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->ip_proto.valid == true )
    & ( ( p_match->eth_type.valid != true ) | ( ( p_match->eth_type.value != 0x0800 ) & ( p_match->eth_type.value != 0x86dd ) ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->ipv4_src.valid == true )
    & ( ( p_match->eth_type.valid != true ) | ( p_match->eth_type.value != 0x0800 ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->ipv4_dst.valid == true )
    & ( ( p_match->eth_type.valid != true ) | ( p_match->eth_type.value != 0x0800 ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->tcp_src.valid == true )
    & ( ( p_match->ip_proto.valid != true ) | ( p_match->ip_proto.value != 6 ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->tcp_dst.valid == true )
    & ( ( p_match->ip_proto.valid != true ) | ( p_match->ip_proto.value != 6 ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->udp_src.valid == true )
    & ( ( p_match->ip_proto.valid != true ) | ( p_match->ip_proto.value != 17 ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->udp_dst.valid == true )
    & ( ( p_match->ip_proto.valid != true ) | ( p_match->ip_proto.value != 17 ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->sctp_src.valid == true )
    & ( ( p_match->ip_proto.valid != true ) | ( p_match->ip_proto.value != 132 ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->sctp_dst.valid == true )
    & ( ( p_match->ip_proto.valid != true ) | ( p_match->ip_proto.value != 132 ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->icmpv4_type.valid == true )
    & ( ( p_match->ip_proto.valid != true ) | ( p_match->ip_proto.value != 1 ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->icmpv4_code.valid == true )
    & ( ( p_match->ip_proto.valid != true ) | ( p_match->ip_proto.value != 1 ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->arp_op.valid == true )
    & ( ( p_match->eth_type.valid != true ) | ( p_match->eth_type.value != 0x0806 ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->arp_spa.valid == true )
    & ( ( p_match->eth_type.valid != true ) | ( p_match->eth_type.value != 0x0806 ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->arp_tpa.valid == true )
    & ( ( p_match->eth_type.valid != true ) | ( p_match->eth_type.value != 0x0806 ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->arp_sha[ 0 ].valid == true )
    & ( ( p_match->eth_type.valid != true ) | ( p_match->eth_type.value != 0x0806 ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->arp_tha[ 0 ].valid == true )
    & ( ( p_match->eth_type.valid != true ) | ( p_match->eth_type.value != 0x0806 ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->ipv6_src[ 0 ].valid == true )
    & ( ( p_match->eth_type.valid != true ) | ( p_match->eth_type.value != 0x86dd ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->ipv6_dst[ 0 ].valid == true )
    & ( ( p_match->eth_type.valid != true ) | ( p_match->eth_type.value != 0x86dd ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->ipv6_flabel.valid == true )
    & ( ( p_match->eth_type.valid != true ) | ( p_match->eth_type.value != 0x86dd ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->icmpv6_type.valid == true )
    & ( ( p_match->ip_proto.valid != true ) | ( p_match->ip_proto.value != 58 ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->icmpv6_code.valid == true )
    & ( ( p_match->ip_proto.valid != true ) | ( p_match->ip_proto.value != 58 ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->ipv6_nd_target[ 0 ].valid == true )
    & ( ( p_match->icmpv6_type.valid != true ) | ( ( p_match->icmpv6_type.value != 135 ) & ( p_match->icmpv6_type.value != 136 ) ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->ipv6_nd_sll[ 0 ].valid == true )
    & ( ( p_match->icmpv6_type.valid != true ) | ( p_match->icmpv6_type.value != 135 ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->ipv6_nd_tll[ 0 ].valid == true )
    & ( ( p_match->icmpv6_type.valid != true ) | ( p_match->icmpv6_type.value != 136 ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->mpls_label.valid == true )
    & ( ( p_match->eth_type.valid != true ) | ( ( p_match->eth_type.value != 0x8847 ) & ( p_match->eth_type.value != 0x8848 ) ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->mpls_tc.valid == true )
    & ( ( p_match->eth_type.valid != true ) | ( ( p_match->eth_type.value != 0x8847 ) & ( p_match->eth_type.value != 0x8848 ) ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->mpls_bos.valid == true )
    & ( ( p_match->eth_type.valid != true ) | ( ( p_match->eth_type.value != 0x8847 ) & ( p_match->eth_type.value != 0x8848 ) ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->pbb_isid.valid == true )
    & ( ( p_match->eth_type.valid != true ) | ( p_match->eth_type.value != 0x88e7 ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  if ( ( p_match->ipv6_exthdr.valid == true )
    & ( ( p_match->eth_type.valid != true ) | ( p_match->eth_type.value != 0x86dd ) ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_MATCH_BAD_PREREQ, NULL );
    return false;
  }
  return true;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
