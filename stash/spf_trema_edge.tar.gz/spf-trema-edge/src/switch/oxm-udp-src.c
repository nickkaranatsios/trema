/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <stdint.h>
#include "openflow.h"
#include "table_manager_match.h"
#include "oxm.h"


static uint16_t udp_src_length( const match *match );
static void pack_udp_src( struct ofp_match *ofp_match, const match *match );


static struct oxm oxm_udp_src = {
  OFPXMT_OFB_UDP_SRC,
  ( uint16_t ) sizeof( uint16_t ),
  udp_src_length,
  pack_udp_src
};


void 
init_oxm_udp_src( void ) {
  register_oxm( &oxm_udp_src );
}


static uint16_t
udp_src_length( const match *match ) {
  uint16_t length = 0;
  
  if ( match->udp_src.valid ) {
    length = oxm_udp_src.length;
  }
  return length;
}


static void
pack_udp_src( struct ofp_match *ofp_match, const match *match ) {
  if ( match->udp_src.valid ) {
    ofp_match->type = oxm_udp_src.type;
    ofp_match->length = oxm_udp_src.length;
    memcpy( &ofp_match->oxm_fields, &match->udp_src.value, oxm_udp_src.length );
  }
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
