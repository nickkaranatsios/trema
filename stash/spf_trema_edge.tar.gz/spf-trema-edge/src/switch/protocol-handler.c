/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <sys/socket.h>

#include "openflow_switch_interface.h"
#include "log.h"
#include "ofdp.h"
#include "port_manager.h"
#include "action_executor.h"
#include "async.h"
#include "switch-common.h"
#include "protocol.h"
#include "oxm-helper.h"
#include "action-helper.h"
#include "instruction-helper.h"
#include "stats-helper.h"
#include "group-helper.h"
#include "parse-options.h"


static void
_handle_hello( const uint32_t transaction_id, const uint8_t version, const buffer *version_data, void *user_data ) {
  UNUSED( user_data );
  info( "handle hello received %u %u", transaction_id, version );

  struct ofp_hello_elem_versionbitmap *versionbitmap = ( struct ofp_hello_elem_versionbitmap * ) version_data->data;
  const uint32_t ofp_versions[ 1 ] = { OFP_VERSION };
  
  uint32_t bitmap = versionbitmap->bitmaps[ 0 ];
  if ( ( bitmap & ( ( uint32_t ) 1 << ofp_versions[ 0 ] ) ) != ( ( uint32_t ) ofp_versions[ 0 ] ) ) {
    buffer *hello_buf = create_hello_elem_versionbitmap( transaction_id, ofp_versions,
      sizeof( ofp_versions ) / sizeof( ofp_versions[ 0 ] ) );
    switch_send_openflow_message( hello_buf );
    free_buffer( hello_buf );
  } else {
    send_error_message( transaction_id, OFPET_HELLO_FAILED, OFPHFC_INCOMPATIBLE );
  }
}
void ( *handle_hello )( const uint32_t transaction_id,
        const uint8_t version,
        const buffer *version_data,
        void *user_data ) = _handle_hello;


static void
_handle_features_request( const uint32_t transaction_id, void *user_data ) {
  assert( user_data );
  struct protocol *protocol = user_data;

  struct ofp_switch_features switch_features;
  memset( &switch_features, 0, sizeof( struct ofp_switch_features ) );
  get_switch_features( &switch_features );
  /*
   * The n_buffers field specifies the maximum number of packets the switch can
   * buffer when sending packets to the controller using packet-in messages.
   */
  buffer *features_reply = create_features_reply( transaction_id,
    switch_features.datapath_id,
    switch_features.n_buffers,
    switch_features.n_tables,
    switch_features.auxiliary_id,
    switch_features.capabilities );
  if ( switch_send_openflow_message( features_reply ) ) {
    protocol->ctrl.controller_connected = true;
  }
  free_buffer( features_reply );
}
void ( *handle_features_request )( const uint32_t transaction_id,
        void *user_data ) = _handle_features_request;


// protocol to datapath message.
static void
_handle_set_config( const uint32_t transaction_id, const uint16_t flags, uint16_t miss_send_len, void *user_data ) {
  UNUSED( user_data );

  buffer *buffer = create_set_config( transaction_id, flags, miss_send_len );
  struct ofp_switch_config *switch_config = ( struct ofp_switch_config * ) buffer->data;
  set_switch_config( switch_config );
  free_buffer( buffer );
}
void ( *handle_set_config )( const uint32_t transaction_id,
        const uint16_t flags,
        uint16_t miss_send_len,
        void *user_data ) = _handle_set_config;


static void
_handle_get_config_request( const uint32_t transaction_id, void * user_data ) {
  UNUSED( user_data );
  
  struct ofp_switch_config switch_config;
  if ( get_switch_config( &switch_config ) == OFDPE_SUCCESS ) {
    buffer *get_config_reply = create_get_config_reply( transaction_id, switch_config.flags, switch_config.miss_send_len );
    switch_send_openflow_message( get_config_reply );
    free_buffer( get_config_reply );
  }
}
void ( *handle_get_config_request )( const uint32_t transaction_id, void *user_data ) = _handle_get_config_request;


static void
_handle_echo_request( const uint32_t transaction_id, const buffer *body, void *user_data ) {
  UNUSED( user_data );
  buffer *echo_reply = create_echo_reply( transaction_id, body );
  switch_send_openflow_message( echo_reply );
  free_buffer( echo_reply );
}
void ( *handle_echo_request )( const uint32_t transaction_id,
        const buffer *body,
        void *user_data ) = _handle_echo_request;


static instruction_list *
create_assign_instruction_list( list_element *list, uint8_t table_id ) {
  instruction_list *ins_list;
  init_instruction_list( &ins_list );
  int ret = assign_instructions( ins_list, list, table_id );
  if ( ret == OFDPE_SUCCESS ) {
    return ins_list;
  }
  return NULL;
}


static void
handle_flow_mod_add( const uint32_t transaction_id, const uint64_t cookie, 
                     const uint64_t cookie_mask, const uint8_t table_id,
                     const uint16_t idle_timeout, const uint16_t hard_timeout,
                     const uint16_t priority, const uint32_t buffer_id,
                     const uint16_t flags, const oxm_matches *oxm,
                     const openflow_instructions *instructions,
                     const uint32_t packet_in_buffer_id ) {
  /*
   * currently if flags set OFPFF_SEND_FLOW_REM is the only allowed value.
   */
  if ( flags && ( flags | OFPFF_SEND_FLOW_REM ) != OFPFF_SEND_FLOW_REM ) {
    warn( "An unsupported flags value found %d", flags );
    return;
  }
  /*
   * The use of OFPTT_ALL is only valid for delete requests.
   */
  if ( table_id == OFPTT_ALL ) {
    send_error_message( transaction_id, OFPET_FLOW_MOD_FAILED, OFPFMFC_BAD_TABLE_ID );
    return;
  }
  /*
   * If no buffered packet is associated with a flow mod it must be set
   * to OFP_NO_BUFFER otherwise it must be equal to the buffer_id sent to
   * controller by a packet-in message.
   */
  if ( buffer_id != OFP_NO_BUFFER && ( buffer_id != packet_in_buffer_id ) ) {
      send_error_message( transaction_id, OFPET_FLOW_MOD_FAILED, OFPFMFC_UNKNOWN );
      return;
  }
  match *match = NULL;

  match = init_match();
  if ( oxm != NULL && oxm->n_matches > 0 ) {
    
#ifdef DEBUG    
    char oxm_str[ 2048 ];
    match_to_string( oxm, oxm_str, sizeof( oxm_str ) );
    printf( "%s\n", oxm_str );
#endif
    
    for ( list_element *e = oxm->list; e != NULL; e = e->next ) {
      oxm_match_header *hdr = e->data;
      assign_match( match, hdr );
    }
  }
  flow_entry *entry = NULL;
  uint64_t packet_count = 0;
  uint64_t byte_count = 0;
  entry = lookup_flow_entry_strict( table_id, match, priority );
  if ( entry != NULL ) {
    /*
     * If a flow entry with identical match fields and priority already resides
     * in the requested table, then that entry, including its duration, must be
     * cleared from the table, and the new flow entry added.
     * If the OFPFF_RESET_COUNTS flag is set, the flow entry counters must be
     * cleared, otherwise they should be copied from the replaced flow entry.
     */
    packet_count = entry->packet_count;
    byte_count = entry->byte_count;
    entry->duration_nsec = 0;
    entry->duration_sec = 0;
    time_now( &entry->created_at );
    entry->last_seen = entry->created_at;


    // after the deletion the entry is set to null.
    // This call should be update_entry( table_id, entry )
    update_flow_entry( cookie, cookie_mask, table_id, false, priority, flags, entry->match, entry->instructions );
  }
  if ( entry == NULL ) {
    instruction_list *instruction_list = create_assign_instruction_list( instructions->list, table_id );
    if ( instruction_list == NULL ) {
      finalize_instruction_list( &instruction_list );
      send_error_message( transaction_id, OFPET_FLOW_MOD_FAILED, OFPBIC_UNSUP_INST );
      xfree( match );
      return;
    }
    flow_entry *new_entry;
    /*
     * When a flow entry is inserted in a table, its flags field is set with the
     * values from the message.
     * When a flow entry is inserted in a table, its idle_timeout and
     * hard_timeout fields are set with the values from the message.
     * When a flow entry is inserted in a table through an OFPFC_ADD message,
     * its cookie field is set to the provided value
     */
    new_entry = create_flow_entry( match, instruction_list, priority,
                                   idle_timeout, hard_timeout, flags, cookie );
    if ( new_entry != NULL ) {
      /*
       * Just overwrite the counter values.
       */
      new_entry->packet_count = packet_count;
      new_entry->byte_count = byte_count;
      if ( append_flow_entry( table_id, new_entry ) != OFDPE_SUCCESS ) {
        /*
         * TODO we should send a more appropriate error once we worked out the
         * datapath errors.
        */
        finalize_instruction_list( &instruction_list );
        send_error_message( transaction_id, OFPET_FLOW_MOD_FAILED, OFPFMFC_UNKNOWN );
      }
    } else {
      finalize_instruction_list( &instruction_list );
      xfree( match );
    }
  }
}


static void
handle_flow_mod_delete( const uint32_t transaction_id, const uint64_t cookie,
                        const uint64_t cookie_mask, const uint8_t table_id,
                        const uint16_t idle_timeout, const uint16_t hard_timeout,
                        const uint16_t priority, const uint32_t buffer_id,
                        const uint32_t out_port, const uint32_t out_group,
                        const uint16_t flags, const oxm_matches *oxm_match,
                        const openflow_instructions *instructions,
                        const bool strict ) {

  UNUSED( transaction_id );
  UNUSED( cookie );
  UNUSED( cookie_mask );
  UNUSED( idle_timeout );
  UNUSED( hard_timeout );
  UNUSED( priority );
  UNUSED( buffer_id );
  UNUSED( flags );
  UNUSED( instructions );
  
  /*
   * TODO At the moment not sure which datapath API to call to delete all flow
   * entries from all tables. Calling lookup_flow_entry_strict() or
   * lookup_flow_entry() one by one maybe the only way to delete all flow
   * entries which seems like an overhead.
   */
  if ( table_id == OFPTT_ALL ) {
    return;
  }
  match *match = init_match();
  if ( oxm_match != NULL && oxm_match->n_matches > 0 ) {
    for ( list_element *e = oxm_match->list; e != NULL; e = e->next ) {
      oxm_match_header *hdr = e->data;
      assign_match( match, hdr );
    }
  }
  flow_entry *entry = NULL;
  if ( strict ) {
    entry = lookup_flow_entry_strict( table_id, match, priority );
  } else {
    entry = lookup_flow_entry( table_id, match );
  }
  if ( entry != NULL ) {
    /*
     * if the out_port or out_group contain a value either than OFPP_ANY
     * or OPGP_ANY should match the looked up entry.
     * Retrieve the action that matches the out_port or out_group from
     * datapath's flow entry's instruction list.
     */
    action *action = NULL;

    if ( out_port != OFPP_ANY ) {
      const struct ofp_action_output ac_output = {
        .type = OFPAT_OUTPUT,
        .port = out_port
      };
      action = find_action( ( const struct ofp_action_header * ) &ac_output, &entry->instructions );
    }
    if ( out_group != OFPG_ANY ) {
      const struct ofp_action_group ac_group = {
        .type = OFPAT_GROUP,
        .group_id = out_group
      };
      action = find_action( ( const struct ofp_action_header * ) &ac_group, &entry->instructions );
    }
    if ( action != NULL ) {
      if (  action->port == out_port || action->group_id == out_group ) {
        remove_flow_entry( table_id, entry );
      }
    } else {
      remove_flow_entry( table_id, entry );
    }
  }
}


static void
handle_flow_mod_mod( const uint32_t transaction_id,
        const uint64_t cookie,
        const uint64_t cookie_mask,
        const uint8_t table_id,
        const uint16_t priority,
        const oxm_matches *oxm,
        const openflow_instructions *instructions,
        const bool strict ) {
  UNUSED( transaction_id );
  
  match *match = init_match( );
  if ( oxm != NULL && oxm->n_matches > 0 ) {
    for ( list_element *e = oxm->list; e != NULL; e = e->next ) {
      oxm_match_header *hdr = e->data;
      assign_match( match, hdr );
    }
  }
  
  flow_entry *entry = NULL;
  if ( strict ) {
    /*
     * In the strict versions, the set of match fields, all match fields,
     * including their masks, and the priority, are strictly matched against the
     * entry, and only an identical flow entry is modified or removed.
     */
    entry = lookup_flow_entry_strict( table_id, match, priority );
  } else {
    /*
     * For non-strict modify and delete commands, all flow entries that match
     * the flow mod description are modified or removed.
     * Is this ok for the lookup_flow_entry function to return a single entry.
     */
    entry = lookup_flow_entry( table_id, match );
  }
  bool update = true;
  /*
   * Modify and delete commands can also be filtered by cookie value, if the
   * cookie_mask field contains a value other than 0. This constraint is that
   * the bits specified by the cookie_mask in both the cookie field of the flow
   * mod and a flow entry’s cookie value must be equal. In other words,
   * (flow entry.cookie & flow mod.cookie mask) == 
   * (flow mod.cookie & flow mod.cookie mask).
   */
  if ( cookie_mask ) {
    if ( ( entry->cookie & cookie_mask ) != ( cookie & cookie_mask ) ) {
      update = false;
    }
  }
  if ( entry != NULL && update ) {
    instruction_list *ins_list = NULL;
    if ( instructions != NULL ) {
      init_instruction_list( &ins_list );
      assign_instructions( ins_list, instructions->list, table_id );
    }
    /*
     * For modify requests (OFPFC_MODIFY or OFPFC_MODIFY_STRICT), if a
     * matching entry exists in the ta-ble, the instructions field of this 
     * entry is updated with the value from the request, whereas its cookie, 
     * idle_timeout, hard_timeout, flags, counters and duration fields are 
     * left unchanged.
     */
    entry->instructions = ins_list;
    // update_flow_entry( table_id, entry );
  }
}


static void
_handle_flow_mod( const uint32_t transaction_id,
        const uint64_t cookie,
        const uint64_t cookie_mask,
        const uint8_t table_id,
        const uint8_t command,
        const uint16_t idle_timeout,
        const uint16_t hard_timeout,
        const uint16_t priority,
        const uint32_t buffer_id,
        const uint32_t out_port,
        const uint32_t out_group,
        const uint16_t flags,
        const oxm_matches *oxm,
        const openflow_instructions *instructions,
        void *user_data
  ) {
  assert( user_data );
  struct protocol *protocol = user_data;
  bool strict = false;

  switch ( command ) {
    case OFPFC_ADD:
      /*
       * The cookie_mask field is ignored for this command.
       * TODO the datapath flow entry contains no buffer_id field to set.
       * From observation datapath buffers every packet regardless of buffer_id
       */
      handle_flow_mod_add( transaction_id, cookie, cookie_mask,
                           table_id, idle_timeout, hard_timeout,
                           priority, buffer_id, flags, oxm,
                           instructions, protocol->ctrl.buffer_id );
      break;
    case OFPFC_MODIFY:
      /*
       * The idle_timeout and hard_timeout fields are ignored.
       * Also the out_port and out_group fields are ignored.
       * When a flow entry is matched or modified the flags field is ignored.
       * When a flow entry is modified its cookie field is unchanged.
       */
      handle_flow_mod_mod( transaction_id, cookie, cookie_mask, table_id,
                           priority, oxm, instructions, strict );
      break;
    case OFPFC_MODIFY_STRICT:
      strict = true;
      handle_flow_mod_mod( transaction_id, cookie, cookie_mask, table_id,
                           priority, oxm, instructions, strict );
      break;
    case OFPFC_DELETE:
      /*
       * The out_port and out_group introduce a constraint when matching
       * flow entries.
       */
      handle_flow_mod_delete( transaction_id, cookie, cookie_mask,
                              table_id, idle_timeout, hard_timeout,
                              priority, buffer_id, out_port,
                              out_group, flags, oxm,
                              instructions, strict );
      break;
    case OFPFC_DELETE_STRICT:
      strict = true;
      handle_flow_mod_delete( transaction_id, cookie, cookie_mask, table_id,
                              idle_timeout, hard_timeout, priority, buffer_id,
                              out_port, out_group, flags, oxm,
                              instructions, strict );
      break;
    default:
      warn( "Undefined flow mod command type %d", command );
      send_error_message( transaction_id, OFPET_FLOW_MOD_FAILED, OFPFMFC_BAD_COMMAND );
      break;
  }
}
void ( *handle_flow_mod )( const uint32_t transaction_id,
        const uint64_t cookie,
        const uint64_t cookie_mask,
        const uint8_t table_id,
        const uint8_t command,
        const uint16_t idle_timeout,
        const uint16_t hard_timeout,
        const uint16_t priority,
        const uint32_t buffer_id,
        const uint32_t out_port,
        const uint32_t out_group,
        const uint16_t flags,
        const oxm_matches *match,
        const openflow_instructions *instructions,
        void *user_data) = _handle_flow_mod;


static void
_handle_packet_out( const uint32_t transaction_id, uint32_t buffer_id, 
                    uint32_t in_port, const openflow_actions *actions,
                    const buffer *frame, void *user_data ) {
  UNUSED( transaction_id );
  UNUSED( user_data );
  assert( actions->list );
  
  action_list *ac_list = init_action_list();
  for ( list_element *e = actions->list; e != NULL; e = e->next ) {
    struct ofp_action_header *ac_hdr = e->data;
    ac_list = assign_actions( ac_list, ac_hdr, ac_hdr->len );
  }
  execute_action_packet_out( buffer_id, in_port, 
          ac_list, cast_non_const( frame ) );
  finalize_action_list( &ac_list );
}
void ( *handle_packet_out )( uint32_t transaction_id, uint32_t buffer_id,
                           uint32_t in_port, const openflow_actions *actions,
                           const buffer *frame, void *user_data ) = _handle_packet_out;


static void
_handle_port_mod( uint32_t transaction_id, uint32_t port_no, uint8_t hw_addr[],
                  uint32_t config, uint32_t mask, uint32_t advertise, void *user_data ) {
  UNUSED( hw_addr );
  UNUSED( advertise );
  UNUSED( user_data );
  int ret;
  
  /*
   * the update_port_config() performs a port lookup.
   */
  ret = update_port_config( port_no, config, mask );
  if ( ret != OFDPE_SUCCESS ) {
    int error_type;
    int error_code;
    get_ofp_error( ret, &error_type, &error_code );
    if ( error_type != ~0 && error_code != ~0 ) {
      send_error_message( transaction_id, ( uint16_t ) error_type, ( uint16_t ) error_code );
    } else {
      send_error_message( transaction_id, OFPET_PORT_MOD_FAILED, OFPPMFC_EPERM );
    }
  }
}
void ( *handle_port_mod )( uint32_t transaction_id, uint32_t port_no, uint8_t hw_addr[],
  uint32_t config, uint32_t mask, uint32_t advertise, void *user_data ) = _handle_port_mod;


static void
_handle_table_mod( uint32_t transaction_id, uint8_t table_id, uint32_t config,
  void *user_data ) {
  UNUSED( user_data );
  
  const struct ofp_table_mod table_mod = {
    .table_id = table_id,
    .config = config
  };
  
  if ( set_table_configuration( &table_mod ) != OFDPE_SUCCESS ) {
    send_error_message( transaction_id, OFPET_TABLE_MOD_FAILED, OFPTMFC_EPERM );    
  }
}
void ( *handle_table_mod )( uint32_t transaction_id, uint8_t table_id, uint32_t config,
  void *user_data ) = _handle_table_mod;


static void
_handle_group_mod( const uint32_t transaction_id,
        const uint16_t command,
        const uint8_t type,
        const uint32_t group_id,
        const list_element *buckets,
        void *user_data ) {
  UNUSED( user_data );
  switch( command ) {
    case OFPGC_ADD:
      handle_group_add( transaction_id, type, group_id, buckets );
      break;
    case OFPGC_MODIFY:
      handle_group_mod_mod( transaction_id, type, group_id, buckets );
      break;
    case OFPGC_DELETE:
      handle_group_mod_delete( transaction_id, group_id );
      break;
    default:
      send_error_message( transaction_id, OFPET_GROUP_MOD_FAILED, OFPGMFC_BAD_COMMAND );
      break;
  }
}
void ( *handle_group_mod )( const uint32_t transaction_id, const uint16_t command, const uint8_t type, const uint32_t group_id, const list_element *buckets, void *user_data ) = _handle_group_mod;


static void
shrink_array( struct outstanding_request outstanding_requests[], int pos ) {
  memset( &outstanding_requests[ pos ], 0, sizeof( struct outstanding_request ) );

  for ( int i = pos; i < MAX_OUTSTANDING_REQUESTS  - 1; i++ ) {
    outstanding_requests[ i ] = outstanding_requests[ i + 1 ];
  }
}


static int
save_outstanding_request( struct protocol_ctrl *ctrl, const uint32_t transaction_id, const uint16_t type, const uint16_t flags ) {
  int i;
  int error = 0;

  // search for an request entry
  for ( i = 0; i < MAX_OUTSTANDING_REQUESTS; i++ ) {
    if ( ctrl->outstanding_requests[ i ].transaction_id == transaction_id && 
      ctrl->outstanding_requests[ i ].type == type ) {
      break;
    }
  }
  /*
   * a request entry is found and the flags is not set to OFPMPF_REQ_MORE.
   * remove the entry from the array.
   */
  if ( i < MAX_OUTSTANDING_REQUESTS  ) {
    if ( ( flags & OFPMPF_REQ_MORE ) == 0 ) {
      shrink_array( ctrl->outstanding_requests, i );
      ctrl->nr_requests--;
    }
  } else {
    /*
     * a request entry is not found but there is to store it and the flags
     * is set to OFPMPF_REQ_MORE
     */
    if ( ctrl->nr_requests < MAX_OUTSTANDING_REQUESTS ) {
      if ( ( flags & OFPMPF_REQ_MORE ) == OFPMPF_REQ_MORE ) {
        ctrl->outstanding_requests[ i ].transaction_id = transaction_id;
        ctrl->outstanding_requests[ i ].type = type;
        ctrl->outstanding_requests[ i ].flags = flags;
        ctrl->nr_requests++;
      }
    } else {
      /*
       * the only error condition to flag no more room to accept further
       * requests
       */
      error = -1;
    }
  }
  return error;
}


static void
_handle_multipart_request( uint32_t transaction_id, uint16_t type, uint16_t flags, const buffer *body, void *user_data ) {

  struct protocol *protocol = user_data;
  assert( protocol );
  if ( save_outstanding_request( &protocol->ctrl, transaction_id, type, flags ) == -1 ) {
    send_error_message( transaction_id, OFPET_BAD_REQUEST, OFPBRC_MULTIPART_BUFFER_OVERFLOW );
    return;
  }
  switch( type ) {
    case OFPMP_DESC:
      {
        // the request body is empty
        char *desc = hw_desc();
        buffer *msg = create_desc_multipart_reply( transaction_id, 0, mfr_desc(), desc, protocol->args->progname, serial_num(), dp_desc() );
        switch_send_openflow_message( msg );
        xfree( desc );
        free_buffer( msg );
      }
      break;
    case OFPMP_FLOW: 
      {
        const struct ofp_flow_stats_request *req = ( const struct ofp_flow_stats_request * ) body->data;

        request_send_flow_stats( req, transaction_id );
      }
      break;
    case OFPMP_AGGREGATE:
      {
        const struct ofp_aggregate_stats_request *req = ( const struct ofp_aggregate_stats_request * ) body->data;

        struct ofp_aggregate_stats_reply *reply = request_aggregate_stats( req );
        if ( reply ) {
          buffer *msg = create_aggregate_multipart_reply( transaction_id, 0, reply->packet_count, reply->byte_count, reply->flow_count );
          switch_send_openflow_message( msg );
          xfree( reply );
          free_buffer( msg );
        }
      }
      break;
    case OFPMP_TABLE: 
      {
        // no request body is included with this type.
        request_send_table_stats( transaction_id );
      }
      break;
    case OFPMP_PORT_STATS:
      {
        const struct ofp_port_stats_request *req = ( const struct ofp_port_stats_request * ) body->data;
        request_send_port_stats( req, transaction_id );
      }
      break;
    case OFPMP_PORT_DESC: 
      {
        // no request body is included with this type.
        list_element *list = request_port_desc();
        SEND_STATS( port_desc, transaction_id, flags, list )
      }
      break;
    case OFPMP_QUEUE: 
      {
        const struct ofp_queue_stats_request *req = ( const struct ofp_queue_stats_request * ) body->data;
        // TODO no support for queue statistics in datapath.
        UNUSED( req );
      }
      break;
    case OFPMP_GROUP: 
      {
        const struct ofp_group_stats_request *req = ( const struct ofp_group_stats_request * ) body->data;
        request_send_group_stats( req, transaction_id );
      }
      break;
    case OFPMP_GROUP_DESC: 
      {
        // the request body is empty.
        list_element *list = request_group_desc_stats();
        SEND_STATS( group_desc, transaction_id, flags, list )
      }
      break;
    case OFPMP_GROUP_FEATURES: 
      {
        struct ofp_group_features *reply = request_group_features();
        if ( reply != NULL ) {
          buffer *msg = create_group_features_multipart_reply( transaction_id, flags,
            reply->types, reply->capabilities, reply->max_groups, reply->actions );
          switch_send_openflow_message( msg );
          free_buffer( msg );
          xfree( reply );
        }
      }
      break;
    case OFPMP_METER: 
      {
        const struct ofp_meter_multipart_request *req = ( const struct ofp_meter_multipart_request * ) body->data;
        /*
         * TODO Currently this setting not supported by datapath.
         */
        UNUSED( req );
      }
      break;
    case OFPMP_METER_CONFIG: 
      {
        const struct ofp_meter_multipart_request *req = ( const struct ofp_meter_multipart_request * ) body->data;
        UNUSED( req );
      }
      break;
    case OFPMP_METER_FEATURES: 
      {
        // request body is empty
        const struct ofp_meter_features *reply = ( const struct ofp_meter_features * ) body->data;
        /*
         * TODO Currently meter features not supported by datapath.
         */
        UNUSED( reply );
      }
      break;
    case OFPMP_TABLE_FEATURES: 
      {
        const struct ofp_table_features *table_features = ( const struct ofp_table_features * ) body->data;
        /*
         * TODO Currently the setting of table features not supported by datapath
         * therefore ignored.
         */
        UNUSED( table_features );
        request_send_table_features_stats( transaction_id );
      }
      break;
    case OFPMP_EXPERIMENTER: 
      {
        const struct ofp_experimenter_multipart_header *em_hdr = ( const struct ofp_experimenter_multipart_header * ) body->data;
        // TODO not supported yet in datapath.
        UNUSED( em_hdr );
      }
      break;
    default:
      break;
  }
}
void ( *handle_multipart_request )( uint32_t transaction_id, uint16_t type, uint16_t flags, const buffer *body, void *user_data ) = _handle_multipart_request;


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
