/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <stdio.h>
#include <string.h>
#include "cmockery_trema.h"
#include "openflow.h"
#include "wrapper.h"
#include "checks.h"
#include "ofdp_error.h"
#include "port_manager.h"
#include "switch_port.h"
#include "controller_manager.h"
#include "stats-helper.h"


#define SELECT_TIMEOUT_USEC 100000 
#define MAX_SEND_QUEUE 512
#define MAX_RECV_QUEUE 512
#define PORT_NO 2

#undef get_ofp_port_structure
#define get_ofp_port_structure mock_get_ofp_port_structure
OFDPE get_ofp_port_structure( uint32_t port_no, ofp_port *out_port );


bool
mock_send_error_message( uint32_t transaction_id, uint16_t type, uint16_t code ) {
  check_expected( transaction_id );
  check_expected( type );
  check_expected( code );
  return true;
}

int
mock_time_now( struct timespec *now ) {
  UNUSED( now );
  return 1;
}


ether_device *
mock_create_ether_device( const char *name, const size_t max_send_queue, const size_t max_recv_queue ) {
  check_expected( name );
  check_expected( max_send_queue );
  check_expected( max_recv_queue );
  return ( ether_device * ) ( ( uint32_t ) mock() );
}


bool
mock_set_frame_received_handler( ether_device *device, frame_received_handler callback, void *user_data ) {
  UNUSED( device );
  UNUSED( callback );
  UNUSED( user_data );
  return true;
}


OFDPE
mock_send_for_notify_port_config( uint32_t port_no, uint8_t reason ) {
  check_expected( port_no );
  check_expected( reason );
  return OFDPE_SUCCESS;
}


void
mock_delete_ether_device( ether_device * device ) {
  UNUSED( device );
  return;
}


static void
create_port_desc( void **state ) {
  UNUSED( state );

  int ret = init_port_manager( SELECT_TIMEOUT_USEC, MAX_SEND_QUEUE, MAX_RECV_QUEUE );
  if ( ret != OFDPE_SUCCESS ) {
   return;
  }

  expect_string( mock_create_ether_device, name, "lo" );
  expect_value( mock_create_ether_device, max_send_queue, MAX_SEND_QUEUE );
  expect_value( mock_create_ether_device, max_recv_queue, MAX_RECV_QUEUE );
  switch_port *port = ( switch_port * ) xmalloc( sizeof( switch_port ) );
  port->device = ( ether_device * ) xmalloc( sizeof( ether_device ) );
  will_return( mock_create_ether_device, port->device );

  expect_value( mock_send_for_notify_port_config, port_no, PORT_NO );
  expect_value( mock_send_for_notify_port_config, reason, OFPPR_ADD );

  char *device_name = xstrdup( "lo" );
  ret = add_port( PORT_NO, device_name );
  xfree( device_name );
}


static void
destroy_port_desc( void **state ) {
  UNUSED( state );
  finalize_port_manager();
}


static void
test_request_port_desc( void **state ) {
  UNUSED( state );

  list_element *list = request_port_desc();
  assert_true( list );
}



int
main() {
  const UnitTest tests[] = {
    unit_test_setup_teardown( test_request_port_desc, create_port_desc, destroy_port_desc ),
  };
  return run_tests( tests );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
