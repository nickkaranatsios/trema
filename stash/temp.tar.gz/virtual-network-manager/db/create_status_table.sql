use vnet;

create table status (
       hostname        varchar(255),
       primary key (hostname)
) engine = innodb;

