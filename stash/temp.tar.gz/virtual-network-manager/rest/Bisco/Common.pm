#
# Copyright (C) 2012 NEC Corporation
# Copyright (C) NEC BIGLOBE, Ltd. 2012
# NEC Confidential
#

package Bisco::Common;

=head1 Bisco::Common

=head2 概要

  bisco.psgi を通じて送られてきたHTTPリクエストに応じた関数を呼び出す。
  また、関数から戻されるオブジェクトからHTTPの応答を生成する。

=cut

use strict;
use warnings;

use Error qw(:try);
use bignum;
use vars qw(@ISA @EXPORT);
@ISA = qw(Exporter);

use lib qw( /usr/share/bisco );

use Bisco::Constant;
use Bisco::Message;

sub _check_num($) {
    my $num = shift;
    return TRUE if $num =~ /^\d+$/;
    return FALSE;
}

sub _check_smallint($) {
    my $num = shift;
    if ( _check_num($num) ) {
        return TRUE if $num > 0 and $num < 2**16;
    }
    return FALSE;
}

sub _check_int($) {
    my $num = shift;
    if ( _check_num($num) ) {
        return TRUE if $num > 0 and $num < 2**32;
    }
    return FALSE;
}

sub _check_bigint($) {
    my $num = shift;
    if ( _check_num($num) ) {
        return TRUE if $num > 0 and $num < 2**64;
    }
    return FALSE;
}

push @EXPORT, qw(check_vlanid);

sub check_vlanid($) {
    my $id = shift;
    if ( _check_num($id) ) {
        return TRUE if $id > 1 and $id <= 4094;
    }
    return FALSE;
}

push @EXPORT, qw(check_slice_id);

sub check_slice_id($) {
    my $slice_id = shift;
    return _check_int($slice_id);
}

push @EXPORT, qw(check_port_id);

sub check_port_id($) {
    my $port_id = shift;
    return _check_int($port_id);
}

push @EXPORT, qw(check_port_no);

sub check_port_no($) {
    my $port_no = shift;
    return _check_smallint($port_no);
}

push @EXPORT, qw(check_port_name);

sub check_port_name($) {
    my $port_name = shift;
    if ( $port_name =~ /^(vlan|vnet)(\d+)$/ ) {
        return TRUE if check_vlanid($2);
    }
    return FALSE;
}

push @EXPORT, qw(check_dpid);

sub check_dpid($) {
    my $dpid = shift;
    return _check_bigint($dpid);
}

push @EXPORT, qw(check_ipv4addr);

sub check_ipv4addr($) {
    my $ip = shift;

    return FALSE if $ip !~ /^\d+(\.\d+){3}$/;
    foreach ( split( /\./, $ip ) ) {
        return FALSE unless ( 0 <= $_ and $_ <= 255 );
    }
    return TRUE;
}

push @EXPORT, qw(check_protocol);

sub check_protocol($) {
    my $protocol = shift;

    return TRUE if $protocol =~ /^https?$/;
    return FALSE;
}

push @EXPORT, qw(check_port);

sub check_port($) {
    my $port = shift;

    return FALSE unless _check_num($port);
    return FALSE unless ( 0 <= $port and $port < 65535 );
    return TRUE;
}

push @EXPORT, qw(check_mac_address);

sub check_mac_address($) {
    my $mac = shift;
    return FALSE
        if $mac eq "00:00:00:00:00:00"
            or $mac =~ /^ff:ff:ff:ff:ff:ff$/i;
    return TRUE if $mac =~ /^([0-9a-f]{2}:){5}[0-9a-f]{2}$/i;
    return FALSE;
}

push @EXPORT, qw(check_text_length);

sub check_text_length($) {
    my $text = shift;
    return TRUE if length($text) < 2**16;
    return FALSE;
}

push @EXPORT, qw(check_allowed_action);

sub check_allowed_action($) {
    my $action = shift;
    return TRUE if $action =~ /^(reset)$/;
    return FALSE;
}

push @EXPORT, qw( get_ipaddr_from_nic );

sub get_ipaddr_from_nic($) {
    my $target_nic = shift;

    my $ifconfig = get_constant('IFCONFIG');

    local *IN;
    open( IN, "$ifconfig $target_nic |" )
        or throw Error( "status", 500, "-text",
        "_get_ipaddr_from_nic: $ifconfig execute error. $!" );
    while (<IN>) {
        chomp;
        if (/^\s*inet addr:(\S+)\s+/) {
            my $addr = $1;
            close IN;
            return $addr;
        }
    }
    return "";
}

1;

