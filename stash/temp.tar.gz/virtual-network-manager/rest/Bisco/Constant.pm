#
# Copyright (C) 2012 NEC Corporation
# Copyright (C) NEC BIGLOBE, Ltd. 2012
# NEC Confidential
#

package Bisco::Constant;

=head1 Bisco::Constant

=head2 概要

  bisco共通の定数を定義する
  必要があればconfigで書き換えられる

=cut

use strict;

use Config::Simple;
use Exporter;
use vars qw(@EXPORT @ISA $SYSLOG_FACILITY);
@ISA    = qw(Exporter);
@EXPORT = qw($SYSLOG_FACILITY);

push @EXPORT, qw(TRUE FALSE);
use constant TRUE  => 1;
use constant FALSE => 0;

# exit コード (/usr/include/sysexits.h から)
use constant EX_OK          => 0;     # successful termination
use constant EX__BASE       => 64;    # base value for error messages
use constant EX_USAGE       => 64;    # command line usage error
use constant EX_DATAERR     => 65;    # data format error
use constant EX_NOINPUT     => 66;    # cannot open input
use constant EX_NOUSER      => 67;    # addressee unknown
use constant EX_NOHOST      => 68;    # host name unknown
use constant EX_UNAVAILABLE => 69;    # service unavailable
use constant EX_SOFTWARE    => 70;    # internal software error
use constant EX_OSERR       => 71;    # system error (e.g., can't fork)
use constant EX_OSFILE      => 72;    # critical OS file missing
use constant EX_CANTCREAT   => 73;    # can't create (user) output file
use constant EX_IOERR       => 74;    # input/output error
use constant EX_TEMPFAIL    => 75;    # temp failure; user is invited to retry
use constant EX_PROTOCOL    => 76;    # remote error in protocol
use constant EX_NOPERM      => 77;    # permission denied
use constant EX_CONFIG      => 78;    # configuration error
use constant EX__MAX        => 78;    # maximum listed value
push @EXPORT, qw( EX_OK
    EX__BASE
    EX_USAGE
    EX_DATAERR
    EX_NOINPUT
    EX_NOUSER
    EX_NOHOST
    EX_UNAVAILABLE
    EX_SOFTWARE
    EX_OSERR
    EX_OSFILE
    EX_CANTCREAT
    EX_IOERR
    EX_TEMPFAIL
    EX_PROTOCOL
    EX_NOPERM
    EX_CONFIG
    EX__MAX);

# 独自 exit code
push @EXPORT, qw( EX_SIGNAL EX_NOT_EXEC );
use constant EX_SIGNAL   => 130;    # Signal trap による exit
use constant EX_NOT_EXEC => 254;    # 子プロセスの exec 失敗

push @EXPORT, qw(EX_LOCKERR);
use constant EX_LOCKERR => 149;     # lock 処理エラー

push @EXPORT, qw(EX_DBERR);
use constant EX_DBERR => 79;        # DB エラー

use constant {
    PARAM => {
        'CONFIG_FILE' => '/etc/bisco_rest.conf',
        'IFCONFIG'    => '/sbin/ifconfig',

        'SYSLOG.FACILITY' => 'local0',

        'BISCO.DB_HOST'     => '127.0.0.1',
        'BISCO.DB_PORT '    => '3306',
        'BISCO.DB_USERNAME' => 'root',
        'BISCO.DB_PASSWORD' => 'root123',
        'BISCO.DB_NAME'     => 'vnet',

        'BISCO.SERVICE_INTERFACE' => '',
        'BISCO.SERVICE_PORT'      => '80',
        'BISCO.PROTOCOL'          => 'http'
    }
};

push @EXPORT, qw(set_constant get_constant clear_constant);
my %param;

sub set_constant($$) {
    my $key = shift;
    my $val = shift;
    if ( exists PARAM->{$key} ) {
        $param{$key} = $val;
    }
    else {
        throw Error::Simple("$key : set_file can not set.");
    }
}

sub get_constant($) {
    my $key = shift;

    # ユーザによって登録されていればそれを返答
    if ( defined $param{$key} ) {
        return $param{$key};
    }

    # 登録されていなければデフォルト値を返答
    return PARAM->{$key};
}

sub clear_constant() {
    %param = {};
}

push @EXPORT, qw(read_config_file);

sub read_config_file(;$) {

    my $conf_file = shift || get_constant('CONFIG_FILE');

    return unless ( -f $conf_file );

    my $cfg = new Config::Simple($conf_file);

    $cfg or die "Can not get param from config($conf_file)";

    my %config = $cfg->vars();
    foreach my $key ( keys %config ) {
        next unless ( exists PARAM->{$key} );
        my $val = $config{$key};

        if ( ref($val) eq 'ARRAY' ) {
            $val = join( ",", @{$val} );
        }
        set_constant( $key, $val );
    }
    $SYSLOG_FACILITY = get_constant('SYSLOG.FACILITY');
}

1;

