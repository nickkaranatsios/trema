#
# Copyright (C) 2012 NEC Corporation
# Copyright (C) NEC BIGLOBE, Ltd. 2012
# NEC Confidential
#

package Bisco::Controller;

=head1 Bisco::Controller

=head2 概要

  bisco.psgi を通じて送られてきたHTTPリクエストに応じた関数を呼び出す。
  また、関数から戻されるオブジェクトからHTTPの応答を生成する。

=cut

use strict;
use warnings;

use Error qw(:try);

use lib qw( /usr/share/bisco );

use Bisco::Common;
use Bisco::Constant;
use Bisco::Message;
use Bisco::Response;
use Bisco::GET;
use Bisco::POST;
use Bisco::PUT;
use Bisco::DELETE;

=head3 start

=item 説明

      Plack::Builder の builder の宣言をする

=item 引数

      なし

=item 戻り値

      なし

=item 例外

      なし

=cut

sub start($) {
    my $env = shift;

    read_config_file();

    my $path_string = $env->{'PATH_INFO'};
    unless ( $path_string =~ /^\/(networks|agents|status|reflector|cap(file)?)/ ) {
        return make_reply_not_found("Unknown path: $path_string");
    }

    my ( $Slice, $reply );
    try {
        my $db_host     = get_constant('BISCO.DB_HOST');
        my $db_port     = get_constant('BISCO.DB_PORT');
        my $db_username = get_constant('BISCO.DB_USERNAME');
        my $db_password = get_constant('BISCO.DB_PASSWORD');
        my $db_name     = get_constant('BISCO.DB_NAME');

        $Slice = Bisco::DB::Slice->new( $db_host, $db_port, $db_username,
            $db_password, $db_name );
        unless ( defined($Slice) ) {
            message( LOG_DEBUG,
                "DB_HOST: $db_host, DB_PORT: $db_port, " .
                "DB_USERNAME: $db_username, DB_NAME: $db_name"
            );
            return make_reply_error("Failed to open slice database.");
        }

        my @path = split( '/', $path_string );
        shift(@path);

        my $method = $env->{'REQUEST_METHOD'};
        if ( $method eq "GET" ) {
            $reply = handle_get_requests( $Slice, @path );
        }
        elsif ( $method eq "POST" ) {
            $reply = handle_post_requests( $Slice, $env, @path );
        }
        elsif ( $method eq "PUT" ) {
            $reply = handle_put_requests( $Slice, $env, @path );
        }
        elsif ( $method eq "DELETE" ) {
            $reply = handle_delete_requests( $Slice, @path );
        }
        else {
            $reply = make_reply_not_implemented(
                "Unhandled request method ($method)");
        }
    }
    catch Error with {
        my $e = shift;
        message( LOG_ERROR, $e->text );
        $reply = make_reply_error( $e->stacktrace );
    };

    if ( exists $ENV{DEBUG} ) {
        if ( eval {use Data::Dumper; 1;} ) {
            message( LOG_DEBUG, Dumper $Slice);
            message( LOG_DEBUG, Dumper $reply);
        }
    }

    $Slice->close() if defined $Slice;
    unless ($reply) {
        $reply = make_reply_error("Unknown error.");
    }

    return $reply;
}

1;

