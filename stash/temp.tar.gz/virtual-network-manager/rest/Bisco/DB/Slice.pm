#
# Slice configuration module for virtual network manager application.
#
# Author: Yasunobu Chiba
#
# Copyright (C) 2012 NEC Corporation
# NEC Confidential
#

package Bisco::DB::Slice;

use strict;
use bignum;
use DBI;
use Sys::Hostname;

use lib qw( /usr/share/bisco );

use Bisco::Common;
use Bisco::Message;

use constant {
    SUCCEEDED            => 0,
    FAILED               => -1,
    NO_SLICE_FOUND       => -2,
    NO_PORT_FOUND        => -3,
    NO_MAC_ADDRESS_FOUND => -4,
    NO_TARGET_FOUND      => -5,
    DUPLICATED_SLICE     => -6,
    DUPLICATED_PORT_ID   => -7,
    DUPLICATED_PORT      => -8,
    DUPLICATED_MAC       => -9,

    PORT_NO_UNDEFINED   => 65535,
    VLAN_ID_UNSPECIFIED => 65535,

    SLICE_STATE_CONFIRMED            => 0,
    SLICE_STATE_PREPARING_TO_UPDATE  => 1,
    SLICE_STATE_READY_TO_UPDATE      => 2,
    SLICE_STATE_UPDATING             => 3,
    SLICE_STATE_UPDATE_FAILED        => 4,
    SLICE_STATE_PREPARING_TO_DESTROY => 5,
    SLICE_STATE_READY_TO_DESTROY     => 6,
    SLICE_STATE_DESTROYING           => 7,
    SLICE_STATE_DESTROY_FAILED       => 8,
    SLICE_STATE_DESTROYED            => 9,
    SLICE_STATE_MAX                  => 10,

    PORT_STATE_CONFIRMED            => 0,
    PORT_STATE_PREPARING_TO_UPDATE  => 1,
    PORT_STATE_READY_TO_UPDATE      => 2,
    PORT_STATE_UPDATING             => 3,
    PORT_STATE_UPDATE_FAILED        => 4,
    PORT_STATE_PREPARING_TO_DESTROY => 5,
    PORT_STATE_READY_TO_DESTROY     => 6,
    PORT_STATE_DESTROYING           => 7,
    PORT_STATE_DESTROY_FAILED       => 8,
    PORT_STATE_DESTROYED            => 9,
    PORT_STATE_MAX                  => 10,

    MAC_STATE_INSTALLED        => 0,
    MAC_STATE_READY_TO_INSTALL => 1,
    MAC_STATE_INSTALLING       => 2,
    MAC_STATE_INSTALL_FAILED   => 3,
    MAC_STATE_READY_TO_DELETE  => 4,
    MAC_STATE_DELETING         => 5,
    MAC_STATE_DELETE_FAILED    => 6,
    MAC_STATE_DELETED          => 7,
    MAC_STATE_MAX              => 8,

    PORT_TYPE_CUSTOMER => 0,
    PORT_TYPE_OVERLAY  => 1,
    PORT_TYPE_MAX      => 2,
    PORT_TYPE_ANY      => 255,

    MAC_TYPE_LOCAL  => 0,
    MAC_TYPE_REMOTE => 1,
    MAC_TYPE_MAX    => 2,
    MAC_TYPE_ANY    => 255,

    DEFAULT_DB_HOST     => "127.0.0.1",
    DEFAULT_DB_PORT     => "3306",
    DEFAULT_DB_USERNAME => "root",
    DEFAULT_DB_PASSWORD => "root123",
    DEFAULT_DB_NAME     => "vnet"
};

my %SliceStates = (
    &SLICE_STATE_CONFIRMED            => "confirmed",
    &SLICE_STATE_PREPARING_TO_UPDATE  => "preparing-to-update",
    &SLICE_STATE_READY_TO_UPDATE      => "ready-to-update",
    &SLICE_STATE_UPDATING             => "updating",
    &SLICE_STATE_UPDATE_FAILED        => "update-failed",
    &SLICE_STATE_PREPARING_TO_DESTROY => "preparing-to-destroy",
    &SLICE_STATE_READY_TO_DESTROY     => "ready-to-destroy",
    &SLICE_STATE_DESTROYING           => "destroying",
    &SLICE_STATE_DESTROY_FAILED       => "destroy-failed",
    &SLICE_STATE_DESTROYED            => "destroyed"
);

my %PortStates = (
    &PORT_STATE_CONFIRMED            => "confirmed",
    &PORT_STATE_PREPARING_TO_UPDATE  => "preparing-to-update",
    &PORT_STATE_READY_TO_UPDATE      => "ready-to-update",
    &PORT_STATE_UPDATING             => "updating",
    &PORT_STATE_UPDATE_FAILED        => "update-failed",
    &PORT_STATE_PREPARING_TO_DESTROY => "preparing-to-destroy",
    &PORT_STATE_READY_TO_DESTROY     => "ready-to-destroy",
    &PORT_STATE_DESTROYING           => "destroying",
    &PORT_STATE_DESTROY_FAILED       => "destroy-failed",
    &PORT_STATE_DESTROYED            => "destroyed"
);

my %MacStates = (
    &MAC_STATE_INSTALLED        => "installed",
    &MAC_STATE_READY_TO_INSTALL => "ready-to-install",
    &MAC_STATE_INSTALLING       => "installing",
    &MAC_STATE_INSTALL_FAILED   => "install-failed",
    &MAC_STATE_READY_TO_DELETE  => "ready-to-delete",
    &MAC_STATE_DELETING         => "deleting",
    &MAC_STATE_DELETE_FAILED    => "delete-failed",
    &MAC_STATE_DELETED          => "deleted"
);

my %PortTypes = (
    &PORT_TYPE_CUSTOMER => "customer",
    &PORT_TYPE_OVERLAY  => "overlay"
);

my %MacTypes = (
    &MAC_TYPE_LOCAL  => "local",
    &MAC_TYPE_REMOTE => "remote"
);

my $Debug = 0;

sub new() {
    my ( $class, $db_host, $db_port, $db_username, $db_password, $db_name )
        = @_;
    my $hash = { dbh => undef };

    if ( !defined($db_host) ) {
        $db_host = DEFAULT_DB_HOST;
    }
    if ( !defined($db_port) ) {
        $db_port = DEFAULT_DB_PORT;
    }
    if ( !defined($db_username) ) {
        $db_username = DEFAULT_DB_USERNAME;
    }
    if ( !defined($db_password) ) {
        $db_password = DEFAULT_DB_PASSWORD;
    }
    if ( !defined($db_name) ) {
        $db_name = DEFAULT_DB_NAME;
    }

    $hash->{'dbh'} = DBI->connect( "DBI:mysql:$db_name:$db_host:$db_port",
        $db_username, $db_password );
    if ( !defined( $hash->{'dbh'} ) ) {
        error(
            qq(DBI connect("DBI:mysql:$db_name:$db_host:$db_port") failed.));
        return undef;
    }

    bless( $hash, $class );
}

sub close() {
    my $self = shift;

    if ( defined( $self->{'dbh'} ) ) {
        $self->{'dbh'}->disconnect();
    }
}

sub start_transaction() {
    my $self = shift;

    if ( !defined($self) ) {
        return FAILED;
    }
    if ( !defined( $self->{'dbh'} ) ) {
        error("Failed to get a DB handler.");
        return FAILED;
    }

    my $ret = $self->{'dbh'}->begin_work();
    if ( !defined($ret) ) {
        error(
            "Failed to start transaction (" . $self->{'dbh'}->errstr . ")." );
        return FAILED;
    }

    return SUCCEEDED;
}

sub commit() {
    my $self = shift;

    if ( !defined($self) ) {
        return FAILED;
    }
    if ( !defined( $self->{'dbh'} ) ) {
        error("Failed to get a DB handler.");
        return FAILED;
    }

    my $ret = $self->{'dbh'}->commit();
    if ( !defined($ret) ) {
        error(    "Failed to commit transaction ("
                . $self->{'dbh'}->errstr
                . ")." );
        return FAILED;
    }

    return SUCCEEDED;
}

sub rollback() {
    my $self = shift;

    if ( !defined($self) ) {
        return FAILED;
    }
    if ( !defined( $self->{'dbh'} ) ) {
        error("Failed to get a DB handler.");
        return FAILED;
    }

    my $ret = $self->{'dbh'}->rollback();
    if ( !defined($ret) ) {
        error(    "Failed to rollback transaction ("
                . $self->{'dbh'}->errstr
                . ")." );
        return FAILED;
    }

    return SUCCEEDED;
}

sub valid_slice_state() {
    my ( $self, $state ) = @_;

    if ( !defined($state) ) {
        return 0;
    }
    if ( $state < 0 || $state >= SLICE_STATE_MAX ) {
        return 0;
    }

    return 1;
}

sub update_slice_state() {
    my $self     = shift;
    my $slice_id = shift;
    my $to       = shift;
    my @from     = @_;

    if ( !defined($slice_id) ) {
        debug("slice id must be specified.");
        return FAILED;
    }
    if ( !$self->slice_exists($slice_id) ) {
        debug("No slice found (slice_id = $slice_id).");
        return NO_SLICE_FOUND;
    }

    if ( !defined($to) ) {
        debug("New slice state must be specified.");
        return FAILED;
    }
    if ( !$self->valid_slice_state($to) ) {
        debug("Invalid new slice state ($to).");
        return FAILED;
    }

    unless (@from) {
        debug("Current slice state must be specified.");
        return FAILED;
    }
    foreach my $current (@from) {
        if ( !$self->valid_slice_state($current) ) {
            error("Invalid current slice state ($current).");
            return FAILED;
        }
    }

    my $statement
        = "UPDATE slices SET state = " . $to . " WHERE id = $slice_id AND ( ";
    for ( my $index = 0; $index < @from; $index++ ) {
        if ( $index == 0 ) {
            $statement .= "state = $from[$index] ";
        }
        else {
            $statement .= "OR state = $from[$index] ";
        }
    }
    $statement .= ")";

    debug("Executing a SQL query (statement = $statement).");
    my $ret = $self->{'dbh'}->do($statement);
    if ( $ret == 0 ) {
        return NO_TARGET_FOUND;
    }
    elsif ( $ret < 0 ) {
        error( "Failed to update slice state (slice_id = $slice_id). "
                . $self->{'dbh'}->errstr );
        return FAILED;
    }

    return SUCCEEDED;
}

sub valid_port_state() {
    my ( $self, $state ) = @_;

    if ( !defined($state) ) {
        return 0;
    }
    if ( $state < 0 || $state >= PORT_STATE_MAX ) {
        return 0;
    }

    return 1;
}

sub update_port_state() {
    my $self     = shift;
    my $slice_id = shift;
    my $port_id  = shift;
    my $type     = shift;
    my $to       = shift;
    my @from     = @_;

    if ( !defined($slice_id) ) {
        debug("slice id must be specified.");
        return FAILED;
    }
    if ( !$self->slice_exists($slice_id) ) {
        debug("No slice found (slice_id = $slice_id).");
        return NO_SLICE_FOUND;
    }

    if ( defined($port_id) ) {
        if ( !$self->port_id_exists( $slice_id, $port_id ) ) {
            debug(
                "No port found (slice_id = $slice_id, port_id = $port_id).");
            return NO_PORT_FOUND;
        }
    }
    if ( !defined($type) ) {
        debug("Port type must be specified.");
        return FAILED;
    }
    if ( $type < 0 || ( $type >= PORT_TYPE_MAX && $type != PORT_TYPE_ANY ) ) {
        debug("Invalid port type ($type).");
        return FAILED;
    }

    if ( !defined($to) ) {
        debug("New port state must be specified.");
        return FAILED;
    }
    if ( !$self->valid_port_state($to) ) {
        debug("Invalid new port state ($to).");
        return FAILED;
    }

    unless (@from) {
        debug("Current port state must be specified.");
        return FAILED;
    }
    foreach my $current (@from) {
        if ( !$self->valid_port_state($current) ) {
            error("Invalid current port state ($current).");
            return FAILED;
        }
    }

    my $statement
        = "UPDATE ports SET state = " 
        . $to
        . " WHERE slice_id = $slice_id AND ";
    if ( $type < PORT_TYPE_MAX ) {
        $statement .= "type = $type AND ";
    }
    if ( defined($port_id) ) {
        $statement .= "id = $port_id AND ( ";
    }
    else {
        $statement .= "( ";
    }
    for ( my $index = 0; $index < @from; $index++ ) {
        if ( $index == 0 ) {
            $statement .= "state = $from[$index] ";
        }
        else {
            $statement .= "OR state = $from[$index] ";
        }
    }
    $statement .= ")";

    debug("Executing a SQL query (statement = $statement).");
    my $ret = $self->{'dbh'}->do($statement);
    if ( $ret == 0 ) {
        return NO_TARGET_FOUND;
    }
    elsif ( $ret < 0 ) {
        error(
            "Failed to update port state (slice_id = $slice_id, port_id = $port_id). "
                . $$self->{'dbh'}->errstr );
        return FAILED;
    }

    return SUCCEEDED;
}

sub valid_mac_state() {
    my ( $self, $state ) = @_;

    if ( !defined($state) ) {
        return 0;
    }
    if ( $state < 0 || $state >= MAC_STATE_MAX ) {
        return 0;
    }

    return 1;
}

sub update_mac_address_state() {
    my $self     = shift;
    my $slice_id = shift;
    my $port_id  = shift;
    my $mac      = shift;
    my $type     = shift;
    my $to       = shift;
    my @from     = @_;

    if ( !defined($slice_id) ) {
        debug("slice id must be specified.");
        return FAILED;
    }
    if ( !$self->slice_exists($slice_id) ) {
        debug("No slice found (slice_id = $slice_id).");
        return NO_SLICE_FOUND;
    }

    if ( defined($port_id) ) {
        if ( !$self->port_id_exists( $slice_id, $port_id ) ) {
            debug(
                "No port found (slice_id = $slice_id, port_id = $port_id).");
            return NO_PORT_FOUND;
        }
    }
    if ( defined($mac) ) {
        if ( !$self->mac_address_exists( $slice_id, $port_id, $mac ) ) {
            debug(
                "No MAC address found (slice_id = $slice_id, port_id = $port_id, mac = $mac)."
            );
            return NO_MAC_ADDRESS_FOUND;
        }
    }
    if ( !defined($type) ) {
        debug("MAC address type must be specified.");
        return FAILED;
    }
    if ( $type < 0 || ( $type >= MAC_TYPE_MAX && $type != MAC_TYPE_ANY ) ) {
        debug("Invalid MAC address type ($type).");
        return FAILED;
    }

    if ( !defined($to) ) {
        debug("New MAC address state must be specified.");
        return FAILED;
    }
    if ( !$self->valid_mac_state($to) ) {
        debug("Invalid new MAC address state ($to).");
        return FAILED;
    }

    unless (@from) {
        debug("Current MAC address state must be specified.");
        return FAILED;
    }
    foreach my $current (@from) {
        if ( !$self->valid_mac_state($current) ) {
            error("Invalid current MAC address state ($current).");
            return FAILED;
        }
    }

    my $statement
        = "UPDATE mac_addresses SET state = " 
        . $to
        . " WHERE slice_id = $slice_id AND ";
    if ( defined($port_id) ) {
        $statement .= "port_id = $port_id AND ";
    }
    if ( $type < MAC_TYPE_MAX ) {
        $statement .= "type = $type AND ";
    }
    if ( defined($mac) ) {
        $statement .= "mac = $mac AND ";
    }

    $statement .= "( ";
    for ( my $index = 0; $index < @from; $index++ ) {
        if ( $index == 0 ) {
            $statement .= "state = $from[$index] ";
        }
        else {
            $statement .= "OR state = $from[$index] ";
        }
    }
    $statement .= ")";

    debug("Executing a SQL query (statement = $statement).");
    my $ret = $self->{'dbh'}->do($statement);
    if ( $ret == 0 ) {
        return NO_TARGET_FOUND;
    }
    elsif ( $ret < 0 ) {
        error(
            "Failed to update MAC address state (slice_id = $slice_id, port_id = $port_id, mac = $mac). "
                . $self->{'dbh'}->errstr );
        return FAILED;
    }

    return SUCCEEDED;
}

sub create_slice() {
    my ( $self, $slice_id, $description ) = @_;

    if ( !defined($slice_id) ) {
        debug("slice id must be specified.");
        return FAILED;
    }

    if ( defined($slice_id) && $self->slice_exists($slice_id) ) {
        return DUPLICATED_SLICE;
    }

    if ( !defined($description) ) {
        $description = "";
    }

    my $state = SLICE_STATE_CONFIRMED;
    debug( "creating a alice (id = %u, description = %s).",
        $slice_id, $description );
    my $ret = $self->{'dbh'}->do( "INSERT INTO slices (id,description,state) "
            . "VALUES ($slice_id,'$description','$state')" );
    if ( $ret <= 0 ) {
        error("Create slice failed (slice_id = $slice_id).");
        return FAILED;
    }

    debug("Slice created successfully.");

    return SUCCEEDED;
}

sub update_slice() {
    my ( $self, $slice_id, $description ) = @_;

    if ( !defined($slice_id) ) {
        debug("slice id must be specified.");
        return FAILED;
    }

    if ( !defined($description) ) {
        $description = "";
    }

    if ( !$self->slice_exists($slice_id) ) {
        debug("No slice found (slice_id = $slice_id).");
        return NO_SLICE_FOUND;
    }

    debug( "updating a alice (id = %s, description = %s).",
        $slice_id, $description );

    my $ret
        = $self->{'dbh'}->do(
        "UPDATE slices SET description = '$description' WHERE id = $slice_id"
        );
    if ( $ret <= 0 ) {
        error("Slice update failed (slice_id = $slice_id).");
        return FAILED;
    }
    debug("Slice updated successfully.");

    return SUCCEEDED;
}

sub destroy_slice() {
    my ( $self, $slice_id ) = @_;

    debug( "destroying a alice (id = %s).", $slice_id );

    if ( !defined($slice_id) ) {
        debug("slice id must be specified.");
        return FAILED;
    }

    if ( !$self->slice_exists($slice_id) ) {
        debug("No slice found (slice_id = $slice_id).");
        return NO_SLICE_FOUND;
    }

    my $ret
        = $self->update_slice_state( $slice_id,
        SLICE_STATE_PREPARING_TO_DESTROY,
        SLICE_STATE_CONFIRMED );
    if ( $ret < 0 ) {
        return FAILED;
    }

    $ret
        = $self->update_port_state( $slice_id, undef, PORT_TYPE_ANY,
        PORT_STATE_PREPARING_TO_DESTROY,
        PORT_STATE_CONFIRMED );
    if ( $ret < 0 && $ret != NO_TARGET_FOUND ) {
        $self->update_slice_state( $slice_id, SLICE_STATE_DESTROY_FAILED,
            SLICE_STATE_PREPARING_TO_DESTROY );
        return FAILED;
    }

    $ret = $self->update_mac_address_state( $slice_id, undef, undef,
        MAC_TYPE_ANY, MAC_STATE_READY_TO_DELETE, MAC_STATE_INSTALLED );
    if ( $ret < 0 && $ret != NO_TARGET_FOUND ) {
        $self->update_port_state( $slice_id, undef, PORT_TYPE_ANY,
            PORT_STATE_DESTROY_FAILED, PORT_STATE_PREPARING_TO_DESTROY );
        $self->update_slice_state( $slice_id, SLICE_STATE_DESTROY_FAILED,
            SLICE_STATE_PREPARING_TO_DESTROY );
        return FAILED;
    }

    $ret = $self->update_port_state( $slice_id, undef, PORT_TYPE_ANY,
        PORT_STATE_READY_TO_DESTROY, PORT_STATE_PREPARING_TO_DESTROY );
    if ( $ret < 0 && $ret != NO_TARGET_FOUND ) {
        $self->update_slice_state( $slice_id, SLICE_STATE_DESTROY_FAILED,
            SLICE_STATE_PREPARING_TO_DESTROY );
        return FAILED;
    }

    $ret = $self->update_slice_state( $slice_id, SLICE_STATE_READY_TO_DESTROY,
        SLICE_STATE_PREPARING_TO_DESTROY );
    if ( $ret < 0 ) {
        return FAILED;
    }

    debug("Slice destroyed successfully.");

    return SUCCEEDED;
}

sub get_slices() {
    my $self = shift;

    my $sth = $self->{'dbh'}
        ->prepare("SELECT id,description,state,updated_at FROM slices");

    my $ret = $sth->execute();

    my @slices = ();
    while ( my @row = $sth->fetchrow_array ) {
        my %slice = ();
        $slice{'id'}          = $row[0];
        $slice{'description'} = $row[1];
        $slice{'state'}       = $row[2];
        $slice{'updated_at'}  = $row[3];
        push( @slices, \%slice );
    }

    return @slices;
}

sub list_slices() {
    my $self = shift;

    my @slices = $self->get_slices();

    if ( @slices == 0 ) {
        info("No slice found.");
        return 0;
    }

    my $out = sprintf( "%8s%32s%21s%20s\n",
        "ID", "Description", "State", "Updated At" );
    foreach my $slice (@slices) {
        $out .= sprintf(
            "%8s%32s%21s%20s\n",
            ${$slice}{'id'},
            ${$slice}{'description'},
            slice_state_to_string( ${$slice}{'state'} ),
            ${$slice}{'updated_at'}
        );
    }

    info($out);

    return 0;
}

sub overlay_port_exists() {
    my ( $self, $slice_id, $dpid, $id ) = @_;

    my $name = sprintf( "vxlan%u", $slice_id );
    my $statement = sprintf(
        "SELECT port_no,id FROM ports WHERE slice_id = %u AND datapath_id = %u AND port_name = \'%s\' AND type = %u AND "
            . "( state = %u OR state = %u OR state = %u OR state = %u )",
        $slice_id,                  $dpid,
        $name,                      PORT_TYPE_OVERLAY,
        PORT_STATE_CONFIRMED,       PORT_STATE_PREPARING_TO_UPDATE,
        PORT_STATE_READY_TO_UPDATE, PORT_STATE_UPDATING
    );
    my $sth = $self->{'dbh'}->prepare($statement);
    my $ret = $sth->execute();
    my $row = $sth->fetch();
    if ( defined($row) && defined( $row->[0] ) ) {
        if ( defined($id) ) {
            ${$id} = $row->[1];
        }
        return 1;
    }

    return 0;
}

sub get_active_switches() {
    my ( $self, $slice_id ) = @_;

    debug(
        "Retrieving the list of active/activating switches in a slice (slice_id = $slice_id)."
    );

    my $statement = sprintf(
        "SELECT DISTINCT datapath_id FROM ports WHERE slice_id = %u AND type = %u AND "
            . "( state = %u OR state = %u OR state = %u OR state = %u )",
        $slice_id, PORT_TYPE_CUSTOMER, PORT_STATE_CONFIRMED,
        PORT_STATE_PREPARING_TO_UPDATE,
        PORT_STATE_READY_TO_UPDATE, PORT_STATE_UPDATING
    );
    my $sth      = $self->{'dbh'}->prepare($statement);
    my $ret      = $sth->execute();
    my @switches = ();
    while ( my @row = $sth->fetchrow_array ) {
        push( @switches, $row[0] );
    }

    return @switches;
}

sub add_overlay_port() {
    my $self                 = shift;
    my $slice_id             = shift;
    my $dpid                 = shift;
    my @remote_mac_addresses = @_;

    debug(
        "Adding an overlay port (slice_id = $slice_id, datapath_id = $dpid, remote_mac_addresses = ["
            . join( ',', @remote_mac_addresses )
            . "])." );

    if ( $self->overlay_port_exists( $slice_id, $dpid ) ) {
        debug(
            "An overlay port already exists (slice_id = $slice_id, datapath_id = $dpid)."
        );
        return SUCCEEDED;
    }

    my $port_no     = PORT_NO_UNDEFINED;
    my $port_name   = sprintf( "vxlan%u", $slice_id );
    my $vid         = VLAN_ID_UNSPECIFIED;
    my $description = "";
    my $state       = PORT_STATE_READY_TO_UPDATE;
    my $ret
        = $self->{'dbh'}->do(
        "INSERT INTO ports (slice_id,datapath_id,port_no,port_name,vid,type,description,state) "
            . "VALUES ($slice_id,$dpid,$port_no,'$port_name',$vid,"
            . PORT_TYPE_OVERLAY
            . ",'$description',$state)" );
    if ( $ret <= 0 ) {
        error(
            "Failed to insert overlay port (slice_id = $slice_id, datapath_id = $dpid)."
        );
        return FAILED;
    }

    my $port_id;
    if ( !$self->overlay_port_exists( $slice_id, $dpid, \$port_id ) ) {
        error(
            "Failed to retrieve overlay port id (slice_id = $slice_id, datapath_id = $dpid)."
        );
        return FAILED;
    }
    foreach my $mac (@remote_mac_addresses) {
        $state = MAC_STATE_READY_TO_INSTALL;
        $ret
            = $self->{'dbh'}->do(
            "INSERT INTO mac_addresses (slice_id,port_id,mac,type,state) "
                . "VALUES ($slice_id,$port_id,$mac,"
                . MAC_TYPE_REMOTE
                . ",$state)" );
        if ( $ret <= 0 ) {
            error(
                "Failed to insert remote MAC address to an overlay port (slice_id = $slice_id, datapath_id = $dpid, port_id = $port_id, mac = $mac)."
            );
            return FAILED;
        }
    }

    return SUCCEEDED;
}

sub add_overlay_ports() {
    my ( $self, $slice_id ) = @_;

    debug("Adding overlay ports (slice_id = $slice_id)");

    my @switches = $self->get_active_switches($slice_id);
    if ( @switches <= 1 ) {
        return SUCCEEDED;
    }

    my $err = SUCCEEDED;
    my %mac_addresses
        = $self->get_mac_addresses( $slice_id, undef, undef, MAC_TYPE_LOCAL,
        \$err );
    if ( $err != SUCCEEDED && $err != NO_MAC_ADDRESS_FOUND ) {
        error("Failed to retrieve MAC addresses (slice_id = $slice_id).");
        return FAILED;
    }
    my $errors = 0;
    foreach my $dpid (@switches) {
        my @remote_mac_addresses = ();
        foreach my $mac ( keys(%mac_addresses) ) {
            my $remote;
            my $ret = $self->get_datapath_id_by_port_id( $slice_id,
                $mac_addresses{$mac}{'port_id'}, \$remote );
            if ( $ret < 0 ) {
                error(
                    "Failed to retrieve datapath_id (slice_id = $slice_id, port_id = $mac_addresses{$mac}{'port_id'}, mac_address = $mac)."
                );
                $errors++;
                next;
            }
            if ( $dpid != $remote ) {
                push( @remote_mac_addresses, $mac );
            }
        }
        my $ret = $self->add_overlay_port( $slice_id, $dpid,
            @remote_mac_addresses );
        if ( $ret != SUCCEEDED ) {
            $errors++;
        }
    }

    return $errors == 0 ? SUCCEEDED : FAILED;
}

sub add_port() {
    my ( $self, $slice_id, $dpid, $port_no, $port_name, $vid, $description,
        $id )
        = @_;

    if ( !$self->slice_exists($slice_id) ) {
        debug("No slice found (slice_id = $slice_id).");
        return NO_SLICE_FOUND;
    }

    if ( !defined($port_no) && !defined($port_name) ) {
        debug("port no or port name must be specified.");
        return FAILED;
    }

    if ( defined($id) && $self->port_id_exists( $slice_id, $id ) ) {
        debug("port id found (port_id = $id).");
        return DUPLICATED_PORT_ID;
    }

    if ( $self->port_exists( $dpid, $port_no, $port_name, $vid ) ) {
        my $err = "port found (datapath_id = $dpid, ";
        $err .= "port_no = $port_no, "     if defined($port_no);
        $err .= "port_name = $port_name, " if defined($port_name);
        $err .= "vid = $vid).";
        debug($err);
        return DUPLICATED_PORT;
    }

    my $ret = $self->update_slice_state(
        $slice_id,             SLICE_STATE_PREPARING_TO_UPDATE,
        SLICE_STATE_CONFIRMED, SLICE_STATE_READY_TO_UPDATE
    );
    if ( $ret < 0 ) {
        return FAILED;
    }

    if ( !defined($port_no) ) {
        $port_no = PORT_NO_UNDEFINED;
    }
    if ( !defined($port_name) ) {
        $port_name = "";
    }
    if ( !defined($vid) ) {
        $vid = VLAN_ID_UNSPECIFIED;
    }
    if ( !defined($description) ) {
        $description = "";
    }

    my $state = PORT_STATE_READY_TO_UPDATE;
    if ( defined($id) ) {
        $ret
            = $self->{'dbh'}->do(
            "INSERT INTO ports (id,slice_id,datapath_id,port_no,port_name,vid,type,description,state) "
                . "VALUES ($id,$slice_id,$dpid,$port_no,'$port_name',$vid,"
                . PORT_TYPE_CUSTOMER
                . ",'$description',$state)" );
    }
    else {
        $ret
            = $self->{'dbh'}->do(
            "INSERT INTO ports (slice_id,datapath_id,port_no,port_name,vid,type,description,state) "
                . "VALUES ($slice_id,$dpid,$port_no,'$port_name',$vid,"
                . PORT_TYPE_CUSTOMER
                . ",'$description',$state)" );
    }

    if ( $ret <= 0 ) {
        $self->update_slice_state( $slice_id, SLICE_STATE_UPDATE_FAILED,
            SLICE_STATE_PREPARING_TO_UPDATE );
        error(
            "Failed to insert customer port (slice_id = $slice_id, datapath_id = $dpid)."
        );
        return FAILED;
    }

    $ret = $self->add_overlay_ports($slice_id);
    if ( $ret < 0 ) {
        $self->update_slice_state( $slice_id, SLICE_STATE_UPDATE_FAILED,
            SLICE_STATE_PREPARING_TO_UPDATE );
        return FAILED;
    }

    $ret = $self->update_slice_state( $slice_id, SLICE_STATE_READY_TO_UPDATE,
        SLICE_STATE_PREPARING_TO_UPDATE );
    if ( $ret < 0 ) {
        return FAILED;
    }

    debug("Port is added successfully.");

    return SUCCEEDED;
}

sub get_inactive_switches() {
    my ( $self, $slice_id ) = @_;

    debug(
        "Retrieving the list of inactive/inactivating switches in a slice (slice_id = $slice_id)."
    );

    my $statement = sprintf(
        "SELECT datapath_id,SUM(CASE WHEN state = %u OR state = %u OR state = %u OR state = %u THEN 1 ELSE 0 END) from ports "
            . "WHERE slice_id = %u AND type = %u GROUP BY datapath_id",
        PORT_STATE_CONFIRMED, PORT_STATE_PREPARING_TO_UPDATE,
        PORT_STATE_READY_TO_UPDATE, PORT_STATE_UPDATING, $slice_id,
        PORT_TYPE_CUSTOMER
    );
    my $sth      = $self->{'dbh'}->prepare($statement);
    my $ret      = $sth->execute();
    my @switches = ();
    while ( my @row = $sth->fetchrow_array ) {
        if ( $row[1] == 0 ) {
            push( @switches, $row[0] );
        }
    }

    return @switches;
}

sub delete_overlay_port() {
    my ( $self, $slice_id, $dpid ) = @_;

    debug(
        "Deleting an overlay port (slice_id = $slice_id, datapath_id = $dpid)."
    );

    my $id;
    if ( !$self->overlay_port_exists( $slice_id, $dpid, \$id ) ) {
        debug(
            "An overlay port does not exist (slice_id = $slice_id, datapath_id = $dpid)."
        );
        return SUCCEEDED;
    }

    my $errors = 0;
    my $ret
        = $self->update_port_state( $slice_id, $id, PORT_TYPE_OVERLAY,
        PORT_STATE_READY_TO_DESTROY, PORT_STATE_CONFIRMED,
        PORT_STATE_READY_TO_UPDATE );
    if ( $ret == SUCCEEDED ) {
        $ret = $self->update_mac_address_state( $slice_id, $id, undef,
            MAC_TYPE_REMOTE, MAC_STATE_READY_TO_DELETE, MAC_STATE_INSTALLED );
        if ( $ret < 0 && $ret != NO_TARGET_FOUND ) {
            $errors++;
        }
    }
    else {
        $errors++;
    }

    return $errors == 0 ? SUCCEEDED : FAILED;
}

sub delete_overlay_ports() {
    my ( $self, $slice_id ) = @_;

    debug("Deleting overlay ports (slice_id = $slice_id)");

    my @switches = $self->get_inactive_switches($slice_id);
    my $errors   = 0;
    foreach my $dpid (@switches) {
        my $ret = $self->delete_overlay_port( $slice_id, $dpid );
        if ( $ret != SUCCEEDED ) {
            $errors++;
        }
    }

    @switches = ();
    @switches = $self->get_active_switches($slice_id);
    if ( @switches == 1 ) {
        my $ret = $self->delete_overlay_port( $slice_id, $switches[0] );
        if ( $ret != SUCCEEDED ) {
            $errors++;
        }
    }

    return $errors == 0 ? SUCCEEDED : FAILED;
}

sub delete_port() {
    return delete_port_by_id(@_);
}

sub delete_port_by_id() {
    my ( $self, $slice_id, $id ) = @_;

    if ( !$self->slice_exists($slice_id) ) {
        debug("No slice found (slice_id = $slice_id).");
        return NO_SLICE_FOUND;
    }

    my $err = SUCCEEDED;
    $self->get_ports( $slice_id, undef, $id, PORT_TYPE_CUSTOMER, \$err );
    if ( $err == NO_SLICE_FOUND || $err == NO_PORT_FOUND ) {
        return $err;
    }

    my $dpid;
    my $ret = $self->get_datapath_id_by_port_id( $slice_id, $id, \$dpid );
    if ( $ret < 0 ) {
        return FAILED;
    }

    $ret = $self->update_slice_state(
        $slice_id,             SLICE_STATE_PREPARING_TO_UPDATE,
        SLICE_STATE_CONFIRMED, SLICE_STATE_READY_TO_UPDATE
    );
    if ( $ret < 0 ) {
        return FAILED;
    }

    my $errors = 0;
    $ret = $self->update_port_state( $slice_id, $id, PORT_TYPE_CUSTOMER,
        PORT_STATE_READY_TO_DESTROY, PORT_STATE_CONFIRMED );
    if ( $ret == SUCCEEDED ) {
        $ret = $self->update_mac_address_state( $slice_id, $id, undef,
            MAC_TYPE_LOCAL, MAC_STATE_READY_TO_DELETE, MAC_STATE_INSTALLED );
        if ( $ret < 0 && $ret != NO_TARGET_FOUND ) {
            $errors++;
        }
    }
    else {
        $errors++;
    }

    $err = SUCCEEDED;
    my %mac_addresses
        = $self->get_mac_addresses( $slice_id, $id, undef, MAC_TYPE_LOCAL,
        \$err );
    foreach my $mac ( keys(%mac_addresses) ) {
        $ret = $self->delete_mac_address_from_remotes( $slice_id, $dpid,
            $mac );
        if ( $ret < 0 ) {
            $errors++;
        }
    }

    if ( $errors == 0 ) {
        $ret = $self->delete_overlay_ports($slice_id);
        if ( $ret < 0 ) {
            $errors++;
        }
    }

    if ($errors) {
        $self->update_slice_state( $slice_id, SLICE_STATE_UPDATE_FAILED,
            SLICE_STATE_PREPARING_TO_UPDATE );
        return FAILED;
    }

    $ret = $self->update_slice_state( $slice_id, SLICE_STATE_READY_TO_UPDATE,
        SLICE_STATE_PREPARING_TO_UPDATE );
    if ( $ret < 0 ) {
        return FAILED;
    }

    debug("Port is deleted successfully.");

    return SUCCEEDED;
}

sub get_ports() {
    my ( $self, $slice_id, $dpid, $id, $type, $err ) = @_;

    if ( defined($err) ) {
        ${$err} = SUCCEEDED;
    }

    if ( !$self->slice_exists($slice_id) ) {
        debug("No slice found (slice_id = $slice_id).");
        if ( defined($err) ) {
            ${$err} = NO_SLICE_FOUND;
        }
        return;
    }

    my $statement
        = "SELECT id,slice_id,datapath_id,port_no,port_name,vid,type,description,state,updated_at "
        . "FROM ports WHERE slice_id = $slice_id";

    if ( defined($id) ) {
        $statement .= " AND id = $id";
    }
    if ( defined($dpid) ) {
        $statement .= " AND datapath_id = $dpid";
    }
    if ( defined($type) && $type < PORT_TYPE_MAX ) {
        $statement .= " AND type = $type";
    }

    my $sth = $self->{'dbh'}->prepare($statement);
    my $ret = $sth->execute();

    my %ports = ();
    while ( my @row = $sth->fetchrow_array ) {
        $id                        = $row[0];
        $ports{$id}{'datapath_id'} = $row[2];
        $ports{$id}{'port_no'}     = $row[3];
        $ports{$id}{'port_name'}   = $row[4];
        $ports{$id}{'vid'}         = $row[5];
        $ports{$id}{'type'}        = $row[6];
        $ports{$id}{'description'} = $row[7];
        $ports{$id}{'state'}       = $row[8];
        $ports{$id}{'updated_at'}  = $row[9];
    }

    if ( !%ports ) {
        if ( defined($err) ) {
            ${$err} = NO_PORT_FOUND;
        }
    }

    return %ports;
}

sub get_port_id_by_name() {
    my ( $self, $slice_id, $datapath_id, $name, $err ) = @_;

    if ( defined($err) ) {
        ${$err} = SUCCEEDED;
    }

    if ( !$self->slice_exists($slice_id) ) {
        debug("No slice found (slice_id = $slice_id).");
        if ( defined($err) ) {
            ${$err} = NO_SLICE_FOUND;
        }
        return;
    }

    my $statement
        = "SELECT id FROM ports WHERE slice_id = $slice_id AND datapath_id = $datapath_id AND port_name = '$name'";
    my $sth = $self->{'dbh'}->prepare($statement);
    my $ret = $sth->execute();
    my $row = $sth->fetch();
    if ( defined($row) && defined( $row->[0] ) ) {
        return $row->[0];
    }

    ${$err} = NO_PORT_FOUND;

    return;
}

sub add_mac_address_to_remote() {
    my ( $self, $slice_id, $dpid, $mac ) = @_;

    if ( !defined($slice_id) || !defined($dpid) || !defined($mac) ) {
        debug("slice id and datapath_id and MAC address must be specified.");
        return FAILED;
    }

    my $port_id;
    if ( !$self->overlay_port_exists( $slice_id, $dpid, \$port_id ) ) {
        debug(
            "An overlay port does not exist (slice_id = $slice_id, datapath_id = $dpid)."
        );
        return FAILED;
    }

    my $ret
        = $self->update_port_state( $slice_id, $port_id, PORT_TYPE_OVERLAY,
        PORT_STATE_PREPARING_TO_UPDATE,
        PORT_STATE_CONFIRMED, PORT_STATE_READY_TO_UPDATE );
    if ( $ret < 0 ) {
        return FAILED;
    }

    my $state = MAC_STATE_READY_TO_INSTALL;
    $ret
        = $self->{'dbh'}
        ->do( "INSERT INTO mac_addresses (slice_id,port_id,mac,type,state) "
            . "VALUES ($slice_id,$port_id,$mac,"
            . MAC_TYPE_REMOTE
            . ",$state)" );
    if ( $ret <= 0 ) {
        $self->update_port_state( $slice_id, $port_id, PORT_TYPE_OVERLAY,
            PORT_STATE_UPDATE_FAILED, PORT_STATE_PREPARING_TO_UPDATE );
        return FAILED;
    }

    $ret = $self->update_port_state( $slice_id, $port_id, PORT_TYPE_OVERLAY,
        PORT_STATE_READY_TO_UPDATE, PORT_STATE_PREPARING_TO_UPDATE );
    if ( $ret < 0 ) {
        return FAILED;
    }

    return SUCCEEDED;
}

sub get_datapath_id_by_port_id() {
    my ( $self, $slice_id, $port_id, $dpid ) = @_;

    if ( !defined($slice_id) || !defined($port_id) || !defined($dpid) ) {
        debug("slice id and port id and datapath_id must be specified.");
        return FAILED;
    }

    my $sth
        = $self->{'dbh'}->prepare(
        "SELECT datapath_id FROM ports WHERE slice_id = $slice_id AND id = $port_id"
        );
    my $ret = $sth->execute();
    my $row = $sth->fetch();
    if ( !defined($row) ) {
        error(
            "Failed to retrieve datapath_id (slice_id = $slice_id, port_id = $port_id)."
        );
        return FAILED;
    }
    ${$dpid} = $row->[0];

    return SUCCEEDED;
}

sub add_mac_address_to_remotes() {
    my ( $self, $slice_id, $dpid, $mac ) = @_;

    if ( !defined($slice_id) || !defined($dpid) || !defined($mac) ) {
        debug("slice id and datapath_id and MAC address must be specified.");
        return FAILED;
    }

    my @switches = $self->get_active_switches($slice_id);
    my $errors   = 0;
    foreach my $remote (@switches) {
        if ( $remote == $dpid ) {
            next;
        }
        my $ret
            = $self->add_mac_address_to_remote( $slice_id, $remote, $mac );
        if ( $ret < 0 ) {
            $errors++;
        }
    }

    return $errors == 0 ? SUCCEEDED : FAILED;
}

sub add_mac_address() {
    my ( $self, $slice_id, $port_id, $mac ) = @_;

    if ( !defined($slice_id) || !defined($port_id) || !defined($mac) ) {
        debug("slice id and port id and MAC address must be specified.");
        return FAILED;
    }

    my $err = SUCCEEDED;
    $self->get_ports( $slice_id, undef, $port_id, PORT_TYPE_CUSTOMER, \$err );
    if ( $err == NO_SLICE_FOUND || $err == NO_PORT_FOUND ) {
        return $err;
    }

    my $dpid;
    my $ret
        = $self->get_datapath_id_by_port_id( $slice_id, $port_id, \$dpid );
    if ( $ret < 0 ) {
        return FAILED;
    }

    $ret = $self->update_slice_state(
        $slice_id,             SLICE_STATE_PREPARING_TO_UPDATE,
        SLICE_STATE_CONFIRMED, SLICE_STATE_READY_TO_UPDATE
    );
    if ( $ret < 0 ) {
        return FAILED;
    }

    $ret
        = $self->update_port_state( $slice_id, $port_id, PORT_TYPE_CUSTOMER,
        PORT_STATE_PREPARING_TO_UPDATE,
        PORT_STATE_CONFIRMED, PORT_STATE_READY_TO_UPDATE );
    if ( $ret < 0 ) {
        return FAILED;
    }

    $mac = mac_string_to_int($mac);
    my $state = MAC_STATE_READY_TO_INSTALL;
    $ret
        = $self->{'dbh'}
        ->do( "INSERT INTO mac_addresses (slice_id,port_id,mac,type,state) "
            . "VALUES ($slice_id,$port_id,$mac,"
            . MAC_TYPE_LOCAL
            . ",$state)" );
    if ( $ret <= 0 ) {
        $self->update_port_state( $slice_id, $port_id, PORT_TYPE_CUSTOMER,
            PORT_STATE_UPDATE_FAILED, PORT_STATE_PREPARING_TO_UPDATE );
        $self->update_slice_state( $slice_id, SLICE_STATE_UPDATE_FAILED,
            SLICE_STATE_PREPARING_TO_UPDATE );
        return FAILED;
    }

    $ret = $self->update_port_state( $slice_id, $port_id, PORT_TYPE_CUSTOMER,
        PORT_STATE_READY_TO_UPDATE, PORT_STATE_PREPARING_TO_UPDATE );
    if ( $ret < 0 ) {
        return FAILED;
    }

    $ret = $self->add_mac_address_to_remotes( $slice_id, $dpid, $mac );
    if ( $ret < 0 ) {
        $self->update_slice_state( $slice_id, SLICE_STATE_UPDATE_FAILED,
            SLICE_STATE_PREPARING_TO_UPDATE );
        return FAILED;
    }

    $ret = $self->update_slice_state( $slice_id, SLICE_STATE_READY_TO_UPDATE,
        SLICE_STATE_PREPARING_TO_UPDATE );
    if ( $ret < 0 ) {
        return FAILED;
    }

    debug("Port is added successfully.");

    return SUCCEEDED;
}

sub delete_mac_address_from_remote() {
    my ( $self, $slice_id, $dpid, $mac ) = @_;

    if ( !defined($slice_id) || !defined($dpid) || !defined($mac) ) {
        debug("slice id and datapath_id and MAC address must be specified.");
        return FAILED;
    }

    my $port_id;
    if ( !$self->overlay_port_exists( $slice_id, $dpid, \$port_id ) ) {
        debug(
            "An overlay port does not exist (slice_id = $slice_id, datapath_id = $dpid)."
        );
        return FAILED;
    }

    my $ret
        = $self->update_port_state( $slice_id, $port_id, PORT_TYPE_OVERLAY,
        PORT_STATE_PREPARING_TO_UPDATE,
        PORT_STATE_CONFIRMED, PORT_STATE_READY_TO_UPDATE );
    if ( $ret < 0 ) {
        return FAILED;
    }

    $ret = $self->update_mac_address_state( $slice_id, $port_id, $mac,
        MAC_TYPE_REMOTE, MAC_STATE_READY_TO_DELETE, MAC_STATE_INSTALLED );
    if ( $ret < 0 ) {
        $self->update_port_state( $slice_id, $port_id, PORT_TYPE_OVERLAY,
            PORT_STATE_UPDATE_FAILED, PORT_STATE_PREPARING_TO_UPDATE );
        return FAILED;
    }

    $ret = $self->update_port_state( $slice_id, $port_id, PORT_TYPE_OVERLAY,
        PORT_STATE_READY_TO_UPDATE, PORT_STATE_PREPARING_TO_UPDATE );
    if ( $ret < 0 ) {
        return FAILED;
    }

    return SUCCEEDED;
}

sub delete_mac_address_from_remotes() {
    my ( $self, $slice_id, $dpid, $mac ) = @_;

    if ( !defined($slice_id) || !defined($dpid) || !defined($mac) ) {
        debug("slice id and datapath_id and MAC address must be specified.");
        return FAILED;
    }

    # FIXME: should we target all (both active and inactive) switches?
    my @switches = $self->get_active_switches($slice_id);
    my $errors   = 0;
    foreach my $remote (@switches) {
        if ( $remote == $dpid ) {
            next;
        }
        my $ret = $self->delete_mac_address_from_remote( $slice_id, $remote,
            $mac );
        if ( $ret < 0 ) {
            $errors++;
        }
    }

    return $errors == 0 ? SUCCEEDED : FAILED;
}

sub delete_mac_address() {
    my ( $self, $slice_id, $port_id, $mac ) = @_;

    if ( !defined($slice_id) || !defined($port_id) || !defined($mac) ) {
        debug("slice id and port id and MAC address must be specified.");
        return FAILED;
    }

    my $err = SUCCEEDED;
    $self->get_mac_addresses( $slice_id, $port_id, $mac, MAC_TYPE_LOCAL,
        \$err );
    if (   $err == NO_SLICE_FOUND
        || $err == NO_PORT_FOUND
        || $err == NO_MAC_ADDRESS_FOUND )
    {
        return $err;
    }

    my $dpid;
    my $ret
        = $self->get_datapath_id_by_port_id( $slice_id, $port_id, \$dpid );
    if ( $ret < 0 ) {
        return FAILED;
    }

    $ret = $self->update_slice_state(
        $slice_id,             SLICE_STATE_PREPARING_TO_UPDATE,
        SLICE_STATE_CONFIRMED, SLICE_STATE_READY_TO_UPDATE
    );
    if ( $ret < 0 ) {
        return FAILED;
    }
    $ret
        = $self->update_port_state( $slice_id, $port_id, PORT_TYPE_CUSTOMER,
        PORT_STATE_PREPARING_TO_UPDATE,
        PORT_STATE_CONFIRMED, PORT_STATE_READY_TO_UPDATE );
    if ( $ret < 0 ) {
        return FAILED;
    }

    $mac = mac_string_to_int($mac);
    $ret = $self->update_mac_address_state( $slice_id, $port_id, $mac,
        MAC_TYPE_LOCAL, MAC_STATE_READY_TO_DELETE, MAC_STATE_INSTALLED );
    if ( $ret < 0 ) {
        $self->update_port_state( $slice_id, $port_id, PORT_TYPE_CUSTOMER,
            PORT_STATE_UPDATE_FAILED, PORT_STATE_PREPARING_TO_UPDATE );
        $self->update_slice_state( $slice_id, SLICE_STATE_UPDATE_FAILED,
            SLICE_STATE_PREPARING_TO_UPDATE );
        return FAILED;
    }

    $ret = $self->delete_mac_address_from_remotes( $slice_id, $dpid, $mac );
    if ( $ret < 0 ) {
        $self->update_port_state( $slice_id, $port_id, PORT_TYPE_CUSTOMER,
            PORT_STATE_UPDATE_FAILED, PORT_STATE_PREPARING_TO_UPDATE );
        $self->update_slice_state( $slice_id, SLICE_STATE_UPDATE_FAILED,
            SLICE_STATE_PREPARING_TO_UPDATE );
        return FAILED;
    }

    $ret = $self->update_port_state( $slice_id, $port_id, PORT_TYPE_CUSTOMER,
        PORT_STATE_READY_TO_UPDATE, PORT_STATE_PREPARING_TO_UPDATE );
    if ( $ret < 0 ) {
        return FAILED;
    }
    $ret = $self->update_slice_state( $slice_id, SLICE_STATE_READY_TO_UPDATE,
        SLICE_STATE_PREPARING_TO_UPDATE );
    if ( $ret < 0 ) {
        return FAILED;
    }

    return SUCCEEDED;
}

sub get_mac_addresses() {
    my ( $self, $slice_id, $port_id, $mac, $type, $err ) = @_;

    my $err_port;
    $self->get_ports( $slice_id, undef, $port_id, PORT_TYPE_ANY, \$err_port );
    if ( $err_port == NO_SLICE_FOUND || $err_port == NO_PORT_FOUND ) {
        if ( defined($err) ) {
            ${$err} = $err_port;
        }
        return;
    }

    if ( defined($err) ) {
        ${$err} = SUCCEEDED;
    }

    my $statement
        = "SELECT port_id,mac,state,type,updated_at FROM mac_addresses "
        . "WHERE slice_id = $slice_id";
    if ( defined($port_id) ) {
        $statement .= " AND port_id = $port_id";
    }
    if ( defined($mac) ) {
        $mac = mac_string_to_int($mac);
        $statement .= " AND mac = $mac";
    }
    if ( defined($type) && $type < MAC_TYPE_ANY ) {
        $statement .= " AND type = $type";
    }

    my $sth = $self->{'dbh'}->prepare($statement);
    my $ret = $sth->execute();

    my %addresses = ();
    while ( my @row = $sth->fetchrow_array ) {
        $mac                           = $row[1];
        $addresses{$mac}{'port_id'}    = $row[0];
        $addresses{$mac}{'state'}      = $row[2];
        $addresses{$mac}{'type'}       = $row[3];
        $addresses{$mac}{'updated_at'} = $row[4];
    }

    if ( !%addresses ) {
        if ( defined($err) ) {
            ${$err} = NO_MAC_ADDRESS_FOUND;
        }
    }

    return %addresses;
}

sub show_description() {
    my ( $self, $slice_id ) = @_;

    my $description = "";
    my $ret = $self->get_slice_description_by_id( $slice_id, \$description );
    if ( $ret == NO_SLICE_FOUND ) {
        error("No slice found.");
        return FAILED;
    }

    info( "[Description]\n%s\n", $description );

    return SUCCEEDED;
}

sub show_ports() {
    my ( $self, $slice_id, $id ) = @_;

    my $err = SUCCEEDED;
    my %ports
        = $self->get_ports( $slice_id, undef, $id, PORT_TYPE_ANY, \$err );

    if ( $err == NO_SLICE_FOUND ) {
        error("No slice found.");
        return FAILED;
    }
    elsif ( $err == NO_PORT_FOUND ) {
        info("No ports found.");
        return SUCCEEDED;
    }

    my $port_count = 0;
    my $port_out   = "";
    foreach my $id ( keys(%ports) ) {
        if ( $port_count > 0 ) {
            $port_out .= "\n";
        }
        $port_out .= sprintf( "  [ID: %s]\n", $id );
        $port_out .= sprintf( "%13s: %s\n", "Description",
            $ports{$id}{'description'} );
        $port_out .= sprintf( "%13s: %#x\n",
            "Datapath ID", $ports{$id}{'datapath_id'} );
        $port_out .= sprintf( "%13s: %u(%s)\n",
            "Port",
            $ports{$id}{'port_no'},
            $ports{$id}{'port_name'} );
        $port_out .= sprintf( "%13s: %u\n", "VLAN ID", $ports{$id}{'vid'} );
        $port_out .= sprintf( "%13s: %s\n",
            "Type", port_type_to_string( $ports{$id}{'type'} ) );
        $port_out .= sprintf( "%13s: %s\n",
            "State", port_state_to_string( $ports{$id}{'state'} ) );
        $port_out .= sprintf( "%13s: %s\n", "Updated At",
            $ports{$id}{'updated_at'} );
        $port_count++;

        my %addresses
            = $self->get_mac_addresses( $slice_id, $id, undef, MAC_TYPE_ANY,
            \$err );
        foreach my $mac ( keys(%addresses) ) {
            $port_out
                .= sprintf( "\n    [MAC: %s]\n", int_to_mac_string($mac) );
            $port_out .= sprintf( "%15s: %s\n",
                "Type", mac_type_to_string( $addresses{$mac}{'type'} ) );
            $port_out .= sprintf( "%15s: %s\n",
                "State", mac_state_to_string( $addresses{$mac}{'state'} ) );
            $port_out .= sprintf( "%15s: %s\n",
                "Updated At", $addresses{$mac}{'updated_at'} );
        }
    }

    if ( $port_count == 0 ) {
        $port_out = "No ports found.\n";
    }

    info("[Ports]");
    info($port_out);

    return SUCCEEDED;
}

sub show_mac_addresses() {
    my ( $self, $slice_id, $port_id, $mac ) = @_;

    my $err = SUCCEEDED;
    my %addresses
        = $self->get_mac_addresses( $slice_id, $port_id, $mac, MAC_TYPE_ANY,
        \$err );

    if ( $err == NO_SLICE_FOUND ) {
        error("No slice found.");
        return FAILED;
    }
    elsif ( $err == NO_PORT_FOUND ) {
        info("No ports found.");
        return SUCCEEDED;
    }
    elsif ( $err == NO_MAC_ADDRESS_FOUND ) {
        info("No MAC address found.");
        return SUCCEEDED;
    }

    my $mac_count = 0;
    my $mac_out   = "";
    foreach my $mac ( keys(%addresses) ) {
        if ( $mac_count > 0 ) {
            $mac_out .= "\n";
        }
        $mac_out .= sprintf( "  [MAC: %s]\n", int_to_mac_string($mac) );
        $mac_out .= sprintf( "%13s: %s\n",
            "State", mac_state_to_string( $addresses{$mac}{'state'} ) );
        $mac_out .= sprintf( "%13s: %s\n",
            "Updated At", $addresses{$mac}{'updated_at'} );
        $mac_count++;
    }

    if ( $mac_count == 0 ) {
        $mac_out = "No MAC addresses found.\n";
    }

    info("[MAC Addresses]");
    info($mac_out);

    return SUCCEEDED;
}

sub show_slice_state() {
    my ( $self, $slice_id ) = @_;

    my $state = SLICE_STATE_MAX;
    my $ret = $self->get_slice_state_by_id( $slice_id, \$state );
    if ( $ret == NO_SLICE_FOUND ) {
        error("No slice found.");
        return FAILED;
    }

    info( "[State]\n%s\n", slice_state_to_string($state) );

    return SUCCEEDED;
}

sub show_slice_updated_at() {
    my ( $self, $slice_id ) = @_;

    my $updated_at = 0;
    my $ret = $self->get_slice_updated_at_by_id( $slice_id, \$updated_at );
    if ( $ret == NO_SLICE_FOUND ) {
        error("No slice found.");
        return FAILED;
    }

    info( "[Updated At]\n%s\n", $updated_at );

    return SUCCEEDED;
}

sub show_slice() {
    my ( $self, $slice_id ) = @_;

    my $ret = $self->show_description($slice_id);
    if ( $ret == SUCCEEDED ) {
        $self->show_slice_state($slice_id);
        $self->show_slice_updated_at($slice_id);
        $self->show_ports($slice_id);
    }
}

sub get_slice_description_by_id() {
    my $self        = shift;
    my $id          = shift;
    my $description = shift;

    my $sth = $self->{'dbh'}
        ->prepare("SELECT description FROM slices WHERE id = $id");
    my $ret = $sth->execute();
    my $row = $sth->fetch();
    if ( !defined($row) ) {
        return NO_SLICE_FOUND;
    }
    ${$description} = $row->[0];

    return SUCCEEDED;
}

sub get_slice_state_by_id() {
    my $self  = shift;
    my $id    = shift;
    my $state = shift;

    my $sth
        = $self->{'dbh'}->prepare("SELECT state FROM slices WHERE id = $id");
    my $ret = $sth->execute();
    my $row = $sth->fetch();
    if ( !defined($row) ) {
        return NO_SLICE_FOUND;
    }
    ${$state} = $row->[0];

    return SUCCEEDED;
}

sub get_slice_updated_at_by_id() {
    my $self       = shift;
    my $id         = shift;
    my $updated_at = shift;

    my $sth = $self->{'dbh'}
        ->prepare("SELECT updated_at FROM slices WHERE id = $id");
    my $ret = $sth->execute();
    my $row = $sth->fetch();
    if ( !defined($row) ) {
        return NO_SLICE_FOUND;
    }
    ${$updated_at} = $row->[0];

    return SUCCEEDED;
}

sub reset_slice() {
    my $self = shift;
    my $id   = shift;

    if ( !defined($id) ) {
        return FAILED;
    }

    my $ret = $self->start_transaction();
    if ( $ret < 0 ) {
        debug("Failed to start transaction (slice_id = $id).");
        return FAILED;
    }

    my $updated = 0;
    $ret = $self->update_slice_state( $id, SLICE_STATE_PREPARING_TO_UPDATE,
        SLICE_STATE_CONFIRMED, SLICE_STATE_UPDATE_FAILED );
    if ( $ret == SUCCEEDED ) {
        $updated++;
    }
    $ret = $self->update_slice_state( $id, SLICE_STATE_PREPARING_TO_DESTROY,
        SLICE_STATE_DESTROY_FAILED );
    if ( $ret == SUCCEEDED ) {
        $updated++;
    }
    if ( $updated == 0 ) {
        $ret = $self->rollback();
        if ( $ret < 0 ) {
            error("Failed to rollback transaction (slice_id = $id).");
        }
        return FAILED;
    }

    $ret
        = $self->update_port_state( $id, undef, PORT_TYPE_ANY,
        PORT_STATE_READY_TO_UPDATE, PORT_STATE_CONFIRMED,
        PORT_STATE_UPDATE_FAILED );
    if ( $ret < 0 && $ret != NO_TARGET_FOUND ) {
        $ret = $self->rollback();
        if ( $ret < 0 ) {
            error("Failed to rollback transaction (slice_id = $id).");
        }
        return FAILED;
    }
    $ret = $self->update_port_state( $id, undef, PORT_TYPE_ANY,
        PORT_STATE_READY_TO_DESTROY, PORT_STATE_DESTROY_FAILED );
    if ( $ret < 0 && $ret != NO_TARGET_FOUND ) {
        $ret = $self->rollback();
        if ( $ret < 0 ) {
            error("Failed to rollback transaction (slice_id = $id).");
        }
        return FAILED;
    }

    $ret
        = $self->update_mac_address_state( $id, undef, undef, PORT_TYPE_ANY,
        MAC_STATE_READY_TO_INSTALL, MAC_STATE_INSTALLED,
        MAC_STATE_INSTALL_FAILED );
    if ( $ret < 0 && $ret != NO_TARGET_FOUND ) {
        $ret = $self->rollback();
        if ( $ret < 0 ) {
            error("Failed to rollback transaction (slice_id = $id).");
        }
        return FAILED;
    }
    $ret = $self->update_mac_address_state( $id, undef, undef, PORT_TYPE_ANY,
        MAC_STATE_READY_TO_DELETE, MAC_STATE_DELETE_FAILED );
    if ( $ret < 0 && $ret != NO_TARGET_FOUND ) {
        $ret = $self->rollback();
        if ( $ret < 0 ) {
            error("Failed to rollback transaction (slice_id = $id).");
        }
        return FAILED;
    }

    $updated = 0;
    $ret     = $self->update_slice_state( $id, SLICE_STATE_READY_TO_UPDATE,
        SLICE_STATE_PREPARING_TO_UPDATE );
    if ( $ret == SUCCEEDED ) {
        $updated++;
    }
    $ret = $self->update_slice_state( $id, SLICE_STATE_READY_TO_DESTROY,
        SLICE_STATE_PREPARING_TO_DESTROY );
    if ( $ret == SUCCEEDED ) {
        $updated++;
    }
    if ( $updated == 0 ) {
        $ret = $self->rollback();
        if ( $ret < 0 ) {
            error("Failed to rollback transaction (slice_id = $id).");
        }
        return FAILED;
    }

    $ret = $self->commit();
    if ( $ret < 0 ) {
        error("Failed to commit transaction (slice_id = $id).");
        return FAILED;
    }

    return SUCCEEDED;
}

sub get_slices_by_datapath_id() {
    my ( $self, $dpid, $slices ) = @_;

    my $sth = $self->{'dbh'}->prepare(
        "SELECT DISTINCT slice_id FROM ports WHERE datapath_id = $dpid");

    my $ret = $sth->execute();

    while ( my @row = $sth->fetchrow_array ) {
        push( @{$slices}, $row[0] );
    }

    return SUCCEEDED;
}

sub reset_switch() {
    my ( $self, $dpid ) = @_;

    my $ret = $self->start_transaction();
    if ( $ret < 0 ) {
        error("Failed to start transaction (datapath_id = $dpid).");
        return FAILED;
    }

    my @slices = ();
    $ret = $self->get_slices_by_datapath_id( $dpid, \@slices );
    if ( $ret < 0 ) {
        error(
            "Failed to retrieve the list of slices associated with a switch (datapath_id = $dpid)."
        );
        $ret = $self->rollback();
        if ( $ret < 0 ) {
            error("Failed to rollback transaction (datapath_id = $dpid).");
        }
        return FAILED;
    }

    my $errors = 0;
    foreach my $slice_id (@slices) {
        $ret
            = $self->update_slice_state( $slice_id,
            SLICE_STATE_PREPARING_TO_UPDATE,
            SLICE_STATE_CONFIRMED, SLICE_STATE_UPDATE_FAILED );
        if ( $ret != SUCCEEDED && $ret != NO_TARGET_FOUND ) {
            $errors++;
            last;
        }
        $ret
            = $self->update_slice_state( $slice_id,
            SLICE_STATE_PREPARING_TO_DESTROY,
            SLICE_STATE_DESTROY_FAILED );
        if ( $ret != SUCCEEDED && $ret != NO_TARGET_FOUND ) {
            $errors++;
            last;
        }
    }

    if ($errors) {
        $ret = $self->rollback();
        if ( $ret < 0 ) {
            error("Failed to rollback transaction (datapath_id = $dpid).");
        }
        return FAILED;
    }

    $errors = 0;
    foreach my $slice_id (@slices) {
        my $err = SUCCEEDED;
        my %ports = $self->get_ports( $slice_id, $dpid, undef, PORT_TYPE_ANY,
            \$err );
        if ( $err == NO_SLICE_FOUND ) {
            error(
                "Failed to retrieve the ports associated with a switch (datapath_id = $dpid)."
            );
            $errors++;
            last;
        }
        foreach my $port_id ( keys(%ports) ) {
            $ret
                = $self->update_port_state( $slice_id, $port_id,
                PORT_TYPE_ANY, PORT_STATE_READY_TO_UPDATE,
                PORT_STATE_CONFIRMED, PORT_STATE_UPDATE_FAILED );
            if ( $ret < 0 && $ret != NO_TARGET_FOUND ) {
                $errors++;
                last;
            }
            $ret
                = $self->update_port_state( $slice_id, $port_id,
                PORT_TYPE_ANY, PORT_STATE_READY_TO_DESTROY,
                PORT_STATE_DESTROY_FAILED );
            if ( $ret < 0 && $ret != NO_TARGET_FOUND ) {
                $errors++;
                last;
            }
            $ret
                = $self->update_mac_address_state( $slice_id, $port_id, undef,
                PORT_TYPE_ANY, MAC_STATE_READY_TO_INSTALL,
                MAC_STATE_INSTALLED, MAC_STATE_INSTALL_FAILED );
            if ( $ret < 0 && $ret != NO_TARGET_FOUND ) {
                $errors++;
                last;
            }
            $ret
                = $self->update_mac_address_state( $slice_id, $port_id, undef,
                PORT_TYPE_ANY, MAC_STATE_READY_TO_DELETE,
                MAC_STATE_DELETE_FAILED );
            if ( $ret < 0 && $ret != NO_TARGET_FOUND ) {
                $errors++;
                last;
            }
        }
        if ($errors) {
            last;
        }
    }

    if ($errors) {
        $ret = $self->rollback();
        if ( $ret < 0 ) {
            error("Failed to rollback transaction (datapath_id = $dpid).");
        }
        return FAILED;
    }

    $errors = 0;
    foreach my $slice_id (@slices) {
        $ret = $self->update_slice_state( $slice_id,
            SLICE_STATE_READY_TO_UPDATE, SLICE_STATE_PREPARING_TO_UPDATE );
        if ( $ret != SUCCEEDED && $ret != NO_TARGET_FOUND ) {
            $errors++;
            last;
        }
        $ret = $self->update_slice_state( $slice_id,
            SLICE_STATE_READY_TO_DESTROY, SLICE_STATE_PREPARING_TO_DESTROY );
        if ( $ret != SUCCEEDED && $ret != NO_TARGET_FOUND ) {
            $errors++;
            last;
        }
    }

    if ($errors) {
        $ret = $self->rollback();
        if ( $ret < 0 ) {
            error("Failed to rollback transaction (datapath_id = $dpid).");
        }
        return FAILED;
    }

    $ret = $self->commit();
    if ( $ret < 0 ) {
        error("Failed to commit transaction (datapath_id = $dpid).");
        return FAILED;
    }

    return SUCCEEDED;
}

sub register_gs() {
    my ( $self, $dpid, $uri, $tep_addr, $tep_port ) = @_;

    if (   !defined($dpid)
        || !defined($uri)
        || !defined($tep_addr)
        || !defined($tep_port) )
    {
        return FAILED;
    }

    my $ret;
    if ( !agent_exists($dpid) ) {
        $ret = $self->{'dbh'}->do( "INSERT INTO agents (datapath_id,uri) "
                . "VALUES ($dpid,'$uri')" );
        if ( $ret <= 0 ) {
            error(
                "Failed to insert GateSwitch uri (datapath_id = $dpid, uri = $uri)."
            );
            return FAILED;
        }
    }

    if ( !tunnel_endpoint_exists($dpid) ) {
        $ret
            = $self->{'dbh'}->do( "INSERT INTO tunnel_endpoints "
                . "(datapath_id,local_address,local_port) "
                . "VALUES ($dpid,'$tep_addr',$tep_port)" );
        if ( $ret <= 0 ) {
            error(
                "Failed to insert tunnel endpoints data (datapath_id = $dpid, local_address = $tep_addr, local_port = $tep_port)."
            );
            return FAILED;
        }
    }

    return SUCCEEDED;
}

sub remove_gs() {
    my ( $self, $dpid ) = @_;

    if ( !defined($dpid) ) {
        return FAILED;
    }

    my $ret_num = 0;
    my $ret     = $self->{'dbh'}
        ->do( "DELETE FROM agents " . "WHERE datapath_id = $dpid" );
    if ( $ret < 0 ) {
        error("Failed to delete GateSwitch uri (datapath_id = $dpid).");
        return FAILED;
    }
    $ret_num += $ret;

    $ret = $self->{'dbh'}
        ->do( "DELETE FROM tunnel_endpoints " . "WHERE datapath_id = $dpid" );
    if ( $ret < 0 ) {
        error("Failed to delete tunnel endpoint data (datapath_id = $dpid).");
        return FAILED;
    }
    $ret_num += $ret;

    if ( $ret_num = 0 ) {
        error("Failed to delete GateSwitch data (datapath_id = $dpid).");
        return FAILED;
    }

    return SUCCEEDED;
}

sub health_check() {
    my $self   = shift;
    my $status = shift;

    my $hostname = hostname();

    my $sth = $self->{'dbh'}
        ->prepare("SELECT hostname FROM status WHERE hostname = '$hostname'");
    my $ret = $sth->execute();
    if ( $sth->errstr ) {
        return 0;
    }

    if ($ret) {
        $sth = $self->{'dbh'}
            ->prepare("DELETE FROM status WHERE hostname = '$hostname'");
        $ret = $sth->execute();
        if ( $sth->errstr ) {
            return 0;
        }

        $sth = $self->{'dbh'}
            ->prepare("INSERT INTO status (hostname) values ('$hostname')");
        $ret = $sth->execute();
        if ( $sth->errstr ) {
            return 0;
        }
    }
    else {
        $sth = $self->{'dbh'}
            ->prepare("INSERT INTO status (hostname) values ('$hostname')");
        $ret = $sth->execute();
        if ( $sth->errstr ) {
            return 0;
        }

        $sth = $self->{'dbh'}->prepare(
            "SELECT hostname FROM status WHERE hostname = '$hostname'");
        $ret = $sth->execute();
        if ( $sth->errstr ) {
            return 0;
        }
    }

    $sth = $self->{'dbh'}
        ->prepare("DELETE FROM status WHERE hostname = '$hostname'");
    $ret = $sth->execute();
    if ( $sth->errstr ) {
        return 0;
    }

    @{$status} = ("OK");
    return 1;
}

sub get_all_teps_info() {
    my $self  = shift;
    my $param = shift;

    my $sth
        = $self->{'dbh'}
        ->prepare( "SELECT DISTINCT P.slice_id, T.local_address, T.local_port"
            . " FROM ports P,tunnel_endpoints T"
            . " WHERE P.datapath_id = T.datapath_id" );
    my $ret = $sth->execute();

    while ( my @row = $sth->fetchrow_array ) {
        my %tep = ( 'ip' => $row[1], 'port' => $row[2] );
        push( @{ ${$param}{ $row[0] } }, \%tep );
    }

    return 1;
}

sub slice_exists() {
    my $self = shift;
    my $id   = shift;

    if ( !defined($id) ) {
        return 0;
    }

    my $sth = $self->{'dbh'}
        ->prepare("SELECT description FROM slices WHERE id = $id");
    my $ret = $sth->execute();
    my $row = $sth->fetch();
    if ( !defined($row) ) {
        return 0;
    }

    return 1;
}

sub slice_in_busy_state() {
    my $self = shift;
    my $id   = shift;

    if ( !defined($id) ) {
        return 0;
    }

    my $sth
        = $self->{'dbh'}
        ->prepare( "SELECT description FROM slices WHERE id = $id and ( "
            . "state = "
            . SLICE_STATE_READY_TO_UPDATE . " OR "
            . "state = "
            . SLICE_STATE_UPDATING . " OR "
            . "state = "
            . SLICE_STATE_READY_TO_DESTROY . " OR "
            . "state = "
            . SLICE_STATE_DESTROYING
            . " )" );
    my $ret = $sth->execute();
    my $row = $sth->fetch();
    if ( !defined($row) ) {
        return 0;
    }

    return 1;
}


sub set_slice_state_from_busy_to_failed_when_timeout() {
    my ( $self, $timeout ) = @_;
    my $sth = $self->{'dbh'}->prepare( "SELECT id,updated_at,state FROM slices WHERE ( updated_at + interval $timeout second ) < now() AND ( " .
                                    "state = " . SLICE_STATE_PREPARING_TO_UPDATE . " OR " .
                                    "state = " . SLICE_STATE_READY_TO_UPDATE . " OR " .
                                    "state = " . SLICE_STATE_UPDATING . " OR " .
                                    "state = " . SLICE_STATE_PREPARING_TO_DESTROY . " OR " .
                                    "state = " . SLICE_STATE_READY_TO_DESTROY . " OR ".
                                    "state = " . SLICE_STATE_DESTROYING . " )" );
    my $ret = $sth->execute();
    if( !defined( $ret ) ) {
        return 0;
    }
    while( my @row = $sth->fetchrow_array() ) {
        my $id = $row[0];
        my $updated_at = $row[1];
        my $state = $row[2];
        if ( $state == SLICE_STATE_PREPARING_TO_UPDATE ||
             $state == SLICE_STATE_READY_TO_UPDATE ||
             $state == SLICE_STATE_UPDATING ) {
            my $result = $self->{'dbh'}->do( "UPDATE slices SET state = " . Bisco::DB::Slice::SLICE_STATE_UPDATE_FAILED .
                            " WHERE ( updated_at + interval $timeout second ) < now() AND id = $id AND state = $state" );
            if( $result < 0 ) {
              return 0;
            }
            elsif( $result == 1 ) {
                message( LOG_ERROR, "Slice:${id}'s setting is not finished normally.Being updated at:${updated_at}." );
            }
        }
        elsif ( $state == SLICE_STATE_PREPARING_TO_DESTROY ||
                $state == SLICE_STATE_READY_TO_DESTROY ||
                $state == SLICE_STATE_DESTROYING ) {
            my $result = $self->{'dbh'}->do( "UPDATE slices SET state = " . SLICE_STATE_DESTROY_FAILED . 
                              " WHERE ( updated_at + interval $timeout second ) < now() AND id = $id AND state = $state" );
            if( $result < 0 ) {
                return 0;
            }
            elsif( $result == 1 ) {
                message( LOG_ERROR, "Slice:${id}'s setting is not finished normally.Being updated at:${updated_at}." );
            }
        }
    }
    return 1;
}


sub port_id_exists() {
    my ( $self, $slice_id, $id ) = @_;

    if ( !defined($slice_id) || !defined($id) ) {
        debug("slice id and port id must be specified.");
        return 0;
    }

    my $sth
        = $self->{'dbh'}->prepare(
        "SELECT description FROM ports WHERE slice_id = $slice_id AND id = $id"
        );
    my $ret = $sth->execute();
    my $row = $sth->fetch();
    if ( !defined($row) ) {
        return 0;
    }

    return 1;
}

sub port_exists() {
    my ( $self, $dpid, $port_no, $port_name, $vid ) = @_;

    if ( !defined($dpid) ) {
        debug("datapath_id must be specified.");
        return FAILED;
    }

    if ( !defined($port_no) && !defined($port_name) ) {
        debug("port no or port name must be specified.");
        return FAILED;
    }

    my $statement = "SELECT id FROM ports WHERE datapath_id = $dpid ";
    if ( defined($port_no) ) {
        $statement .= "AND port_no = $port_no ";
    }
    if ( defined($port_name) ) {
        $statement .= "AND port_name = '$port_name' ";
    }
    if ( defined($vid) ) {
        $statement .= "AND vid = $vid ";
    }

    my $sth = $self->{'dbh'}->prepare($statement);
    my $ret = $sth->execute();
    my $row = $sth->fetch();
    if ( !defined($row) ) {
        return 0;
    }

    return 1;
}

sub mac_address_exists() {
    my ( $self, $slice_id, $port_id, $mac ) = @_;

    if ( !defined($slice_id) || !defined($port_id) || !defined($mac) ) {
        debug("slice id and port_id and MAC address must be specified.");
        return 0;
    }

    my $sth
        = $self->{'dbh'}
        ->prepare( "SELECT mac FROM mac_addresses WHERE slice_id = $slice_id "
            . "AND port_id = $port_id AND mac = $mac" );
    my $ret = $sth->execute();
    my $row = $sth->fetch();
    if ( !defined($row) ) {
        return 0;
    }

    return 1;
}

sub agent_exists() {
    my ( $self, $dpid, $uri ) = @_;

    if ( !defined($dpid) ) {
        return 0;
    }

    my $statement
        = "SELECT datapath_id FROM agents " . "WHERE datapath_id = $dpid ";
    if ( defined($uri) ) {
        $statement .= "AND uri = '$uri'";
    }

    my $sth = $self->{'dbh'}->prepare($statement);
    my $ret = $sth->execute();
    my $row = $sth->fetch();
    if ( !defined($row) ) {
        return 0;
    }

    return 1;
}

sub tunnel_endpoint_exists() {
    my ( $self, $dpid, $address, $port ) = @_;

    if ( !defined($dpid) ) {
        return 0;
    }

    my $statement = "SELECT datapath_id FROM tunnel_endpoints "
        . "WHERE datapath_id = $dpid ";
    if ( defined($address) ) {
        $statement .= "AND local_address = '$address' ";
    }
    if ( defined($port) ) {
        $statement .= "AND local_port = '$port'";
    }

    my $sth = $self->{'dbh'}->prepare($statement);
    my $ret = $sth->execute();
    my $row = $sth->fetch();
    if ( !defined($row) ) {
        return 0;
    }

    return 1;
}

sub int_to_mac_string() {
    my $self = shift;
    my $mac  = shift;

    if ( !defined($mac) ) {
        $mac = $self;
    }

    my $string = sprintf( "%04x%08x", $mac >> 32, $mac & 0xffffffff );
    $string =~ s/(.{2})(.{2})(.{2})(.{2})(.{2})(.{2})/$1:$2:$3:$4:$5:$6/;

    return $string;
}

sub mac_string_to_int() {
    my $self = shift;
    my $mac  = shift;

    if ( !defined($mac) ) {
        $mac = $self;
    }

    $mac =~ s/://g;
    $mac =~ s/\-//g;

    return hex($mac);
}

sub slice_state_to_string() {
    my $self  = shift;
    my $state = shift;

    if ( !defined($state) ) {
        $state = $self;
    }

    my $string = $SliceStates{$state};
    if ( !defined($string) ) {
        $string = "undefined";
    }

    return $string;
}

sub port_state_to_string() {
    my $self  = shift;
    my $state = shift;

    if ( !defined($state) ) {
        $state = $self;
    }

    my $string = $PortStates{$state};
    if ( !defined($string) ) {
        $string = "undefined";
    }

    return $string;
}

sub mac_state_to_string() {
    my $self  = shift;
    my $state = shift;

    if ( !defined($state) ) {
        $state = $self;
    }

    my $string = $MacStates{$state};
    if ( !defined($string) ) {
        $string = "undefined";
    }

    return $string;
}

sub port_type_to_string() {
    my $self = shift;
    my $type = shift;

    if ( !defined($type) ) {
        $type = $self;
    }

    my $string = $PortTypes{$type};
    if ( !defined($string) ) {
        $string = "undefined";
    }

    return $string;
}

sub mac_type_to_string() {
    my $self = shift;
    my $type = shift;

    if ( !defined($type) ) {
        $type = $self;
    }

    my $string = $MacTypes{$type};
    if ( !defined($string) ) {
        $string = "undefined";
    }

    return $string;
}

sub debug() {
    if ( exists $ENV{DEBUG} ) {
        message( LOG_DEBUG, sprintf(shift, @_) );
    }
}

sub info() {
    message( LOG_NOTICE, sprintf(shift, @_) );
}

sub error() {
    message( LOG_ERROR, sprintf(shift, @_) );
}

1;

