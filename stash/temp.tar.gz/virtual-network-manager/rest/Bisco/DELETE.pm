#
# Copyright (C) 2012 NEC Corporation
# Copyright (C) NEC BIGLOBE, Ltd. 2012
# NEC Confidential
#

package Bisco::DELETE;

=head1 Bisco::DELETE

=head2 概要

  bisco.psgi を通じて送られてきたHTTPリクエストに応じた関数を呼び出す。
  また、関数から戻されるオブジェクトからHTTPの応答を生成する。

=cut

use strict;
use warnings;
use Exporter;
use bignum;

use vars qw(@ISA @EXPORT);
@ISA = qw(Exporter);

use lib qw( /usr/share/bisco );

use Bisco::Common;
use Bisco::Constant;
use Bisco::Response;
use Bisco::DB::Slice;

sub _remove_gs($$) {
    my $Slice = shift;
    my $dpid  = shift;

    if ( $Slice->remove_gs($dpid) < 0 ) {
        return make_reply_error(
            "Failed to remove GateSwitch datapath-id ($dpid).");
    }

    return make_reply_accepted();
}

sub _destroy_network($$) {
    my $Slice    = shift;
    my $slice_id = shift;

    my $ret = $Slice->destroy_slice($slice_id);
    if ( $ret == Bisco::DB::Slice::NO_SLICE_FOUND ) {
        return make_reply_not_found("slice ($slice_id) is not exists.");
    }
    elsif ( $ret < 0 ) {
        return make_reply_error("Failed to destroy a slice ($slice_id).");
    }

    return make_reply_accepted();
}

sub _delete_port($$$) {
    my $Slice    = shift;
    my $slice_id = shift;
    my $port_id  = shift;

    unless ( $Slice->slice_exists($slice_id) ) {
        return make_reply_not_found("slice ($slice_id) is not exists.");
    }

    my $ret = $Slice->delete_port_by_id( $slice_id, $port_id );
    if ( $ret == Bisco::DB::Slice::NO_SLICE_FOUND ) {
        return make_reply_not_found("slice ($slice_id) is not exists.");
    }
    elsif ( $ret == Bisco::DB::Slice::NO_PORT_FOUND ) {
        return make_reply_not_found("port ($port_id) is not exists.");
    }
    elsif ( $ret < 0 ) {
        return make_reply_error("Failed to delete a port ($port_id).");
    }

    return make_reply_accepted();
}

sub _delete_mac_address($$$$) {
    my $Slice    = shift;
    my $slice_id = shift;
    my $port_id  = shift;
    my $mac      = shift;

    unless ( $Slice->mac_address_exists( $slice_id, $port_id, $mac ) ) {
        return make_reply_not_found("MAC address ($mac) is not exists.");
    }

    my $ret = $Slice->delete_mac_address( $slice_id, $port_id, $mac );
    if ( $ret == Bisco::DB::Slice::NO_SLICE_FOUND ) {
        return make_reply_not_found("slice ($slice_id) is not exists.");
    }
    elsif ( $ret == Bisco::DB::Slice::NO_PORT_FOUND ) {
        return make_reply_not_found("port ($port_id) is not exists.");
    }
    elsif ( $ret == Bisco::DB::Slice::NO_MAC_ADDRESS_FOUND ) {
        return make_reply_not_found("MAC address ($mac) is not exists.");
    }
    elsif ( $ret < 0 ) {
        return make_reply_error("Failed to delete a MAC address ($mac).");
    }

    return make_reply_accepted();
}

push @EXPORT, qw(handle_delete_requests);

sub handle_delete_requests($@) {
    my $Slice = shift;
    my @path  = @_;
    my $reply;

    if ( $path[0] eq "networks" ) {
        my ( $slice_id, $port_id, $mac ) = ();
        if ( @path >= 2 ) {
            $slice_id = $path[1];
            unless ( check_slice_id($slice_id) ) {
                return make_reply_not_found(
                    "slice id ($slice_id) is illegal format.");
            }
            if ( $Slice->slice_in_busy_state($slice_id) ) {
                return make_reply_busy("Update in progress.");
            }
        }
        if ( @path >= 4 ) {
            $port_id = $path[3];
            unless ( check_port_id($port_id) ) {
                return make_reply_not_found(
                    "port id ($port_id) is illegal format.");
            }
        }
        if ( @path >= 6 ) {
            $mac = $path[5];
            unless ( check_mac_address($mac) ) {
                return make_reply_not_found(
                    "MAC address ($mac) is illegal format.");
            }
        }

        if ( @path == 1 ) {
            make_reply_method_not_allowed(
                "Method not allowed. /" . join( "/", @path ) );
        }
        elsif ( @path == 2 ) {
            $reply = _destroy_network( $Slice, $slice_id );
        }
        elsif ( $path[2] eq "ports" && @path == 3 ) {
            make_reply_method_not_allowed(
                "Method not allowed. /" . join( "/", @path ) );
        }
        elsif ( $path[2] eq "ports" && @path == 4 ) {
            $reply = _delete_port( $Slice, $slice_id, $port_id );
        }
        elsif ($path[2] eq "ports"
            && $path[4] eq "mac_addresses"
            && @path == 5 )
        {
            make_reply_method_not_allowed(
                "Method not allowed. /" . join( "/", @path ) );
        }
        elsif ($path[2] eq "ports"
            && $path[4] eq "mac_addresses"
            && @path == 6 )
        {
            $reply = _delete_mac_address( $Slice, $slice_id, $port_id, $mac );
        }
        else {
            $reply = make_reply_not_found(
                "Unknown path: /" . join( "/", @path ) );
        }
    }
    elsif ( $path[0] eq "agents" ) {
        my $dpid;
        if ( @path >= 2 ) {
            $dpid = $path[1];
            unless ( check_dpid($dpid) ) {
                return make_reply_unprocessable_entity(
                    "datapath-id ($dpid) is illegal format.");
            }
        }

        if ( @path == 1 ) {
            make_reply_method_not_allowed(
                "Method not allowed. /" . join( "/", @path ) );
        }
        elsif ( @path == 2 ) {
            $reply = _remove_gs( $Slice, $dpid );
        }
        else {
            $reply = make_reply_not_found(
                "Unknown path: /" . join( "/", @path ) );
        }
    }
    else {
        $reply
            = make_reply_not_found( "Unknown path: /" . join( "/", @path ) );
    }

    return $reply;
}

1;
