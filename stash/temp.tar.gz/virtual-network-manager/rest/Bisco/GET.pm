#
# Copyright (C) 2012 NEC Corporation
# Copyright (C) NEC BIGLOBE, Ltd. 2012
# NEC Confidential
#

package Bisco::GET;

=head1 Bisco::GET

=head2 概要

  bisco.psgi を通じて送られてきたHTTPリクエストに応じた関数を呼び出す。
  また、関数から戻されるオブジェクトからHTTPの応答を生成する。

=cut

use strict;
use warnings;
use Exporter;
use bignum;

use vars qw(@ISA @EXPORT);
@ISA = qw(Exporter);

use lib qw( /usr/share/bisco );

use Bisco::Common;
use Bisco::Constant;
use Bisco::Response;
use Bisco::DB::Slice;

my $ShowTimestamps = 0;

sub _list_networks($) {
    my $Slice  = shift;
    my @slices = $Slice->get_slices();
    foreach my $slice (@slices) {
        delete( ${$slice}{'updated_at'} ) unless $ShowTimestamps;
        ${$slice}{'id'} = int( ${$slice}{'id'} );
        ${$slice}{'state'}
            = $Slice->slice_state_to_string( ${$slice}{'state'} );
    }
    return make_reply_ok_with_json( \@slices );
}

sub _show_network($$) {
    my $Slice    = shift;
    my $slice_id = shift;

    unless ( $Slice->slice_exists($slice_id) ) {
        return make_reply_not_found("slice ($slice_id) is not exists.");
    }

    my %output = ();

    my $slice_description;
    if ( $Slice->get_slice_description_by_id( $slice_id, \$slice_description )
        < 0 )
    {
        return make_reply_error(
            "Failed to retrieve slice ($slice_id) description.");
    }
    my $slice_state;
    if ( $Slice->get_slice_state_by_id( $slice_id, \$slice_state ) < 0 ) {
        return make_reply_error(
            "Failed to retrieve slice ($slice_id) state.");
    }
    my $slice_updated_at;
    if ( $Slice->get_slice_updated_at_by_id( $slice_id, \$slice_updated_at )
        < 0 )
    {
        return make_reply_error(
            "Failed to retrieve slice ($slice_id) updated timestamp.");
    }

    unless ( defined($slice_description) ) {
        $slice_description = "";
    }
    $output{'id'}          = int($slice_id);
    $output{'description'} = $slice_description;
    $output{'state'}       = $Slice->slice_state_to_string($slice_state);
    $output{'updated_at'}  = $slice_updated_at if $ShowTimestamps;

    return make_reply_ok_with_json( \%output );
}

sub _show_ports($$) {
    my $Slice    = shift;
    my $slice_id = shift;

    unless ( $Slice->slice_exists($slice_id) ) {
        return make_reply_not_found("slice ($slice_id) is not exists.");
    }

    my %ports = $Slice->get_ports( $slice_id, undef, undef,
        Bisco::DB::Slice::PORT_TYPE_CUSTOMER );
    my @output = ();

    foreach my $id ( keys(%ports) ) {
        my %port = ();
        $port{'id'}          = int($id);
        $port{'datapath_id'} = sprintf( "%s", $ports{$id}{'datapath_id'} );
        $port{'number'}      = int( $ports{$id}{'port_no'} );
        $port{'name'}        = $ports{$id}{'port_name'};
        $port{'vid'}         = int( $ports{$id}{'vid'} );
        $port{'description'} = $ports{$id}{'description'};
        $port{'state'} = $Slice->port_state_to_string( $ports{$id}{'state'} );
        $port{'updated_at'} = $ports{$id}{'updated_at'} if $ShowTimestamps;
        push( @output, \%port );
    }

    return make_reply_ok_with_json( \@output );
}

sub _show_port($$$) {
    my $Slice    = shift;
    my $slice_id = shift;
    my $port_id  = shift;

    unless ( $Slice->slice_exists($slice_id) ) {
        return make_reply_not_found("slice ($slice_id) is not exists.");
    }

    my %ports = $Slice->get_ports( $slice_id, undef, $port_id,
        Bisco::DB::Slice::PORT_TYPE_CUSTOMER );

    my $found = 0;
    my %port  = ();
    foreach my $id ( keys(%ports) ) {
        $port{'id'}          = int($id);
        $port{'datapath_id'} = sprintf( "%s", $ports{$id}{'datapath_id'} );
        $port{'number'}      = int( $ports{$id}{'port_no'} );
        $port{'name'}        = $ports{$id}{'port_name'};
        $port{'vid'}         = int( $ports{$id}{'vid'} );
        $port{'description'} = $ports{$id}{'description'};
        $port{'state'} = $Slice->port_state_to_string( $ports{$id}{'state'} );
        $port{'updated_at'} = $ports{$id}{'updated_at'} if $ShowTimestamps;
        $found++;
        last;
    }

    if ( $found == 0 ) {
        return make_reply_not_found(
            "port ($port_id) is not exists in slice ($slice_id).");
    }

    return make_reply_ok_with_json( \%port );
}

sub _show_mac_addresses($$$) {
    my $Slice    = shift;
    my $slice_id = shift;
    my $port_id  = shift;

    unless ( $Slice->port_id_exists( $slice_id, $port_id ) ) {
        return make_reply_not_found(
            "port ($port_id) is not exists in slice ($slice_id).");
    }

    my @output        = ();
    my %mac_addresses = $Slice->get_mac_addresses( $slice_id, $port_id, undef,
        Bisco::DB::Slice::MAC_TYPE_LOCAL );
    foreach my $mac ( keys(%mac_addresses) ) {
        my %mac_out = ();
        $mac_out{'address'} = $Slice->int_to_mac_string($mac);
        $mac_out{'state'}
            = $Slice->mac_state_to_string( $mac_addresses{$mac}{'state'} );
        $mac_out{'updated_at'} = $mac_addresses{$mac}{'updated_at'}
            if $ShowTimestamps;
        push( @output, \%mac_out );
    }

    return make_reply_ok_with_json( \@output );
}

sub _show_mac_address($$$$) {
    my $Slice    = shift;
    my $slice_id = shift;
    my $port_id  = shift;
    my $mac      = shift;

    unless ( $Slice->mac_address_exists( $slice_id, $port_id, $mac ) ) {
        return make_reply_not_found(
            "MAC address ($mac) is not exists on port ($port_id) in slice ($slice_id)."
        );
    }

    my %output        = ();
    my %mac_addresses = $Slice->get_mac_addresses( $slice_id, $port_id, $mac,
        Bisco::DB::Slice::MAC_TYPE_LOCAL );
    foreach my $mac ( keys(%mac_addresses) ) {
        $output{'address'} = $Slice->int_to_mac_string($mac);
        $output{'state'}
            = $Slice->mac_state_to_string( $mac_addresses{$mac}{'state'} );
        $output{'updated_at'} = $mac_addresses{$mac}{'updated_at'}
            if $ShowTimestamps;
        last;
    }

    return make_reply_ok_with_json( \%output );
}

sub _get_status($) {
    my $Slice = shift;

    my @status;
    unless ( $Slice->health_check( \@status ) ) {
        make_reply_error("Failed to health check.");
    }

    return make_reply_ok_with_json( \@status );
}

sub _retrive_all_teps($) {
    my $Slice = shift;

    my %param = ();
    unless ( $Slice->get_all_teps_info( \%param ) ) {
        make_reply_error("Failed to retrieve all tunnel endpoints.");
    }

    return make_reply_ok_with_json( \%param );
}

push @EXPORT, qw(handle_get_requests);

sub handle_get_requests($@) {
    my $Slice = shift;
    my @path  = @_;
    my $reply;

    if ( $path[0] eq "networks" ) {
        my ( $slice_id, $port_id, $mac ) = ();
        if ( @path >= 2 ) {
            $slice_id = $path[1];
            unless ( check_slice_id($slice_id) ) {
                return make_reply_not_found(
                    "slice id ($slice_id) is illegal format.");
            }
        }
        if ( @path >= 4 ) {
            $port_id = $path[3];
            unless ( check_port_id($port_id) ) {
                return make_reply_not_found(
                    "port id ($port_id) is illegal format.");
            }
        }
        if ( @path >= 6 ) {
            $mac = $path[5];
            unless ( check_mac_address($mac) ) {
                return make_reply_not_found(
                    "MAC address ($mac) is illegal format.");
            }
        }

        if ( @path == 1 ) {
            $reply = _list_networks($Slice);
        }
        elsif ( @path == 2 ) {
            $reply = _show_network( $Slice, $slice_id );
        }
        elsif ( $path[2] eq "ports" && @path == 3 ) {
            $reply = _show_ports( $Slice, $slice_id );
        }
        elsif ( $path[2] eq "ports" && @path == 4 ) {
            $reply = _show_port( $Slice, $slice_id, $port_id );
        }
        elsif ($path[2] eq "ports"
            && $path[4] eq "mac_addresses"
            && @path == 5 )
        {
            $reply = _show_mac_addresses( $Slice, $slice_id, $port_id );
        }
        elsif ($path[2] eq "ports"
            && $path[4] eq "mac_addresses"
            && @path == 6 )
        {
            $reply = _show_mac_address( $Slice, $slice_id, $port_id, $mac );
        }
        else {
            $reply = make_reply_not_found(
                "Unknown path: /" . join( "/", @path ) );
        }
    }
    elsif ( $path[0] eq "status" ) {
        $reply = _get_status($Slice);
    }
    elsif ( $path[0] eq "reflector" ) {
        if( @path == 2 and $path[1] eq "config" ) {
            $reply = _retrive_all_teps($Slice);
        }
        else {
            $reply = make_reply_not_found(
                "Unknown path: /" . join( "/", @path ) );
        }
    }
    elsif ( $path[0] eq "capfile" ) {
        my ( $cap_file ) = ();
        if ( @path >= 2 ) {
            $cap_file = $path[1];
            unless ( $cap_file =~ /^\d+$/ ) {
                return make_reply_not_found(
                    "Packet capture file ($cap_file) is illegal format.");
            }
        }

        if ( @path == 1 ) {
            $reply = make_reply_not_implemented(
                "Unhandled request method.");
        }
        elsif ( @path == 2 ) {
            $reply = _get_capfile( $Slice, $cap_file );
        }
        else {
            $reply = make_reply_not_found(
                "Unknown path: /" . join( "/", @path ) );
        }
    }
    else {
        $reply
            = make_reply_not_found( "Unknown path: /" . join( "/", @path ) );
    }

    return $reply;
}

1;
