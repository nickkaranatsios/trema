#
# Copyright (C) 2012 NEC Corporation
# Copyright (C) NEC BIGLOBE, Ltd. 2012
# NEC Confidential
#

package Bisco::Message;

use strict;
use warnings;
use Exporter;
use Sys::Syslog;

use vars qw(@ISA @EXPORT);
@ISA = qw(Exporter);

use lib qw( /usr/share/bisco );

use Bisco::Constant;

use constant LOG_EMERG    => [ 255,  'emerg',   'EMERG' ];
use constant LOG_ALERT    => [ 255,  'alert',   'ALERT' ];
use constant LOG_CRIT     => [ 255,  'crit',    'CRIT' ];
use constant LOG_ERROR    => [ 255,  'err',     'ERROR' ];
use constant LOG_WARNING  => [ 128,  'warning', 'WARNING' ];
use constant LOG_NOTICE   => [ 64,   'notice',  'NOTICE' ];
use constant LOG_INFO     => [ 0,    'info',    'INFO' ];
use constant LOG_DEBUG    => [ -1,   'debug',   'DEBUG' ];
push @EXPORT, qw( LOG_EMERG
    LOG_ALERT
    LOG_CRIT
    LOG_ERROR
    LOG_WARNING
    LOG_NOTICE
    LOG_INFO
    LOG_DEBUG );

push @EXPORT, qw(message);

sub message($$) {
    my $level_ref = shift;
    my $message   = shift;

    if ( -t STDOUT && -t STDERR && -t STDIN ) {
        print STDOUT "$message\n";
    }

    $SYSLOG_FACILITY or return;

    my ( $mlv, $slv, $msg ) = @{$level_ref};
    my $subroutine = ( caller(1) )[3];
    $message = "$subroutine: $message" if $subroutine;

    my $command = ( split /\//, $0 )[-1];
    if ( openlog( $command, 'pid,ndelay', $SYSLOG_FACILITY ) ) {
	syslog( $slv, $message );
	closelog();
    }
    else {
	if ( print -t STDERR ) {
	    print STDERR "ERROR: message: openlog failed.\n";
	}
    }
}

1;
