#
# Copyright (C) 2012 NEC Corporation
# Copyright (C) NEC BIGLOBE, Ltd. 2012
# NEC Confidential
#

package Bisco::POST;

=head1 Bisco::POST

=head2 概要

  bisco.psgi を通じて送られてきたHTTPリクエストに応じた関数を呼び出す。
  また、関数から戻されるオブジェクトからHTTPの応答を生成する。

=cut

use strict;
use warnings;
use Exporter;
use bignum;

use vars qw(@ISA @EXPORT);
@ISA = qw(Exporter);

use lib qw( /usr/share/bisco );

use Bisco::Common;
use Bisco::Constant;
use Bisco::Response;
use Bisco::DB::Slice;

sub _register_gs($$$) {
    my $Slice          = shift;
    my $content_string = shift;
    my $dpid           = shift;

    unless ( defined($content_string) ) {
        return make_reply_error(
            "Failed to receive startup-notice from GateSwitch($dpid) (required parameters must be provided). Content is none."
        );
    }

    my $content;
    unless ( ref_from_json_format( $content_string, $content ) ) {
        return make_reply_bad_request(
            "Failed to receive startup-notice from GateSwitch($dpid). Content: $content_string"
        );
    }

    my $address = ${$content}{'controller_address'};
    my ( $ip, $port ) = split( /:/, $address );
    unless ( check_ipv4addr($ip) ) {
        return make_reply_unprocessable_entity(
            "GateSwitch ip-address ($ip) is illegal format.");
    }
    if ($port) {
        unless ( check_port($port) ) {
            return make_reply_unprocessable_entity(
                "GateSwitch accress port ($port) is illegal format.");
        }
    }

    my $protocol = ${$content}{'controller_protocol'};
    unless ( check_protocol($protocol) ) {
        return make_reply_unprocessable_entity(
            "GateSwitch protocol ($protocol) is illegal format.");
    }

    my $tep_addr_port = ${$content}{'address'};
    my ( $tep_addr, $tep_port ) = split( /:/, $tep_addr_port );
    unless ( check_ipv4addr($tep_addr) ) {
        return make_reply_unprocessable_entity(
            "Tunnel end-point address ($tep_addr) is illegal format.");
    }
    unless ( check_port($tep_port) ) {
        return make_reply_unprocessable_entity(
            "Tunnel end-point port ($tep_port) is illegal format.");
    }

    unless ($Slice->agent_exists( $dpid, "$protocol://$address/" )
        and $Slice->tunnel_endpoint_exists( $dpid, $tep_addr, $tep_port ) )
    {
        if (   $Slice->agent_exists($dpid)
            or $Slice->tunnel_endpoint_exists($dpid) )
        {
            if ( $Slice->remove_gs($dpid) < 0 ) {
                return make_reply_error(
                    "Failed to regist GateSwitch ($dpid).");
            }
        }
        if ($Slice->register_gs( $dpid, "$protocol://$address/", $tep_addr,
                $tep_port ) < 0
            )
        {
            return make_reply_error("Failed to regist GateSwitch ($dpid).");
        }
    }

    return make_reply_accepted();
}

sub _create_network($$) {
    my $Slice          = shift;
    my $content_string = shift;
    unless ( defined($content_string) ) {
        return make_reply_error(
            "Failed to create a slice (required parameters must be provided). Content is none."
        );
    }

    my $content;
    unless ( ref_from_json_format( $content_string, $content ) ) {
        return make_reply_bad_request(
            "Failed to create a slice. Cannot interprets json. Content: $content_string"
        );
    }

    my $slice_id = int( ${$content}{'id'} );
    unless ( check_slice_id($slice_id) ) {
        return make_reply_unprocessable_entity(
            "slice id ($slice_id) is illegal format.");
    }
    my $description = ${$content}{'description'};
    unless ( check_text_length($description) ) {
        return make_reply_unprocessable_entity("description is too long.");
    }

    unless ( defined($slice_id) ) {
        $slice_id = int( rand(4294967296) ); # FIXME: assign slice id properly
    }
    unless ( defined($description) ) {
        $description = "";
    }

    my $ret = $Slice->create_slice( $slice_id, $description );
    if ( $ret == Bisco::DB::Slice::DUPLICATED_SLICE ) {
        return make_reply_unprocessable_entity(
            "Failed to create a slice (duplicated slice id $slice_id).");
    }
    elsif ( $ret < 0 ) {
        return make_reply_error("Failed to create a slice ($slice_id).");
    }

    my %created = ();
    $created{'id'}          = $slice_id;
    $created{'description'} = $description;
    $created{'state'}       = $Slice
        ->slice_state_to_string(Bisco::DB::Slice::SLICE_STATE_CONFIRMED);

    return make_reply_accepted_with_json( \%created );
}

sub _create_port($$$) {
    my $Slice          = shift;
    my $content_string = shift;
    my $slice_id       = shift;

    unless ( $Slice->slice_exists($slice_id) ) {
        return make_reply_not_found("slice ($slice_id) is not exists.");
    }

    unless ( defined($content_string) ) {
        return make_reply_error(
            "Failed to add a port (required parameters must be provided). Content is none."
        );
    }

    my $content;
    unless ( ref_from_json_format( $content_string, $content ) ) {
        return make_reply_bad_request(
            "Failed to add a port. Cannot interprets json. Content: $content_string"
        );
    }

    my $id = ${$content}{'id'};
    unless ( check_port_id($id) ) {
        return make_reply_unprocessable_entity(
            "port id ($id) is illegal format.");
    }
    my $dpid = oct( ${$content}{'datapath_id'} );
    unless ( check_dpid($dpid) ) {
        return make_reply_unprocessable_entity(
            "datapath-id ($dpid) is illegal format.");
    }
    my $port_no   = ${$content}{'number'};
    my $port_name = ${$content}{'name'};
    unless ( $port_no or $port_name ) {
        return make_reply_unprocessable_entity(
            "port no or name is required.");
    }
    if ( defined $port_no ) {
        unless ( check_port_no($port_no) ) {
            return make_reply_unprocessable_entity(
                "port no ($port_no) is illegal format.");
        }
    }
    if ($port_name) {
        unless ( check_port_name($port_name) ) {
            return make_reply_unprocessable_entity(
                "port name ($port_name) is illegal format.");
        }
    }
    my $vid = ${$content}{'vid'};
    unless ( check_vlanid($vid) or $vid == 65535 ) {
        return make_reply_unprocessable_entity(
            "vlan id ($vid) is illegal format.");
    }
    my $description = ${$content}{'description'};
    unless ( check_text_length($description) ) {
        return make_reply_unprocessable_entity("description is too long.");
    }

    if ( $id and $Slice->port_id_exists( $slice_id, $id ) ) {
        return make_reply_unprocessable_entity("port id ($id) is exists.");
    }

    if ( $Slice->port_exists( $dpid, $port_no, $port_name, $vid ) ) {
        my $err = "port (datapath_id = $dpid, ";
        $err .= "port_no = $port_no, "     if defined($port_no);
        $err .= "port_name = $port_name, " if defined($port_name);
        $err .= "vid = $vid) is exists.";
        return make_reply_unprocessable_entity($err);
    }

    my $ret = $Slice->add_port( $slice_id, $dpid, $port_no, $port_name, $vid,
        $description, $id );
    if ( $ret < 0 ) {
        return make_reply_error(
            "Failed to add a port to slice (slice id = $slice_id).");
    }

    return make_reply_accepted();
}

sub _create_mac_address($$$$) {
    my $Slice          = shift;
    my $content_string = shift;
    my $slice_id       = shift;
    my $port_id        = shift;

    unless ( $Slice->port_id_exists( $slice_id, $port_id ) ) {
        unless ( $Slice->slice_exists($slice_id) ) {
            return make_reply_not_found("slice ($slice_id) is not exists.");
        }
        return make_reply_not_found(
            "port ($port_id) is not exists in slice ($slice_id).");
    }

    unless ( defined($content_string) ) {
        return make_reply_error(
            "Failed to add a MAC address (required parameters must be provided). Content is none."
        );
    }

    my $content;
    unless ( ref_from_json_format( $content_string, $content ) ) {
        return make_reply_bad_request(
            "Failed to add a MAC address. Cannot interprets json. Content: $content_string"
        );
    }

    my $mac = ${$content}{'address'};
    unless ( check_mac_address($mac) ) {
        return make_reply_unprocessable_entity(
            "MAC address ($mac) is illegal format.");
    }

    if ( $Slice->mac_address_exists( $slice_id, $port_id, $mac ) ) {
        return make_reply_unprocessable_entity(
            "mac address (slice_id = $slice_id, port_id = $port_id, mac address = $mac) is exists."
        );
    }

    my $ret = $Slice->add_mac_address( $slice_id, $port_id, $mac );
    if ( $ret < 0 ) {
        return make_reply_error("Failed to add a MAC address to '$port_id'");
    }

    return make_reply_accepted();
}

push @EXPORT, qw(handle_post_requests);

sub handle_post_requests($$@) {
    my $Slice = shift;
    my $env   = shift;
    my @path  = @_;
    my $reply;

    if ( $path[0] eq "networks" ) {
        my ( $slice_id, $port_id ) = ();
        if ( @path >= 2 ) {
            $slice_id = $path[1];
            unless ( check_slice_id($slice_id) ) {
                return make_reply_unprocessable_entity(
                    "slice id ($slice_id) is illegal format.");
            }
            if ( $Slice->slice_in_busy_state($slice_id) ) {
                return make_reply_busy("Update in progress.");
            }
        }
        if ( @path >= 4 ) {
            $port_id = $path[3];
            unless ( check_port_id($port_id) ) {
                return make_reply_unprocessable_entity(
                    "port id ($port_id) is illegal format.");
            }
        }

        if ( @path == 1 ) {
            my $body = get_request_body($env);
            $reply = _create_network( $Slice, $body );
        }
        elsif ( @path == 2 ) {
            make_reply_method_not_allowed(
                "Method not allowed. /" . join( "/", @path ) );
        }
        elsif ( $path[2] eq "ports" && @path == 3 ) {
            my $body = get_request_body($env);
            $reply = _create_port( $Slice, $body, $slice_id );
        }
        elsif ( $path[2] eq "ports" && @path == 4 ) {
            make_reply_method_not_allowed(
                "Method not allowed. /" . join( "/", @path ) );
        }
        elsif ($path[2] eq "ports"
            && $path[4] eq "mac_addresses"
            && @path == 5 )
        {
            my $body = get_request_body($env);
            $reply
                = _create_mac_address( $Slice, $body, $slice_id, $port_id );
        }
        elsif ($path[2] eq "ports"
            && $path[4] eq "mac_addresses"
            && @path == 6 )
        {
            $reply = make_reply_method_not_allowed(
                "Method not allowed. /" . join( "/", @path ) );
        }
        else {
            $reply = make_reply_not_found(
                "Unknown path: /" . join( "/", @path ) );
        }
    }
    elsif ( $path[0] eq "agents" ) {
        my $dpid;
        if ( @path >= 2 ) {
            $dpid = $path[1];
            unless ( check_dpid($dpid) ) {
                return make_reply_unprocessable_entity(
                    "datapath-id ($dpid) is illegal format.");
            }
        }

        if ( @path == 1 ) {
            make_reply_method_not_allowed(
                "Method not allowed. /" . join( "/", @path ) );
        }
        elsif ( @path == 2 ) {
            my $body = get_request_body($env);
            $reply = _register_gs( $Slice, $body, $dpid );
        }
        else {
            $reply = make_reply_not_found(
                "Unknown path: /" . join( "/", @path ) );
        }
    }
    else {
        $reply
            = make_reply_not_found( "Unknown path: /" . join( "/", @path ) );
    }

    return $reply;
}

1;
