#
# Copyright (C) 2012 NEC Corporation
# Copyright (C) NEC BIGLOBE, Ltd. 2012
# NEC Confidential
#

package Bisco::PUT;

=head1 Bisco::PUT

=head2 概要

  bisco.psgi を通じて送られてきたHTTPリクエストに応じた関数を呼び出す。
  また、関数から戻されるオブジェクトからHTTPの応答を生成する。

=cut

use strict;
use warnings;
use Exporter;
use bignum;

use vars qw(@ISA @EXPORT);
@ISA = qw(Exporter);

use lib qw( /usr/share/bisco );

use Bisco::Common;
use Bisco::Constant;
use Bisco::Response;
use Bisco::DB::Slice;

sub _modify_network($$$) {
    my $Slice          = shift;
    my $content_string = shift;
    my $slice_id       = shift;

    unless ( $Slice->slice_exists($slice_id) ) {
        return make_reply_not_found("slice ($slice_id) is not exists.");
    }

    unless ( defined($content_string) ) {
        return make_reply_error(
            "Failed to modify a slice (required parameters must be provided). Content is none"
        );
    }

    my $content;
    unless ( ref_from_json_format( $content_string, $content ) ) {
        return make_reply_bad_request(
            "Failed to modify a slice. Cannot interprets json. Content: $content_string"
        );
    }

    my $description = ${$content}{'description'};
    unless ( check_text_length($description) ) {
        return make_reply_unprocessable_entity("description is too long.");
    }

    if ( defined($description) ) {
        if ( $Slice->update_slice( $slice_id, $description ) < 0 ) {
            return make_reply_error("Failed to modify a slice.");
        }
    }

    return make_reply_accepted();
}

sub _action_agents($$$) {
    my $Slice          = shift;
    my $content_string = shift;
    my $dpid           = shift;

    unless ( defined($content_string) ) {
        return make_reply_error(
            "Failed to reset a datapath (required parameters must be provided). Content is none."
        );
    }

    my $content;
    unless ( ref_from_json_format( $content_string, $content ) ) {
        return make_reply_bad_request(
            "Failed to action to datapath-id ($dpid). Content: $content_string"
        );
    }

    my $action = ${$content}{'action'};
    unless ( check_allowed_action($action) ) {
        return make_reply_unprocessable_entity(
            "action ($action) is illegal format.");
    }

    my $ret;
    if ( $action eq "reset" ) {
        $ret = $Slice->reset_switch($dpid);
    }
    else {
        return make_reply_method_not_allowed(
            "Failed to $action to the datapath.");
    }

    if ( $ret < 0 ) {
        return make_reply_error("Failed to $action to the datapath.");
    }

    return make_reply_accepted();
}

push @EXPORT, qw(handle_put_requests);

sub handle_put_requests($$@) {
    my $Slice = shift;
    my $env   = shift;
    my @path  = @_;
    my $reply;

    if ( $path[0] eq "networks" ) {
        my $slice_id;
        if ( @path >= 2 ) {
            $slice_id = $path[1];
            unless ( check_slice_id($slice_id) ) {
                return make_reply_not_found(
                    "slice id ($slice_id) is illegal format.");
            }
            if ( $Slice->slice_in_busy_state($slice_id) ) {
                return make_reply_busy("Update in progress.");
            }
        }

        if ( @path == 1 ) {
            make_reply_method_not_allowed(
                "Method not allowed. /" . join( "/", @path ) );
        }
        elsif ( @path == 2 ) {
            my $body = get_request_body($env);
            $reply = _modify_network( $Slice, $body, $slice_id );
        }
        elsif ( $path[2] eq "ports" && @path == 3 ) {
            make_reply_method_not_allowed(
                "Method not allowed. /" . join( "/", @path ) );
        }
        elsif ( $path[2] eq "ports" && @path == 4 ) {
            make_reply_method_not_allowed(
                "Method not allowed. /" . join( "/", @path ) );
        }
        elsif ($path[2] eq "ports"
            && $path[4] eq "mac_addresses"
            && @path == 5 )
        {
            make_reply_method_not_allowed(
                "Method not allowed. /" . join( "/", @path ) );
        }
        elsif ($path[2] eq "ports"
            && $path[4] eq "mac_addresses"
            && @path == 6 )
        {
            make_reply_method_not_allowed(
                "Method not allowed. /" . join( "/", @path ) );
        }
        else {
            $reply = make_reply_not_found(
                "Unknown path: /" . join( "/", @path ) );
        }
    }
    elsif ( $path[0] eq "agents" ) {
        my $dpid;
        if ( @path >= 2 ) {
            $dpid = $path[1];
            unless ( check_dpid($dpid) ) {
                return make_reply_unprocessable_entity(
                    "datapath-id ($dpid) is illegal format.");
            }
        }

        if ( @path == 1 ) {
            make_reply_method_not_allowed(
                "Method not allowed. /" . join( "/", @path ) );
        }
        elsif ( @path == 2 ) {
            my $body = get_request_body($env);
            $reply = _action_agents( $Slice, $body, $dpid );
        }
        else {
            $reply = make_reply_not_found(
                "Unknown path: /" . join( "/", @path ) );
        }
    }
    else {
        $reply
            = make_reply_not_found( "Unknown path: /" . join( "/", @path ) );
    }

    return $reply;
}

1;
