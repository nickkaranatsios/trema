#
# Copyright (C) 2012 NEC Corporation
# Copyright (C) NEC BIGLOBE, Ltd. 2012
# NEC Confidential
#

package Bisco::Response;

=head1 Bisco::Response

=head2 概要

  bisco.psgi を通じて送られてきたHTTPリクエストに応じた関数を呼び出す。
  また、関数から戻されるオブジェクトからHTTPの応答を生成する。

=cut

use strict;
use warnings;

use Plack::Request;

use Error qw(:try);
use JSON;
use bignum;
use vars qw(@ISA @EXPORT);
@ISA = qw(Exporter);

use lib qw( /usr/share/bisco );

use Bisco::Constant;
use Bisco::Message;

sub _make_text_response($@) {
    my $code = shift;

    my $response_body = "";
    foreach (@_) {
        next unless defined $_;
        $response_body .= " $_";
    }
    $response_body =~ s/^\s//;

    my $reply;
    @{$reply}
        = ( $code, [ 'Content-Type' => "text/plain" ], ["$response_body"], );
    return $reply;
}

sub _make_json_response($$) {
    my $code     = shift;
    my $json_ref = shift;

    my $response_body = to_json($json_ref) if $json_ref;
    message( LOG_DEBUG, "reply json: " . $response_body );

    my $reply;
    @{$reply} = (
        $code, [ 'Content-Type' => "application/json" ],
        ["$response_body"],
    );
    return $reply;
}

push @EXPORT, qw(make_reply_ok_with_json);

sub make_reply_ok_with_json($) {
    my $json_ref = shift;
    message( LOG_DEBUG, "200 OK" );
    return _make_json_response( 200, $json_ref );
}

push @EXPORT, qw(make_reply_accepted);

sub make_reply_accepted(;$) {
    my $mes = shift;
    message( LOG_DEBUG, "202 Accepted" );
    message( LOG_DEBUG, $mes ) if $mes;
    return _make_text_response( 202, "Accepted" );
}

push @EXPORT, qw(make_reply_accepted_with_json);

sub make_reply_accepted_with_json($) {
    my $json_ref = shift;
    message( LOG_DEBUG, "202 Accepted" );
    return _make_json_response( 202, $json_ref );
}

push @EXPORT, qw(make_reply_bad_request);

sub make_reply_bad_request($) {
    my $mes = shift;
    message( LOG_NOTICE, "400 Bad Request" );
    message( LOG_NOTICE, $mes );
    return _make_text_response( 400, "Bad Request" );
}

=head3 make_not_found_reply


=item 説明

      404 Not Found 応答を作成する

=item 引数

      無し

=item 戻り値

      [ <response code>, [ 'Content-Type' => <type> ], [<response body>] ]

=item 例外

      なし

=cut

push @EXPORT, qw(make_reply_not_found);

sub make_reply_not_found($) {
    my $mes = shift;
    message( LOG_NOTICE, "404 Not Found" );
    message( LOG_NOTICE, $mes );
    return _make_text_response( 404, "Not Found" );
}

push @EXPORT, qw(make_reply_method_not_allowed);

sub make_reply_method_not_allowed($) {
    my $mes = shift;
    message( LOG_NOTICE, "Method Not Allowed" );
    message( LOG_NOTICE, $mes );
    return _make_text_response( 405, "Method Not Allowed" );
}

push @EXPORT, qw(make_reply_unprocessable_entity);

sub make_reply_unprocessable_entity($) {
    my $mes = shift;
    message( LOG_NOTICE, "Unprocessable Entity" );
    message( LOG_NOTICE, $mes );
    return _make_text_response( 422, "Unprocessable Entity" );
}

push @EXPORT, qw(make_reply_busy);

sub make_reply_busy($) {
    my $mes = shift;
    message( LOG_NOTICE, "Busy Here" );
    message( LOG_NOTICE, $mes );
    return _make_text_response( 486, "Busy Here" );
}

push @EXPORT, qw(make_reply_error);

sub make_reply_error($) {
    my $mes = shift;
    message( LOG_ERROR, "Internal Server Error" );
    message( LOG_ERROR, $mes );
    return _make_text_response( 500, "Internal Server Error" );
}

push @EXPORT, qw(make_reply_not_implemented);

sub make_reply_not_implemented(;$) {
    my $mes = shift;
    message( LOG_ERROR, "Not Implemented" );
    message( LOG_ERROR, $mes );
    return _make_text_response( 501, "Not Implemented" );
}

push @EXPORT, qw(make_error_reply);

sub make_error_reply($;$) {
    my $status = shift;
    my $text   = shift;

    if ( $status == 400 ) {
        return make_reply_bad_request( $text );
    }
    elsif ( $status == 404 ) {
        return make_reply_not_found( $text );
    }
    elsif ( $status == 405 ) {
        return make_reply_method_not_allowed( $text );
    }
    elsif ( $status == 422 ) {
        return make_reply_unprocessable_entity( $text );
    }
    elsif ( $status == 486 ) {
        return make_reply_busy( $text );
    }
    elsif ( $status == 500 ) {
        return make_reply_error( $text );
    }
    elsif ( $status == 501 ) {
        return make_reply_not_implemented( $text );
    }
    else {
        return make_reply_error( "Unknown error." );
    }
}

push @EXPORT, qw(get_request_body);

sub get_request_body($) {
    my $env = shift;
    my $req = Plack::Request->new($env);
    return $req->content();
}

push @EXPORT, qw(ref_from_json_format);

sub ref_from_json_format($\$) {
    my $json = shift;
    my $ref  = shift;

    try {
        ${$ref} = from_json($json);
    }
    catch Error with {
        my $e = shift;
        message( LOG_NOTICE, $e->text );
    };

    return $ref ? TRUE : FALSE;
}

1;
