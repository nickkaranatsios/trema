/*
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */

#include <assert.h>
#include "trema.h"
#include "http_client.h"


void handle_request_completed( int status, int code, const http_content *content, void *user_data ) {
  UNUSED( user_data );

  info( "Request completed ( status = %d, code = %d, content = [ content-type = \"%s\", body = \"%s\" ] )",
        status, code,
        ( content != NULL ? content->content_type : "(null)" ),
        ( ( content != NULL && content->body != NULL ) ? content->body->data : "(null)" ) );

  stop_trema();
}


static void
timed_out( void *user_data ) {
  UNUSED( user_data );

  error( "timed out." );

  stop_trema();
}


int
main( int argc, char *argv[] ) {
  init_trema( &argc, &argv );
  init_http_client();

  add_periodic_event_callback( 5, timed_out, NULL );
  uint8_t method = HTTP_METHOD_GET;
  const char *uri = "http://172.22.138.34/jenkins/api/json";
  http_content content;
  snprintf( content.content_type, sizeof( content.content_type ) - 1, "application/json" );
  content.body = NULL;
  // size_t content_length = strlen( json_str ) + 1;
  // content.body = alloc_buffer_with_length( content_length );
  // char *p = append_back_buffer( content.body, content_length );
  // strcpy( p, json_str );
  do_http_request( method, uri, ( content.body != NULL ? &content : NULL ), handle_request_completed, NULL );

  start_trema();

  finalize_http_client();

  return 0;
}
