/*
 * Author: SUGYO Kazushi
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include <signal.h>
#include <strings.h>
#include <mysql/mysql.h>
#include <nx.h>
#include "common_wrapper.h"
#undef free
#include "unittest.h"

#include "db.h"
#include "transaction_manager.h"


extern char hostname[];
extern MYSQL *db;
extern bool initialized;


typedef struct {
  int n_transactions;
  bool failed;
} ongoing_transactions;

typedef struct {
  uint8_t table_id;
  uint16_t priority;
  ongoing_transactions *transactions;
  char matches_string[ 256 ];
} flow_entry_to_be_installed;


void default_flow_entry_installed( uint64_t datapath_id, const buffer *message, void *user_data );
void default_flow_entry_not_installed( uint64_t datapath_id, const buffer *message, void *user_data );
void install_default_flow_entry( uint64_t datapath_id, uint8_t table_id, uint16_t priority, const nx_matches *matches,
                                 ongoing_transactions *transactions );
void nx_flow_mod_table_id_succeeded( uint64_t datapath_id, const buffer *message, void *user_data );
void nx_flow_mod_table_id_failed( uint64_t datapath_id, const buffer *message, void *user_data );
void nx_set_flow_format_succeeded( uint64_t datapath_id, const buffer *message, void *user_data );
void nx_set_flow_format_failed( uint64_t datapath_id, const buffer *message, void *user_data );
void handle_switch_ready( uint64_t datapath_id, void *user_data );
void handle_switch_disconnected( uint64_t datapath_id, void *user_data );
void handle_features_reply( uint64_t datapath_id, uint32_t transaction_id, uint32_t n_buffers,
                            uint8_t n_tables, uint32_t capabilities, uint32_t actions,
                            const list_element *phy_ports, void *user_data );
void handle_port_status( uint64_t datapath_id, uint32_t transaction_id, uint8_t reason,
                         struct ofp_phy_port port, void *user_data );
void handle_list_switches_reply( const list_element *switches, void *user_data );
void do_send_list_switches_request( void );
void usage( void );
void reset_getopt( void );
void parse_options( int *argc, char **argv[], db_config *config );
void finalize_vnet_manager( void );
void do_exit( void );
void stop_vnet_manager( void );
void set_exit_handler( void );
void do_start( void );
void init_vnet_manager( int *argc, char **argv[] );
int bisco_main( int argc, char *argv[] );


static char *mock_gethostname_name = NULL;


pid_t
mock_getpid( void ) {
  return ( pid_t ) mock();
}


int
mock_printf(const char *fmt, ...) {
  check_expected( fmt );
  char *str;
  va_list ap;
  va_start( ap, fmt );
  vasprintf( &str, fmt, ap );
  va_end(ap);
  check_expected( str );
  free( str );

  return ( int ) mock();
}


int
mock_gethostname( char *name, size_t len ) {
  check_expected( name );
  check_expected( len );

  if ( name != NULL && len > 0 && mock_gethostname_name != NULL ) {
    strncpy( name, mock_gethostname_name, len - 1 );
    name[ len - 1 ] = '\0';
  }

  return ( int ) mock();
}


int
mock_sigaction(int signum, const struct sigaction *act,
               struct sigaction *oldact) {
  check_expected( signum );
  check_expected( act );
  check_expected( oldact );

  if ( act != NULL ) {
    check_expected( act->sa_handler );
    check_expected( &act->sa_mask );
    check_expected( act->sa_flags );
    check_expected( act->sa_restorer );
  }

  return ( int ) mock();
}


bool
mock_set_switch_ready_handler( switch_ready_handler callback, void *user_data ) {
  check_expected( callback );
  check_expected( user_data );

  return ( bool ) mock();
}


bool
mock_set_switch_disconnected_handler( switch_disconnected_handler callback, void *user_data ) {
  check_expected( callback );
  check_expected( user_data );

  return ( bool ) mock();
}


bool
mock_set_features_reply_handler( features_reply_handler callback, void *user_data ) {
  check_expected( callback );
  check_expected( user_data );

  return ( bool ) mock();
}


bool
mock_set_port_status_handler( port_status_handler callback, void *user_data ) {
  check_expected( callback );
  check_expected( user_data );

  return ( bool ) mock();
}


bool
mock_set_list_switches_reply_handler( list_switches_reply_handler callback ) {
  check_expected( callback );

  return ( bool ) mock();
}


bool
mock_set_external_callback( external_callback_t callback ) {
  check_expected( callback );

  return ( bool ) mock();
}


bool
mock_send_openflow_message( const uint64_t datapath_id, buffer *message ) {
  check_expected( datapath_id );
  check_expected( message );

  return ( bool ) mock();
}


bool
mock_send_list_switches_request( void *user_data ) {
  check_expected( user_data );

  return ( bool ) mock();
}


uint32_t
mock_get_transaction_id( void ) {
  return ( uint32_t ) mock();
}


uint64_t
mock_get_cookie( void ) {
  return ( uint64_t ) mock();
}


void
mock_init_trema( int *argc, char ***argv ) {
  check_expected( argc );
  check_expected( argv );

  ( void ) mock();
}


void
mock_start_trema( void ) {
  ( void ) mock();
}


void
mock_stop_trema( void ) {
  ( void ) mock();
}


const char *
mock_get_executable_name( void ) {
  return ( const char * ) ( intptr_t ) mock();
}


void
mock_free_buffer( buffer *buf ) {
  check_expected( buf );

  ( void ) mock();
}


buffer *
mock_create_features_request( const uint32_t transaction_id ) {
  check_expected( transaction_id );

  return ( buffer * ) ( intptr_t ) mock();
}


buffer *
mock_create_nx_set_flow_format( const uint32_t transaction_id, const uint32_t format ) {
  check_expected( transaction_id );
  check_expected( format );

  return ( buffer * ) ( intptr_t ) mock();
}


buffer *
mock_create_nx_flow_mod( const uint32_t transaction_id, const uint64_t cookie, const uint16_t command,
                                 const uint8_t table_id, const uint16_t idle_timeout, const uint16_t hard_timeout,
                                 const uint16_t priority, const uint32_t buffer_id,
                                 const uint16_t out_port, const uint16_t flags,
                                 const nx_matches *matches, const openflow_actions *actions ) {
  check_expected( transaction_id );
  check_expected( cookie );
  check_expected( command );
  check_expected( table_id );
  check_expected( idle_timeout );
  check_expected( hard_timeout );
  check_expected( priority );
  check_expected( buffer_id );
  check_expected( out_port );
  check_expected( flags );
  check_expected( matches );
  check_expected( actions );
  char matches_string[ 256 ];
  if ( matches != NULL ) {
    nx_matches_to_string( matches, matches_string, sizeof( matches_string ) );
    check_expected( matches_string );
  }

  return ( buffer * ) ( intptr_t ) mock();
}


buffer *
mock_create_nx_flow_mod_table_id( const uint32_t transaction_id, const uint8_t set ) {
  check_expected( transaction_id );
  check_expected( set );

  return ( buffer * ) ( intptr_t ) mock();
}


static MYSQL *mock_init_db_db = NULL;

bool
mock_init_db( MYSQL **db, db_config config ) {
  check_expected( db );
  check_expected ( config.host );
  check_expected ( config.port );
  check_expected ( config.username );
  check_expected ( config.password );
  check_expected ( config.db_name );

  if ( db != NULL ) {
    *db = mock_init_db_db;
  }

  return ( bool ) mock();
}


bool
mock_finalize_db( MYSQL *db ) {
  check_expected( db );

  return ( bool ) mock();
}


bool
mock_init_http_client() {
  return ( bool ) mock();
}


bool
mock_finalize_http_client() {
  return ( bool ) mock();
}


bool
mock_init_overlay_network_manager( MYSQL *db ) {
  check_expected( db );

  return ( bool ) mock();
}


bool
mock_finalize_overlay_network_manager() {
  return ( bool ) mock();
}


bool
mock_init_slice( MYSQL *db ) {
  check_expected( db );

  return ( bool ) mock();
}


bool
mock_finalize_slice() {
  return ( bool ) mock();
}


bool
mock_add_switch( uint64_t datapath_id, const char *controller_host, pid_t controller_pid ) {
  check_expected( datapath_id );
  check_expected( controller_host );
  check_expected( controller_pid );

  return ( bool ) mock();
}


bool
mock_delete_switch( uint64_t datapath_id ) {
  check_expected( datapath_id );

  return ( bool ) mock();
}


bool
mock_delete_switch_by_host_pid( const char* controller_host, pid_t controller_pid ) {
  check_expected( controller_host );
  check_expected( controller_pid );

  return ( bool ) mock();
}


bool
mock_switch_on_duty( uint64_t datapath_id, const char *controller_host, pid_t controller_pid ) {
  check_expected( datapath_id );
  check_expected( controller_host );
  check_expected( controller_pid );

  return ( bool ) mock();
}


bool
mock_add_port( uint64_t datapath_id, uint16_t port_no, const char *name ) {
  check_expected( datapath_id );
  check_expected( port_no );
  check_expected( name );

  return ( bool ) mock();
}


bool
mock_delete_port( uint64_t datapath_id, uint16_t port_no, const char *name ) {
  check_expected( datapath_id );
  check_expected( port_no );
  check_expected( name );

  return ( bool ) mock();
}


bool
mock_init_switch( MYSQL *db ) {
  check_expected( db );

  return ( bool ) mock();
}


bool
mock_finalize_switch() {
  return ( bool ) mock();
}


void *save_mock_execute_transaction_succeeded_user_data = NULL;
void *save_mock_execute_transaction_failed_user_data = NULL;

bool
mock_execute_transaction( uint64_t datapath_id, const buffer *message,
                          succeeded_handler succeeded_callback, void *succeeded_user_data,
                          failed_handler failed_callback, void *failed_user_data ) {
  check_expected( datapath_id );
  check_expected( message );
  check_expected( succeeded_callback );
  check_expected( succeeded_user_data );
  check_expected( failed_callback );
  check_expected( failed_user_data );

  if ( save_mock_execute_transaction_succeeded_user_data != NULL ) {
    if ( save_mock_execute_transaction_succeeded_user_data == save_mock_execute_transaction_failed_user_data ) {
      save_mock_execute_transaction_failed_user_data = NULL;
    }
    xfree( save_mock_execute_transaction_succeeded_user_data );
    save_mock_execute_transaction_succeeded_user_data = NULL;
  }
  if ( save_mock_execute_transaction_failed_user_data != NULL ) {
    xfree( save_mock_execute_transaction_failed_user_data );
    save_mock_execute_transaction_failed_user_data = NULL;
  }
  save_mock_execute_transaction_succeeded_user_data = succeeded_user_data;
  save_mock_execute_transaction_failed_user_data = failed_user_data;

  return ( bool ) mock();
}


bool
mock_init_transaction_manager() {
  return ( bool ) mock();
}


bool
mock_finalize_transaction_manager() {
  return ( bool ) mock();
}


static char **
alloc_argv( int argc, const char *const_argv[] ) {
  char **argv = xcalloc( sizeof( char * ), ( size_t ) argc + 1 );
  int i;
  for ( i = 0; i < argc; ++i ) {
    argv[ i ] = xstrdup( const_argv[ i ] );
  }

  return argv;
}


static char **
copy_argv( int argc, char **argv ) {
  char **copy = xcalloc( sizeof( char * ), ( size_t ) argc + 1 );
  memcpy( copy, argv, sizeof( char * ) * ( ( size_t ) argc + 1 ) );
  return copy;
}


static void
free_argv( int argc, char **argv ) {
  int i;
  for ( i = 0; i < argc; ++i ) {
    xfree( argv[ i ] );
  }
  xfree( argv );
}


/******************************************************************************
 * Test functions.
 ******************************************************************************/

static void
test_bisco_main_succeeds() {
  mock_gethostname_name = xstrdup( "dummy_hostname" );

  const char *const_argv[] = { "bisco", NULL };
  int argc = sizeof( const_argv ) / sizeof( const_argv[ 0 ] ) - 1;
  char **argv = alloc_argv( argc, const_argv );

  mock_init_db_db = ( MYSQL * ) 0xa1;

  expect_not_value( mock_gethostname, name, NULL );
  expect_value( mock_gethostname, len, HOST_NAME_MAX );
  will_return( mock_gethostname, 0 );

  expect_not_value( mock_init_trema, argc, NULL );
  expect_not_value( mock_init_trema, argv, NULL );
  will_return( mock_init_trema, 0 );

  expect_not_value( mock_init_db, db, NULL );
  expect_string( mock_init_db, config.host, "127.0.0.1" );
  expect_value( mock_init_db, config.port, MYSQL_PORT );
  expect_string( mock_init_db, config.username, "root" );
  expect_string( mock_init_db, config.password, "password" );
  expect_string( mock_init_db, config.db_name, "vnet" );
  will_return( mock_init_db, true );

  expect_value( mock_init_slice, db, mock_init_db_db );
  will_return( mock_init_slice, true );

  expect_value( mock_init_switch, db, mock_init_db_db );
  will_return( mock_init_switch, true );

  will_return( mock_init_transaction_manager, true );

  will_return( mock_init_http_client, true );

  expect_value( mock_init_overlay_network_manager, db, mock_init_db_db );
  will_return( mock_init_overlay_network_manager, true );

  expect_value( mock_sigaction, signum, SIGINT );
  expect_value( mock_sigaction, signum, SIGTERM );
  expect_not_value_count( mock_sigaction, act, NULL, 2 );
  expect_value_count( mock_sigaction, act->sa_handler, stop_vnet_manager, 2 );
  sigset_t emptyset;
  sigemptyset( &emptyset );
  expect_memory_count( mock_sigaction, &act->sa_mask, &emptyset, sizeof( emptyset ), 2 );
  expect_value_count( mock_sigaction, act->sa_flags, 0, 2 );
  expect_value_count( mock_sigaction, act->sa_restorer, NULL, 2 );
  expect_value_count( mock_sigaction, oldact, NULL, 2 );
  will_return_count( mock_sigaction, 0, 2 );

  expect_value( mock_set_list_switches_reply_handler, callback, handle_list_switches_reply );
  will_return( mock_set_list_switches_reply_handler, true );

  expect_value( mock_set_switch_ready_handler, callback, handle_switch_ready );
  expect_value( mock_set_switch_ready_handler, user_data, NULL );
  will_return( mock_set_switch_ready_handler, true );

  expect_value( mock_set_switch_disconnected_handler, callback, handle_switch_disconnected );
  expect_value( mock_set_switch_disconnected_handler, user_data, NULL );
  will_return( mock_set_switch_disconnected_handler, true );

  expect_value( mock_set_features_reply_handler, callback, handle_features_reply );
  expect_value( mock_set_features_reply_handler, user_data, NULL );
  will_return( mock_set_features_reply_handler, true );

  expect_value( mock_set_port_status_handler, callback, handle_port_status );
  expect_value( mock_set_port_status_handler, user_data, NULL );
  will_return( mock_set_port_status_handler, true );

  expect_value( mock_set_external_callback, callback, do_start );
  will_return( mock_set_external_callback, true );

  will_return( mock_start_trema, 0 );

  will_return( mock_finalize_transaction_manager, true );

  will_return( mock_finalize_overlay_network_manager, true );

  will_return( mock_getpid, 1 );

  will_return( mock_finalize_http_client, true );

  expect_string( mock_delete_switch_by_host_pid, controller_host,  mock_gethostname_name );
  expect_not_value( mock_delete_switch_by_host_pid, controller_pid,  0 );
  will_return( mock_delete_switch_by_host_pid, true );

  will_return( mock_finalize_switch, true );

  will_return( mock_finalize_slice, true );

  expect_value( mock_finalize_db, db,  mock_init_db_db );
  will_return( mock_finalize_db, true );

  assert_false( initialized );
  assert_true( bisco_main( argc, argv ) == 0 );
  assert_false( initialized );

  xfree( mock_gethostname_name );
  free_argv( argc, argv );
}


static void
test_init_and_finalize_vnet_manager_succeeds() {
  mock_gethostname_name = xstrdup( "hostname" );

  const char *const_argv[] = { "bisco",
                               "-b", "10.0.0.1",
                               "-p", "9999",
                               "-u", "mysql",
                               "-c", "mysql_password",
                               "-m", "vnet_test",
                               NULL };
  int argc = sizeof( const_argv ) / sizeof( const_argv[ 0 ] ) - 1;
  char **argv = alloc_argv( argc, const_argv );
  int argc_backup = argc;
  char **argv_backup = copy_argv( argc, argv );

  mock_init_db_db = ( MYSQL * ) 0xb1;

  expect_not_value( mock_gethostname, name, NULL );
  expect_value( mock_gethostname, len, HOST_NAME_MAX );
  will_return( mock_gethostname, 0 );

  expect_not_value( mock_init_db, db, NULL );
  expect_string( mock_init_db, config.host, "10.0.0.1" );
  expect_value( mock_init_db, config.port, 9999 );
  expect_string( mock_init_db, config.username, "mysql" );
  expect_string( mock_init_db, config.password, "mysql_password" );
  expect_string( mock_init_db, config.db_name, "vnet_test" );
  will_return( mock_init_db, true );

  expect_value( mock_init_slice, db, mock_init_db_db );
  will_return( mock_init_slice, true );

  expect_value( mock_init_switch, db, mock_init_db_db );
  will_return( mock_init_switch, true );

  will_return( mock_init_transaction_manager, true );

  will_return( mock_init_http_client, true );

  expect_value( mock_init_overlay_network_manager, db, mock_init_db_db );
  will_return( mock_init_overlay_network_manager, true );

  expect_value( mock_sigaction, signum, SIGINT );
  expect_value( mock_sigaction, signum, SIGTERM );
  expect_not_value_count( mock_sigaction, act, NULL, 2 );
  expect_value_count( mock_sigaction, act->sa_handler, stop_vnet_manager, 2 );
  sigset_t emptyset;
  sigemptyset( &emptyset );
  expect_memory_count( mock_sigaction, &act->sa_mask, &emptyset, sizeof( emptyset ), 2 );
  expect_value_count( mock_sigaction, act->sa_flags, 0, 2 );
  expect_value_count( mock_sigaction, act->sa_restorer, NULL, 2 );
  expect_value_count( mock_sigaction, oldact, NULL, 2 );
  will_return_count( mock_sigaction, 0, 2 );

  expect_value( mock_set_list_switches_reply_handler, callback, handle_list_switches_reply );
  will_return( mock_set_list_switches_reply_handler, true );

  expect_value( mock_set_switch_ready_handler, callback, handle_switch_ready );
  expect_value( mock_set_switch_ready_handler, user_data, NULL );
  will_return( mock_set_switch_ready_handler, true );

  expect_value( mock_set_switch_disconnected_handler, callback, handle_switch_disconnected );
  expect_value( mock_set_switch_disconnected_handler, user_data, NULL );
  will_return( mock_set_switch_disconnected_handler, true );

  expect_value( mock_set_features_reply_handler, callback, handle_features_reply );
  expect_value( mock_set_features_reply_handler, user_data, NULL );
  will_return( mock_set_features_reply_handler, true );

  expect_value( mock_set_port_status_handler, callback, handle_port_status );
  expect_value( mock_set_port_status_handler, user_data, NULL );
  will_return( mock_set_port_status_handler, true );

  expect_value( mock_set_external_callback, callback, do_start );
  will_return( mock_set_external_callback, true );

  will_return( mock_finalize_transaction_manager, true );

  will_return( mock_finalize_overlay_network_manager, true );

  will_return( mock_getpid, 1 );

  will_return( mock_finalize_http_client, true );

  expect_string( mock_delete_switch_by_host_pid, controller_host,  mock_gethostname_name );
  expect_not_value( mock_delete_switch_by_host_pid, controller_pid,  0 );
  will_return( mock_delete_switch_by_host_pid, true );

  will_return( mock_finalize_switch, true );

  will_return( mock_finalize_slice, true );

  expect_value( mock_finalize_db, db,  mock_init_db_db );
  will_return( mock_finalize_db, true );

  assert_true( db == NULL );
  assert_false( initialized );
  init_vnet_manager( &argc, &argv );

  assert_string_equal( hostname, mock_gethostname_name );
  assert_true( db == mock_init_db_db );
  assert_true( initialized );
  assert_true( argc == 1 );
  assert_string_equal( argv[ 0 ], "bisco" );
  assert_true( argv[ 1 ] == NULL );

  finalize_vnet_manager();
  assert_true( db == NULL );
  assert_false( initialized );

  xfree( mock_gethostname_name );
  free_argv( argc_backup, argv_backup );
  xfree( argv );
}


static void
test_parse_options_succeeds() {
  const char *const_argv[] = { "parse_test",
                               "-b", "192.168.0.1",
                               "-p", "5963",
                               "-u", "mysql_username",
                               "-c", "mysql_password",
                               "-m", "vnet_db",
                               NULL };
  int argc = sizeof( const_argv ) / sizeof( const_argv[ 0 ] ) - 1;
  char **argv = alloc_argv( argc, const_argv );
  int argc_backup = argc;
  char **argv_backup = copy_argv( argc, argv );

  db_config config;
  memset( &config, 0, sizeof( config ) );

  parse_options( &argc, &argv, &config );
  assert_string_equal( config.host, "192.168.0.1" );
  assert_int_equal( config.port, 5963 );
  assert_string_equal( config.username, "mysql_username" );
  assert_string_equal( config.password, "mysql_password" );
  assert_string_equal( config.db_name, "vnet_db" );
  assert_true( argc == 1 );
  assert_string_equal( argv[ 0 ], "parse_test" );
  assert_true( argv[ 1 ] == NULL );

  free_argv( argc_backup, argv_backup );
  xfree( argv );
}


static void
test_usage_succeeds() {
  will_return( mock_get_executable_name, "test_usage" );

  expect_not_value( mock_printf, fmt, NULL );
  expect_string( mock_printf, str,
                 "Usage: test_usage [OPTION]...\n"
                 "\n"
                 "  -b, --db_host=HOST_NAME     database host\n"
                 "  -p, --db_port=PORT          database port\n"
                 "  -u, --db_username=USERNAME  database username\n"
                 "  -c, --db_password=PASSWORD  database password\n"
                 "  -m, --db_name=NAME          database name\n"
                 "  -n, --name=SERVICE_NAME     service name\n"
                 "  -d, --daemonize             run in the background\n"
                 "  -l, --logging_level=LEVEL   set logging level\n"
                 "  -g, --syslog                output log messages to syslog\n"
                 "  -h, --help                  display this help and exit\n" );
  will_return( mock_printf, 0 );

  usage();
}


static void
test_set_exit_handler_succeeds() {
  expect_value( mock_sigaction, signum, SIGINT );
  expect_value( mock_sigaction, signum, SIGTERM );
  expect_not_value_count( mock_sigaction, act, NULL, 2 );
  expect_value_count( mock_sigaction, act->sa_handler, stop_vnet_manager, 2 );
  sigset_t emptyset;
  sigemptyset( &emptyset );
  expect_memory_count( mock_sigaction, &act->sa_mask, &emptyset, sizeof( emptyset ), 2 );
  expect_value_count( mock_sigaction, act->sa_flags, 0, 2 );
  expect_value_count( mock_sigaction, act->sa_restorer, NULL, 2 );
  expect_value_count( mock_sigaction, oldact, NULL, 2 );
  will_return_count( mock_sigaction, 0, 2 );

  set_exit_handler();
}


static void
test_do_start_succeeds() {
  will_return( mock_getpid, 1 );

  expect_value( mock_send_list_switches_request, user_data, NULL );
  will_return( mock_send_list_switches_request, true );

  do_start();
}


static void
test_stop_vnet_manager_succeeds() {
  expect_value( mock_set_external_callback, callback, do_exit );
  will_return( mock_set_external_callback, true );

  stop_vnet_manager();
}


static void
test_do_exit_succeeds() {
  mock_init_db_db = ( MYSQL * ) 0xa1;

  strcpy( hostname, "test_do_exit_hostname" );
  db = mock_init_db_db;
  initialized = true;

  will_return( mock_finalize_transaction_manager, true );

  will_return( mock_finalize_overlay_network_manager, true );

  will_return_count( mock_getpid, 1, 2 );

  will_return( mock_finalize_http_client, true );

  expect_string( mock_delete_switch_by_host_pid, controller_host,  "test_do_exit_hostname" );
  expect_not_value( mock_delete_switch_by_host_pid, controller_pid,  0 );
  will_return( mock_delete_switch_by_host_pid, true );

  will_return( mock_finalize_switch, true );

  will_return( mock_finalize_slice, true );

  expect_value( mock_finalize_db, db,  mock_init_db_db );
  will_return( mock_finalize_db, true );

  will_return( mock_stop_trema, 0 );

  do_exit();
}


static void
test_do_send_list_switches_request_succeeds() {
  expect_value( mock_send_list_switches_request, user_data, NULL );
  will_return( mock_send_list_switches_request, true );

  do_send_list_switches_request();
}


static void
test_handle_list_switches_reply_succeeds() {
  strcpy( hostname, "hostname" );

  list_element *switches;
  create_list( &switches );
  uint64_t datapath_id1 = 1;
  uint64_t datapath_id2 = 2;
  append_to_tail( &switches, &datapath_id1 );
  append_to_tail( &switches, &datapath_id2 );
  void *user_data = ( void *) 0xa1;

  will_return( mock_getpid, 1 );

  expect_value_count( mock_switch_on_duty, datapath_id, datapath_id1, 1 );
  expect_value_count( mock_switch_on_duty, datapath_id, datapath_id2, 1 );
  expect_string_count( mock_switch_on_duty, controller_host, "hostname", 2 );
  expect_value_count( mock_switch_on_duty, controller_pid, 1, 2 );
  will_return_count( mock_switch_on_duty, true, 2 );

  handle_list_switches_reply( switches, user_data );

  delete_list( switches );
}


static void
test_handle_add_port_status_succeeds() {
  uint64_t datapath_id = 1;
  uint32_t transaction_id = 2;
  uint8_t reason = OFPPR_ADD;
  struct ofp_phy_port port;
  memset( &port, 0, sizeof( port ) );
  port.port_no = 3;
  strcpy( port.name, "port3" );
  void *user_data = ( void * ) 0x4;

  expect_value( mock_add_port, datapath_id, datapath_id );
  expect_value( mock_add_port, port_no, port.port_no );
  expect_string( mock_add_port, name, port.name );
  will_return( mock_add_port, true );

  handle_port_status( datapath_id, transaction_id, reason, port, user_data );
}


static void
test_handle_modify_port_status_succeeds() {
  uint64_t datapath_id = 1;
  uint32_t transaction_id = 2;
  uint8_t reason = OFPPR_MODIFY;
  struct ofp_phy_port port;
  memset( &port, 0, sizeof( port ) );
  port.port_no = 3;
  strcpy( port.name, "port3" );
  void *user_data = ( void * ) 0x4;

  expect_value( mock_add_port, datapath_id, datapath_id );
  expect_value( mock_add_port, port_no, port.port_no );
  expect_string( mock_add_port, name, port.name );
  will_return( mock_add_port, true );

  handle_port_status( datapath_id, transaction_id, reason, port, user_data );
}


static void
test_handle_delete_port_status_succeeds() {
  uint64_t datapath_id = 1;
  uint32_t transaction_id = 2;
  uint8_t reason = OFPPR_DELETE;
  struct ofp_phy_port port;
  memset( &port, 0, sizeof( port ) );
  port.port_no = 3;
  strcpy( port.name, "port3" );
  void *user_data = ( void * ) 0x4;

  expect_value( mock_delete_port, datapath_id, datapath_id );
  expect_value( mock_delete_port, port_no, port.port_no );
  expect_string( mock_delete_port, name, port.name );
  will_return( mock_delete_port, true );

  handle_port_status( datapath_id, transaction_id, reason, port, user_data );
}


static void
test_handle_features_reply_succeeds() {
  strcpy( hostname, "hostname" );

  uint64_t datapath_id = 1;
  uint32_t transaction_id = 2;
  uint32_t n_buffers = 3;
  uint8_t n_tables = 4;
  uint32_t capabilities = 0;
  uint32_t actions = 0;
  list_element *phy_ports;
  create_list( &phy_ports );
  struct ofp_phy_port port;
  memset( &port, 0, sizeof( port ) );
  port.port_no = 1;
  strcpy( port.name, "port1" );
  append_to_tail( &phy_ports, &port );
  void *user_data = ( void * ) 0x1;

  will_return( mock_getpid, 1 );

  expect_value( mock_add_switch, datapath_id, datapath_id );
  expect_string( mock_add_switch, controller_host, "hostname" );
  expect_value( mock_add_switch, controller_pid, 1 );
  will_return( mock_add_switch, true );

  expect_value( mock_add_port, datapath_id, datapath_id );
  expect_value( mock_add_port, port_no, port.port_no );
  expect_string( mock_add_port, name, port.name );
  will_return( mock_add_port, true );

  handle_features_reply( datapath_id, transaction_id, n_buffers, n_tables, capabilities, actions, phy_ports, user_data );

  delete_list( phy_ports );
}


static void
test_handle_switch_ready_succeeds() {
  uint64_t datapath_id = 1;
  void *user_data = ( void * ) 0x1;
  buffer *buf = ( void * ) 0x2;

  will_return( mock_get_transaction_id, 1 );

  expect_value( mock_create_nx_set_flow_format, transaction_id, 1 );
  expect_value( mock_create_nx_set_flow_format, format, NXFF_NXM );
  will_return( mock_create_nx_set_flow_format, buf );

  expect_value( mock_execute_transaction, datapath_id, datapath_id );
  expect_value( mock_execute_transaction, message, buf );
  expect_value( mock_execute_transaction, succeeded_callback, nx_set_flow_format_succeeded );
  expect_value( mock_execute_transaction, succeeded_user_data, NULL );
  expect_value( mock_execute_transaction, failed_callback, nx_set_flow_format_failed );
  expect_value( mock_execute_transaction, failed_user_data, NULL );
  will_return( mock_execute_transaction, true );

  expect_value( mock_free_buffer, buf, buf );
  will_return( mock_free_buffer, 0 );

  handle_switch_ready( datapath_id, user_data );
}


static void
test_handle_switch_disconnected_succeeds() {
  uint64_t datapath_id = 1;
  void *user_data = ( void * ) 0x1;

  expect_value( mock_delete_switch, datapath_id, datapath_id );
  will_return( mock_delete_switch, true );

  handle_switch_disconnected( datapath_id, user_data );
}


static void
test_default_flow_entry_installed_succeeds() {
  uint64_t datapath_id = 1;
  buffer *message = NULL;
  flow_entry_to_be_installed *entry = xmalloc( sizeof( *entry ) );
  memset( entry, 0, sizeof( *entry ) );
  entry->transactions = xmalloc( sizeof( *entry->transactions ) );
  memset( entry->transactions, 0, sizeof( *entry->transactions ) );
  entry->transactions->failed = false;

  will_return( mock_get_transaction_id, 1 );

  buffer *buf = ( buffer * ) 0xa1;
  expect_value( mock_create_features_request, transaction_id, 1 );
  will_return( mock_create_features_request, buf );

  expect_value( mock_send_openflow_message, datapath_id, datapath_id );
  expect_value( mock_send_openflow_message, message, buf );
  will_return( mock_send_openflow_message, true );

  expect_value( mock_free_buffer, buf, buf );
  will_return( mock_free_buffer, 0 );

  default_flow_entry_installed( datapath_id, message, entry );
}


static void
test_default_flow_entry_not_installed_succeeds() {
  uint64_t datapath_id = 1;
  buffer *message = alloc_buffer();
  void *p = append_back_buffer( message, 1 );
  memset( p, 0, 1 );
  flow_entry_to_be_installed *entry = xmalloc( sizeof( *entry ) );
  memset( entry, 0, sizeof( *entry ) );
  ongoing_transactions *transactions = xmalloc( sizeof( *entry->transactions ) );
  entry->transactions = transactions;
  memset( entry->transactions, 0, sizeof( *entry->transactions ) );
  entry->transactions->failed = false;

  default_flow_entry_not_installed( datapath_id, message, entry );

  assert_true( transactions->failed == true );

  xfree( transactions );
  free_buffer( message );
}


static void
test_install_default_flow_entry_succeeds() {
  uint64_t datapath_id = 1;
  uint8_t table_id = 2;
  uint16_t priority = 3;
  nx_matches matches;
  memset( &matches, 0, sizeof( matches ) );
  ongoing_transactions transactions;
  memset( &transactions, 0, sizeof ( &transactions ) );

  will_return( mock_get_transaction_id, 1 );

  will_return( mock_get_cookie, 2 );

  buffer *buf = ( buffer * ) 0xa1;
  expect_value( mock_create_nx_flow_mod, transaction_id, 1 );
  expect_value( mock_create_nx_flow_mod, cookie, 2 );
  expect_value( mock_create_nx_flow_mod, command, OFPFC_MODIFY_STRICT );
  expect_value( mock_create_nx_flow_mod, table_id, table_id );
  expect_value( mock_create_nx_flow_mod, idle_timeout, 0 );
  expect_value( mock_create_nx_flow_mod, hard_timeout, 0 );
  expect_value( mock_create_nx_flow_mod, priority, priority );
  expect_value( mock_create_nx_flow_mod, buffer_id, UINT32_MAX );
  expect_value( mock_create_nx_flow_mod, out_port, OFPP_NONE );
  expect_value( mock_create_nx_flow_mod, flags, 0 );
  expect_value( mock_create_nx_flow_mod, matches, &matches );
  expect_value( mock_create_nx_flow_mod, actions, NULL );
  expect_string( mock_create_nx_flow_mod, matches_string, "all" );
  will_return( mock_create_nx_flow_mod, buf );

  expect_value( mock_execute_transaction, datapath_id, 1 );
  expect_value( mock_execute_transaction, message, buf );
  expect_value( mock_execute_transaction, succeeded_callback, default_flow_entry_installed );
  expect_not_value( mock_execute_transaction, succeeded_user_data, NULL );
  expect_value( mock_execute_transaction, failed_callback, default_flow_entry_not_installed );
  expect_not_value( mock_execute_transaction, failed_user_data, NULL );
  will_return( mock_execute_transaction, true );
  save_mock_execute_transaction_succeeded_user_data = NULL;
  save_mock_execute_transaction_failed_user_data = NULL;

  expect_value( mock_free_buffer, buf, buf );
  will_return( mock_free_buffer, 0 );

  install_default_flow_entry( datapath_id, table_id, priority, &matches, &transactions );

  assert_true( save_mock_execute_transaction_succeeded_user_data == save_mock_execute_transaction_failed_user_data );

  xfree( save_mock_execute_transaction_succeeded_user_data );
  save_mock_execute_transaction_succeeded_user_data = NULL;
  save_mock_execute_transaction_failed_user_data = NULL;
}


static void
test_nx_flow_mod_table_id_succeeded_succeeds() {
  uint64_t datapath_id = 1;
  buffer *message = NULL;
  void *user_data = NULL;

  will_return_count( mock_get_transaction_id, 1, 5 );

  will_return_count( mock_get_cookie, 2, 5 );

  buffer *buf = ( buffer * ) 0xa1;
  expect_value_count( mock_create_nx_flow_mod, transaction_id, 1, 5 );
  expect_value_count( mock_create_nx_flow_mod, cookie, 2, 5 );
  expect_value_count( mock_create_nx_flow_mod, command, OFPFC_MODIFY_STRICT, 5 );
  expect_value_count( mock_create_nx_flow_mod, table_id, 0, 4 );
  expect_value_count( mock_create_nx_flow_mod, table_id, 2, 1 );
  expect_value_count( mock_create_nx_flow_mod, idle_timeout, 0, 5 );
  expect_value_count( mock_create_nx_flow_mod, hard_timeout, 0, 5 );
  expect_value_count( mock_create_nx_flow_mod, priority, 0, 1 );
  expect_value_count( mock_create_nx_flow_mod, priority, UINT16_MAX, 3 );
  expect_value_count( mock_create_nx_flow_mod, priority, 0, 1 );
  expect_value_count( mock_create_nx_flow_mod, buffer_id, UINT32_MAX, 5 );
  expect_value_count( mock_create_nx_flow_mod, out_port, OFPP_NONE, 5 );
  expect_value_count( mock_create_nx_flow_mod, flags, 0, 5 );
  expect_not_value_count( mock_create_nx_flow_mod, matches, NULL, 5 );
  expect_value_count( mock_create_nx_flow_mod, actions, NULL, 5 );
  expect_string( mock_create_nx_flow_mod, matches_string, "all" );
  expect_string( mock_create_nx_flow_mod, matches_string, "eth_dst = 00:00:00:00:00:00/ff:ff:ff:ff:ff:ff" );
  expect_string( mock_create_nx_flow_mod, matches_string, "eth_src = 00:00:00:00:00:00" );
  expect_string( mock_create_nx_flow_mod, matches_string, "eth_src = ff:ff:ff:ff:ff:ff" );
  expect_string( mock_create_nx_flow_mod, matches_string, "all" );
  will_return_count( mock_create_nx_flow_mod, buf, 5 );

  expect_value_count( mock_execute_transaction, datapath_id, 1, 5 );
  expect_value_count( mock_execute_transaction, message, buf, 5 );
  expect_value_count( mock_execute_transaction, succeeded_callback, default_flow_entry_installed, 5 );
  expect_not_value_count( mock_execute_transaction, succeeded_user_data, NULL, 5 );
  expect_value_count( mock_execute_transaction, failed_callback, default_flow_entry_not_installed, 5 );
  expect_not_value_count( mock_execute_transaction, failed_user_data, NULL, 5 );
  will_return_count( mock_execute_transaction, true, 5 );
  save_mock_execute_transaction_succeeded_user_data = NULL;
  save_mock_execute_transaction_failed_user_data = NULL;

  expect_value_count( mock_free_buffer, buf, buf, 5 );
  will_return_count( mock_free_buffer, 0, 5 );

  nx_flow_mod_table_id_succeeded( datapath_id, message, user_data );

  flow_entry_to_be_installed *entry = save_mock_execute_transaction_succeeded_user_data;
  save_mock_execute_transaction_succeeded_user_data = NULL;
  save_mock_execute_transaction_failed_user_data = NULL;

  assert_true( entry->transactions != NULL );
  assert_true( entry != NULL );
  xfree( entry->transactions );
  xfree( entry );
}


static void
test_nx_flow_mod_table_id_failed_succeeds() {
  uint64_t datapath_id = 1;
  buffer *message = NULL;
  void *user_data = NULL;

  nx_flow_mod_table_id_failed( datapath_id, message, user_data );
}


static void
test_nx_set_flow_format_succeeded_succeeds() {
  uint64_t datapath_id = 1;
  buffer *message = NULL;
  void *user_data = NULL;

  will_return( mock_get_transaction_id, 1 );

  expect_value( mock_create_nx_flow_mod_table_id, transaction_id, 1 );
  expect_value( mock_create_nx_flow_mod_table_id, set, ENABLE_FLOW_MOD_TABLE_ID );
  buffer *buf = ( buffer * ) 0xa1;
  will_return( mock_create_nx_flow_mod_table_id, buf );

  expect_value( mock_execute_transaction, datapath_id, 1 );
  expect_value( mock_execute_transaction, message, buf );
  expect_value( mock_execute_transaction, succeeded_callback, nx_flow_mod_table_id_succeeded );
  expect_value( mock_execute_transaction, succeeded_user_data, NULL );
  expect_value( mock_execute_transaction, failed_callback, nx_flow_mod_table_id_failed );
  expect_value( mock_execute_transaction, failed_user_data, NULL );
  will_return( mock_execute_transaction, true );
  save_mock_execute_transaction_succeeded_user_data = NULL;
  save_mock_execute_transaction_failed_user_data = NULL;

  expect_value( mock_free_buffer, buf, buf );
  will_return( mock_free_buffer, 0 );

  nx_set_flow_format_succeeded( datapath_id, message, user_data );
}


static void
test_nx_set_flow_format_failed_succeeds() {
  uint64_t datapath_id = 1;
  buffer *message = NULL;
  void *user_data = NULL;

  nx_set_flow_format_failed( datapath_id, message, user_data );
}


/******************************************************************************
 * Run tests.
 ******************************************************************************/

int
main() {
  UnitTest tests[] = {
    unit_test( test_bisco_main_succeeds ),
    unit_test( test_init_and_finalize_vnet_manager_succeeds ),
    unit_test( test_parse_options_succeeds ),
    unit_test( test_usage_succeeds ),
    unit_test( test_set_exit_handler_succeeds ),
    unit_test( test_do_start_succeeds ),
    unit_test( test_stop_vnet_manager_succeeds ),
    unit_test( test_do_exit_succeeds ),
    unit_test( test_do_send_list_switches_request_succeeds ),
    unit_test( test_handle_list_switches_reply_succeeds ),
    unit_test( test_handle_add_port_status_succeeds ),
    unit_test( test_handle_modify_port_status_succeeds ),
    unit_test( test_handle_delete_port_status_succeeds ),
    unit_test( test_handle_features_reply_succeeds ),
    unit_test( test_handle_switch_ready_succeeds ),
    unit_test( test_handle_switch_disconnected_succeeds ),
    unit_test( test_default_flow_entry_installed_succeeds ),
    unit_test( test_default_flow_entry_not_installed_succeeds ),
    unit_test( test_install_default_flow_entry_succeeds ),
    unit_test( test_nx_flow_mod_table_id_succeeded_succeeds ),
    unit_test( test_nx_flow_mod_table_id_failed_succeeds ),
    unit_test( test_nx_set_flow_format_succeeded_succeeds ),
    unit_test( test_nx_set_flow_format_failed_succeeds ),
  };

  setup_leak_detector();

  return run_tests( tests );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
