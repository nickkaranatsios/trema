/*
 * Author: SUGYO Kazushi
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef BISCO_UNITTEST_H
#define BISCO_UNITTEST_H

#include "common_wrapper.h"


#ifdef getpid
#undef getpid
#endif
#define getpid mock_getpid
pid_t mock_getpid( void );


#ifdef printf
#undef printf
#endif
#define printf mock_printf
int mock_printf( const char *format, ... );


#ifdef gethostname
#undef gethostname
#endif
#define gethostname mock_gethostname
int mock_gethostname( char *name, size_t len );


#ifdef sigaction
#undef sigaction
#endif
#define sigaction( signum, act, oldact ) mock_sigaction( signum, act, oldact )
int mock_sigaction(int signum, const struct sigaction *act,
                   struct sigaction *oldact);


#ifdef init_trema
#undef init_trema
#endif
#define init_trema mock_init_trema
void mock_init_trema( int *argc, char ***argv );


#ifdef start_trema
#undef start_trema
#endif
#define start_trema mock_start_trema
void mock_start_trema( void );


#ifdef stop_trema
#undef stop_trema
#endif
#define stop_trema mock_stop_trema
void mock_stop_trema( void );


#ifdef get_executable_name
#undef get_executable_name
#endif
#define get_executable_name mock_get_executable_name
const char *mock_get_executable_name( void );


#ifdef set_switch_ready_handler
#undef set_switch_ready_handler
#endif
#define set_switch_ready_handler mock_set_switch_ready_handler
bool mock_set_switch_ready_handler( switch_ready_handler callback, void *user_data );


#ifdef set_switch_disconnected_handler
#undef set_switch_disconnected_handler
#endif
#define set_switch_disconnected_handler mock_set_switch_disconnected_handler
bool mock_set_switch_disconnected_handler( switch_disconnected_handler callback, void *user_data );


#ifdef set_features_reply_handler
#undef set_features_reply_handler
#endif
#define set_features_reply_handler mock_set_features_reply_handler
bool mock_set_features_reply_handler( features_reply_handler callback, void *user_data );


#ifdef set_port_status_handler
#undef set_port_status_handler
#endif
#define set_port_status_handler mock_set_port_status_handler
bool mock_set_port_status_handler( port_status_handler callback, void *user_data );


#ifdef set_list_switches_reply_handler
#undef set_list_switches_reply_handler
#endif
#define set_list_switches_reply_handler mock_set_list_switches_reply_handler
bool mock_set_list_switches_reply_handler( list_switches_reply_handler callback );


#ifdef set_external_callback
#undef set_external_callback
#endif
#define set_external_callback mock_set_external_callback
bool mock_set_external_callback( external_callback_t callback );


#ifdef send_openflow_message
#undef send_openflow_message
#endif
#define send_openflow_message mock_send_openflow_message
bool mock_send_openflow_message( const uint64_t datapath_id, buffer *message );


#ifdef send_list_switches_request
#undef send_list_switches_request
#endif
#define send_list_switches_request mock_send_list_switches_request
bool mock_send_list_switches_request( void *user_data );


#ifdef get_transaction_id
#undef get_transaction_id
#endif
#define get_transaction_id mock_get_transaction_id
uint32_t mock_get_transaction_id( void );


#ifdef get_cookie
#undef get_cookie
#endif
#define get_cookie mock_get_cookie
uint64_t mock_get_cookie( void );


#ifdef free_buffer
#undef free_buffer
#endif
#define free_buffer mock_free_buffer
void mock_free_buffer( buffer *buf );


#ifdef create_features_request
#undef create_features_request
#endif
#define create_features_request mock_create_features_request
buffer *mock_create_features_request( const uint32_t transaction_id );


#ifdef create_nx_set_flow_format
#undef create_nx_set_flow_format
#endif
#define create_nx_set_flow_format mock_create_nx_set_flow_format
buffer *mock_create_nx_set_flow_format( const uint32_t transaction_id, const uint32_t format );


#ifdef create_nx_flow_mod
#undef create_nx_flow_mod
#endif
#define create_nx_flow_mod mock_create_nx_flow_mod
buffer *mock_create_nx_flow_mod( const uint32_t transaction_id, const uint64_t cookie, const uint16_t command,
                                 const uint8_t table_id, const uint16_t idle_timeout, const uint16_t hard_timeout,
                                 const uint16_t priority, const uint32_t buffer_id,
                                 const uint16_t out_port, const uint16_t flags,
                                 const nx_matches *matches, const openflow_actions *actions );


#ifdef create_nx_flow_mod_table_id
#undef create_nx_flow_mod_table_id
#endif
#define create_nx_flow_mod_table_id mock_create_nx_flow_mod_table_id
buffer *mock_create_nx_flow_mod_table_id( const uint32_t transaction_id, const uint8_t set );


#ifdef init_db
#undef init_db
#endif
#define init_db mock_init_db
bool mock_init_db( MYSQL **db, db_config config );

#ifdef finalize_db
#undef finalize_db
#endif
#define finalize_db mock_finalize_db
bool mock_finalize_db( MYSQL *db );

#ifdef init_http_client
#undef init_http_client
#endif
#define init_http_client mock_init_http_client
bool mock_init_http_client();

#ifdef finalize_http_client
#undef finalize_http_client
#endif
#define finalize_http_client mock_finalize_http_client
bool mock_finalize_http_client();

#ifdef init_overlay_network_manager
#undef init_overlay_network_manager
#endif
#define init_overlay_network_manager mock_init_overlay_network_manager
bool mock_init_overlay_network_manager( MYSQL *db );

#ifdef finalize_overlay_network_manager
#undef finalize_overlay_network_manager
#endif
#define finalize_overlay_network_manager mock_finalize_overlay_network_manager
bool mock_finalize_overlay_network_manager();

#ifdef init_slice
#undef init_slice
#endif
#define init_slice mock_init_slice
bool mock_init_slice( MYSQL *db );

#ifdef finalize_slice
#undef finalize_slice
#endif
#define finalize_slice mock_finalize_slice
bool mock_finalize_slice();

#ifdef add_switch
#undef add_switch
#endif
#define add_switch mock_add_switch
bool mock_add_switch( uint64_t datapath_id, const char *controller_host, pid_t controller_pid );

#ifdef delete_switch
#undef delete_switch
#endif
#define delete_switch mock_delete_switch
bool mock_delete_switch( uint64_t datapath_id );

#ifdef delete_switch_by_host_pid
#undef delete_switch_by_host_pid
#endif
#define delete_switch_by_host_pid mock_delete_switch_by_host_pid
bool mock_delete_switch_by_host_pid( const char* controller_host, pid_t controller_pid );

#ifdef switch_on_duty
#undef switch_on_duty
#endif
#define switch_on_duty mock_switch_on_duty
bool mock_switch_on_duty( uint64_t datapath_id, const char *controller_host, pid_t controller_pid );

#ifdef add_port
#undef add_port
#endif
#define add_port mock_add_port
bool mock_add_port( uint64_t datapath_id, uint16_t port_no, const char *name );

#ifdef delete_port
#undef delete_port
#endif
#define delete_port mock_delete_port
bool mock_delete_port( uint64_t datapath_id, uint16_t port_no, const char *name );


#ifdef init_switch
#undef init_switch
#endif
#define init_switch mock_init_switch
bool mock_init_switch( MYSQL *db );

#ifdef finalize_switch
#undef finalize_switch
#endif
#define finalize_switch mock_finalize_switch
bool mock_finalize_switch();

#ifdef execute_transaction
#undef execute_transaction
#endif
#define execute_transaction mock_execute_transaction
bool mock_execute_transaction( uint64_t datapath_id, const buffer *message,
                               succeeded_handler succeeded_callback, void *succeeded_user_data,
                               failed_handler failed_callback, void *failed_user_data );

#ifdef init_transaction_manager
#undef init_transaction_manager
#endif
#define init_transaction_manager mock_init_transaction_manager
bool mock_init_transaction_manager();

#ifdef finalize_transaction_manager
#undef finalize_transaction_manager
#endif
#define finalize_transaction_manager mock_finalize_transaction_manager
bool mock_finalize_transaction_manager();


#define main bisco_main


#endif // BISCO_UNITTEST_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
