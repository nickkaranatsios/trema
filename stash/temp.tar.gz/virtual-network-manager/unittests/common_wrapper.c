/*
 * Author: Yasunobu Chiba
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include "common_wrapper.h"


#ifdef test_malloc
#undef test_malloc
#endif
static void *
test_malloc( size_t size ) {
  return _test_malloc( size, __FILE__, __LINE__ );
}


#ifdef test_calloc
#undef test_calloc
#endif
static void *
test_calloc( size_t nmemb, size_t size ) {
  return _test_calloc( nmemb, size, __FILE__, __LINE__ );
}


#ifdef test_free
#undef test_free
#endif
static void
test_free( void *ptr ) {
  _test_free( ptr, __FILE__, __LINE__ );
}


void
setup_leak_detector() {
  trema_malloc = test_malloc;
  trema_calloc = test_calloc;
  trema_free = test_free;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
