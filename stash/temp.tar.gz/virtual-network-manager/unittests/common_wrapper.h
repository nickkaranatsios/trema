/*
 * Author: Yasunobu Chiba
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef COMMON_WRAPPER_H
#define COMMON_WRAPPER_H


#include <stdlib.h>


#define static

#ifdef assert
#undef assert
#endif
#define assert( expression ) \
  mock_assert( ( int ) ( expression ), #expression, __FILE__, __LINE__ );
extern void mock_assert( const int result, const char *const expression, const char *const file, const int line );

extern void* _test_malloc( const size_t size, const char* file, const int line );
extern void* _test_calloc( const size_t number_of_elements, const size_t size,
                           const char* file, const int line );
extern void _test_free( void* const ptr, const char* file, const int line );

#ifdef malloc
#undef malloc
#endif
#define malloc( size ) _test_malloc( size, __FILE__, __LINE__ )

#ifdef calloc
#undef calloc
#endif
#define calloc( num, size ) _test_calloc( num, size, __FILE__, __LINE__ )

#ifdef free
#undef free
#endif
#define free( ptr ) _test_free( ptr, __FILE__, __LINE__ )


extern void * ( *trema_malloc )( size_t size );
extern void * ( *trema_calloc )( size_t nmemb, size_t size );
extern void ( *trema_free )( void *ptr );


void setup_leak_detector();


#endif // COMMON_WRAPPER_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
