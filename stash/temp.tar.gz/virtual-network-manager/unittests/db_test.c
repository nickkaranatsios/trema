/*
 * Author:Dan Xu
 *
 * Copyright (C) NEC BIGLOBE, Ltd. 2012
 * NEC Confidential
 */

#include <stdio.h>
#include <stdarg.h>
#include <mysql/mysql.h>
#include <wrapper.h>
#include "common_wrapper.h"
#include "unittest.h"
#include "db.h"

static int
xvasnprintf( char **strp, size_t size, const char *fmt, va_list ap ) {
  *strp = xmalloc( size );
  int n = vsnprintf( *strp, size, fmt, ap );
  if ( n > -1 && ( size_t ) n < size ) {
    return n;
  }
  xfree( *strp );
  *strp = NULL;
  return n;
}


int
mock_xvasprintf( char **strp, const char *fmt, va_list ap ) {
  int ret = ( int ) mock();
  if ( ret < 0 ) {
    return ret;
  }
  size_t size = 100;
  va_list aq;
  va_copy( aq, ap );
  int n = xvasnprintf( strp, size, fmt, aq );
  va_end( aq );
  if ( n < 0 || ( size_t ) n < size ) {
    return ret;
  }
  size = ( size_t ) ( n + 1 );
  va_copy( aq, ap );
  n = xvasnprintf( strp, size, fmt, aq );
  va_end( aq );
  return ret;
}


const char * STDCALL
mock_mysql_error( MYSQL *mysql ) {
  check_expected( mysql );

  return ( const char * ) ( intptr_t ) mock();
}


MYSQL * STDCALL
mock_mysql_init( MYSQL *mysql ) {
  check_expected( mysql );

  return ( MYSQL * ) ( intptr_t ) mock();
}


MYSQL * STDCALL
mock_mysql_real_connect( MYSQL *mysql, /* const */ char *host,
                         /* const */ char *user,
                         /* const */ char *passwd,
                         /* const */ char *db,
                         unsigned int port,
                         /* const */ char *unix_socket,
                         unsigned long clientflag ) {
  check_expected( mysql );
  check_expected( host );
  check_expected( user );
  check_expected( passwd );
  check_expected( db );
  check_expected( port );
  check_expected( unix_socket );
  check_expected( clientflag );

  return ( MYSQL * ) ( intptr_t ) mock();
}


int STDCALL
mock_mysql_real_query( MYSQL *mysql, /* const */ char *q, unsigned long length ) {
  check_expected( mysql );
  check_expected( q );
  check_expected( length );

  return ( int ) mock();
}


int STDCALL
mock_mysql_ping( MYSQL *mysql ) {
  check_expected( mysql );

  return ( int ) mock();
}


int STDCALL
mock_mysql_options( MYSQL *mysql, enum mysql_option option, /* const */ void *arg ) {
  check_expected( mysql );
  check_expected( option );
  check_expected( arg );

  return ( int ) mock();
}


void STDCALL
mock_mysql_close( MYSQL *sock ) {
  check_expected( sock );

  ( void ) mock();
}


void 
mock_error( /* const */ char *format, ... ) { 
  va_list args;
  va_start( args, format );
  char message[ 1000 ];
  vsprintf( message, format, args );
  va_end( args );

  check_expected( message );
}


void
mock_debug( /* const */ char *format, ... ) {
  va_list args;
  va_start( args, format );
  char message[ 1000 ];
  vsprintf( message, format, args );
  va_end( args );

  check_expected( message );
}



void
mock_info( /* const */ char *format, ... ) {
  va_list args;
  va_start( args, format );
  char message[ 1000 ];
  vsprintf( message, format, args );
  va_end( args );

  check_expected( message );
}


void
mock_warn( /* const */ char *format, ... ) {
  va_list args;
  va_start( args, format );
  char message[ 1000 ];
  vsprintf( message, format, args );
  va_end( args );

  check_expected( message );
}


/******************************************************************************
 * Test functions.
 ******************************************************************************/

static void 
test_execute_query_succeeds() {
  MYSQL *db = ( void * ) 0x1;
  const char *format = "select * from switch_ports";
  expect_string( mock_debug, message, "Checking if a database connection is alive or not ( db = 0x1 )." );
  expect_value( mock_mysql_ping, mysql, db );
  will_return( mock_mysql_ping, 0 );

  will_return( mock_xvasprintf, 26 );
  const char *statement = "select * from switch_ports";
  size_t len = strlen( statement );
  expect_string( mock_debug, message, "Executing a SQL statement ( statement = 'select * from switch_ports', length = 26 )." );
  
  expect_value( mock_mysql_real_query, mysql, db );
  expect_string( mock_mysql_real_query, q, "select * from switch_ports" );
  expect_value( mock_mysql_real_query, length, len );
  will_return( mock_mysql_real_query, 0 );

  expect_string( mock_debug, message, "A SQL statement is executed successfully ( statement = 'select * from switch_ports', length = 26 )." );
  assert_true( execute_query( db, format ) );
}


static void 
test_execute_query_succeeds_if_mysql_ping_does_not_return_0() {
  MYSQL *db = ( void * ) 0x1;
  const char *format = "select * from switch_ports";
  expect_string( mock_debug, message, "Checking if a database connection is alive or not ( db = 0x1 )." );

  expect_value( mock_mysql_ping, mysql, db );
  will_return( mock_mysql_ping, 1 );
  expect_string( mock_info, message, "Database connection has been lost ( ret = 1 ). Reconnecting." );

  will_return( mock_xvasprintf, 26 );
  const char *statement = "select * from switch_ports";
  size_t len = strlen( statement );
  expect_string( mock_debug, message, "Executing a SQL statement ( statement = 'select * from switch_ports', length = 26 )." );

  expect_value( mock_mysql_real_query, mysql, db );
  expect_string( mock_mysql_real_query, q, "select * from switch_ports" );
  expect_value( mock_mysql_real_query, length, len );
  will_return( mock_mysql_real_query, 0 );

  expect_string( mock_debug, message, "A SQL statement is executed successfully ( statement = 'select * from switch_ports', length = 26 )." );

  assert_true( execute_query( db, format ) );
}


static void 
test_execute_query_fails_if_db_is_NULL() {
  MYSQL *db = NULL;
  const char *format = "select * from switch_ports";
  expect_assert_failure( execute_query( db, format ) );
}


static void 
test_execute_query_fails_if_format_is_NULL() {
  MYSQL *db = ( void * ) 0x1;

  expect_assert_failure( execute_query( db, NULL ) );
}


static void 
test_execute_query_fails_if_vasprintf_return_negative() {
  MYSQL *db = ( void * ) 0x1;
  const char *format = "select * from switch_ports";

  expect_string( mock_debug, message, "Checking if a database connection is alive or not ( db = 0x1 )." );
  expect_value( mock_mysql_ping, mysql, db );
  will_return( mock_mysql_ping, 0 );

  will_return( mock_xvasprintf, -1 );
  expect_string( mock_error, message, "Failed to format a SQL statement ( ret = -1 )." );
  assert_false( execute_query( db, format ) );
}


static void 
test_execute_query_fails_if_mysql_real_query_does_not_return_0() {
  MYSQL *db = ( void * ) 0x1;
  const char *format = "select * from switch_ports";
 
  expect_string( mock_debug, message, "Checking if a database connection is alive or not ( db = 0x1 )." );

  expect_value( mock_mysql_ping, mysql, db );
  will_return( mock_mysql_ping, 0 );

  will_return( mock_xvasprintf, 26 );

  expect_string( mock_debug, message, "Executing a SQL statement ( statement = 'select * from switch_ports', length = 26 )." );

  expect_value( mock_mysql_real_query, mysql, db );
  expect_string( mock_mysql_real_query, q, "select * from switch_ports" );
  size_t len = strlen( "select * from switch_ports" );
  expect_value( mock_mysql_real_query, length, len );
  will_return( mock_mysql_real_query, 1 );

  expect_value( mock_mysql_error, mysql, db );
  will_return( mock_mysql_error, "Mysql error." );
  expect_string( mock_error, message, "Failed to execute a SQL statement ( statement = 'select * from switch_ports', ret = 1, error = 'Mysql error.' )." );

  assert_false( execute_query( db, format ) ); 
}


static db_config
config_prepare() {
  db_config config;
  memset( config.host, 0, HOSTNAME_LENGTH + 1 );
  strncpy( config.host, "127.0.0.1", HOSTNAME_LENGTH );
  memset( config.username, 0, USERNAME_LENGTH + 1 );
  strncpy( config.username, "root", USERNAME_LENGTH );
  memset( config.password, 0, NAME_LEN + 1 );
  strncpy( config.password, "root123", NAME_LEN );
  memset( config.db_name, 0, NAME_LEN + 1 );
  strncpy( config.db_name, "vnet", NAME_LEN );
  config.port = 3306;
  return config;
}


static void 
test_init_db_succeeds() {
  db_config config = config_prepare();
  MYSQL *db = NULL;
  char str[1024];
  snprintf( str, 1024, "Initializing backend database ( db = %p, host = %s, port = %u, username = %s, password = %s, db_name = %s ).", &db, config.host, config.port, config.username, config.password, config.db_name );
  MYSQL *db1 = ( void * ) 0x1;
  MYSQL *res = ( void * ) 0x2;
  
  expect_string( mock_debug, message, str );

  expect_value( mock_mysql_init, mysql, NULL );
  will_return( mock_mysql_init, db1 );

  expect_value( mock_mysql_options, mysql, db1 );
  expect_value( mock_mysql_options, option, MYSQL_OPT_RECONNECT );
  expect_not_value( mock_mysql_options, arg, NULL );
  will_return( mock_mysql_options, 0 );
  
  expect_not_value( mock_mysql_real_connect, mysql, NULL );
  expect_string( mock_mysql_real_connect, host, "127.0.0.1" );
  expect_string( mock_mysql_real_connect, user, "root" );
  expect_string( mock_mysql_real_connect, passwd, "root123" );
  expect_string( mock_mysql_real_connect, db, "vnet" );
  expect_value( mock_mysql_real_connect, port, 3306 );
  expect_value( mock_mysql_real_connect, unix_socket, NULL );
  expect_value( mock_mysql_real_connect, clientflag, 0 );
  will_return( mock_mysql_real_connect, res );
  char str2[1024]; 
  snprintf( str2, 1024, "Initialization completed successfully ( db = %p ).", &db );
  expect_string( mock_debug, message, str2 );
  assert_true( init_db( &db, config ) );
}


static void 
test_init_db_fails_if_mysql_init_returns_NULL() {
  db_config config = config_prepare();

  MYSQL *db = NULL;
  char str[1024];
  snprintf( str, 1024, "Initializing backend database ( db = %p, host = %s, port = %u, username = %s, password = %s, db_name = %s ).", &db, config.host, config.port, config.username, config.password, config.db_name );

  expect_string( mock_debug, message, str );
  expect_value( mock_mysql_init, mysql, NULL );
  will_return( mock_mysql_init, NULL );

  expect_string( mock_error, message, "Failed to initialize backend database." );
  assert_false( init_db( &db, config ) );
}


static void 
test_init_db_fails_if_mysql_options_does_not_return_0() {
  db_config config = config_prepare();

  MYSQL *db = NULL;
  MYSQL *db1 = ( void * ) 0x1;
  char str[1024];
  snprintf( str, 1024, "Initializing backend database ( db = %p, host = %s, port = %u, username = %s, password = %s, db_name = %s ).", &db, config.host, config.port, config.username, config.password, config.db_name );

  expect_string( mock_debug, message, str );
  expect_value( mock_mysql_init, mysql, NULL );
  will_return( mock_mysql_init, db1 );

  expect_value( mock_mysql_options, mysql, db1 );
  expect_value( mock_mysql_options, option, MYSQL_OPT_RECONNECT );
  expect_not_value( mock_mysql_options, arg, NULL );
  will_return( mock_mysql_options, 1 );
  expect_value( mock_mysql_error, mysql, db1 );
  will_return( mock_mysql_error, "MYSQL ERROR" );
  char str2[1024];
  snprintf( str2, 1024, "Failed to enable automatic reconnect option ( db = %p, error = 'MYSQL ERROR' ).", &db );
  expect_string( mock_error, message, str2 );

  expect_value( mock_mysql_close, sock, db1 );
  will_return( mock_mysql_close, NULL );

  assert_false( init_db( &db, config ) );
}


static void 
test_init_db_fails_if_mysql_real_connect_returns_NULL() {
  db_config config = config_prepare();

  MYSQL *db = NULL;
  MYSQL *db1 = ( void * ) 0x1;
  char str[1024];
  snprintf( str, 1024, "Initializing backend database ( db = %p, host = %s, port = %u, username = %s, password = %s, db_name = %s ).", &db, config.host, config.port, config.username, config.password, config.db_name );

  expect_string( mock_debug, message, str );
  expect_value( mock_mysql_init, mysql, NULL );
  will_return( mock_mysql_init, db1 );

  expect_value( mock_mysql_options, mysql, db1 );
  expect_value( mock_mysql_options, option, MYSQL_OPT_RECONNECT );
  expect_not_value( mock_mysql_options, arg, NULL );
  will_return( mock_mysql_options, 0 );

  expect_not_value( mock_mysql_real_connect, mysql, NULL );
  expect_string( mock_mysql_real_connect, host, "127.0.0.1" );
  expect_string( mock_mysql_real_connect, user, "root" );
  expect_string( mock_mysql_real_connect, passwd, "root123" );
  expect_string( mock_mysql_real_connect, db, "vnet" );
  expect_value( mock_mysql_real_connect, port, 3306 );
  expect_value( mock_mysql_real_connect, unix_socket, NULL );
  expect_value( mock_mysql_real_connect, clientflag, 0 );
  will_return( mock_mysql_real_connect, NULL );

  expect_value( mock_mysql_error, mysql, db1 );
  will_return( mock_mysql_error, "MYSQL ERROR" ) ;
  char str2[1024];
  snprintf( str2, 1024, "Failed to connect to database ( db = %p, error = 'MYSQL ERROR' ).", &db );

  expect_string( mock_error, message, str2 );
  expect_value( mock_mysql_close, sock, db1 );
  will_return( mock_mysql_close, NULL );

  assert_false( init_db( &db, config ) );
}


static void 
test_init_db_fails_if_db_is_NULL() {
  db_config config = config_prepare();

  expect_assert_failure( init_db( NULL, config ) );
}


static void
test_init_db_fails_if_db_address_is_not_NULL() {
  MYSQL *db = ( void * ) 0x1;
  db_config config = config_prepare();
  
  expect_assert_failure( init_db( &db, config ) );

}


static void 
test_finalize_db_succeeds() {
  MYSQL *db = ( void * ) 0x1;
  expect_string( mock_debug, message, "Finalizing backend database ( db = 0x1 )." );
  expect_value( mock_mysql_close, sock, db );
  will_return( mock_mysql_close, NULL );
  expect_string( mock_debug, message, "Finalization completed successfully ( db = 0x1 )." );

  assert_true( finalize_db( db ) );
}


static void 
test_finalize_db_fails_if_db_is_NULL() {
  MYSQL *db = NULL;
  expect_string( mock_debug, message, "Finalizing backend database ( db = (nil) )." );
  expect_string( mock_warn, message, "Backend database is already closed or not initialized yet ( db = (nil) )." ); 
  assert_false( finalize_db( db ) );
}


/******************************************************************************
 * Run tests.
 ******************************************************************************/

int
main() {
  UnitTest tests[] = {
    unit_test( test_execute_query_succeeds ),
    unit_test( test_execute_query_succeeds_if_mysql_ping_does_not_return_0 ),
    unit_test( test_execute_query_fails_if_db_is_NULL ),
    unit_test( test_execute_query_fails_if_format_is_NULL ),
    unit_test( test_execute_query_fails_if_vasprintf_return_negative ), 
    unit_test( test_execute_query_fails_if_mysql_real_query_does_not_return_0 ),
    unit_test( test_init_db_succeeds ),
    unit_test( test_init_db_fails_if_mysql_init_returns_NULL ),
    unit_test( test_init_db_fails_if_mysql_options_does_not_return_0 ),
    unit_test( test_init_db_fails_if_mysql_real_connect_returns_NULL ),
    unit_test( test_init_db_fails_if_db_is_NULL ),
    unit_test( test_init_db_fails_if_db_address_is_not_NULL ),
    unit_test( test_finalize_db_succeeds ),
    unit_test( test_finalize_db_fails_if_db_is_NULL ),
  };
  setup_leak_detector();
  return run_tests( tests );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
