/*
 * Author: Yasunobu Chiba
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef DB_UNITTEST_H
#define DB_UNITTEST_H

#include "common_wrapper.h"


#ifdef vasprintf
#undef vasprintf
#endif
#define vasprintf( str, format, ap) mock_xvasprintf( str, format, ap )
int mock_xvasprintf( char **strp, const char *fmt, va_list ap );


#ifdef mysql_error
#undef mysql_error
#endif
#define mysql_error mock_mysql_error
const char * STDCALL mock_mysql_error( MYSQL *mysql );


#ifdef mysql_init
#undef mysql_init
#endif
#define mysql_init mock_mysql_init
MYSQL * STDCALL mock_mysql_init( MYSQL *mysql );


#ifdef mysql_real_connect
#undef mysql_real_connect
#endif
#define mysql_real_connect mock_mysql_real_connect
MYSQL * STDCALL mock_mysql_real_connect( MYSQL *mysql, const char *host,
                                         const char *user,
                                         const char *passwd,
                                         const char *db,
                                         unsigned int port,
                                         const char *unix_socket,
                                         unsigned long clientflag );


#ifdef mysql_real_query
#undef mysql_real_query
#endif
#define mysql_real_query mock_mysql_real_query
int STDCALL mock_mysql_real_query( MYSQL *mysql, const char *q, unsigned long length );


#ifdef mysql_ping
#undef mysql_ping
#endif
#define mysql_ping mock_mysql_ping
int STDCALL mock_mysql_ping( MYSQL *mysql );


#ifdef mysql_options
#undef mysql_options
#endif
#define mysql_options mock_mysql_options
int STDCALL mock_mysql_options( MYSQL *mysql,enum mysql_option option, const void *arg );


#ifdef mysql_close
#undef mysql_close
#endif
#define mysql_close mock_mysql_close
void STDCALL mock_mysql_close( MYSQL *sock );


#ifdef debug
#undef debug
#endif
#define debug mock_debug
void mock_debug( const char *format, ... );

#ifdef info
#undef info
#endif
#define info mock_info
void mock_info( const char *format, ... );

#ifdef warn
#undef warn
#endif
#define warn mock_warn
void mock_warn( const char *format, ... );

#ifdef error
#undef error
#endif
#define error mock_error
void mock_error( const char *format, ... );

#endif // DB_UNITTEST_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
