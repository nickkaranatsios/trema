/*
 * Author: Yikun Wei
 *
 * Copyright (C) NEC BIGLOBE, Ltd. 2012
 * NEC Confidential
 */


#include "common_wrapper.h"
#include "http_client.h"
#include "queue.h"
#include "unittest.h"
#include <curl/curl.h>
#include <sys/eventfd.h>


typedef struct {
  uint8_t method;
  char uri[ 1024 ];
  http_content content;
} http_request;

typedef struct {
  int status;
  int code;
  http_content content;
} http_response;

typedef struct {
  CURL *handle;
  struct curl_slist *slist;
  http_request request;
  http_response response;
  request_completed_handler callback;
  void *user_data;
} http_transaction;


extern pthread_t *http_client_thread;
extern int http_client_efd;
extern int main_efd;
extern queue *main_to_http_client_queue;
extern queue *http_client_to_main_queue;
extern hash_table *transactions;
extern CURLM *curl_handle;
extern int curl_running;
extern uint64_t http_client_notify_count;
extern uint64_t main_notify_count;

extern bool init_curl();
extern bool finalize_curl();
extern void create_http_transaction_db();
extern hash_table *transactions;
extern void maybe_create_http_client_thread();
extern bool compare_http_transaction( const void *x, const void *y );
extern unsigned int hash_http_transaction( const void *key );
extern void notify_main_actually();
extern bool notify_main();
extern void notify_http_client_actually( int fd, void *user_data );
extern bool notify_http_client();
extern int create_event_fd();
extern http_transaction *alloc_http_transaction();
extern void free_http_transaction( http_transaction *transaction );
extern bool add_http_transaction( http_transaction *transaction, CURL *handle );
extern void retrieve_http_transactions_from_http_client( int fd, void *user_data );


struct curl_slist *
mock_curl_slist_append( struct curl_slist * list, /* const */ char * string ) {
  check_expected( list );
  check_expected( string );

  return ( struct curl_slist * ) ( intptr_t ) mock();
}


void
mock_curl_slist_free_all( struct curl_slist * list ) {
  check_expected( list );

  ( void ) mock();
}


const char *
mock_curl_easy_strerror( CURLcode code ) {
  check_expected( code );

  return ( const char * ) ( intptr_t ) mock();
}


CURL *
mock_curl_easy_init( void ) {

  return ( CURL * ) ( intptr_t ) mock();
}


CURLcode
mock_curl_easy_setopt( CURL *curl, CURLoption option, ... ) {
  check_expected( curl );
  check_expected( option );

  return ( CURLcode ) mock();
}


void
mock_curl_easy_cleanup( CURL *curl ) {
  check_expected( curl );

  ( void ) mock();
}


CURLcode
mock_curl_easy_getinfo( CURL *curl, CURLINFO info, ... ) {
  check_expected( curl );
  check_expected( info );

  return ( CURLcode ) mock();
}


CURLM *
mock_curl_multi_init( void ) {

  return ( CURLM * ) ( intptr_t ) mock();
}


CURLMcode
mock_curl_multi_add_handle( CURLM *multi_handle, CURL *curl_handle ) {
  check_expected( multi_handle );
  check_expected( curl_handle );

  return ( CURLMcode ) mock();
}


CURLMcode
mock_curl_multi_remove_handle( CURLM *multi_handle, CURL *curl_handle ) {
  check_expected( multi_handle );
  check_expected( curl_handle );

  return ( CURLMcode ) mock();
}


CURLMcode
mock_curl_multi_fdset( CURLM *multi_handle, fd_set *read_fd_set, fd_set *write_fd_set, fd_set *exc_fd_set, int *max_fd ) {
  check_expected( multi_handle );
  check_expected( read_fd_set );
  check_expected( write_fd_set );
  check_expected( exc_fd_set );
  check_expected( max_fd );

  return ( CURLMcode ) mock();
}


const char *
mock_curl_multi_strerror( CURLMcode code ) {
  check_expected( code );

  return ( const char * ) ( intptr_t ) mock();
}


CURLMcode
mock_curl_multi_perform( CURLM *multi_handle, int *running_handles ) {
  check_expected( multi_handle );
  check_expected( running_handles );

  return ( CURLMcode ) mock();
}


CURLMcode
mock_curl_multi_cleanup( CURLM *multi_handle ) {
  check_expected( multi_handle );

  return ( CURLMcode ) mock();
}


CURLMsg *
mock_curl_multi_info_read( CURLM *multi_handle, int *msgs_in_queue ) {
  check_expected( multi_handle );
  check_expected( msgs_in_queue );

  return ( CURLMsg * ) ( intptr_t ) mock();
}


CURLMcode
mock_curl_multi_timeout( CURLM *multi_handle, long *milliseconds ) {
  check_expected( multi_handle );
  check_expected( milliseconds );

  return ( CURLMcode ) mock();
}


queue *
mock_create_queue( void ) {
  return ( queue * ) ( intptr_t ) mock();
}


bool
mock_delete_queue( queue *queue ) {
  check_expected( queue );

  return ( bool ) mock();
}


bool
mock_enqueue( queue *queue, void *data ) {
  check_expected( queue );
  check_expected( data );

  return ( bool ) mock();
}


void *
mock_dequeue( queue *queue ) {
  check_expected( queue );

  return ( void * ) ( intptr_t ) mock();
}


void
mock_set_fd_handler( int fd, event_fd_callback read_callback, void *read_data, event_fd_callback write_callback, void *write_data ) {
  check_expected( fd );
  check_expected( read_callback );
  check_expected( read_data );
  check_expected( write_callback );
  check_expected( write_data );
}


void
mock_set_writable( int fd, bool state ) {
  check_expected( fd );
  check_expected( state );
}


void
mock_set_readable( int fd, bool state ) {
  check_expected( fd );
  check_expected( state );
}


hash_table *
mock_create_hash( const compare_function compare, const hash_function hash ) {
  check_expected( compare );
  check_expected( hash );

  return ( hash_table * ) ( intptr_t ) mock();
}


void
mock_error( /* const */ char *format, ... ) {
  char statement[ 512 ];
  memset( statement, '\0', sizeof( statement ) );

  va_list args;
  va_start( args, format );
  vsnprintf( statement, sizeof( statement ) - 1, format, args );
  va_end( args );

  check_expected( statement );

  return ( void ) mock();
}


ssize_t
mock_write( int fildes, const void *buf, size_t nbytes ) {
  check_expected( fildes );
  check_expected( buf );
  check_expected( nbytes );

  return ( ssize_t ) mock();
}


int
mock_eventfd( unsigned int initval, int flags ) {
  check_expected( initval );
  check_expected( flags );

  return ( int ) mock();
}


static void
cleanup() {
  http_client_thread = NULL;
  http_client_efd = -1;
  main_efd = -1;
  main_to_http_client_queue = NULL;
  http_client_to_main_queue = NULL;
  transactions = NULL;
  curl_handle = NULL;
  curl_running = 0;
  http_client_notify_count = 0;
  main_notify_count = 0;
}


/******************************************************************************
 * Test functions.
 ******************************************************************************/

static void
test_init_curl_succeeds() {
  CURLM *handle = ( void * ) 0x1;
  will_return( mock_curl_multi_init, handle );

  assert_true( init_curl() );
  assert_true( curl_handle == handle );
}


static void
test_finalize_curl_succeeds() {
  CURLM *handle = ( void * ) 0x1;
  will_return( mock_curl_multi_init, handle );
  init_curl();

  expect_value( mock_curl_multi_cleanup, multi_handle, curl_handle );
  will_return( mock_curl_multi_cleanup, CURLM_OK );
  assert_true( finalize_curl() );
  assert_true( curl_handle == NULL );
}


static void
test_init_http_client_succeeds() {
  CURLM *handle = ( void * ) 0x1;
  will_return( mock_curl_multi_init, handle );
  init_curl();

  int h_efd  = 1;
  expect_value( mock_eventfd, initval, 0 );
  expect_value( mock_eventfd, flags, EFD_NONBLOCK );
  will_return( mock_eventfd, h_efd );

  expect_value( mock_set_fd_handler, fd, h_efd );
  expect_value( mock_set_fd_handler, read_callback, NULL );
  expect_value( mock_set_fd_handler, read_data, NULL );
  expect_value( mock_set_fd_handler, write_callback, notify_http_client_actually );
  expect_value( mock_set_fd_handler, write_data, &http_client_notify_count );

  expect_value( mock_set_writable, fd, h_efd );
  expect_value( mock_set_writable, state, false );

  int m_efd = 2;
  expect_value( mock_eventfd, initval, 0 );
  expect_value( mock_eventfd, flags, EFD_NONBLOCK );
  will_return( mock_eventfd, m_efd  );

  expect_value( mock_set_fd_handler, fd, m_efd );
  expect_value( mock_set_fd_handler, read_callback, retrieve_http_transactions_from_http_client );
  expect_value( mock_set_fd_handler, read_data, NULL );
  expect_value( mock_set_fd_handler, write_callback, NULL );
  expect_value( mock_set_fd_handler, write_data, NULL );

  expect_value( mock_set_readable, fd, m_efd );
  expect_value( mock_set_readable, state, true );

  queue *m_queue = ( void * ) 0x2;
  will_return( mock_create_queue, m_queue );

  queue *h_queue = ( void * ) 0x3;
  will_return( mock_create_queue, h_queue );

  hash_table *h_transactions = ( void * ) 0x4;
  expect_value( mock_create_hash, compare, compare_http_transaction );
  expect_value( mock_create_hash, hash, hash_http_transaction );
  will_return( mock_create_hash, h_transactions );

  assert_true( init_http_client() );
  assert_int_equal( http_client_efd, h_efd );
  assert_int_equal( main_efd, m_efd );
  assert_true( main_to_http_client_queue == m_queue );
  assert_true( http_client_to_main_queue == h_queue );
  assert_true( transactions == h_transactions );
}


static void
test_create_http_transaction_db_succeeds() {
  transactions = NULL;

  hash_table *h_transactions = ( void * ) 0x1;
  expect_value( mock_create_hash, compare, compare_http_transaction );
  expect_value( mock_create_hash, hash, hash_http_transaction );
  will_return( mock_create_hash, h_transactions );

  create_http_transaction_db();
  assert_true( transactions == h_transactions );
}


static void
test_compare_http_transaction_returns_true_if_keys_match() {
  http_transaction x;
  http_transaction y;

  memset( &x, 0, sizeof( http_transaction ) );
  memset( &y, 0, sizeof( http_transaction ) );

  x.handle = ( void * ) 0x1;
  y.handle = ( void * ) 0x1;

  assert_true( compare_http_transaction( &x, &y ) );
}


static void
test_compare_http_transaction_returns_false_if_keys_dont_match() {
  http_transaction x;
  http_transaction y;

  memset( &x, 0, sizeof( http_transaction ) );
  memset( &y, 0, sizeof( http_transaction ) );

  x.handle = ( void * ) 0x1;
  y.handle = ( void * ) 0x2;

  assert_false( compare_http_transaction( &x, &y ) );
}


static void
test_hash_http_transaction_succeeds() {
  unsigned int key = 1;

  assert_int_equal( hash_http_transaction( ( void * ) ( uintptr_t ) key ), 1 );
}


static void
test_notify_main_actually_succeeds() {
  main_efd = 1;
  main_notify_count = 1;

  expect_value( mock_write, fildes, main_efd );
  expect_value( mock_write, buf, &main_notify_count );
  expect_value( mock_write, nbytes, sizeof( uint64_t ) );

  will_return( mock_write, sizeof( uint64_t ) );

  notify_main_actually();
  uint64_t expected_value = 0;
  assert_memory_equal( &main_notify_count, &expected_value, sizeof( uint64_t ) );
}


static void
test_notify_main_succeeds(){
  assert_true( notify_main() );
  uint64_t expected_value = 1;
  assert_memory_equal( &main_notify_count, &expected_value, sizeof( uint64_t ) );
}


static void
test_notify_http_client_actually_succeeds() {
  http_client_efd = 1;
  http_client_notify_count = 1;

  expect_value( mock_write, fildes, http_client_efd );
  expect_value( mock_write, buf, &http_client_notify_count );
  expect_value( mock_write, nbytes, sizeof( uint64_t ) );
  will_return( mock_write, sizeof( uint64_t ) );

  expect_value( mock_set_writable, fd, http_client_efd );
  expect_value( mock_set_writable, state, false );

  notify_http_client_actually( http_client_efd, &http_client_notify_count );
  uint64_t expected_value = 0;
  assert_memory_equal( &http_client_notify_count, &expected_value, sizeof( uint64_t ) );
}


static void
test_notify_http_client_succeeds() {
  http_client_efd = 1;
  http_client_notify_count = 1;

  expect_value( mock_set_writable, fd, http_client_efd );
  expect_value( mock_set_writable, state, true );

  assert_true( notify_http_client() );
  uint64_t expected_value = 2;
  assert_memory_equal( &http_client_notify_count, &expected_value, sizeof( uint64_t ) );
}


static void
test_create_event_fd_succeeds() {
  int fd = 1;
  expect_value( mock_eventfd, initval, 0 );
  expect_value( mock_eventfd, flags, EFD_NONBLOCK );
  will_return( mock_eventfd, fd );

  int ret = create_event_fd();
  assert_int_equal( ret, fd );
}


static void
test_alloc_http_transaction_succeeds() {
  http_transaction *t = alloc_http_transaction();

  assert_true( t != NULL );
  http_transaction expected_data;
  memset( &expected_data, 0, sizeof( http_transaction ) );
  assert_memory_equal( t, &expected_data, sizeof( http_transaction ) );

  free_http_transaction( t );
}


static void
test_free_http_transaction_succeeds() {
  http_transaction *t = alloc_http_transaction();

  free_http_transaction( t );
}


/******************************************************************************
 * Run tests.
 ******************************************************************************/

int
main() {
  UnitTest tests[] = {
    unit_test_setup_teardown( test_init_curl_succeeds, cleanup, cleanup ),
    unit_test( test_finalize_curl_succeeds ),
    unit_test( test_init_http_client_succeeds ),
    unit_test( test_create_http_transaction_db_succeeds ),
    unit_test( test_compare_http_transaction_returns_true_if_keys_match ),
    unit_test( test_compare_http_transaction_returns_false_if_keys_dont_match ),
    unit_test( test_hash_http_transaction_succeeds ),
    unit_test( test_create_event_fd_succeeds ),
    unit_test( test_alloc_http_transaction_succeeds ),
    unit_test( test_free_http_transaction_succeeds ),
    unit_test_setup_teardown( test_notify_main_actually_succeeds, cleanup, cleanup ),
    unit_test_setup_teardown( test_notify_main_succeeds, cleanup, cleanup ),
    unit_test_setup_teardown( test_notify_http_client_actually_succeeds, cleanup, cleanup ),
    unit_test_setup_teardown( test_notify_http_client_succeeds, cleanup, cleanup ),
  };

  setup_leak_detector();

  return run_tests( tests );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
