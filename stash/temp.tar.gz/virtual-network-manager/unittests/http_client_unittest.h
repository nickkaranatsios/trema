/*
 * Author: Yikun Wei
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef HTTP_CLIENT_UNITTEST_H
#define HTTP_CLIENT_UNITTEST_H


#include "common_wrapper.h"
#include "trema.h"


#ifdef curl_slist_append
#undef curl_slist_append
#endif
#define curl_slist_append mock_curl_slist_append
struct curl_slist *mock_curl_slist_append( struct curl_slist *, const char * );


#ifdef curl_slist_free_all
#undef curl_slist_free_all
#endif
#define curl_slist_free_all mock_curl_slist_free_all
void mock_curl_slist_free_all( struct curl_slist * );


#ifdef curl_easy_strerror
#undef curl_easy_strerror
#endif
#define curl_easy_strerror mock_curl_easy_strerror
const char *mock_curl_easy_strerror( CURLcode code );


#ifdef curl_easy_init
#undef curl_easy_init
#endif
#define curl_easy_init mock_curl_easy_init
CURL *mock_curl_easy_init( void );


#ifdef curl_easy_setopt
#undef curl_easy_setopt
#endif
#define curl_easy_setopt mock_curl_easy_setopt
CURLcode mock_curl_easy_setopt( CURL *curl, CURLoption option, ... );


#ifdef curl_easy_cleanup
#undef curl_easy_cleanup
#endif
#define curl_easy_cleanup mock_curl_easy_cleanup
void mock_curl_easy_cleanup( CURL *curl );


#ifdef curl_easy_getinfo
#undef curl_easy_getinfo
#endif
#define curl_easy_getinfo mock_curl_easy_getinfo
CURLcode mock_curl_easy_getinfo( CURL *curl, CURLINFO info, ... );


#ifdef curl_multi_init
#undef curl_multi_init
#endif
#define curl_multi_init mock_curl_multi_init
CURLM *mock_curl_multi_init( void );


#ifdef curl_multi_add_handle
#undef curl_multi_add_handle
#endif
#define curl_multi_add_handle mock_curl_multi_add_handle
CURLMcode mock_curl_multi_add_handle( CURLM *multi_handle, CURL *curl_handle );


#ifdef curl_multi_remove_handle
#undef curl_multi_remove_handle
#endif
#define curl_multi_remove_handle mock_curl_multi_remove_handle
CURLMcode mock_curl_multi_remove_handle( CURLM *multi_handle, CURL *curl_handle );


#ifdef curl_multi_fdset
#undef curl_multi_fdset
#endif
#define curl_multi_fdset mock_curl_multi_fdset
CURLMcode mock_curl_multi_fdset( CURLM *multi_handle, fd_set *read_fd_set, fd_set *write_fd_set, fd_set *exc_fd_set, int *max_fd );


#ifdef curl_multi_strerror
#undef curl_multi_strerror
#endif
#define curl_multi_strerror mock_curl_multi_strerror
const char *mock_curl_multi_strerror( CURLMcode code );


#ifdef curl_multi_perform
#undef curl_multi_perform
#endif
#define curl_multi_perform mock_curl_multi_perform
CURLMcode mock_curl_multi_perform( CURLM *multi_handle, int *running_handles );


#ifdef curl_multi_cleanup
#undef curl_multi_cleanup
#endif
#define curl_multi_cleanup mock_curl_multi_cleanup
CURLMcode mock_curl_multi_cleanup( CURLM *multi_handle );


#ifdef curl_multi_info_read
#undef curl_multi_info_read
#endif
#define curl_multi_info_read mock_curl_multi_info_read
CURLMsg *mock_curl_multi_info_read( CURLM *multi_handle, int *msgs_in_queue );


#ifdef curl_multi_timeout
#undef curl_multi_timeout
#endif
#define curl_multi_timeout mock_curl_multi_timeout
CURLMcode mock_curl_multi_timeout( CURLM *multi_handle, long *milliseconds );


#ifdef create_queue
#undef create_queue
#endif
#define create_queue mock_create_queue
queue *mock_create_queue( void );


#ifdef delete_queue
#undef delete_queue
#endif
#define delete_queue mock_delete_queue
bool mock_delete_queue( queue *queue );


#ifdef enqueue
#undef enqueue
#endif
#define enqueue mock_enqueue
bool mock_enqueue( queue *queue, void *data );


#ifdef dequeue
#undef dequeue
#endif
#define dequeue mock_dequeue
void *mock_dequeue( queue *queue );


#ifdef set_fd_handler
#undef set_fd_handler
#endif
#define set_fd_handler mock_set_fd_handler
void mock_set_fd_handler( int fd, event_fd_callback read_callback, void *read_data, event_fd_callback write_callback, void *write_data );


#ifdef set_writable
#undef set_writable
#endif
#define set_writable mock_set_writable
void mock_set_writable( int fd, bool state );


#ifdef set_readable
#undef set_readable
#endif
#define set_readable mock_set_readable
void mock_set_readable( int fd, bool state );


#ifdef create_hash
#undef create_hash
#endif
#define create_hash mock_create_hash
hash_table* mock_create_hash( const compare_function compare, const hash_function hash );


#ifdef error
#undef error
#endif
#define error mock_error
void mock_error( const char *format, ... );


#ifdef write
#undef write
#endif
#define write mock_write
ssize_t mock_write( int fildes, const void *buf, size_t nbytes );


#ifdef eventfd
#undef eventfd
#endif
#define eventfd mock_eventfd
int mock_eventfd( unsigned int initval, int flags );


#endif // HTTP_CLIENT_UNITTEST_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
