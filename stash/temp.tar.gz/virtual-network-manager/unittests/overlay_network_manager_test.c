/*
 * Author: Satoshi Tsuyama
 *
 * Copyright (C) NEC BIGLOBE, Ltd. 2012
 * NEC Confidential
 */


#include <arpa/inet.h>
#include <inttypes.h>
#include <json/json.h>
#include <mysql/mysql.h>
#include <stdio.h>
#include "common_wrapper.h"
#include "http_client.h"
#include "overlay_network_manager.h"
#include "utilities.h"
#include "unittest.h"


enum {
  OPERATION_ATTACH,
  OPERATION_DETACH,
};


typedef struct {
  uint64_t datapath_id;
  uint32_t vni;
  int operation;
  int port_wait_count;
  unsigned int n_ongoing_http_requests;
  unsigned int n_failed_http_requests;
  overlay_operation_completed_handler callback;
  void *user_data;
} transaction_entry;


extern MYSQL *db;
extern hash_table *transactions;

static list_element *list = NULL;
static transaction_entry *entry_ = NULL;


bool valid_vni( uint32_t vni );
bool valid_reflector_address( const char *address );
bool create_json_to_add_tunnel( char **json_string, uint32_t vni, const char * broadcast_address, uint16_t broadcast_port );
bool create_json_to_add_tep( char **json_string, const char *unicast_address, uint16_t unicast_port );
unsigned int hash_transaction( const void *key );
bool compare_transaction( const void *x, const void *y );
bool create_transaction_db();
bool add_transaction( uint64_t datapath_id, uint32_t vni, int operation,
                      overlay_operation_completed_handler callback, void *user_data );
bool delete_transaction( uint64_t datapath_id, uint32_t vni );
transaction_entry *lookup_transaction( uint64_t datapath_id, uint32_t vni );
bool get_overlay_info( uint32_t vni, uint64_t datapath_id, char **local_address, uint16_t *local_port, char **broadcast_address, uint16_t *broadcast_port );
bool get_reflectors_to_update( list_element **reflectors_to_update, uint32_t vni );
bool get_agent_uri( uint64_t datapath_id, char **uri );
void wait_for_port_to_be_added( void *user_data );
void wait_for_port_to_be_deleted( void *user_data );
void http_transaction_completed( int status, int code, const http_content *content, void *user_data );
bool add_tep_to_packet_reflectors( transaction_entry *entry, uint32_t vni, const char *address, uint16_t port );
bool delete_tep_from_packet_reflectors( transaction_entry *entry, uint32_t vni, const char *address );
bool add_tunnel_to_tep( transaction_entry *entry, uint32_t vni, uint64_t datapath_id, const char *broadcast_address, uint16_t broadcast_port );
bool delete_tunnel_from_tep( transaction_entry *entry, uint32_t vni, uint64_t datapath_id );


/*******************************************************************
 * mock functions.
 *******************************************************************/

static bool call_real_json_object_new_object = false;

json_object *
mock_json_object_new_object() {
  return call_real_json_object_new_object ? json_object_new_object() : ( json_object * ) ( intptr_t ) mock();
}

static bool call_real_json_object_new_int = false;

json_object *
mock_json_object_new_int( int i ) {
  check_expected( i );

  return call_real_json_object_new_int ? json_object_new_int( i ) : ( json_object * ) ( intptr_t ) mock();
}

static bool call_real_json_object_new_string = false;

json_object *
mock_json_object_new_string( const char *s ) {
  check_expected( s );

  return call_real_json_object_new_string ? json_object_new_string( s ) : ( json_object * ) ( intptr_t ) mock();
}

static bool call_real_json_object_object_add = false;

void
mock_json_object_object_add( struct json_object* obj, const char *key, struct json_object *val ) {
  check_expected( obj );
  check_expected( key );
  check_expected( val );
  return call_real_json_object_object_add ? json_object_object_add( obj, key, val ) : ( void ) mock();
}


static bool call_real_json_object_to_json_string = false;

const char *
mock_json_object_to_json_string( json_object *obj ) {
  check_expected( obj );

  return call_real_json_object_to_json_string ? json_object_to_json_string( obj ) : ( const char * ) ( intptr_t ) mock();
}


hash_table *
mock_create_hash( const compare_function compare, const hash_function hash ) {
  check_expected( compare );
  check_expected( hash );

  return ( hash_table * ) ( intptr_t ) mock();
}


void *
mock_insert_hash_entry( hash_table *table, void *key, void *value ) {
  check_expected( table );
  check_expected( key );
  check_expected( value );
  entry_ = key;

  return ( void * ) ( intptr_t ) mock();
}

void *
mock_delete_hash_entry( hash_table *table, void *key ) {
  check_expected( table );
  check_expected( key );

  return ( void * ) ( intptr_t ) mock();
}


void *
mock_lookup_hash_entry( hash_table *table, void *key ) {
  check_expected( table );
  check_expected( key );

  return ( void * ) ( intptr_t ) mock();
}


bool
mock_execute_query( MYSQL *db, const char *format, ... ) {
  check_expected( db );

  char statement[ 512 ];
  va_list args;
  va_start( args, format );
  vsnprintf( statement, sizeof( statement ) - 1, format, args );
  statement[ sizeof( statement ) - 1 ] = '\0';
  va_end( args );

  check_expected( statement );

  return ( bool ) mock();
}


MYSQL_RES * STDCALL
mock_mysql_store_result( MYSQL *mysql ) {
  check_expected( mysql );

  return ( MYSQL_RES * ) ( intptr_t ) mock();
}


const char * STDCALL
mock_mysql_error( MYSQL *mysql ) {
  check_expected( mysql );

  return ( const char * ) ( intptr_t ) mock();
}


unsigned int STDCALL
mock_mysql_num_fields( MYSQL_RES *res ) {
  check_expected( res );

  return ( unsigned int ) mock();
}


my_ulonglong STDCALL
mock_mysql_num_rows( MYSQL_RES *res ) {
  check_expected( res );

  return ( my_ulonglong ) mock();
}


MYSQL_ROW STDCALL
mock_mysql_fetch_row( MYSQL_RES *result ) {
  check_expected( result );

  return ( MYSQL_ROW ) ( intptr_t ) mock();
}


void STDCALL
mock_mysql_free_result( MYSQL_RES *result ) {
  check_expected( result );

  return ( void ) mock();
}


bool
mock_get_port_no_by_name( uint64_t datapath_id, const char *name, uint16_t *port_no ) {
  check_expected( datapath_id );
  check_expected( name );
  check_expected( port_no );

  return ( bool ) mock();
}


bool
mock_do_http_request( uint8_t method, const char *uri, const http_content *content, request_completed_handler completed_callback, void *completed_user_data ) {
  check_expected( method );
  check_expected( uri );
  check_expected( content );
  check_expected( completed_callback );
  check_expected( completed_user_data );

  return ( bool ) mock();
}

bool
mock_add_periodic_event_callback( const time_t seconds, timer_callback callback, void *user_data ) {
  check_expected( seconds );
  check_expected( callback );
  check_expected( user_data );

  return ( bool ) mock();
}

void
mock_free_list( list_element *head ) {
  check_expected( head );
  list = head;
}


void
mock_error( const char *format, ... ) {

  char statement[ 512 ];

  va_list args;
  va_start( args, format );
  vsnprintf( statement, sizeof( statement ) - 1 , format, args );
  statement[ sizeof( statement ) - 1 ] = '\0';
  va_end( args );

  check_expected( statement );

  return ( void ) mock();
}


/*******************************************************************
 *  Test functions.
 *******************************************************************/

// valid_vni() tests.

static void
test_valid_vni_succeeds_if_vni_is_zero() {
  uint32_t vni = 0x00000000;

  assert_true( valid_vni( vni ) );
}


static void
test_valid_vni_succeeds_if_vni_is_upper_bound() {
  uint32_t vni = 0x00ffffff;

  assert_true( valid_vni( vni ) );
}


static void
test_valid_vni_fails_if_vni_is_greater_than_upper_bound() {
  uint32_t vni = 0x01000000;

  assert_false( valid_vni( vni ) );
}


static void
test_valid_vni_fails_with_UINT32_MAX() {
  uint32_t vni = UINT32_MAX;

  assert_false( valid_vni( vni ) );
}


// valid_reflector_address() tests.

static void
test_valid_reflector_address_succeeds_with_classA_address() {
  const char *classa_addr = "1.1.1.1";

  assert_true( valid_reflector_address( classa_addr ) );
}


static void
test_valid_reflector_address_succeeds_with_classB_address() {
  const char *classb_addr = "191.255.255.255";

  assert_true( valid_reflector_address( classb_addr ) );
}


static void
test_valid_reflector_address_succeeds_with_classC_address() {
  const char *classc_addr = "192.22.0.255";

  assert_true( valid_reflector_address( classc_addr ) );
}


static void
test_valid_reflector_address_succeeds_with_classD_address() {
  const char *classd_addr = "224.0.0.255";

  assert_true( valid_reflector_address( classd_addr ) );
}


static void
test_valid_reflector_address_fails_with_loopback() {
  const char *loopback_addr = "127.0.0.1";

  assert_false( valid_reflector_address( loopback_addr ) );
}


static void
test_valid_reflector_address_fails_with_inaddr_any() {
  const char *inaddr_any = "0.0.0.0";

  assert_false( valid_reflector_address( inaddr_any ) );
}

static void
test_valid_reflector_address_fails_with_NULL_address() {
  const char *address = NULL;

  expect_assert_failure( valid_reflector_address( address ) );
}

static void
test_valid_reflector_address_fails_with_alphabetical_address() {
  const char *alphabetical_address = "aaa.bbb.ccc.ddd";

  assert_false( valid_reflector_address( alphabetical_address ) );
}


// create_json_to_add_tunnel() tests.

static void
setup() {
  call_real_json_object_new_object = false;
  call_real_json_object_new_int = false;
  call_real_json_object_new_string = false;
  call_real_json_object_object_add = false;
  call_real_json_object_to_json_string = false;
}

static void
teardown() {
  // Nothing to do...
}


static void
test_create_json_to_add_tunnel_succeeds() {
  char *json_string = NULL;
  uint32_t vni = 0x00000777;
  const char *broadcast_address = "192.168.1.254";
  uint16_t broadcast_port = 0x0077;

  call_real_json_object_new_object = true;
  call_real_json_object_new_int = true;
  call_real_json_object_new_string = true;
  call_real_json_object_object_add = true;
  call_real_json_object_to_json_string = true;

  expect_value( mock_json_object_new_int, i, vni );

  expect_not_value( mock_json_object_object_add, obj, NULL );
  expect_string( mock_json_object_object_add, key, "vni" );
  expect_not_value( mock_json_object_object_add, val, NULL );

  expect_string( mock_json_object_new_string, s, broadcast_address );
  expect_not_value( mock_json_object_to_json_string, obj, NULL );

  expect_not_value( mock_json_object_object_add, obj, NULL );
  expect_string( mock_json_object_object_add, key, "broadcast" );
  expect_not_value( mock_json_object_object_add, val, NULL );

  bool ret = create_json_to_add_tunnel( &json_string, vni, broadcast_address, broadcast_port );
  assert_true( ret );

  assert_string_equal( json_string, "{ \"vni\": 1911, \"broadcast\": \"192.168.1.254\" }" );
  xfree( json_string );
}


static void
test_create_json_to_add_tunnel_aborts_with_NULL_jsonstring() {
  char **json_string = NULL;
  uint32_t vni = 0x00000777;
  const char *broadcast_address = "192.168.1.254";
  uint16_t broadcast_port = 0x0077;

  expect_assert_failure( create_json_to_add_tunnel( json_string, vni, broadcast_address, broadcast_port ) );
}


static void
test_create_json_to_add_tunnel_aborts_with_broadcast_NULL_address() {
  char *json_string = NULL;
  uint32_t vni = 0x00000777;
  const char *broadcast_address = NULL;
  uint16_t broadcast_port = 0x0077;

  expect_assert_failure( create_json_to_add_tunnel( &json_string, vni, broadcast_address, broadcast_port ) );
}


static void
test_create_json_to_add_tunnel_aborts_with_broadcast_port_zero() {
  char *json_string = NULL;
  uint32_t vni = 0x00000777;
  const char *broadcast_address = "192.168.1.254";

  expect_assert_failure( create_json_to_add_tunnel( &json_string, vni, broadcast_address, 0 ) );
}


static void
test_create_json_to_add_tunnel_fails_if_valid_vni_fails() {
  char *json_string = NULL;
  uint32_t vni = 0x01000000;
  const char *broadcast_address = "192.168.1.254";
  uint16_t broadcast_port = 0x0077;

  assert_false( create_json_to_add_tunnel( &json_string, vni, broadcast_address, broadcast_port ) );
}


static void
test_create_json_to_add_tunnel_fails_if_valid_reflector_address_fails() {
  char *json_string = NULL;
  uint32_t vni = 0x00000777;
  const char *broadcast_address = "127.0.0.1";
  uint16_t broadcast_port = 0x0077;

  assert_false( create_json_to_add_tunnel( &json_string, vni, broadcast_address, broadcast_port ) );
}


static void
test_create_json_to_add_tunnel_fails_in_creating_root_object() {
  char *json_string = NULL;
  uint32_t vni = 0x00000777;
  const char *broadcast_address = "192.168.1.254";
  uint16_t broadcast_port = 0x0077;

  will_return( mock_json_object_new_object, NULL );
  assert_false( create_json_to_add_tunnel( &json_string, vni, broadcast_address, broadcast_port ) );
}


static void
test_create_json_to_add_tunnel_fails_in_creating_vni_json_object() {
  char *json_string = NULL;
  uint32_t vni = 0x00000777;
  const char *broadcast_address = "192.168.1.254";
  uint16_t broadcast_port = 0x0077;

  call_real_json_object_new_object = true;

  expect_value( mock_json_object_new_int, i, vni );
  will_return( mock_json_object_new_int, NULL );
  assert_false( create_json_to_add_tunnel( &json_string, vni, broadcast_address, broadcast_port ) );
}


static void
test_create_json_to_add_tunnel_fails_in_creating_broadcast_json_object() {
  char *json_string = NULL;
  uint32_t vni = 0x00000777;
  const char *broadcast_address = "192.168.1.254";
  uint16_t broadcast_port = 0x0077;

  call_real_json_object_new_object = true;
  call_real_json_object_new_int = true;
  call_real_json_object_object_add = true;

  expect_value( mock_json_object_new_int, i, vni );

  expect_not_value( mock_json_object_object_add, obj, NULL );
  expect_string( mock_json_object_object_add, key, "vni" );
  expect_not_value( mock_json_object_object_add, val, NULL );

  expect_string( mock_json_object_new_string, s, broadcast_address );
  will_return( mock_json_object_new_string, NULL );
  assert_false( create_json_to_add_tunnel( &json_string, vni, broadcast_address, broadcast_port ) );
}


static void
test_create_json_to_add_tunnel_fails_in_creating_json_string() {
  char *json_string = NULL;
  uint32_t vni = 0x00000777;
  const char *broadcast_address = "192.168.1.254";
  uint16_t broadcast_port = 0x0077;

  call_real_json_object_new_object = true;
  call_real_json_object_new_int = true;
  call_real_json_object_new_string = true;

  will_return( mock_json_object_to_string,  NULL );
  assert_false( create_json_to_add_tunnel( &json_string, vni, broadcast_address, broadcast_port ) );
}


// create_json_to_add_tep() tests.


static void
test_create_json_to_add_tep_succeeds() {
  char *json_string = NULL;
  const char *unicast_address = "192.168.1.254";
  uint16_t unicast_port = 60000;

  call_real_json_object_new_object = true;
  call_real_json_object_new_string = true;
  call_real_json_object_new_int = true;
  call_real_json_object_object_add = true;
  call_real_json_object_to_json_string = true;

  expect_value( mock_json_object_new_string, s, unicast_address );

  expect_not_value( mock_json_object_object_add, obj, NULL );
  expect_string( mock_json_object_object_add, key, "ip" );
  expect_not_value( mock_json_object_object_add, val, NULL );

  expect_value( mock_json_object_new_int, i, unicast_port );

  expect_not_value( mock_json_object_object_add, obj, NULL );
  expect_string( mock_json_object_object_add, key, "port" );
  expect_not_value( mock_json_object_object_add, val, NULL );

  expect_not_value( mock_json_object_to_json_string, obj, NULL );
  bool ret = create_json_to_add_tep( &json_string, unicast_address, unicast_port );
  assert_true( ret );
  assert_string_equal( json_string, "{ \"ip\": \"192.168.1.254\", \"port\": 60000 }" );
  xfree( json_string );
}


// create_transaction_db() tests.

static void
test_create_transaction_db_succeeds() {
  transactions = NULL;

  expect_value( mock_create_hash, compare, compare_transaction );
  expect_value( mock_create_hash, hash, hash_transaction );
  will_return( mock_create_hash, ( void * ) 0x1 );

  bool ret = create_transaction_db();
  assert_true( ret );
}


// add_transaction() tests.

static void
test_add_transaction_succeeds() {
  uint64_t datapath_id = 0x1;
  uint32_t vni = 0x2;
  int operation = OPERATION_ATTACH;
  overlay_operation_completed_handler callback = ( void * ) 0x3;
  void *user_data = ( void * ) 0x4;

  transactions = ( void * ) 0x5;
  expect_value( mock_insert_hash_entry, table, transactions );
  expect_not_value( mock_insert_hash_entry, key, NULL );
  expect_not_value( mock_insert_hash_entry, value, NULL );
  will_return( mock_insert_hash_entry, NULL );

  bool ret = add_transaction( datapath_id, vni, operation, callback, user_data );
  assert_true( ret );
  assert_memory_equal( &entry_->datapath_id, &datapath_id, sizeof( uint64_t ) );
  assert_int_equal( entry_->vni, vni );
  assert_int_equal( entry_->operation, operation );
  assert_memory_equal( &entry_->callback, &callback, sizeof( overlay_operation_completed_handler ) );
  xfree( entry_ );
}


// delete_transaction() tests.

static void
test_delete_transaction_succeeds() {
  uint64_t datapath_id = 0x1;
  uint32_t vni = 0x2;
  transaction_entry *result_entry = xmalloc( 1 );

  transactions = ( void * ) 0x3;
  expect_value( mock_delete_hash_entry, table, transactions );
  expect_not_value( mock_delete_hash_entry, key, NULL );
  will_return( mock_delete_hash_entry, result_entry );

  bool ret = delete_transaction( datapath_id, vni );
  assert_true( ret );
} 


// lookup_transaction() tests.

static void
test_lookup_transaction_succeeds() {
  uint64_t datapath_id = 0x1;
  uint32_t vni = 0x2;
  transaction_entry entry = {
    .datapath_id = datapath_id,
    .vni =  vni,
    .operation =  0,
    .port_wait_count = 0,
    .n_ongoing_http_requests = 0,
    .n_failed_http_requests = 0,
    .callback = NULL,
    .user_data = NULL,
  };

  transactions = ( void * ) 0x3;
  expect_value( mock_lookup_hash_entry, table, transactions );
  expect_not_value( mock_lookup_hash_entry, key, NULL );
  will_return( mock_lookup_hash_entry, &entry );

  bool ret = lookup_transaction( datapath_id, vni );
  assert_true( ret );
}


// get_overlay_info() tests.

static void
test_get_overlay_info_succeeds() {
  uint32_t vni = 0x1;
  uint64_t datapath_id = 0x2;
  char *local_address = NULL;
  uint16_t local_port;
  char *broadcast_address = NULL;
  uint16_t broadcast_port;
  MYSQL *db_ = ( void * ) 0x3;
  MYSQL_RES *myres = ( void * ) 0x4;
  char broadaddr[] = "192.168.1.254";
  char broadport[] = "60000";
  char *reflector_info[] = { broadaddr, broadport };
  MYSQL_ROW reflector_row = ( MYSQL_ROW ) reflector_info;
  char localaddr[] = "192.168.0.1";
  char localport[] = "60000";
  char *tep_info[] = { localaddr, localport };
  MYSQL_ROW tep_row = ( MYSQL_ROW ) tep_info;

  db = db_;

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select reflectors.broadcast_address,reflectors.broadcast_port from "
                            "overlay_networks,reflectors where overlay_networks.reflector_group_id = reflectors.group_id and "
                            "overlay_networks.slice_id = 1" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, myres );

  expect_value( mock_mysql_num_fields, res, myres );
  will_return( mock_mysql_num_fields, 2 );

  expect_value( mock_mysql_num_rows, res, myres );
  will_return( mock_mysql_num_rows, 1 );

  expect_value( mock_mysql_fetch_row, result, myres );
  will_return( mock_mysql_fetch_row, reflector_row );

  expect_value( mock_mysql_free_result, result, myres );
  will_return( mock_mysql_free_result, NULL );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select local_address,local_port from tunnel_endpoints where datapath_id = 2" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, myres );

  expect_value( mock_mysql_num_fields, res, myres );
  will_return( mock_mysql_num_fields, 2 );

  expect_value( mock_mysql_num_rows, res, myres );
  will_return( mock_mysql_num_rows, 1 );

  expect_value( mock_mysql_fetch_row, result, myres );
  will_return( mock_mysql_fetch_row, tep_row );

  expect_value( mock_mysql_free_result, result, myres );
  will_return( mock_mysql_free_result, NULL );

  bool ret = get_overlay_info( vni, datapath_id, &local_address, &local_port, &broadcast_address, &broadcast_port );
  assert_true( ret );
  xfree( broadcast_address );
  xfree( local_address );
} 



// get_reflectors_to_update() tests.

static void
test_get_reflectors_to_update_succeeds() {
  uint32_t vni = 0x1;
  list_element *reflectors = NULL;
  MYSQL *db_ = ( void * ) 0x2;
  MYSQL_RES *myres = ( void * ) 0x3;
  char reflector_uri[] = "http://192.168.0.1/";
  char *row[] = { reflector_uri };
  MYSQL_ROW myrow = ( MYSQL_ROW ) row;

  db = db_;

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select reflectors.uri from reflectors,overlay_networks "
               "where overlay_networks.reflector_group_id = reflectors.group_id and "
               "overlay_networks.slice_id = 1" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, myres );

  expect_value( mock_mysql_num_fields, res, myres );
  will_return( mock_mysql_num_fields, 1 );

  expect_value( mock_mysql_num_rows, res, myres );
  will_return( mock_mysql_num_rows, 1 );

  expect_value( mock_mysql_fetch_row, result, myres );
  will_return( mock_mysql_fetch_row, myrow );

  expect_value( mock_mysql_fetch_row, result, myres );
  will_return( mock_mysql_fetch_row, NULL );

  expect_value( mock_mysql_free_result, result, myres );
  will_return( mock_mysql_free_result, NULL );

  bool ret = get_reflectors_to_update( &reflectors, vni );
  assert_true( ret );
  for ( list_element *e = reflectors; e != NULL; e = e->next ) {
    if ( e->data != NULL ) {
      xfree( e->data );
    }
  }
  if ( reflectors != NULL ) {
    delete_list( reflectors );
  }
  db = NULL;
}


// get_agent_uri() tests.

static void
test_get_agent_uri_succeeds() {
  uint64_t datapath_id = 0x1;
  char *uri = NULL;
  MYSQL *db_ = ( void * ) 0x2;
  MYSQL_RES *myres = ( void * ) 0x3;
  char agent_uri[] = "http://192.168.0.1/";
  char *agent_uris[] = { agent_uri };
  MYSQL_ROW agent_uri_rows = ( MYSQL_ROW ) agent_uris;

  db = db_;

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select uri from agents "
               "where datapath_id = 1" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, myres );

  expect_value( mock_mysql_num_fields, res, myres );
  will_return( mock_mysql_num_fields, 1 );

  expect_value( mock_mysql_num_rows, res, myres );
  will_return( mock_mysql_num_rows, 1 );

  expect_value( mock_mysql_fetch_row, result, myres );
  will_return( mock_mysql_fetch_row, agent_uri_rows );

  expect_value( mock_mysql_free_result, result, myres );
  will_return( mock_mysql_free_result, NULL );

  bool ret = get_agent_uri( datapath_id, &uri );
  assert_true( ret );
  xfree( uri );
}


// http_transaction_completed()

static void
test_http_transaction_completed_succeeds_if_http_transaction_succeeded_and_http_requests_are_ongoing() {
  int status = HTTP_TRANSACTION_SUCCEEDED;
  int code = 202;
  const http_content *content = ( void * ) 0x1;
  transaction_entry entry = {
    .datapath_id = 0x2,
    .vni = 0x3,
    .operation = OPERATION_ATTACH,
    .port_wait_count = 0,
    .n_ongoing_http_requests = 2,
    .n_failed_http_requests = 0,
    .callback = ( void * ) 0x4,
    .user_data = ( void * ) 0x5,
  };
  void *user_data = &entry;

  http_transaction_completed( status, code, content, user_data );
  assert_int_equal( entry.n_ongoing_http_requests, 1 );
  assert_int_equal( entry.n_failed_http_requests, 0 );
}


static void
test_http_transaction_completed_succeeds_if_http_transaction_failed_and_http_requests_are_ongoing() {
  int status = HTTP_TRANSACTION_FAILED;
  int code = 404;
  const http_content *content = ( void * ) 0x1;
  transaction_entry entry = {
    .datapath_id = 0x2,
    .vni = 0x3,
    .operation = OPERATION_ATTACH,
    .port_wait_count = 0,
    .n_ongoing_http_requests = 2,
    .n_failed_http_requests = 0,
    .callback = ( void * ) 0x4,
    .user_data = ( void * ) 0x5,
  };
  void *user_data = &entry;

  http_transaction_completed( status, code, content, user_data );
  assert_int_equal( entry.n_ongoing_http_requests, 1 );
  assert_int_equal( entry.n_failed_http_requests, 1 );
}


static void
test_http_transaction_completed_succeeds_if_http_transaction_failed_and_code_is_440_and_http_requests_are_ongoing() {
  int status = HTTP_TRANSACTION_FAILED;
  int code = 440;
  const http_content *content = ( void * ) 0x1;
  transaction_entry entry = {
    .datapath_id = 0x2,
    .vni = 0x3,
    .operation = OPERATION_ATTACH,
    .port_wait_count = 0,
    .n_ongoing_http_requests = 2,
    .n_failed_http_requests = 0,
    .callback = ( void * ) 0x4,
    .user_data = ( void * ) 0x5,
  };
  void *user_data = &entry;

  http_transaction_completed( status, code, content, user_data );
  assert_int_equal( entry.n_ongoing_http_requests, 1 );
  assert_int_equal( entry.n_failed_http_requests, 0 );
}


static void
test_http_transaction_completed_succeeds_with_OPERATION_ATTACH_if_all_http_requests_succeeds() {
  int status = HTTP_TRANSACTION_SUCCEEDED;
  int code = 202;
  const http_content *content = ( void * ) 0x1;
  transaction_entry entry = {
    .datapath_id = 0x2,
    .vni = 0x3,
    .operation = OPERATION_ATTACH,
    .port_wait_count = 0,
    .n_ongoing_http_requests = 1,
    .n_failed_http_requests = 0,
    .callback = ( void * ) 0x4,
    .user_data = ( void * ) 0x5,
  };
  void *user_data = &entry;

  expect_value( mock_add_periodic_event_callback, seconds, 1 );
  expect_value( mock_add_periodic_event_callback, callback, wait_for_port_to_be_added );
  expect_value( mock_add_periodic_event_callback, user_data, &entry );
  will_return( mock_add_periodic_event_callback, true );

  http_transaction_completed( status, code, content, user_data );
  assert_int_equal( entry.n_ongoing_http_requests, 0 );
  assert_int_equal( entry.n_failed_http_requests, 0 );
}


static void
test_http_transaction_completed_succeeds_with_OPERATION_DETACH_if_all_http_requests_succeeds() {
  int status = HTTP_TRANSACTION_SUCCEEDED;
  int code = 202;
  const http_content *content = ( void * ) 0x1;
  transaction_entry entry = {
    .datapath_id = 0x2,
    .vni = 0x3,
    .operation = OPERATION_DETACH,
    .port_wait_count = 0,
    .n_ongoing_http_requests = 1,
    .n_failed_http_requests = 0,
    .callback = ( void * ) 0x4,
    .user_data = ( void * ) 0x5,
  };
  void *user_data = &entry;

  http_transaction_completed( status, code, content, user_data );
  assert_int_equal( entry.n_ongoing_http_requests, 0 );
  assert_int_equal( entry.n_failed_http_requests, 0 );
}


// add_tep_to_packet_reflectors() tests.

static void
test_add_tep_to_packet_reflectors_succeeds() {
  uint32_t vni = 0x00ffffff;
  transaction_entry entry = {
    .datapath_id = 0x1,
    .vni = vni,
    .operation = OPERATION_ATTACH,
    .port_wait_count = 0,
    .n_ongoing_http_requests = 0,
    .n_failed_http_requests = 0,
    .callback = ( void * ) 0x2,
    .user_data = ( void * ) 0x3,
  };
  const char *address = "192.168.0.254";
  uint16_t port = 60000;
  MYSQL *db_ = ( void * ) 0x4;
  MYSQL_RES *myres = ( void * ) 0x5;
  char reflector_uri[] = "http://192.168.0.1/";
  char *row[] = { reflector_uri };
  MYSQL_ROW myrow = ( MYSQL_ROW ) row;

  db = db_;

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select reflectors.uri from reflectors,overlay_networks "
               "where overlay_networks.reflector_group_id = reflectors.group_id and "
               "overlay_networks.slice_id = 16777215" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, myres );

  expect_value( mock_mysql_num_fields, res, myres );
  will_return( mock_mysql_num_fields, 1 );

  expect_value( mock_mysql_num_rows, res, myres );
  will_return( mock_mysql_num_rows, 1 );

  expect_value( mock_mysql_fetch_row, result, myres );
  will_return( mock_mysql_fetch_row, myrow );

  expect_value( mock_mysql_fetch_row, result, myres );
  will_return( mock_mysql_fetch_row, NULL );

  expect_value( mock_mysql_free_result, result, myres );
  will_return( mock_mysql_free_result, NULL );

  call_real_json_object_new_object = true;
  call_real_json_object_new_string = true;
  call_real_json_object_new_int = true;
  call_real_json_object_object_add = true;
  call_real_json_object_to_json_string = true;

  expect_value( mock_json_object_new_string, s, address );

  expect_not_value( mock_json_object_object_add, obj, NULL );
  expect_string( mock_json_object_object_add, key, "ip" );
  expect_not_value( mock_json_object_object_add, val, NULL );

  expect_value( mock_json_object_new_int, i, port );

  expect_not_value( mock_json_object_object_add, obj, NULL );
  expect_string( mock_json_object_object_add, key, "port" );
  expect_not_value( mock_json_object_object_add, val, NULL );

  expect_not_value( mock_json_object_to_json_string, obj, NULL );

  expect_value( mock_do_http_request, method, HTTP_METHOD_POST );
  expect_string( mock_do_http_request, uri, "http://192.168.0.1/reflector/16777215" );
  expect_not_value( mock_do_http_request, content, NULL );
  expect_value( mock_do_http_request, completed_callback, http_transaction_completed );
  expect_value( mock_do_http_request, completed_user_data, &entry );
  will_return( mock_do_http_request, true );

  expect_not_value( mock_free_list, head, NULL );

  bool ret = add_tep_to_packet_reflectors( &entry, vni, address, port );
  assert_true( ret );
  assert_int_equal( entry.n_ongoing_http_requests, 1 );
  assert_int_equal( entry.n_failed_http_requests, 0 );
  for ( list_element *e = list; e != NULL; e = e->next ) {
    if ( e->data != NULL ) {
      xfree( e->data );
    }
  }
  if ( list != NULL ) {
    delete_list( list );
  }
}


// delete_tep_from_packet_reflectors() tests.

static void
test_delete_tep_from_packet_reflectors_succeeds() {
  uint32_t vni = 0x00ffffff;
  transaction_entry entry = {
    .datapath_id = 0x1,
    .vni = vni,
    .operation = OPERATION_DETACH,
    .port_wait_count = 0,
    .n_ongoing_http_requests = 0,
    .n_failed_http_requests = 0,
    .callback = ( void * ) 0x2,
    .user_data = ( void * ) 0x3,
  };
  const char *address = "192.168.0.254";
  MYSQL *db_ = ( void * ) 0x4;
  MYSQL_RES *myres = ( void * ) 0x5;
  char reflector_uri[] = "http://192.168.0.1/";
  char *row[] = { reflector_uri };
  MYSQL_ROW myrow = ( MYSQL_ROW ) row;

  db = db_;

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select reflectors.uri from reflectors,overlay_networks "
               "where overlay_networks.reflector_group_id = reflectors.group_id and "
               "overlay_networks.slice_id = 16777215" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, myres );

  expect_value( mock_mysql_num_fields, res, myres );
  will_return( mock_mysql_num_fields, 1 );

  expect_value( mock_mysql_num_rows, res, myres );
  will_return( mock_mysql_num_rows, 1 );

  expect_value( mock_mysql_fetch_row, result, myres );
  will_return( mock_mysql_fetch_row, myrow );

  expect_value( mock_mysql_fetch_row, result, myres );
  will_return( mock_mysql_fetch_row, NULL );

  expect_value( mock_mysql_free_result, result, myres );
  will_return( mock_mysql_free_result, NULL );

  expect_value( mock_do_http_request, method, HTTP_METHOD_DELETE );
  expect_string( mock_do_http_request, uri, "http://192.168.0.1/reflector/16777215/192.168.0.254" );
  expect_value( mock_do_http_request, content, NULL );
  expect_value( mock_do_http_request, completed_callback, http_transaction_completed );
  expect_value( mock_do_http_request, completed_user_data, &entry );
  will_return( mock_do_http_request, true );

  expect_not_value( mock_free_list, head, NULL );

  bool ret = delete_tep_from_packet_reflectors( &entry, vni, address );
  assert_true( ret );
  assert_int_equal( entry.n_ongoing_http_requests, 1 );
  assert_int_equal( entry.n_failed_http_requests, 0 );
  for ( list_element *e = list; e != NULL; e = e->next ) {
    if ( e->data != NULL ) {
      xfree( e->data );
    }
  }
  if ( list != NULL ) {
    delete_list( list );
  }
} 


// add_tunnel_to_tep() tests.

static void
test_add_tunnel_to_tep_succeeds() {
  uint32_t vni = 0x00ffffff;
  uint64_t datapath_id = 0x1;
  transaction_entry entry = {
    .datapath_id = datapath_id,
    .vni = vni,
    .operation = OPERATION_ATTACH,
    .port_wait_count = 0,
    .n_ongoing_http_requests = 0,
    .n_failed_http_requests = 0,
    .callback = ( void * ) 0x2,
    .user_data = ( void * ) 0x3,
  };
  const char *broadcast_address = "192.168.0.254";
  uint16_t broadcast_port = 60000;
  MYSQL *db_ = ( void * ) 0x4;
  MYSQL_RES *myres = ( void * ) 0x5;
  char agent_uri[] = "http://192.168.0.1/";
  char *row[] = { agent_uri };
  MYSQL_ROW myrow = ( MYSQL_ROW ) row;

  db = db_;

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select uri from agents "
               "where datapath_id = 1" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, myres );

  expect_value( mock_mysql_num_fields, res, myres );
  will_return( mock_mysql_num_fields, 1 );

  expect_value( mock_mysql_num_rows, res, myres );
  will_return( mock_mysql_num_rows, 1 );

  expect_value( mock_mysql_fetch_row, result, myres );
  will_return( mock_mysql_fetch_row, myrow );

  expect_value( mock_mysql_free_result, result, myres );
  will_return( mock_mysql_free_result, NULL );

  call_real_json_object_new_object = true;
  call_real_json_object_new_int = true;
  call_real_json_object_new_string = true;
  call_real_json_object_object_add = true;
  call_real_json_object_to_json_string = true;

  expect_value( mock_json_object_new_int, i, vni );

  expect_not_value( mock_json_object_object_add, obj, NULL );
  expect_string( mock_json_object_object_add, key, "vni" );
  expect_not_value( mock_json_object_object_add, val, NULL );

  expect_string( mock_json_object_new_string, s, broadcast_address );
  expect_not_value( mock_json_object_to_json_string, obj, NULL );

  expect_not_value( mock_json_object_object_add, obj, NULL );
  expect_string( mock_json_object_object_add, key, "broadcast" );
  expect_not_value( mock_json_object_object_add, val, NULL );

  expect_value( mock_do_http_request, method, HTTP_METHOD_POST );
  expect_string( mock_do_http_request, uri, "http://192.168.0.1/overlay_networks" );
  expect_not_value( mock_do_http_request, content, NULL );
  expect_value( mock_do_http_request, completed_callback, http_transaction_completed );
  expect_value( mock_do_http_request, completed_user_data, &entry );
  will_return( mock_do_http_request, true );

  bool ret = add_tunnel_to_tep( &entry, vni, datapath_id, broadcast_address, broadcast_port );
  assert_true( ret );
  assert_int_equal( entry.n_ongoing_http_requests, 1 );
  assert_int_equal( entry.n_failed_http_requests, 0 );
}


// delete_tunnel_from_tep() tests.

static void
test_delete_tunnel_from_tep_succeeds() {
  uint32_t vni = 0x00ffffff;
  uint64_t datapath_id = 0x1;
  transaction_entry entry = {
    .datapath_id = datapath_id,
    .vni = vni,
    .operation = OPERATION_DETACH,
    .port_wait_count = 0,
    .n_ongoing_http_requests = 0,
    .n_failed_http_requests = 0,
    .callback = ( void * ) 0x2,
    .user_data = ( void * ) 0x3,
  };
  MYSQL *db_ = ( void * ) 0x4;
  MYSQL_RES *myres = ( void * ) 0x5;
  char agent_uri[] = "http://192.168.0.1/";
  char *row[] = { agent_uri };
  MYSQL_ROW myrow = ( MYSQL_ROW ) row;

  db = db_;

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select uri from agents "
               "where datapath_id = 1" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, myres );

  expect_value( mock_mysql_num_fields, res, myres );
  will_return( mock_mysql_num_fields, 1 );

  expect_value( mock_mysql_num_rows, res, myres );
  will_return( mock_mysql_num_rows, 1 );

  expect_value( mock_mysql_fetch_row, result, myres );
  will_return( mock_mysql_fetch_row, myrow );

  expect_value( mock_mysql_free_result, result, myres );
  will_return( mock_mysql_free_result, NULL );

  expect_value( mock_do_http_request, method, HTTP_METHOD_DELETE );
  expect_string( mock_do_http_request, uri, "http://192.168.0.1/overlay_networks/16777215" );
  expect_value( mock_do_http_request, content, NULL );
  expect_value( mock_do_http_request, completed_callback, http_transaction_completed );
  expect_value( mock_do_http_request, completed_user_data, &entry );
  will_return( mock_do_http_request, true );

  bool ret = delete_tunnel_from_tep( &entry, vni, datapath_id );
  assert_true( ret );
  assert_int_equal( entry.n_ongoing_http_requests, 1 );
  assert_int_equal( entry.n_failed_http_requests, 0 );
}


// attach_to_network() tests.

static void
test_attach_to_network_succeeds() {
  uint64_t datapath_id = 0x1;
  uint32_t vni = 0x2;
  overlay_operation_completed_handler callback = NULL;
  void *user_data = ( void * ) 0x3;
  MYSQL *db_ = ( void * ) 0x4;
  MYSQL_RES *myres = ( void * ) 0x5;
  char broadaddr[] = "192.168.1.254";
  char broadport[] = "60000";
  char *reflector_info[] = { broadaddr, broadport };
  MYSQL_ROW reflector_row = ( MYSQL_ROW ) reflector_info;
  char localaddr[] = "192.168.0.1";
  char localport[] = "60000";
  char *tep_info[] = { localaddr, localport };
  MYSQL_ROW tep_row = ( MYSQL_ROW ) tep_info;
  transaction_entry entry = {
    .datapath_id = datapath_id,
    .vni = vni,
    .operation = OPERATION_ATTACH,
    .port_wait_count = 0,
    .n_ongoing_http_requests = 0,
    .n_failed_http_requests = 0,
    .callback = callback,
    .user_data = user_data
  };


  transactions = ( void * ) 0x6;

  expect_value( mock_lookup_hash_entry, table, transactions );
  expect_not_value( mock_lookup_hash_entry, key, NULL );
  will_return( mock_lookup_hash_entry, NULL );

  expect_value( mock_insert_hash_entry, table, transactions );
  expect_not_value( mock_insert_hash_entry, key, NULL );
  expect_not_value( mock_insert_hash_entry, value, NULL );
  will_return( mock_insert_hash_entry, NULL );

  db = db_;

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select reflectors.broadcast_address,reflectors.broadcast_port from "
                            "overlay_networks,reflectors where overlay_networks.reflector_group_id = reflectors.group_id and "
                            "overlay_networks.slice_id = 2" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, myres );

  expect_value( mock_mysql_num_fields, res, myres );
  will_return( mock_mysql_num_fields, 2 );

  expect_value( mock_mysql_num_rows, res, myres );
  will_return( mock_mysql_num_rows, 1 );

  expect_value( mock_mysql_fetch_row, result, myres );
  will_return( mock_mysql_fetch_row, reflector_row );

  expect_value( mock_mysql_free_result, result, myres );
  will_return( mock_mysql_free_result, NULL );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select local_address,local_port from tunnel_endpoints where datapath_id = 1" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, myres );

  expect_value( mock_mysql_num_fields, res, myres );
  will_return( mock_mysql_num_fields, 2 );

  expect_value( mock_mysql_num_rows, res, myres );
  will_return( mock_mysql_num_rows, 1 );

  expect_value( mock_mysql_fetch_row, result, myres );
  will_return( mock_mysql_fetch_row, tep_row );

  expect_value( mock_mysql_free_result, result, myres );
  will_return( mock_mysql_free_result, NULL );

  expect_value( mock_lookup_hash_entry, table, transactions );
  expect_not_value( mock_lookup_hash_entry, key, NULL );
  will_return( mock_lookup_hash_entry, &entry );

  uint16_t port = 60000;
  char reflector_uri[ 26 ];
  memset( reflector_uri, '\0', sizeof( reflector_uri ) );
  snprintf( reflector_uri, sizeof( reflector_uri ), "http://%s/", localaddr );
  char *reflector_urls[] = { reflector_uri };
  MYSQL_ROW reflector_url_rows = ( MYSQL_ROW ) reflector_urls;

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select reflectors.uri from reflectors,overlay_networks "
               "where overlay_networks.reflector_group_id = reflectors.group_id and "
               "overlay_networks.slice_id = 2" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, myres );

  expect_value( mock_mysql_num_fields, res, myres );
  will_return( mock_mysql_num_fields, 1 );

  expect_value( mock_mysql_num_rows, res, myres );
  will_return( mock_mysql_num_rows, 1 );

  expect_value( mock_mysql_fetch_row, result, myres );
  will_return( mock_mysql_fetch_row, reflector_url_rows );

  expect_value( mock_mysql_fetch_row, result, myres );
  will_return( mock_mysql_fetch_row, NULL );

  expect_value( mock_mysql_free_result, result, myres );
  will_return( mock_mysql_free_result, NULL );

  call_real_json_object_new_object = true;
  call_real_json_object_new_string = true;
  call_real_json_object_new_int = true;
  call_real_json_object_object_add = true;
  call_real_json_object_to_json_string = true;

  expect_string( mock_json_object_new_string, s, localaddr );

  expect_not_value( mock_json_object_object_add, obj, NULL );
  expect_string( mock_json_object_object_add, key, "ip" );
  expect_not_value( mock_json_object_object_add, val, NULL );

  expect_value( mock_json_object_new_int, i, port );

  expect_not_value( mock_json_object_object_add, obj, NULL );
  expect_string( mock_json_object_object_add, key, "port" );
  expect_not_value( mock_json_object_object_add, val, NULL );

  expect_not_value( mock_json_object_to_json_string, obj, NULL );

  expect_value( mock_do_http_request, method, HTTP_METHOD_POST );
  expect_string( mock_do_http_request, uri, "http://192.168.0.1/reflector/2" );
  expect_not_value( mock_do_http_request, content, NULL );
  expect_value( mock_do_http_request, completed_callback, http_transaction_completed );
  expect_value( mock_do_http_request, completed_user_data, &entry );
  will_return( mock_do_http_request, true );

  expect_not_value( mock_free_list, head, NULL );

  char agent_uri[ 26 ];
  memset( agent_uri, '\0', sizeof( agent_uri ) );
  snprintf( agent_uri, sizeof( agent_uri ), "http://%s/", localaddr );
  char *agent_urls[] = { agent_uri };
  MYSQL_ROW agent_url_rows = ( MYSQL_ROW ) agent_urls;

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select uri from agents "
               "where datapath_id = 1" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, myres );

  expect_value( mock_mysql_num_fields, res, myres );
  will_return( mock_mysql_num_fields, 1 );

  expect_value( mock_mysql_num_rows, res, myres );
  will_return( mock_mysql_num_rows, 1 );

  expect_value( mock_mysql_fetch_row, result, myres );
  will_return( mock_mysql_fetch_row, agent_url_rows );

  expect_value( mock_mysql_free_result, result, myres );
  will_return( mock_mysql_free_result, NULL );

  expect_value( mock_json_object_new_int, i, vni );

  expect_not_value( mock_json_object_object_add, obj, NULL );
  expect_string( mock_json_object_object_add, key, "vni" );
  expect_not_value( mock_json_object_object_add, val, NULL );

  expect_string( mock_json_object_new_string, s, broadaddr );
  expect_not_value( mock_json_object_to_json_string, obj, NULL );

  expect_not_value( mock_json_object_object_add, obj, NULL );
  expect_string( mock_json_object_object_add, key, "broadcast" );
  expect_not_value( mock_json_object_object_add, val, NULL );

  expect_value( mock_do_http_request, method, HTTP_METHOD_POST );
  expect_string( mock_do_http_request, uri, "http://192.168.0.1/overlay_networks" );
  expect_not_value( mock_do_http_request, content, NULL );
  expect_value( mock_do_http_request, completed_callback, http_transaction_completed );
  expect_value( mock_do_http_request, completed_user_data, &entry );
  will_return( mock_do_http_request, true );

  int ret = attach_to_network( datapath_id, vni, callback, user_data );
  assert_int_equal( ret, OVERLAY_NETWORK_OPERATION_SUCCEEDED );
  assert_int_equal( entry.n_ongoing_http_requests, 2 );
  assert_int_equal( entry.n_failed_http_requests, 0 );
  xfree( entry_ );
  for ( list_element *e = list; e != NULL; e = e->next ) {
    if ( e->data != NULL ) {
      xfree( e->data );
    }
  }
  if ( list != NULL ) {
    delete_list( list );
  }
}


// detach_from_network() tests.

static void
test_detach_from_network() {
  uint64_t datapath_id = 0x1;
  uint32_t vni = 0x2;
  overlay_operation_completed_handler callback = NULL;
  void *user_data = ( void * ) 0x3;
  MYSQL *db_ = ( void * ) 0x4;
  MYSQL_RES *myres = ( void * ) 0x5;
  char broadaddr[] = "192.168.1.254";
  char broadport[] = "60000";
  char *reflector_info[] = { broadaddr, broadport };
  MYSQL_ROW reflector_rows = ( MYSQL_ROW ) reflector_info;
  char localaddr[] = "192.168.0.1";
  char localport[] = "60000";
  char *tep_info[] = { localaddr, localport };
  MYSQL_ROW tep_row = ( MYSQL_ROW ) tep_info;
  transaction_entry entry = { datapath_id, vni, OPERATION_DETACH, 0, 0, 0, callback, user_data };

  transactions = ( void * ) 0x6;

  expect_value( mock_lookup_hash_entry, table, transactions );
  expect_not_value( mock_lookup_hash_entry, key, NULL );
  will_return( mock_lookup_hash_entry, NULL );

  expect_value( mock_insert_hash_entry, table, transactions );
  expect_not_value( mock_insert_hash_entry, key, NULL );
  expect_not_value( mock_insert_hash_entry, value, NULL );
  will_return( mock_insert_hash_entry, NULL );

  db = db_;

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select reflectors.broadcast_address,reflectors.broadcast_port from "
                            "overlay_networks,reflectors where overlay_networks.reflector_group_id = reflectors.group_id and "
                            "overlay_networks.slice_id = 2" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, myres );

  expect_value( mock_mysql_num_fields, res, myres );
  will_return( mock_mysql_num_fields, 2 );

  expect_value( mock_mysql_num_rows, res, myres );
  will_return( mock_mysql_num_rows, 1 );

  expect_value( mock_mysql_fetch_row, result, myres );
  will_return( mock_mysql_fetch_row, reflector_rows );

  expect_value( mock_mysql_free_result, result, myres );
  will_return( mock_mysql_free_result, NULL );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select local_address,local_port from tunnel_endpoints where datapath_id = 1" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, myres );

  expect_value( mock_mysql_num_fields, res, myres );
  will_return( mock_mysql_num_fields, 2 );

  expect_value( mock_mysql_num_rows, res, myres );
  will_return( mock_mysql_num_rows, 1 );

  expect_value( mock_mysql_fetch_row, result, myres );
  will_return( mock_mysql_fetch_row, tep_row );

  expect_value( mock_mysql_free_result, result, myres );
  will_return( mock_mysql_free_result, NULL );

  expect_value( mock_lookup_hash_entry, table, transactions );
  expect_not_value( mock_lookup_hash_entry, key, NULL );
  will_return( mock_lookup_hash_entry, &entry );

  char agent_uri[ 26 ];
  memset( agent_uri, '\0', sizeof( agent_uri ) );
  snprintf( agent_uri, sizeof( agent_uri ), "http://%s/", localaddr );
  char *agent_urls[] = { agent_uri };
  MYSQL_ROW agent_url_rows = ( MYSQL_ROW ) agent_urls;

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select uri from agents "
               "where datapath_id = 1" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, myres );

  expect_value( mock_mysql_num_fields, res, myres );
  will_return( mock_mysql_num_fields, 1 );

  expect_value( mock_mysql_num_rows, res, myres );
  will_return( mock_mysql_num_rows, 1 );

  expect_value( mock_mysql_fetch_row, result, myres );
  will_return( mock_mysql_fetch_row, agent_url_rows );

  expect_value( mock_mysql_free_result, result, myres );
  will_return( mock_mysql_free_result, NULL );

  expect_value( mock_do_http_request, method, HTTP_METHOD_DELETE );
  expect_string( mock_do_http_request, uri, "http://192.168.0.1/overlay_networks/2" );
  expect_value( mock_do_http_request, content, NULL );
  expect_value( mock_do_http_request, completed_callback, http_transaction_completed );
  expect_value( mock_do_http_request, completed_user_data, &entry );
  will_return( mock_do_http_request, true );

  char reflector_uri[] = "http://192.168.0.3/";
  char *reflector_uris[] = { reflector_uri };
  MYSQL_ROW reflector_uri_rows = ( MYSQL_ROW ) reflector_uris;

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select reflectors.uri from reflectors,overlay_networks "
               "where overlay_networks.reflector_group_id = reflectors.group_id and "
               "overlay_networks.slice_id = 2" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, myres );

  expect_value( mock_mysql_num_fields, res, myres );
  will_return( mock_mysql_num_fields, 1 );

  expect_value( mock_mysql_num_rows, res, myres );
  will_return( mock_mysql_num_rows, 1 );

  expect_value( mock_mysql_fetch_row, result, myres );
  will_return( mock_mysql_fetch_row, reflector_uri_rows );

  expect_value( mock_mysql_fetch_row, result, myres );
  will_return( mock_mysql_fetch_row, NULL );

  expect_value( mock_mysql_free_result, result, myres );
  will_return( mock_mysql_free_result, NULL );

  expect_value( mock_do_http_request, method, HTTP_METHOD_DELETE );
  expect_string( mock_do_http_request, uri, "http://192.168.0.3/reflector/2/192.168.0.1" );
  expect_value( mock_do_http_request, content, NULL );
  expect_value( mock_do_http_request, completed_callback, http_transaction_completed );
  expect_value( mock_do_http_request, completed_user_data, &entry );
  will_return( mock_do_http_request, true );

  expect_not_value( mock_free_list, head, NULL );

  int ret = detach_from_network( datapath_id, vni, callback, user_data );
  assert_int_equal( ret, OVERLAY_NETWORK_OPERATION_SUCCEEDED );
  assert_int_equal( entry.n_ongoing_http_requests, 2 );
  assert_int_equal( entry.n_failed_http_requests, 0 );
  xfree( entry_ );
  for ( list_element *e = list; e != NULL; e = e->next ) {
    if ( e->data != NULL ) {
      xfree( e->data );
    }
  }
  if ( list != NULL ) {
    delete_list( list );
  }
}


int
main( int argc, char *argv[] ) {
  UNUSED( argc );
  UNUSED( argv );

  const UnitTest tests[] = {
    unit_test( test_valid_vni_succeeds_if_vni_is_zero ),
    unit_test( test_valid_vni_succeeds_if_vni_is_upper_bound ),
    unit_test( test_valid_vni_fails_if_vni_is_greater_than_upper_bound ),
    unit_test( test_valid_vni_fails_with_UINT32_MAX ),
    unit_test( test_valid_reflector_address_succeeds_with_classA_address ),
    unit_test( test_valid_reflector_address_succeeds_with_classB_address ),
    unit_test( test_valid_reflector_address_succeeds_with_classC_address ),
    unit_test( test_valid_reflector_address_succeeds_with_classD_address ),
    unit_test( test_valid_reflector_address_fails_with_loopback ),
    unit_test( test_valid_reflector_address_fails_with_inaddr_any ),
    unit_test( test_valid_reflector_address_fails_with_NULL_address ),
    unit_test( test_valid_reflector_address_fails_with_alphabetical_address ),
    unit_test_setup_teardown( test_create_json_to_add_tunnel_succeeds, setup, teardown ),
    unit_test_setup_teardown( test_create_json_to_add_tunnel_aborts_with_NULL_jsonstring, setup, teardown ),
    unit_test_setup_teardown( test_create_json_to_add_tunnel_aborts_with_broadcast_NULL_address, setup, teardown ),
    unit_test_setup_teardown( test_create_json_to_add_tunnel_aborts_with_broadcast_port_zero, setup, teardown ),
    unit_test_setup_teardown( test_create_json_to_add_tunnel_fails_if_valid_vni_fails, setup, teardown ),
    unit_test_setup_teardown( test_create_json_to_add_tunnel_fails_if_valid_reflector_address_fails, setup, teardown ),
    unit_test_setup_teardown( test_create_json_to_add_tunnel_fails_in_creating_root_object, setup, teardown ),
    unit_test_setup_teardown( test_create_json_to_add_tunnel_fails_in_creating_vni_json_object, setup, teardown ),
    unit_test_setup_teardown( test_create_json_to_add_tunnel_fails_in_creating_broadcast_json_object, setup, teardown ),
    unit_test_setup_teardown( test_create_json_to_add_tep_succeeds, setup, teardown ),
    unit_test( test_create_transaction_db_succeeds ),
    unit_test( test_add_transaction_succeeds ),
    unit_test( test_delete_transaction_succeeds ),
    unit_test( test_lookup_transaction_succeeds ),
    unit_test( test_get_overlay_info_succeeds ),
    unit_test( test_get_reflectors_to_update_succeeds ),
    unit_test( test_get_agent_uri_succeeds ),
    unit_test( test_http_transaction_completed_succeeds_if_http_transaction_succeeded_and_http_requests_are_ongoing ),
    unit_test( test_http_transaction_completed_succeeds_if_http_transaction_failed_and_http_requests_are_ongoing ),
    unit_test( test_http_transaction_completed_succeeds_if_http_transaction_failed_and_code_is_440_and_http_requests_are_ongoing ),
    unit_test( test_http_transaction_completed_succeeds_with_OPERATION_ATTACH_if_all_http_requests_succeeds ),
    unit_test( test_add_tep_to_packet_reflectors_succeeds ),
    unit_test( test_delete_tep_from_packet_reflectors_succeeds ),
    unit_test( test_add_tunnel_to_tep_succeeds ),
    unit_test( test_delete_tunnel_from_tep_succeeds ),
    unit_test( test_attach_to_network_succeeds ),
    unit_test( test_detach_from_network ),
  };

  setup_leak_detector();

  return run_tests( tests );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
