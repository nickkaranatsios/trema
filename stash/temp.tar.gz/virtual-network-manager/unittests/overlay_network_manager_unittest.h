/*
 * Author: Satoshi Tsuyama
 *
 * Copyright (C) NEC BIGLOBE, Ltd. 2012
 * NEC Confidential
 */


#ifndef OVERLAY_NETWORK_MANAGER_UNITTEST_H
#define OVERLAY_NETWORK_MANAGER_UNITTEST_H


#include "common_wrapper.h"


#ifdef json_object_new_object
#undef json_object_new_object
#endif
#define json_object_new_object mock_json_object_new_object
json_object *mock_json_object_new_object();

#ifdef json_object_new_int
#undef json_object_new_int
#endif
#define json_object_new_int mock_json_object_new_int
json_object *mock_json_object_new_int( int i );

#ifdef json_object_new_string
#undef json_object_new_string
#endif
#define json_object_new_string mock_json_object_new_string
json_object *mock_json_object_new_string( const char *s );

#ifdef json_object_object_add
#undef json_object_object_add
#endif
#define json_object_object_add mock_json_object_object_add
void mock_json_object_object_add( struct json_object* obj, const char *key, struct json_object *val);

#ifdef json_object_to_json_string
#undef json_object_to_json_string
#endif
#define json_object_to_json_string mock_json_object_to_json_string
const char *mock_json_object_to_json_string( json_object *obj );

#ifdef create_hash
#undef create_hash
#endif
#define create_hash mock_create_hash
hash_table *mock_create_hash( const compare_function compare, const hash_function hash );

#ifdef insert_hash_entry
#undef insert_hash_entry
#endif
#define insert_hash_entry mock_insert_hash_entry
void *mock_insert_hash_entry( hash_table *table, void *key, void *value );

#ifdef delete_hash_entry
#undef delete_hash_entry
#endif
#define delete_hash_entry mock_delete_hash_entry
void *mock_delete_hash_entry( hash_table *table, void *key );

#ifdef lookup_hash_entry
#undef lookup_hash_entry
#endif
#define lookup_hash_entry mock_lookup_hash_entry
void *mock_lookup_hash_entry( hash_table *table, void *key );

#ifdef execute_query
#undef execute_query
#endif
#define execute_query mock_execute_query
bool mock_execute_query( MYSQL *db, const char *format, ... );

#ifdef mysql_store_result
#undef mysql_store_result
#endif
#define mysql_store_result mock_mysql_store_result
MYSQL_RES * STDCALL mock_mysql_store_result( MYSQL *mysql );

#ifdef mysql_error
#undef mysql_error
#endif
#define mysql_error mock_mysql_error
const char * STDCALL mock_mysql_error( MYSQL *mysql );

#ifdef mysql_num_fields
#undef mysql_num_fields
#endif
#define mysql_num_fields mock_mysql_num_fields
unsigned int STDCALL mock_mysql_num_fields( MYSQL_RES *res );

#ifdef mysql_num_rows
#undef mysql_num_rows
#endif
#define mysql_num_rows mock_mysql_num_rows
my_ulonglong STDCALL mock_mysql_num_rows( MYSQL_RES *res );

#ifdef mysql_fetch_row
#undef mysql_fetch_row
#endif
#define mysql_fetch_row mock_mysql_fetch_row
MYSQL_ROW STDCALL mock_mysql_fetch_row( MYSQL_RES *result );

#ifdef mysql_free_result
#undef mysql_free_result
#endif
#define mysql_free_result mock_mysql_free_result
void STDCALL mock_mysql_free_result( MYSQL_RES *result );

#ifdef get_port_no_by_name
#undef get_port_no_by_name
#endif
#define get_port_no_by_name mock_get_port_no_by_name
bool mock_get_port_no_by_name( uint64_t datapath_id, const char *name, uint16_t *port_no );

#ifdef do_http_request
#undef do_http_request
#endif
#define do_http_request mock_do_http_request
bool mock_do_http_request( uint8_t method, const char *uri, const http_content *content, request_completed_handler completed_callback, void *completed_user_data );

#ifdef add_periodic_event_callback
#undef add_periodic_event_callback
#endif
#define add_periodic_event_callback mock_add_periodic_event_callback
bool mock_add_periodic_event_callback( const time_t seconds, timer_callback callback, void *user_data );

#ifdef free_list
#undef free_list
#endif
#define free_list mock_free_list
void mock_free_list( list_element *head );

#endif // OVERLAY_NETWORK_MANAGER_UNITTEST_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */


