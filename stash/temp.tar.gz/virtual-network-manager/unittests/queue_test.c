/*
 * Author: Yasunobu Chiba
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include "common_wrapper.h"
#include "unittest.h"
#include "queue.h"


void collect_garbage( queue *queue );


/******************************************************************************
 * Mock function.
 ******************************************************************************/

void
mock_debug( const char *format, ... ) {
  UNUSED( format );
}


/******************************************************************************
 * Test functions.
 ******************************************************************************/

static void
test_create_queue_succeeds() {
  queue *q = create_queue();
  assert_true( q != NULL );
  assert_int_equal( q->length, 0 );
  assert_true( q->head != NULL );
  assert_true( q->head->data == NULL );
  assert_true( q->head->next == NULL );
  assert_true( q->tail == q->head );
  assert_true( q->divider == q->tail );

  delete_queue( q );
}


void
test_delete_queue_succeeds() {
  queue *q = create_queue();

  assert_true( delete_queue( q ) );
}


void
test_delete_queue_fails_if_queue_is_NULL() {
  expect_assert_failure( delete_queue( NULL ) );
}


void
test_enqueue_succeeds() {
  queue *q = create_queue();

  int *data = xmalloc( sizeof( int ) );
  assert_true( enqueue( q, data ) );
  assert_int_equal( q->length, 1 );
  assert_int_equal( q->tail->data, data );

  delete_queue( q );
}


void
test_enqueue_collects_garbage() {
  queue *q = create_queue();

  int *data = xmalloc( sizeof( int ) );
  enqueue( q, data );
  dequeue( q );

  assert_int_equal( q->divider, q->tail );
  assert_int_not_equal( q->divider, q->head );
  assert_true( enqueue( q, data ) );
  assert_int_equal( q->divider, q->head );

  delete_queue( q );
}


void
test_enqueue_fails_if_queue_is_NULL() {
  int *data = xmalloc( sizeof( int ) );

  expect_assert_failure( enqueue( NULL, data ) );

  xfree( data );
}


void
test_enqueue_fails_if_data_is_NULL() {
  int *data = NULL;
  queue *q = create_queue();

  expect_assert_failure( enqueue( q, data ) );
  assert_int_equal( q->length, 0 );

  delete_queue( q );
}


void
test_enqueue_fails_if_queue_and_data_are_NULL() {
  expect_assert_failure( enqueue( NULL, NULL ) );
}


void
test_dequeue_succeeds() {
  queue *q = create_queue();
  int *expected_data = xmalloc( sizeof( int ) );
  enqueue( q, expected_data );

  void *data = dequeue( q );
  assert_int_equal( data, expected_data );
  assert_int_equal( q->length, 0 );

  delete_queue( q );
  xfree( data );
}


void
test_dequeue_returns_NULL_if_no_data_queued() {
  queue *q = create_queue();

  void *data = dequeue( q );
  assert_int_equal( data, NULL );
  assert_int_equal( q->length, 0 );

  delete_queue( q );
}


void
test_dequeue_fails_if_queue_is_NULL() {
  expect_assert_failure( dequeue( NULL ) );
}


void
test_collect_garbage_fails_if_queue_is_NULL() {
  expect_assert_failure( collect_garbage( NULL ) );
}


/******************************************************************************
 * Run tests.
 ******************************************************************************/

int
main() {
  UnitTest tests[] = {
    unit_test( test_create_queue_succeeds ),
    unit_test( test_delete_queue_succeeds ),
    unit_test( test_delete_queue_fails_if_queue_is_NULL ),
    unit_test( test_enqueue_succeeds ),
    unit_test( test_enqueue_collects_garbage ),
    unit_test( test_enqueue_fails_if_queue_is_NULL ),
    unit_test( test_enqueue_fails_if_data_is_NULL ),
    unit_test( test_enqueue_fails_if_queue_and_data_are_NULL ),
    unit_test( test_dequeue_succeeds ),
    unit_test( test_dequeue_returns_NULL_if_no_data_queued ),
    unit_test( test_dequeue_fails_if_queue_is_NULL ),
    unit_test( test_collect_garbage_fails_if_queue_is_NULL ),
  };

  setup_leak_detector();

  return run_tests( tests );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
