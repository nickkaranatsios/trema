/*
 * Author: Yasunobu Chiba
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include <mysql/mysql.h>
#include <nx.h>
#include "common_wrapper.h"
#include "unittest.h"

#include "queue.h"
#include "overlay_network_manager.h"
#include "switch.h"
#include "transaction_manager.h"
#include "queue.h"


typedef struct {
  uint64_t datapath_id;
  buffer *message;
  succeeded_handler succeeded_callback;
  void *succeeded_user_data;
  failed_handler failed_callback;
  void *failed_user_data;
} openflow_transaction;


openflow_transaction *alloc_openflow_transaction();
void free_openflow_transaction( openflow_transaction *transaction );
bool add_openflow_transaction( queue *transactions, uint64_t datapath_id,
                               buffer *message, succeeded_handler succeeded_callback,
                               void *succeeded_user_data,
                               failed_handler failed_callback,
                               void *failed_user_data );
bool execute_openflow_transactions( queue *transactions );

static void *queued_data = NULL;


/******************************************************************************
 * mock functions.
 *****************************************************************************/


queue *
mock_create_queue( void ) {
  return ( queue * ) ( intptr_t ) mock();
}


bool
mock_delete_queue( queue *queue ) {
  check_expected( queue );

  return ( bool ) mock();
}


bool
mock_enqueue( queue *queue, void *data ) {
  check_expected( queue );
  check_expected( data );

  queued_data = data;
  return ( bool ) mock();
}


void *
mock_dequeue( queue *queue ) {
  check_expected( queue );

  return ( void * ) ( intptr_t ) mock();
}


buffer *
mock_create_nx_flow_mod( const uint32_t transaction_id, const uint64_t cookie, const uint16_t command,
                         const uint8_t table_id, const uint16_t idle_timeout, const uint16_t hard_timeout,
                         const uint16_t priority, const uint32_t buffer_id,
                         const uint16_t out_port, const uint16_t flags,
                         const nx_matches *matches, const openflow_actions *actions ) {
  check_expected( transaction_id );
  check_expected( cookie );
  const uint32_t command32 = command;
  check_expected( command32 );
  const uint32_t table_id32 = table_id;
  check_expected( table_id32 );
  const uint32_t idle_timeout32 = idle_timeout;
  check_expected( idle_timeout32 );
  const uint32_t hard_timeout32 = hard_timeout;
  check_expected( hard_timeout32 );
  const uint32_t priority32 = priority;
  check_expected( priority32 );
  check_expected( buffer_id );
  const uint32_t out_port32 = out_port;
  check_expected( out_port32 );
  const uint32_t flags32 = flags;
  check_expected( flags32 );
  check_expected( matches );
  check_expected( actions );

  return ( buffer * ) ( intptr_t ) mock();
}


bool
mock_append_nx_action_reg_load( openflow_actions *actions, const uint16_t offset, const uint8_t n_bits,
                                const uint32_t destination, const uint64_t value ) {
  check_expected( actions );
  uint32_t offset32 = offset;
  check_expected( offset32 );
  uint32_t n_bits32 = n_bits;
  check_expected( n_bits32 );
  check_expected( destination );
  check_expected( value );

  return ( bool ) mock();
}


bool
mock_append_nx_action_resubmit_table( openflow_actions *actions, const uint16_t in_port, const uint8_t table_id ) {
  check_expected( actions );
  uint32_t in_port32 = in_port;
  check_expected( in_port32 );
  uint32_t table_id32 = table_id;
  check_expected( table_id32 );

  return ( bool ) mock();
}


nx_matches *
mock_create_nx_matches() {

  return ( nx_matches * ) ( intptr_t ) mock();
}


bool
mock_delete_nx_matches( nx_matches *matches ) {
  check_expected( matches );

  return ( bool ) mock();
}



bool
mock_append_nx_match_in_port( nx_matches *matches, uint16_t in_port ) {
  check_expected( matches );
  uint32_t in_port32 = in_port;
  check_expected( in_port32 );

  return ( bool ) mock();
}


bool
mock_append_nx_match_eth_dst( nx_matches *matches, uint8_t addr[ OFP_ETH_ALEN ], uint8_t mask[ OFP_ETH_ALEN ] ) {
  check_expected( matches );
  check_expected( addr );
  check_expected( mask );

  return ( bool ) mock();
}


bool
mock_append_nx_match_reg( nx_matches *matches, uint8_t index, uint32_t value, uint32_t mask ) {
  check_expected( matches );
  uint32_t index32 = index;
  check_expected( index32 );
  check_expected( value );
  check_expected( mask );

  return ( bool ) mock();
}


bool
mock_nx_matches_to_string( const nx_matches *matches, char *str, size_t size ) {
  check_expected( matches );
  check_expected( str );
  check_expected( size );

  return ( bool ) mock();
}


my_ulonglong STDCALL
mock_mysql_num_rows( MYSQL_RES *res ) {
  check_expected( res );

  return ( my_ulonglong ) mock();
}


unsigned int STDCALL
mock_mysql_num_fields( MYSQL_RES *res ) {
  check_expected( res );

  return ( unsigned int ) mock();
}


my_ulonglong STDCALL
mock_mysql_affected_rows( MYSQL *mysql ) {
  check_expected( mysql );

  return ( my_ulonglong ) mock();
}


const char * STDCALL
mock_mysql_error( MYSQL *mysql ) {
  check_expected( mysql );

  return ( const char * ) ( intptr_t ) mock();
}


MYSQL_RES * STDCALL
mock_mysql_store_result( MYSQL *mysql ) {
  check_expected( mysql );

  return ( MYSQL_RES * ) ( intptr_t ) mock();
}


void STDCALL
mock_mysql_free_result( MYSQL_RES *result ) {
  check_expected( result );

  ( void ) mock();
}


MYSQL_ROW STDCALL
mock_mysql_fetch_row( MYSQL_RES *result ) {
  check_expected( result );

  return ( MYSQL_ROW ) ( intptr_t ) mock();
}


bool
mock_execute_query( MYSQL *db, /* const */ char *format, ... ) {
  check_expected( db );

  char *statement = NULL;
  va_list args;
  va_start( args, format );
  vasprintf( &statement, format, args );
  va_end( args );

  check_expected( statement );

  free( statement );

  return ( bool ) mock();
}


int
mock_attach_to_network( uint64_t datapath_id, uint32_t vni,
                        overlay_operation_completed_handler callback, void *user_data ) {
  check_expected( datapath_id );
  check_expected( vni );
  check_expected( callback );
  check_expected( user_data );

  return ( int ) mock();
}


int
mock_detach_from_network( uint64_t datapath_id, uint32_t vni,
                          overlay_operation_completed_handler callback, void *user_data ) {
  check_expected( datapath_id );
  check_expected( vni );
  check_expected( callback );
  check_expected( user_data );

  return ( int ) mock();
}


bool
mock_switch_on_duty( uint64_t datapath_id, /* const */ char *controller_host, pid_t controller_pid ) {
  check_expected( datapath_id );
  check_expected( controller_host );
  check_expected( controller_pid );

  return ( bool ) mock();
}


bool
mock_get_port_no_by_name( uint64_t datapath_id, const char *name, uint16_t *port_no ) {
  check_expected( datapath_id );
  check_expected( name );
  check_expected( port_no );

  return ( bool ) mock();
}


bool
mock_set_switch_port_event_handler( switch_port_event_handler callback, void *user_data ) {
  check_expected( callback );
  check_expected( user_data );

  return ( bool ) mock();
}


bool
mock_execute_transaction( uint64_t datapath_id, const buffer *message,
                          succeeded_handler succeeded_callback, void *succeeded_user_data,
                          failed_handler failed_callback, void *failed_user_data ) {
  check_expected( datapath_id );
  check_expected( message );
  check_expected( succeeded_callback );
  check_expected( succeeded_user_data );
  check_expected( failed_callback );
  check_expected( failed_user_data );

  return ( bool ) mock();
}


void
mock_free_list( list_element *head ) {
  check_expected( head );
}


void
mock_debug( const char *format, ... ) {
  UNUSED( format );
}


/******************************************************************************
 * Test functions.
 ******************************************************************************/

// alloc_openflow_transaction() tests.

static void
test_alloc_openflow_transaction_succeeds() {
  openflow_transaction *transaction = alloc_openflow_transaction();
  uint64_t expected_value = 0;

  assert_true( transaction != NULL );
  assert_memory_equal( &transaction->datapath_id, &expected_value, sizeof( uint64_t ) );
  assert_true( transaction->message == NULL );
  assert_true( transaction->succeeded_callback == NULL );
  assert_true( transaction->succeeded_user_data == NULL );
  assert_true( transaction->failed_callback == NULL );
  assert_true( transaction->failed_user_data == NULL );

  free( transaction );
}


// free_openflow_transaction() tests.

static void
test_free_openflow_transaction_succeeds_if_messeage_is_NULL() {
  openflow_transaction *transaction = alloc_openflow_transaction();

  free_openflow_transaction( transaction );
}


static void
test_free_openflow_transaction_succeeds_if_message_is_not_NULL() {
  openflow_transaction *transaction = alloc_openflow_transaction();

  transaction->message = alloc_buffer_with_length( 256 );
  free_openflow_transaction( transaction );
}


// add_openflow_transaction() tests.

static void
test_add_openflow_transaction_succeeds() {
  queue *transactions = ( void * ) 0x1;
  uint64_t datapath_id = 0x1;
  buffer *message = alloc_buffer_with_length( 256 );
  succeeded_handler succeeded_callback = ( void * ) 0x2;
  void *succeeded_user_data = ( void * ) 0x3;
  failed_handler failed_callback = ( void * ) 0x4;
  void *failed_user_data = ( void * ) 0x5;
  queued_data = NULL;

  expect_value( mock_enqueue, queue, transactions );
  expect_not_value( mock_enqueue, data, NULL);
  will_return( mock_enqueue, true );
  bool ret = add_openflow_transaction( transactions, datapath_id, message, succeeded_callback, succeeded_user_data, failed_callback, failed_user_data );
  assert_true( ret );

  openflow_transaction *transaction = queued_data;
  assert_true( transaction != NULL );
  assert_memory_equal( &transaction->datapath_id, &datapath_id, sizeof( uint64_t ) );
  assert_true( transaction->message == message );
  assert_true( transaction->succeeded_callback == succeeded_callback );
  assert_true( transaction->succeeded_user_data == succeeded_user_data );
  assert_true( transaction->failed_callback == failed_callback );
  assert_true( transaction->failed_user_data = failed_user_data );

  free_openflow_transaction( transaction );
  queued_data = NULL;
}


// execute_openflow_transactions() tests.

static void
test_execute_openflow_transactions_succeeds_if_transaction_queue_is_empty() {
  queue *transactions = ( void * ) 0x1;

  expect_value( mock_dequeue, queue, transactions );
  will_return( mock_dequeue, NULL );
  assert_true( execute_openflow_transactions( transactions ) );
}


static void
test_execute_openflow_transactions_succeeds_if_queue_includes_transaction() {
  queue *transactions = ( void * ) 0x1;
  openflow_transaction *transaction = alloc_openflow_transaction();
  transaction->datapath_id = 0x1;
  transaction->message = alloc_buffer_with_length( 256 );
  transaction->succeeded_callback = ( void * ) 0x2;
  transaction->succeeded_user_data = ( void * ) 0x3;
  transaction->failed_callback = ( void * ) 0x4;
  transaction->failed_user_data = ( void * ) 0x5;

  expect_value( mock_dequeue, queue, transactions );
  will_return( mock_dequeue, transaction );
  expect_value( mock_dequeue, queue, transactions );
  will_return( mock_dequeue, NULL );
  expect_value( mock_execute_transaction, datapath_id, transaction->datapath_id );
  expect_value( mock_execute_transaction, message, transaction->message );
  expect_value( mock_execute_transaction, succeeded_callback, transaction->succeeded_callback );
  expect_value( mock_execute_transaction, succeeded_user_data, transaction->succeeded_user_data );
  expect_value( mock_execute_transaction, failed_callback, transaction->failed_callback );
  expect_value( mock_execute_transaction, failed_user_data, transaction->failed_user_data );
  will_return( mock_execute_transaction, true );

  assert_true( execute_openflow_transactions( transactions ) );
}


static void
test_execute_openflow_transactions_succeeds_if_execute_transaction_fails() {
  queue *transactions = ( void * ) 0x1;
  openflow_transaction *transaction = alloc_openflow_transaction();
  transaction->datapath_id = 0x1;
  transaction->message = alloc_buffer_with_length( 256 );
  transaction->succeeded_callback = ( void * ) 0x2;
  transaction->succeeded_user_data = ( void * ) 0x3;
  transaction->failed_callback = ( void * ) 0x4;
  transaction->failed_user_data = ( void * ) 0x5;

  expect_value( mock_dequeue, queue, transactions );
  will_return( mock_dequeue, transaction );
  expect_value( mock_execute_transaction, datapath_id, transaction->datapath_id );
  expect_value( mock_execute_transaction, message, transaction->message );
  expect_value( mock_execute_transaction, succeeded_callback, transaction->succeeded_callback );
  expect_value( mock_execute_transaction, succeeded_user_data, transaction->succeeded_user_data );
  expect_value( mock_execute_transaction, failed_callback, transaction->failed_callback );
  expect_value( mock_execute_transaction, failed_user_data, transaction->failed_user_data );
  will_return( mock_execute_transaction, false );

  expect_value( mock_enqueue, queue, transactions );
  expect_value( mock_enqueue, data, transaction );
  will_return( mock_enqueue, true );

  assert_true( execute_openflow_transactions( transactions ) );
  free_openflow_transaction( transaction );
}


/******************************************************************************
 * Run tests.
 ******************************************************************************/

int
main() {
  UnitTest tests[] = {
    unit_test( test_alloc_openflow_transaction_succeeds ),
    unit_test( test_free_openflow_transaction_succeeds_if_messeage_is_NULL ),
    unit_test( test_free_openflow_transaction_succeeds_if_message_is_not_NULL ),
    unit_test( test_add_openflow_transaction_succeeds ),
    unit_test( test_execute_openflow_transactions_succeeds_if_transaction_queue_is_empty ),
    unit_test( test_execute_openflow_transactions_succeeds_if_queue_includes_transaction ),
    unit_test( test_execute_openflow_transactions_succeeds_if_execute_transaction_fails ),
  };

  setup_leak_detector();

  return run_tests( tests );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
