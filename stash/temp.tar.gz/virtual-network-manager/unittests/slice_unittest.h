/*
 * Author: Yasunobu Chiba
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef SLICE_UNITTEST_H
#define SLICE_UNITTEST_H

#include "common_wrapper.h"


#ifdef create_queue
#undef create_queue
#endif
#define create_queue mock_create_queue
queue *mock_create_queue( void );


#ifdef delete_queue
#undef delete_queue
#endif
#define delete_queue mock_delete_queue
bool mock_delete_queue( queue *queue );


#ifdef enqueue
#undef enqueue
#endif
#define enqueue mock_enqueue
bool mock_enqueue( queue *queue, void *data );


#ifdef dequeue
#undef dequeue
#endif
#define dequeue mock_dequeue
void *mock_dequeue( queue *queue );


#ifdef create_nx_flow_mod
#undef create_nx_flow_mod
#endif
#define create_nx_flow_mod mock_create_nx_flow_mod
buffer *mock_create_nx_flow_mod( const uint32_t transaction_id, const uint64_t cookie, const uint16_t command,
                                 const uint8_t table_id, const uint16_t idle_timeout, const uint16_t hard_timeout,
                                 const uint16_t priority, const uint32_t buffer_id,
                                 const uint16_t out_port, const uint16_t flags,
                                 const nx_matches *matches, const openflow_actions *actions );


#ifdef append_nx_action_reg_load
#undef append_nx_action_reg_load
#endif
#define append_nx_action_reg_load mock_append_nx_action_reg_load
bool mock_append_nx_action_reg_load( openflow_actions *actions, const uint16_t offset, const uint8_t n_bits,
                                     const uint32_t destination, const uint64_t value );


#ifdef append_nx_action_resubmit_table
#undef append_nx_action_resubmit_table
#endif
#define append_nx_action_resubmit_table mock_append_nx_action_resubmit_table
bool mock_append_nx_action_resubmit_table( openflow_actions *actions, const uint16_t in_port, const uint8_t table_id );


#ifdef create_nx_matches
#undef create_nx_matches
#endif
#define create_nx_matches mock_create_nx_matches
nx_matches *mock_create_nx_matches();


#ifdef delete_nx_matches
#undef delete_nx_matches
#endif
#define delete_nx_matches mock_delete_nx_matches
bool mock_delete_nx_matches( nx_matches *matches );


#ifdef append_nx_match_in_port
#undef append_nx_match_in_port
#endif
#define append_nx_match_in_port mock_append_nx_match_in_port
bool mock_append_nx_match_in_port( nx_matches *matches, uint16_t in_port );


#ifdef append_nx_match_eth_dst
#undef append_nx_match_eth_dst
#endif
#define append_nx_match_eth_dst mock_append_nx_match_eth_dst
bool mock_append_nx_match_eth_dst( nx_matches *matches, uint8_t addr[ OFP_ETH_ALEN ], uint8_t mask[ OFP_ETH_ALEN ] );


#ifdef append_nx_match_reg
#undef append_nx_match_reg
#endif
#define append_nx_match_reg mock_append_nx_match_reg
bool mock_append_nx_match_reg( nx_matches *matches, uint8_t index, uint32_t value, uint32_t mask );


#ifdef nx_matches_to_string
#undef nx_matches_to_string
#endif
#define nx_matches_to_string mock_nx_matches_to_string
bool mock_nx_matches_to_string( const nx_matches *matches, char *str, size_t size );


#ifdef mysql_num_rows
#undef mysql_num_rows
#endif
#define mysql_num_rows mock_mysql_num_rows
my_ulonglong STDCALL mock_mysql_num_rows( MYSQL_RES *res );


#ifdef mysql_num_fields
#undef mysql_num_fields
#endif
#define mysql_num_fields mock_mysql_num_fields
unsigned int STDCALL mock_mysql_num_fields( MYSQL_RES *res );


#ifdef mysql_affected_rows
#undef mysql_affected_rows
#endif
#define mysql_affected_rows mock_mysql_affected_rows
my_ulonglong STDCALL mock_mysql_affected_rows( MYSQL *mysql );


#ifdef mysql_error
#undef mysql_error
#endif
#define mysql_error mock_mysql_error
const char * STDCALL mock_mysql_error( MYSQL *mysql );


#ifdef mysql_store_result
#undef mysql_store_result
#endif
#define mysql_store_result mock_mysql_store_result
MYSQL_RES * STDCALL mock_mysql_store_result( MYSQL *mysql );


#ifdef mysql_free_result
#undef mysql_free_result
#endif
#define mysql_free_result mock_mysql_free_result
void STDCALL mock_mysql_free_result( MYSQL_RES *result );


#ifdef mysql_fetch_row
#undef mysql_fetch_row
#endif
#define mysql_fetch_row mock_mysql_fetch_row
MYSQL_ROW STDCALL mock_mysql_fetch_row( MYSQL_RES *result );



#ifdef execute_query
#undef execute_query
#endif
#define execute_query mock_execute_query
bool mock_execute_query( MYSQL *db, const char *format, ... );


#ifdef attach_to_network
#undef attach_to_network
#endif
#define attach_to_network mock_attach_to_network
int mock_attach_to_network( uint64_t datapath_id, uint32_t vni,
                            overlay_operation_completed_handler callback, void *user_data );


#ifdef detach_from_network
#undef detach_from_network
#endif
#define detach_from_network mock_detach_from_network
int mock_detach_from_network( uint64_t datapath_id, uint32_t vni,
                              overlay_operation_completed_handler callback, void *user_data );


#ifdef switch_on_duty
#undef switch_on_duty
#endif
#define switch_on_duty mock_switch_on_duty
bool mock_switch_on_duty( uint64_t datapath_id, const char *controller_host, pid_t controller_pid );


#ifdef get_port_no_by_name
#undef get_port_no_by_name
#endif
#define get_port_no_by_name mock_get_port_no_by_name
bool mock_get_port_no_by_name( uint64_t datapath_id, const char *name, uint16_t *port_no );


#ifdef set_switch_port_event_handler
#undef set_switch_port_event_handler
#endif
#define set_switch_port_event_handler mock_set_switch_port_event_handler
bool mock_set_switch_port_event_handler( switch_port_event_handler callback, void *user_data );


#ifdef execute_transaction
#undef execute_transaction
#endif
#define execute_transaction mock_execute_transaction
bool mock_execute_transaction( uint64_t datapath_id, const buffer *message,
                               succeeded_handler succeeded_callback, void *succeeded_user_data,
                               failed_handler failed_callback, void *failed_user_data );

#ifdef free_list
#undef free_list
#endif
#define free_list mock_free_list
void mock_free_list( list_element *head );

#endif // SLICE_UNITTEST_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
