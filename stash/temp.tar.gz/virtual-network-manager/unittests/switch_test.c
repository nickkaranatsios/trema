/*
 * Author: Yikun Wei
 *
 * Copyright (C) NEC BIGLOBE, Ltd. 2012
 * NEC Confidential
 */


#include <mysql/mysql.h>
#include "common_wrapper.h"
#include "unittest.h"
#include "switch.h"


my_ulonglong STDCALL
mock_mysql_num_rows( MYSQL_RES *res ) {
  check_expected( res );

  return ( my_ulonglong ) mock();
}


unsigned int STDCALL
mock_mysql_num_fields( MYSQL_RES *res ) {
  check_expected( res );

  return ( unsigned int ) mock();
}


my_ulonglong STDCALL
mock_mysql_affected_rows( MYSQL *mysql ) {
  check_expected( mysql );

  return ( my_ulonglong ) mock();
}


const char * STDCALL
mock_mysql_error( MYSQL *mysql ) {
  check_expected( mysql );

  return ( const char * ) ( intptr_t ) mock();
}


MYSQL_RES * STDCALL
mock_mysql_store_result( MYSQL *mysql ) {
  check_expected( mysql );

  return ( MYSQL_RES * ) ( intptr_t ) mock();
}


void STDCALL
mock_mysql_free_result( MYSQL_RES *result ) {
  check_expected( result );

  ( void ) mock();
}


MYSQL_ROW STDCALL
mock_mysql_fetch_row( MYSQL_RES *result ) {
  check_expected( result );

  return ( MYSQL_ROW ) ( intptr_t ) mock();
}


bool
mock_execute_query( MYSQL *db, const char *format, ... ) {
  check_expected( db );

  char statement[ 512 ];

  va_list args;
  va_start( args, format );
  vsnprintf( statement, sizeof( statement ) - 1 , format, args );
  statement[ sizeof( statement ) -1 ] = '\0';
  va_end( args );

  check_expected( statement );

  return ( bool ) mock();
}


void
mock_error( const char *format, ... ) {

  char statement[ 512 ];

  va_list args;
  va_start( args, format );
  vsnprintf( statement, sizeof( statement ) -1 , format, args );
  statement[ sizeof( statement ) -1 ] = '\0';
  va_end( args );

  check_expected( statement );

  return ( void ) mock();
}


void
mock_handle_switch_port_event( uint8_t event, uint64_t datapath_id, const char *name, uint16_t number, void *user_data ) {
  check_expected( event );
  check_expected( datapath_id );
  check_expected( name );
  check_expected( number );
  check_expected( user_data );

  return ( void ) mock();
}


extern MYSQL *db;
extern switch_port_event_handler port_event_callback;
extern void *port_event_user_data;
bool delete_port_by_datapath_id( uint64_t datapath_id );


/******************************************************************************
 * Test functions.
 ******************************************************************************/

static void
test_init_switch_succeeds() {
  MYSQL *db_ = ( void * ) 0x1;

  assert_true( init_switch( db_ ) );
  assert_true( db == db_ );
}


static void
test_init_switch_fails_if_db_is_NULL() {
  expect_string( mock_error, statement, "MySQL handle must not be null." );
  will_return( mock_error, NULL);

  assert_false( init_switch( NULL ) );
}


static void
test_finalize_switch_succeeds() {
  MYSQL *db_ = ( void * ) 0x1;

  init_switch( db_ );

  assert_true( finalize_switch() );
  assert_true( db == NULL );
  assert_true( port_event_callback == NULL );
  assert_true( port_event_user_data == NULL );
}


static void
test_finalize_switch_fails_if_db_is_NULL() {
  db = NULL;

  expect_string( mock_error, statement, "MySQL handle is already unset." );
  will_return( mock_error, NULL);

  assert_false( finalize_switch() );
}


static void
test_add_switch_succeeds() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;
  const char *hostname = "127.0.0.1";
  pid_t pid = 8888;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "replace into switches (datapath_id,controller_host,controller_pid) values (1,'127.0.0.1',8888)" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_affected_rows, mysql, db_ );
  will_return( mock_mysql_affected_rows, 1 );

  assert_true( add_switch( datapath_id, hostname, pid ) );
  finalize_switch();
}


static void
test_add_switch_fails_if_db_is_NULL() {
  uint64_t datapath_id = 1;
  const char *hostname = "127.0.0.1";
  pid_t pid = 8888;

  db = NULL;

  expect_assert_failure( add_switch( datapath_id, hostname, pid ) );
}


static void
test_add_switch_fails_in_execute_query() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;
  const char *hostname = "127.0.0.1";
  pid_t pid = 8888;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "replace into switches (datapath_id,controller_host,controller_pid) values (1,'127.0.0.1',8888)" );
  will_return( mock_execute_query, false );

  assert_false( add_switch( datapath_id, hostname, pid ) );
  finalize_switch();
}


static void
test_add_switch_fails_if_no_affected_rows() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;
  const char *hostname = "127.0.0.1";
  pid_t pid = 8888;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "replace into switches (datapath_id,controller_host,controller_pid) values (1,'127.0.0.1',8888)" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_affected_rows, mysql, db_ );
  will_return( mock_mysql_affected_rows, 0 );

  expect_string( mock_error, statement, "Failed to add a switch to database ( datapath_id = 0x1, controller_host = 127.0.0.1, controller_pid = 8888 )." );
  will_return( mock_error, NULL );

  assert_false( add_switch( datapath_id, hostname, pid ) );
  finalize_switch();
}


static void
test_add_port_succeeds() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;
  uint16_t port_no = 22;
  const char * name = "vlan2";

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "replace into switch_ports (datapath_id,port_no,name) values (1,22,'vlan2')" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_affected_rows, mysql, db_ );
  will_return( mock_mysql_affected_rows, 1 );

  assert_true( add_port( datapath_id, port_no, name ) );
  finalize_switch();
}


static void
test_add_port_succeeds_if_port_event_callback_is_not_NULL() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;
  uint16_t port_no = 22;
  const char * name = "vlan2";
  void * user_data = ( void * ) 0x2;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "replace into switch_ports (datapath_id,port_no,name) values (1,22,'vlan2')" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_affected_rows, mysql, db_ );
  will_return( mock_mysql_affected_rows, 1 );

  expect_value( mock_handle_switch_port_event, event, SWITCH_PORT_ADDED );
  expect_value( mock_handle_switch_port_event, datapath_id, 1 );
  expect_string( mock_handle_switch_port_event, name, name );
  expect_value( mock_handle_switch_port_event, number, port_no );
  expect_value( mock_handle_switch_port_event, user_data, user_data );
  will_return( mock_handle_switch_port_event, NULL );

  set_switch_port_event_handler( mock_handle_switch_port_event, user_data );
  assert_true( port_event_callback == mock_handle_switch_port_event );
  assert_true( port_event_user_data == user_data );

  assert_true( add_port( datapath_id, port_no, name ) );
  finalize_switch();
}


static void
test_add_port_fails_if_db_is_NULL() {
  uint64_t datapath_id = 1;
  uint16_t port_no = 22;
  const char * name = "vlan2";
  db = NULL;

  expect_assert_failure( add_port( datapath_id, port_no, name ) );
}


static void
test_add_port_fails_if_name_is_NULL() {
  uint64_t datapath_id = 1;
  uint16_t port_no = 22;
  db = ( void * ) 0x1;

  expect_assert_failure( add_port( datapath_id, port_no, NULL ) );
}


static void
test_add_port_fails_in_execute_query() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;
  uint16_t port_no = 22;
  const char * name = "vlan2";

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "replace into switch_ports (datapath_id,port_no,name) values (1,22,'vlan2')" );
  will_return( mock_execute_query, false );

  assert_false( add_port( datapath_id, port_no, name ) );
  finalize_switch();
}


static void
test_add_port_fails_if_no_affected_rows() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;
  uint16_t port_no = 22;
  const char * name = "vlan2";

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "replace into switch_ports (datapath_id,port_no,name) values (1,22,'vlan2')" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_affected_rows, mysql, db_ );
  will_return( mock_mysql_affected_rows, 0 );

  expect_string( mock_error, statement, "Failed to insert a port to database ( datapath_id = 0x1, port_no = 22, name = vlan2 )." );
  will_return( mock_error, NULL );

  assert_false( add_port( datapath_id, port_no, name ) );
  finalize_switch();
}


static void
test_delete_switch_succeeds() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "delete from switches where datapath_id = 1" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_affected_rows, mysql, db_ );
  will_return( mock_mysql_affected_rows, 1 );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "delete from switch_ports where datapath_id = 1" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_affected_rows, mysql, db_ );
  will_return( mock_mysql_affected_rows, 1 );

  assert_true( delete_switch( datapath_id ) );
  finalize_switch();
}


static void
test_delete_switch_fails_if_db_is_NULL() {
  uint64_t datapath_id = 1;
  db = NULL;

  expect_assert_failure( delete_switch( datapath_id ) );
}


static void
test_delete_switch_fails_in_execute_query() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "delete from switches where datapath_id = 1" );
  will_return( mock_execute_query, false );

  assert_false( delete_switch( datapath_id ) );
  finalize_switch();
}


static void
test_delete_switch_fails_if_no_affected_rows() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "delete from switches where datapath_id = 1" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_affected_rows, mysql, db_ );
  will_return( mock_mysql_affected_rows, 0 );

  expect_string( mock_error, statement, "Failed to delete a switch from database ( datapath_id = 0x1 )." );
  will_return( mock_error, NULL );

  assert_false( delete_switch( datapath_id ) );
  finalize_switch();
}


static void
test_delete_switch_fails_in_delete_port_by_datapath_id() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "delete from switches where datapath_id = 1" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_affected_rows, mysql, db_ );
  will_return( mock_mysql_affected_rows, 1 );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "delete from switch_ports where datapath_id = 1" );
  will_return( mock_execute_query, false );

  expect_string( mock_error, statement, "Failed to delete a switch from database ( datapath_id = 0x1 )." );
  will_return( mock_error, NULL );

  assert_false( delete_switch( datapath_id ) );
  finalize_switch();
}


static void
test_delete_port_by_datapath_id_succeeds() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "delete from switch_ports where datapath_id = 1" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_affected_rows, mysql, db_ );
  will_return( mock_mysql_affected_rows, 1 );

  assert_true( delete_port_by_datapath_id( datapath_id ) );
  finalize_switch();
}


static void
test_delete_port_by_datapath_id_succeeds_if_port_event_callback_is_not_NULL() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "delete from switch_ports where datapath_id = 1" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_affected_rows, mysql, db_ );
  will_return( mock_mysql_affected_rows, 1 );

  void * user_data = ( void * ) 0x2;

  expect_value( mock_handle_switch_port_event, event, SWITCH_PORT_DELETED );
  expect_value( mock_handle_switch_port_event, datapath_id, 1 );
  expect_value( mock_handle_switch_port_event, name, NULL );
  expect_value( mock_handle_switch_port_event, number, OFPP_ALL );
  expect_value( mock_handle_switch_port_event, user_data, user_data );
  will_return( mock_handle_switch_port_event, NULL );

  set_switch_port_event_handler( mock_handle_switch_port_event, user_data );
  assert_true( port_event_callback == mock_handle_switch_port_event );
  assert_true( port_event_user_data == user_data );

  assert_true( delete_port_by_datapath_id( datapath_id ) );
  finalize_switch();
}


static void
test_delete_port_by_datapath_id_fails_if_db_is_NULL() {
  uint64_t datapath_id = 1;
  db = NULL;

  expect_assert_failure( delete_port_by_datapath_id( datapath_id ) );
}


static void
test_delete_port_by_datapath_id_fails_in_execute_query() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "delete from switch_ports where datapath_id = 1" );
  will_return( mock_execute_query, false );

  assert_false( delete_port_by_datapath_id( datapath_id ) );
  finalize_switch();
}


static void
test_delete_port_by_datapath_id_fails_if_no_affected_rows() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "delete from switch_ports where datapath_id = 1" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_affected_rows, mysql, db_ );
  will_return( mock_mysql_affected_rows, 0 );

  assert_false( delete_port_by_datapath_id( datapath_id ) );
  finalize_switch();
}


static void
test_delete_port_succeeds() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;
  uint16_t port_no = 22;
  const char * name = "vlan2";

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "delete from switch_ports where datapath_id = 1 and port_no = 22 and name = 'vlan2'" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_affected_rows, mysql, db_ );
  will_return( mock_mysql_affected_rows, 1 );

  assert_true( delete_port( datapath_id, port_no, name ) );
  finalize_switch();
}


static void
test_delete_port_succeeds_if_name_is_NULL() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;
  uint16_t port_no = 22;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "delete from switch_ports where datapath_id = 1 and port_no = 22" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_affected_rows, mysql, db_ );
  will_return( mock_mysql_affected_rows, 1 );

  assert_true( delete_port( datapath_id, port_no, NULL ) );
  finalize_switch();
}


static void
test_delete_port_succeeds_if_port_event_callback_is_not_NULL() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;
  uint16_t port_no = 22;
  const char * name = "vlan2";

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "delete from switch_ports where datapath_id = 1 and port_no = 22 and name = 'vlan2'" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_affected_rows, mysql, db_ );
  will_return( mock_mysql_affected_rows, 1 );

  void *user_data = ( void * ) 0x2;

  expect_value( mock_handle_switch_port_event, event, SWITCH_PORT_DELETED );
  expect_value( mock_handle_switch_port_event, datapath_id, 1 );
  expect_string( mock_handle_switch_port_event, name, name );
  expect_value( mock_handle_switch_port_event, number, port_no );
  expect_value( mock_handle_switch_port_event, user_data, user_data );
  will_return( mock_handle_switch_port_event, NULL );

  set_switch_port_event_handler( mock_handle_switch_port_event, user_data );
  assert_true( port_event_callback == mock_handle_switch_port_event );
  assert_true( port_event_user_data == user_data );

  assert_true( delete_port( datapath_id, port_no, name ) );
  finalize_switch();
}


static void
test_delete_port_fails_if_db_is_NULL() {
  uint64_t datapath_id = 1;
  uint16_t port_no = 22;
  const char * name = "vlan2";
  db = NULL;

  expect_assert_failure( delete_port( datapath_id, port_no, name ) );
}


static void
test_delete_port_fails_in_execute_query() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;
  uint16_t port_no = 22;
  const char * name = "vlan2";

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "delete from switch_ports where datapath_id = 1 and port_no = 22 and name = 'vlan2'" );
  will_return( mock_execute_query, false );

  assert_false( delete_port( datapath_id, port_no, name ) );
  finalize_switch();
}


static void
test_delete_port_fails_in_execute_query_if_name_is_NULL() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;
  uint16_t port_no = 22;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "delete from switch_ports where datapath_id = 1 and port_no = 22" );
  will_return( mock_execute_query, false );

  assert_false( delete_port( datapath_id, port_no, NULL ) );
  finalize_switch();
}


static void
test_delete_port_fails_if_no_affected_rows() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;
  uint16_t port_no = 22;
  const char * name = "vlan2";

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "delete from switch_ports where datapath_id = 1 and port_no = 22 and name = 'vlan2'" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_affected_rows, mysql, db_ );
  will_return( mock_mysql_affected_rows, 0 );

  assert_false( delete_port( datapath_id, port_no, name ) );
  finalize_switch();
}


static void
test_delete_switch_by_host_pid_succeeds() {
  MYSQL *db_ = ( void * ) 0x1;
  const char *hostname = "127.0.0.1";
  pid_t pid = 8888;
  MYSQL_RES *res = ( void * ) 0x2;
  char dpid[] = "5";
  char *rows[] = { dpid };
  MYSQL_ROW row = ( MYSQL_ROW ) rows;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select datapath_id from switches where controller_host = '127.0.0.1' and controller_pid = 8888" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, res );

  expect_value( mock_mysql_num_rows, res, res );
  will_return( mock_mysql_num_rows, 1 );

  expect_value( mock_mysql_num_fields, res, res );
  will_return( mock_mysql_num_fields, 1 );

  expect_value( mock_mysql_fetch_row, result, res );
  will_return( mock_mysql_fetch_row, row );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "delete from switches where datapath_id = 5" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_affected_rows, mysql, db_ );
  will_return( mock_mysql_affected_rows, 1 );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "delete from switch_ports where datapath_id = 5" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_affected_rows, mysql, db_ );
  will_return( mock_mysql_affected_rows, 1 );

  expect_value( mock_mysql_fetch_row, result, res );
  will_return( mock_mysql_fetch_row, NULL );

  expect_value( mock_mysql_free_result, result, res );
  will_return( mock_mysql_free_result, NULL );

  assert_true( delete_switch_by_host_pid( hostname, pid ) );
  finalize_switch();
}


static void
test_delete_switch_by_host_pid_succeeds_if_no_row() {
  MYSQL *db_ = ( void * ) 0x1;
  const char *hostname = "127.0.0.1";
  pid_t pid = 8888;
  MYSQL_RES *res = ( void * ) 0x2;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select datapath_id from switches where controller_host = '127.0.0.1' and controller_pid = 8888" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, res );

  expect_value( mock_mysql_num_rows, res, res );
  will_return( mock_mysql_num_rows, 0 );

  expect_value( mock_mysql_free_result, result, res );
  will_return( mock_mysql_free_result, NULL );

  assert_true( delete_switch_by_host_pid( hostname, pid ) );
  finalize_switch();
}


static void
test_delete_switch_by_host_pid_fails_if_db_is_NULL() {
  const char *hostname = "127.0.0.1";
  pid_t pid = 8888;
  db = NULL;

  expect_assert_failure( delete_switch_by_host_pid( hostname, pid ) );
}


static void
test_delete_switch_by_host_pid_fails_in_execute_query() {
  MYSQL *db_ = ( void * ) 0x1;
  const char *hostname = "127.0.0.1";
  pid_t pid = 8888;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select datapath_id from switches where controller_host = '127.0.0.1' and controller_pid = 8888" );
  will_return( mock_execute_query, false );

  assert_false( delete_switch_by_host_pid( hostname, pid ) );
  finalize_switch();
}


static void
test_delete_switch_by_host_pid_fails_if_no_result() {
  MYSQL *db_ = ( void * ) 0x1;
  const char *hostname = "127.0.0.1";
  pid_t pid = 8888;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select datapath_id from switches where controller_host = '127.0.0.1' and controller_pid = 8888" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, NULL );

  expect_value( mock_mysql_error, mysql, db_ );
  will_return( mock_mysql_error, "vnet" );

  expect_string( mock_error, statement, "Failed to retrieve result from database ( vnet )." );
  will_return( mock_error, NULL );

  assert_false( delete_switch_by_host_pid( hostname, pid ) );
  finalize_switch();
}


static void
test_delete_switch_by_host_pid_fails_if_mysql_num_fields_is_not_equal_to_1() {
  MYSQL *db_ = ( void * ) 0x1;
  const char *hostname = "127.0.0.1";
  pid_t pid = 8888;
  MYSQL_RES *res = ( void * ) 0x2;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select datapath_id from switches where controller_host = '127.0.0.1' and controller_pid = 8888" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, res );

  expect_value( mock_mysql_num_rows, res, res );
  will_return( mock_mysql_num_rows, 1 );

  expect_value( mock_mysql_num_fields, res, res );
  will_return( mock_mysql_num_fields, 2 );

  expect_assert_failure( delete_switch_by_host_pid( hostname, pid ) );
  finalize_switch();
}


static void
test_delete_switch_by_host_pid_fails_if_datapath_id_is_not_numeric() {
  MYSQL *db_ = ( void * ) 0x1;
  const char *hostname = "127.0.0.1";
  pid_t pid = 8888;
  MYSQL_RES *res = ( void * ) 0x2;
  char dpid[] = "Y";
  char *rows[] = { dpid };
  MYSQL_ROW row = ( MYSQL_ROW ) rows;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select datapath_id from switches where controller_host = '127.0.0.1' and controller_pid = 8888" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, res );

  expect_value( mock_mysql_num_rows, res, res );
  will_return( mock_mysql_num_rows, 1 );

  expect_value( mock_mysql_num_fields, res, res );
  will_return( mock_mysql_num_fields, 1 );

  expect_value( mock_mysql_fetch_row, result, res );
  will_return( mock_mysql_fetch_row, row );

  expect_string( mock_error, statement, "Invalid datapath_id ( Y )." );
  will_return( mock_error, NULL );

  expect_value( mock_mysql_fetch_row, result, res );
  will_return( mock_mysql_fetch_row, NULL );

  expect_value( mock_mysql_free_result, result, res );
  will_return( mock_mysql_free_result, NULL );

  assert_false( delete_switch_by_host_pid( hostname, pid ) );
  finalize_switch();
}


static void
test_delete_switch_by_host_pid_fails_in_delete_switch() {
  MYSQL *db_ = ( void * ) 0x1;
  const char *hostname = "127.0.0.1";
  pid_t pid = 8888;
  MYSQL_RES *res = ( void * ) 0x2;
  char dpid[] = "5";
  char *rows[] = { dpid };
  MYSQL_ROW row = ( MYSQL_ROW ) rows;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select datapath_id from switches where controller_host = '127.0.0.1' and controller_pid = 8888" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, res );

  expect_value( mock_mysql_num_rows, res, res );
  will_return( mock_mysql_num_rows, 1 );

  expect_value( mock_mysql_num_fields, res, res );
  will_return( mock_mysql_num_fields, 1 );

  expect_value( mock_mysql_fetch_row, result, res );
  will_return( mock_mysql_fetch_row, row );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "delete from switches where datapath_id = 5" );
  will_return( mock_execute_query, false );

  expect_value( mock_mysql_fetch_row, result, res );
  will_return( mock_mysql_fetch_row, NULL );

  expect_value( mock_mysql_free_result, result, res );
  will_return( mock_mysql_free_result, NULL );

  assert_false( delete_switch_by_host_pid( hostname, pid ) );
  finalize_switch();
}


static void
test_switch_on_duty_succeeds() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;
  const char *hostname = "127.0.0.1";
  pid_t pid = 8888;
  MYSQL_RES *res = ( void * ) 0x2;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select datapath_id from switches where datapath_id = 1 and controller_host = '127.0.0.1' and controller_pid = 8888" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, res );

  expect_value( mock_mysql_num_rows, res, res );
  will_return( mock_mysql_num_rows, 1 );

  expect_value( mock_mysql_free_result, result, res );
  will_return( mock_mysql_free_result, NULL );

  assert_true( switch_on_duty( datapath_id, hostname, pid ) );
  finalize_switch();
}


static void
test_switch_on_duty_fails_if_db_is_NULL() {
  uint64_t datapath_id = 1;
  const char *hostname = "127.0.0.1";
  pid_t pid = 8888;
  db = NULL;

  expect_assert_failure( switch_on_duty( datapath_id, hostname, pid ) );
}


static void
test_switch_on_duty_fails_in_execute_query() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;
  const char *hostname = "127.0.0.1";
  pid_t pid = 8888;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select datapath_id from switches where datapath_id = 1 and controller_host = '127.0.0.1' and controller_pid = 8888" );
  will_return( mock_execute_query, false );

  assert_false( switch_on_duty( datapath_id, hostname, pid ) );
  finalize_switch();
}


static void
test_switch_on_duty_fails_if_no_result() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;
  const char *hostname = "127.0.0.1";
  pid_t  pid = 8888;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select datapath_id from switches where datapath_id = 1 and controller_host = '127.0.0.1' and controller_pid = 8888" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, NULL );

  expect_value( mock_mysql_error, mysql, db_ );
  will_return( mock_mysql_error, "vnet" );

  expect_string( mock_error, statement, "Failed to retrieve result from database ( vnet )." );
  will_return( mock_error, NULL );

  assert_false( switch_on_duty( datapath_id, hostname, pid ) );
  finalize_switch();
}


static void
test_switch_on_duty_fails_if_no_row() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;
  const char *hostname = "127.0.0.1";
  pid_t pid = 8888;
  MYSQL_RES *res = ( void * ) 0x2;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select datapath_id from switches where datapath_id = 1 and controller_host = '127.0.0.1' and controller_pid = 8888" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, res );

  expect_value( mock_mysql_num_rows, res, res );
  will_return( mock_mysql_num_rows, 0 );

  expect_value( mock_mysql_free_result, result, res );
  will_return( mock_mysql_free_result, NULL );

  assert_false( switch_on_duty( datapath_id, hostname, pid ) );
  finalize_switch();
}


static void
test_set_switch_port_event_handler_succeeds(){
  switch_port_event_handler speh = ( void * ) 0x1;
  void * user_data = ( void * ) 0x2;

  assert_true( set_switch_port_event_handler( speh, user_data ) );
  assert_true( port_event_callback == speh );
  assert_true( port_event_user_data == user_data );
}


static void
test_get_port_no_by_name_succeeds() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;
  const char *name = "vlan2";
  uint16_t port_no;
  MYSQL_RES *res = ( void * ) 0x2;
  char dpid[] = "5";
  char *rows[] = { dpid };
  MYSQL_ROW row = ( MYSQL_ROW ) rows;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select port_no from switch_ports where datapath_id = 1 and name = 'vlan2'" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, res );

  expect_value( mock_mysql_num_fields, res, res );
  will_return( mock_mysql_num_fields, 1 );

  expect_value( mock_mysql_num_rows, res, res );
  will_return( mock_mysql_num_rows, 1 );

  expect_value( mock_mysql_fetch_row, result, res );
  will_return( mock_mysql_fetch_row, row );

  expect_value( mock_mysql_free_result, result, res );
  will_return( mock_mysql_free_result, NULL );

  assert_true( get_port_no_by_name( datapath_id, name, &port_no ) );
  finalize_switch();
}


static void
test_get_port_no_by_name_fails_if_db_is_NULL() {
  uint64_t datapath_id = 1;
  const char *name = "vlan2";
  uint16_t port_no;
  db = NULL;

  expect_assert_failure( get_port_no_by_name( datapath_id, name, &port_no ) );
}


static void
test_get_port_no_by_name_fails_if_name_is_NULL() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;
  uint16_t port_no;

  init_switch( db_ );

  expect_assert_failure( get_port_no_by_name( datapath_id, NULL, &port_no ) );
}


static void
test_get_port_no_by_name_fails_if_port_no_is_NULL() {
  MYSQL *db_ = ( void * ) 0x1;
  const char *name = "vlan2";
  uint64_t datapath_id = 1;

  init_switch( db_ );

  expect_assert_failure( get_port_no_by_name( datapath_id, name, NULL ) );
}


static void
test_get_port_no_by_name_fails_in_execute_query() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;
  const char *name = "vlan2";
  uint16_t port_no;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select port_no from switch_ports where datapath_id = 1 and name = 'vlan2'" );
  will_return( mock_execute_query, false );

  assert_false( get_port_no_by_name( datapath_id, name, &port_no ) );
  finalize_switch();
}


static void
test_get_port_no_by_name_fails_if_no_result() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;
  const char *name = "vlan2";
  uint16_t port_no;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select port_no from switch_ports where datapath_id = 1 and name = 'vlan2'" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, NULL );

  expect_value( mock_mysql_error, mysql, db_ );
  will_return( mock_mysql_error, "vnet" );

  expect_string( mock_error, statement, "Failed to retrieve result from database ( vnet )." );
  will_return( mock_error, NULL );

  assert_false( get_port_no_by_name( datapath_id, name, &port_no ) );
  finalize_switch();
}


static void
test_get_port_no_by_name_aborts_if_num_field_is_not_one() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;
  const char *name = "vlan2";
  uint16_t port_no;
  MYSQL_RES *res = ( void * ) 0x2;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select port_no from switch_ports where datapath_id = 1 and name = 'vlan2'" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, res );

  expect_value( mock_mysql_num_fields, res, res );
  will_return( mock_mysql_num_fields, 0 );

  expect_assert_failure( get_port_no_by_name( datapath_id, name, &port_no ) );
  finalize_switch();
}


static void
test_get_port_no_by_name_fails_if_no_row() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;
  const char *name = "vlan2";
  uint16_t port_no;
  MYSQL_RES *res = ( void * ) 0x2;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select port_no from switch_ports where datapath_id = 1 and name = 'vlan2'" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, res );

  expect_value( mock_mysql_num_fields, res, res );
  will_return( mock_mysql_num_fields, 1 );

  expect_value( mock_mysql_num_rows, res, res );
  will_return( mock_mysql_num_rows, 0 );

  expect_value( mock_mysql_free_result, result, res );
  will_return( mock_mysql_free_result, NULL );

  assert_false( get_port_no_by_name( datapath_id, name, &port_no ) );
  finalize_switch();
}


static void
test_get_port_no_by_name_aborts_if_row_is_NULL() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;
  const char *name = "vlan2";
  uint16_t port_no;
  MYSQL_RES *res = ( void * ) 0x2;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select port_no from switch_ports where datapath_id = 1 and name = 'vlan2'" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, res );

  expect_value( mock_mysql_num_fields, res, res );
  will_return( mock_mysql_num_fields, 1 );

  expect_value( mock_mysql_num_rows, res, res );
  will_return( mock_mysql_num_rows, 1 );

  expect_value( mock_mysql_fetch_row, result, res );
  will_return( mock_mysql_fetch_row, NULL );

  expect_assert_failure( get_port_no_by_name( datapath_id, name, &port_no ) );
  finalize_switch();
}


static void
test_get_port_no_by_name_fails_if_port_no_is_not_numeric() {
  MYSQL *db_ = ( void * ) 0x1;
  uint64_t datapath_id = 1;
  const char *name = "vlan2";
  uint16_t port_no;
  MYSQL_RES *res = ( void * ) 0x2;
  char dpid[] = "W";
  char *rows[] = { dpid };
  MYSQL_ROW row = ( MYSQL_ROW ) rows;

  init_switch( db_ );

  expect_value( mock_execute_query, db, db_ );
  expect_string( mock_execute_query, statement, "select port_no from switch_ports where datapath_id = 1 and name = 'vlan2'" );
  will_return( mock_execute_query, true );

  expect_value( mock_mysql_store_result, mysql, db_ );
  will_return( mock_mysql_store_result, res );

  expect_value( mock_mysql_num_fields, res, res );
  will_return( mock_mysql_num_fields, 1 );

  expect_value( mock_mysql_num_rows, res, res );
  will_return( mock_mysql_num_rows, 1 );

  expect_value( mock_mysql_fetch_row, result, res );
  will_return( mock_mysql_fetch_row, row );

  expect_string( mock_error, statement, "Invalid port number ( W )." );
  will_return( mock_error, NULL );

  expect_value( mock_mysql_free_result, result, res );
  will_return( mock_mysql_free_result, NULL );

  assert_false( get_port_no_by_name( datapath_id, name, &port_no ) );
  assert_true( port_no = OFPP_NONE );
  finalize_switch();
}


/******************************************************************************
 * Run tests.
 ******************************************************************************/

int
main() {
  UnitTest tests[] = {
    unit_test( test_init_switch_succeeds ),
    unit_test( test_init_switch_fails_if_db_is_NULL ),
    unit_test( test_finalize_switch_succeeds ),
    unit_test( test_finalize_switch_fails_if_db_is_NULL ),
    unit_test( test_add_switch_succeeds ),
    unit_test( test_add_switch_fails_if_db_is_NULL ),
    unit_test( test_add_switch_fails_in_execute_query ),
    unit_test( test_add_switch_fails_if_no_affected_rows ),
    unit_test( test_add_port_succeeds ),
    unit_test( test_add_port_succeeds_if_port_event_callback_is_not_NULL ),
    unit_test( test_add_port_fails_if_db_is_NULL ),
    unit_test( test_add_port_fails_if_name_is_NULL ),
    unit_test( test_add_port_fails_in_execute_query ),
    unit_test( test_add_port_fails_if_no_affected_rows ),
    unit_test( test_delete_switch_succeeds ),
    unit_test( test_delete_switch_fails_if_db_is_NULL ),
    unit_test( test_delete_switch_fails_in_execute_query ),
    unit_test( test_delete_switch_fails_if_no_affected_rows ),
    unit_test( test_delete_switch_fails_in_delete_port_by_datapath_id ),
    unit_test( test_delete_port_by_datapath_id_succeeds ),
    unit_test( test_delete_port_by_datapath_id_succeeds_if_port_event_callback_is_not_NULL ),
    unit_test( test_delete_port_by_datapath_id_fails_if_db_is_NULL ),
    unit_test( test_delete_port_by_datapath_id_fails_in_execute_query ),
    unit_test( test_delete_port_by_datapath_id_fails_if_no_affected_rows ),
    unit_test( test_delete_port_succeeds ),
    unit_test( test_delete_port_succeeds_if_name_is_NULL ),
    unit_test( test_delete_port_succeeds_if_port_event_callback_is_not_NULL ),
    unit_test( test_delete_port_fails_if_db_is_NULL ),
    unit_test( test_delete_port_fails_in_execute_query ),
    unit_test( test_delete_port_fails_in_execute_query_if_name_is_NULL ),
    unit_test( test_delete_port_fails_if_no_affected_rows ),
    unit_test( test_delete_switch_by_host_pid_succeeds ),
    unit_test( test_delete_switch_by_host_pid_succeeds_if_no_row ),
    unit_test( test_delete_switch_by_host_pid_fails_if_db_is_NULL ),
    unit_test( test_delete_switch_by_host_pid_fails_in_execute_query ),
    unit_test( test_delete_switch_by_host_pid_fails_if_no_result ),
    unit_test( test_delete_switch_by_host_pid_fails_if_mysql_num_fields_is_not_equal_to_1 ),
    unit_test( test_delete_switch_by_host_pid_fails_if_datapath_id_is_not_numeric ),
    unit_test( test_delete_switch_by_host_pid_fails_in_delete_switch ),
    unit_test( test_switch_on_duty_succeeds ),
    unit_test( test_switch_on_duty_fails_if_db_is_NULL ),
    unit_test( test_switch_on_duty_fails_in_execute_query ),
    unit_test( test_switch_on_duty_fails_if_no_result ),
    unit_test( test_switch_on_duty_fails_if_no_row ),
    unit_test( test_set_switch_port_event_handler_succeeds ),
    unit_test( test_get_port_no_by_name_succeeds ),
    unit_test( test_get_port_no_by_name_fails_if_db_is_NULL ),
    unit_test( test_get_port_no_by_name_fails_if_name_is_NULL ),
    unit_test( test_get_port_no_by_name_fails_if_port_no_is_NULL ),
    unit_test( test_get_port_no_by_name_fails_in_execute_query ),
    unit_test( test_get_port_no_by_name_fails_if_no_result ),
    unit_test( test_get_port_no_by_name_aborts_if_num_field_is_not_one ),
    unit_test( test_get_port_no_by_name_fails_if_no_row ),
    unit_test( test_get_port_no_by_name_aborts_if_row_is_NULL ),
    unit_test( test_get_port_no_by_name_fails_if_port_no_is_not_numeric ),
  };

  setup_leak_detector();

  return run_tests( tests );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
