/*
 * Author: Yasunobu Chiba
 *         Yikun Wei
 *
 * Copyright (C) NEC BIGLOBE, Ltd. 2012
 * NEC Confidential
 */


#ifndef SWITCH_UNITTEST_H
#define SWITCH_UNITTEST_H

#include "common_wrapper.h"


#ifdef mysql_num_rows
#undef mysql_num_rows
#endif
#define mysql_num_rows mock_mysql_num_rows
my_ulonglong STDCALL mock_mysql_num_rows( MYSQL_RES *res );


#ifdef mysql_num_fields
#undef mysql_num_fields
#endif
#define mysql_num_fields mock_mysql_num_fields
unsigned int STDCALL mock_mysql_num_fields( MYSQL_RES *res );


#ifdef mysql_affected_rows
#undef mysql_affected_rows
#endif
#define mysql_affected_rows mock_mysql_affected_rows
my_ulonglong STDCALL mock_mysql_affected_rows( MYSQL *mysql );


#ifdef mysql_error
#undef mysql_error
#endif
#define mysql_error mock_mysql_error
const char * STDCALL mock_mysql_error( MYSQL *mysql );


#ifdef mysql_store_result
#undef mysql_store_result
#endif
#define mysql_store_result mock_mysql_store_result
MYSQL_RES * STDCALL mock_mysql_store_result( MYSQL *mysql );


#ifdef mysql_free_result
#undef mysql_free_result
#endif
#define mysql_free_result mock_mysql_free_result
void STDCALL mock_mysql_free_result( MYSQL_RES *result );


#ifdef mysql_fetch_row
#undef mysql_fetch_row
#endif
#define mysql_fetch_row mock_mysql_fetch_row
MYSQL_ROW STDCALL mock_mysql_fetch_row( MYSQL_RES *result );


#ifdef execute_query
#undef execute_query
#endif
#define execute_query mock_execute_query
bool mock_execute_query( MYSQL *db, const char *format, ... );


#ifdef error
#undef error
#endif
#define error mock_error
void mock_error( const char *format, ... );


#ifdef handle_switch_port_event
#undef handle_switch_port_event
#endif
#define handle_switch_port_event mock_handle_switch_port_event
void handle_switch_port_event( uint8_t event, uint64_t datapath_id, const char *name, uint16_t number, void *user_data );


#endif // SWITCH_UNITTEST_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
