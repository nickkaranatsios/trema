/*
 * Author: Yasunobu Chiba
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include "common_wrapper.h"
#include "unittest.h"
#include "transaction_manager.h"


/******************************************************************************
 * Test functions.
 ******************************************************************************/


/******************************************************************************
 * Run tests.
 ******************************************************************************/

int
main() {
  UnitTest tests[] = {
  };

  setup_leak_detector();

  return run_tests( tests );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
