/*
 * Author: Satoshi Tsuyama
 *
 * Copyright (C) NEC BIGLOBE, Ltd. 2012
 * NEC Confidential
 */


#include "common_wrapper.h"
#include "unittest.h"
#include "utilities.h"


/******************************************************************************
 * Test functions.
 ******************************************************************************/


static void
test_free_list_succeeds() {
  list_element *head = NULL;
  void *data = xmalloc( 1 );

  create_list( &head );
  append_to_tail( &head, data );
  free_list( head ); 
}


static void
test_free_list_succeeds_with_multiple_elements() {
  list_element *head = NULL;
  void *data[ 2 ] = { NULL, NULL };
  data[ 0 ] = xmalloc( 1 );
  data[ 1 ] = xmalloc( 1 );

  create_list( &head );
  append_to_tail( &head, data[ 0 ] );
  append_to_tail( &head, data[ 1 ] );
  free_list( head ); 
}


static void
test_free_list_succeeds_without_elements() {
  list_element *head = NULL;

  create_list( &head );
  free_list( head ); 
}


static void
test_free_list_succeeds_without_data() {
  list_element *head = NULL;

  create_list( &head );
  append_to_tail( &head, NULL );
  free_list( head );
}


int
main() {
  UnitTest tests[] = {
    unit_test( test_free_list_succeeds ),
    unit_test( test_free_list_succeeds_with_multiple_elements ),
    unit_test( test_free_list_succeeds_without_elements ),
    unit_test( test_free_list_succeeds_without_data ),
  };

  setup_leak_detector();

  return run_tests( tests );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
