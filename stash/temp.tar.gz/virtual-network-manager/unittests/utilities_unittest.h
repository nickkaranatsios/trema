/*
 * Author: Satoshi Tsuyama
 *
 * Copyright (C) NEC BIGLOBE, Ltd. 2012
 * NEC Confidential
 */


#ifndef UTILITIES_UNITTEST_H
#define UTILITIES_UNITTEST_H

#include "common_wrapper.h"



#endif
