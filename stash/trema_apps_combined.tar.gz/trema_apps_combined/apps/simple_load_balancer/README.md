Simple Server Load Balancer Application
=======================================

This application is created for the tutorial session at Kyushu Institute of
Technology. It is intended for persons who want to understand how to handle
packet-in events and how to install flow entries to OpenFlow switches. Thus,
it does not provide full load balancer functionality and definitely does not
work in real network environment.
