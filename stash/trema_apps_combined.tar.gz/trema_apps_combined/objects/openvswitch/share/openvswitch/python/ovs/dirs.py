import os
PKGDATADIR = os.environ.get("OVS_PKGDATADIR", """/home/nick/trema_apps_combined/objects/openvswitch/share/openvswitch""")
RUNDIR = os.environ.get("OVS_RUNDIR", """/home/nick/trema_apps_combined/tmp/sock""")
LOGDIR = os.environ.get("OVS_LOGDIR", """/home/nick/trema_apps_combined/objects/openvswitch/var/log/openvswitch""")
BINDIR = os.environ.get("OVS_BINDIR", """/home/nick/trema_apps_combined/objects/openvswitch/bin""")
