#include <stdio.h>
#include <stdint.h>
#include <assert.h>
#include <time.h>
#include <pthread.h>
#include <errno.h>
#include "async-util.h"
#include "async-lock.h"



static thread_info_list thread_list;
static pthread_mutex_t thread_mutex;
static pthread_cond_t read_cond[ MAX_SECTIONS ] = PTHREAD_COND_INITIALIZER;
static pthread_cond_t write_cond[ MAX_SECTIONS ] = PTHREAD_COND_INITIALIZER;

static uint32_t read_count[ MAX_SECTIONS ] = 0;
static const uint32_t writer_waiting[ MAX_SECTIONS ] = 0x80000000;

LOCK_OBJ( thread )
UNLOCK_OBJ( thread )
GET_OBJ_INFO( thread )


static inline int
compare_and_swap( const uint32_t old, const uint32_t new, uint32_t *address ) {
  int ret = 0;

  if ( *address == old ) {
    *address = new;
    ret = 1;
  }
  return ret;
}

static void
lock_read_begin( enum lock_section section ) {
  uint32_t new_value;
  uint32_t old_value;

  struct thread_info *thread = get_thread_info();
  assert( thread != NULL );

  if ( thread->sections[ section ]->incremented_read == writer_waiting[ section ] ) {
    trema_abort();
  }
  struct timespec ts;
  int ret;


  do {
again:
    old_value = read_count[ section ];

    if ( ( old_value & writer_waiting[ section ] ) != 0 && thread->sections[ section ]->incremented_read == 0 ) {
       pthread_mutex_lock( &thread_lock[ section ] );
       {
         ts.tv_sec = 0;
         ts.tv_nsec = 5 * 1000; // take a long 5ms snooze for testing
         ret = pthread_cond_timedwait( &read_cond[ section ], &thread_mutex[ section ], &ts );
       }
       pthread_mutex_unlock( &thread_lock[ section ] );
       if ( ret == ETIMEDOUT ) {
         goto again;
       }
    }
    new_value = old_value + 1;
  } while ( !compare_and_swap( old_value, new_value, &read_count[ section ] ) );

  thread->sections[ section ]->incremented_read++;
}

static void
lock_read_end( enum lock_section section ) {
  struct thread_info *thread = get_thread_info();

  assert( thread != NULL );
  thread_lock();
  read_count[ section ]--;
  thread_unlock();
  thread->sections[ section ]->incremented_read--;
  if ( read_count[ section ] == writer_waiting[ section ] ) {
    pthread_mutex_lock( &thread_mutex[ section ] );
    {
      pthread_cond_signal( &write_cond[ section ] );
    }
    pthread_mutex_unlock( &thread_mutex );
  }


void add_thread( void ) {
  struct thread_info *thread = get_thread_info();

  if ( thread != NULL ) {
    error( "init_thread_info has been called twice for thread id %ld", thread->thread_id );
    return;
  }
  thread = ( struct thread_info * ) xmalloc( sizeof( *thread ) );
  thread->thread_id = current_thread();
  thread->incremented_read = 0;
  thread_lock();
  ALLOC_GROW( thread_list.threads, thread_list.threads_nr + 1, thread_list.threads_alloc );
  thread_list.threads[ thread_list.threads_nr++ ] = thread;
  thread_unlock();

}
