#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <assert.h>
#include <time.h>
#include <pthread.h>
#include <errno.h>
#include "wrapper.h"
#include "log.h"
#include "trema_wrapper.h"
#include "async-util.h"
#include "async-lock.h"


static struct thread_info_list thread_list;
static struct lock_group lck_grp[ MAX_SECTIONS ] = { 
  LCK_GRP_INIT,
  LCK_GRP_INIT
};
static pthread_mutex_t global_mutex;
LOCK_OBJ( global )
UNLOCK_OBJ( global )
GET_OBJ_INFO( thread )


static inline int
compare_and_swap( const uint32_t old, const uint32_t new, uint32_t *address ) {
  int ret = 0;

  if ( *address == old ) {
    *address = new;
    ret = 1;
  }
  return ret;
}

static void
lock_read_begin( enum lock_section section ) {
  uint32_t new_value;
  uint32_t old_value;

  struct thread_info *thread = get_thread_info();
  assert( thread != NULL );

  if ( thread->attr( incremented_read, section ) == lck_grp[ section ].writer_waiting ) {
    trema_abort();
  }
  struct timespec ts;
  int ret;


  do {
again:
    old_value = lck_grp[ section ].read_count;

    if ( ( old_value & lck_grp[ section ].writer_waiting ) != 0 && thread->attr( incremented_read, section ) == 0 ) {
      pthread_mutex_lock( &thread->attr( mutex, section ) );
      {
        ts.tv_sec = 0;
        ts.tv_nsec = 5 * 1000; // take a long 5ms snooze for testing
        ret = pthread_cond_timedwait( &thread->attr( read_cond, section ), &thread->attr( mutex, section ), &ts );
      }
      pthread_mutex_unlock( &thread->attr( mutex, section ) );
      if ( ret == ETIMEDOUT ) {
        goto again;
      }
    }
    new_value = old_value + 1;
  } while ( !compare_and_swap( old_value, new_value, &lck_grp[ section ].read_count ) );

  thread->attr( incremented_read, section )++;
}

static void
lock_read_end( enum lock_section section ) {
  struct thread_info *thread = get_thread_info();

  assert( thread != NULL );
  pthread_mutex_lock( &lck_grp[ section ].mutex );
  lck_grp[ section ].read_count--;
  pthread_mutex_unlock( &lck_grp[ section ].mutex );
  thread->attr( incremented_read, section )--;
  if ( lck_grp[ section ].read_count == lck_grp[ section ].writer_waiting ) {
    pthread_mutex_lock( &thread->attr( mutex, section ) );
    {
      pthread_cond_signal( &thread->attr( write_cond, section ) );
    }
    pthread_mutex_unlock( &thread->attr( mutex, section ) );
  }
}

static int
lock_write_begin( enum lock_section section ) {
  struct thread_info *thread = get_thread_info();
  assert( thread != NULL );

  if ( thread->attr( incremented_read, section ) != 0 ) {
    return -1;
  }
  pthread_mutex_lock( &lck_grp[ section ].mutex );
  lck_grp[ section ].read_count |= lck_grp[ section ].writer_waiting;

  struct timespec ts;
  int ret;


again:
  if ( lck_grp[ section ].read_count == lck_grp[ section ].writer_waiting ) {
    thread->attr( incremented_read, section ) = lck_grp[ section ].writer_waiting;
    return 0;
  } else {
    pthread_mutex_lock( &thread->attr( mutex, section ) );
    {
      ts.tv_sec = 0;
      ts.tv_nsec = 5 * 1000; // take a long 5ms snooze for testing
      ret = pthread_cond_timedwait( &thread->attr( write_cond, section ), &thread->attr( mutex, section ), &ts );
    }
    pthread_mutex_unlock( &thread->attr( mutex, section ) );
    if ( ret == ETIMEDOUT ) {
      goto again;
    }
  }
}


static void
lock_write_end( enum lock_section section ) {
  struct thread_info *thread = get_thread_info();
  assert( thread != NULL );

  if ( thread->attr( incremented_read, section ) != lck_grp[ section ].writer_waiting ) {
    trema_abort();
  }
  lck_grp[ section ].read_count &= ~( lck_grp[ section ].writer_waiting );
  pthread_mutex_unlock( &lck_grp[ section ].mutex );
  thread->attr( incremented_read, section ) = 0;
  pthread_mutex_lock( &thread->attr( mutex, section ) ) ;
  {
    pthread_cond_signal( &thread->attr( read_cond, section ) );
  }
  pthread_mutex_unlock( &thread->attr( mutex, section ) ) ;
}


void 
add_thread( void ) {
  struct thread_info *thread = get_thread_info();

  if ( thread != NULL ) {
    error( "init_thread_info has been called twice for thread id %ld", thread->thread_id );
    return;
  }
  thread = ( struct thread_info * ) xmalloc( sizeof( *thread ) );
  thread->thread_id = current_thread();
  memset( &thread->sections, 0, sizeof( struct section ) * MAX_SECTIONS );
  global_lock();
  ALLOC_GROW( thread_list.threads, thread_list.threads_nr + 1, thread_list.threads_alloc );
  thread_list.threads[ thread_list.threads_nr++ ] = thread;
  global_unlock();
}


void
event_read_begin( void ) {
  return lock_read_begin( EVENT_SECTION );
}


void
event_read_end( void ) {
  return lock_read_end( EVENT_SECTION );
}


void
timer_read_begin( void ) {
  return lock_read_begin( TIMER_SECTION );
}


void
timer_read_end( void ) {
  return lock_read_end( TIMER_SECTION );
}


int
event_write_begin( void ) {
  return lock_write_begin( EVENT_SECTION );
}


void
event_write_end( void ) {
  return lock_write_end( EVENT_SECTION );
}
