/* 
 * File:   async-lock.h
 * Author: nick
 *
 * Created on October 26, 2012, 3:08 PM
 */

#ifndef ASYNC_LOCK_H
#define	ASYNC_LOCK_H

#ifdef	__cplusplus
extern "C" {
#endif


enum lock_section {
  EVENT_SECTION,
  TIMER_SECTION,
  MAX_SECTIONS
};


struct sections {

};

#ifdef	__cplusplus
}
#endif

#endif	/* ASYNC_LOCK_H */

