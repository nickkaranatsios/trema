/* 
 * File:   async-lock.h
 * Author: nick
 *
 * Created on October 26, 2012, 3:08 PM
 */

#ifndef ASYNC_LOCK_H
#define	ASYNC_LOCK_H

#ifdef	__cplusplus
extern "C" {
#endif


enum lock_section {
  EVENT_SECTION,
  TIMER_SECTION,
  MAX_SECTIONS
};


struct lock_group {
  pthread_mutex_t mutex;
  uint32_t read_count;
  uint32_t writer_waiting;
};

#define LCK_GRP_INIT { .mutex = PTHREAD_MUTEX_INITIALIZER, .read_count = 0, .writer_waiting = 0x80000000 }

struct section {
  pthread_mutex_t mutex;
  pthread_cond_t read_cond;
  pthread_cond_t write_cond;
  uint32_t incremented_read;
};

struct thread_info {
  pthread_t thread_id;
  struct section sections[ MAX_SECTIONS ];
};

#define attr( attr, idx ) \
  sections[ ( idx ) ].attr

struct thread_info_list {
  struct thread_info **threads;
  uint32_t threads_nr;
  uint32_t threads_alloc;
};


void event_read_begin( void );
void timer_read_begin( void );

int event_write_begin( void );
int timer_write_begin( void );

void event_read_end( void );
void timer_read_end( void );

void event_write_end( void );
void timer_write_end( void );

void add_thread( void );

#ifdef	__cplusplus
}
#endif

#endif	/* ASYNC_LOCK_H */

