/* 
 * File:   async-lock.h
 * Author: nick
 *
 * Created on October 26, 2012, 3:08 PM
 */

#ifndef ASYNC_LOCK_H
#define	ASYNC_LOCK_H

#ifdef	__cplusplus
extern "C" {
#endif


enum lock_section {
  EVENT_SECTION,
  TIMER_SECTION,
  MAX_SECTIONS
};


struct sections {
  uint32_t incremented_read;
};


struct thread_info {
  pthread_t thread_id;
  struct sections sections[ MAX_SECTIONS ];
};


struct thread_info_list {
  struct thread_info **threads;
  uint32_t threads_nr;
  uint32_t threads_alloc;
};


void event_read_begin( void );
void timer_read_begin( void );

int event_write_begin( void );
int timer_write_begin( void );

void event_read_end( void );
void timer_read_end( void );

void event_write_end( void );
void timer_write_end( void );


#ifdef	__cplusplus
}
#endif

#endif	/* ASYNC_LOCK_H */

