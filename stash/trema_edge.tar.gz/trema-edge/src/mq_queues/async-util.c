#include <pthread.h>
#include <sys/eventfd.h>


pthread_t
current_thread( void ) {
  return pthread_self();
}


int
create_event_fd( void ) {
  return eventfd( 0, EFD_NONBLOCK );
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
