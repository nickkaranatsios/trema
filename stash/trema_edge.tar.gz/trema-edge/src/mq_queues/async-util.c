#include <pthread.h>

pthread_t
current_thread() {
  return pthread_self();
}

