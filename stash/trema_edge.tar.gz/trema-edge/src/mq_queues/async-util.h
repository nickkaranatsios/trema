/* 
 * File:   async-util.h
 * Author: co2kara
 *
 * Created on October 26, 2012, 2:03 AM
 */

#ifndef ASYNC_UTIL_H
#define	ASYNC_UTIL_H

#ifdef	__cplusplus
extern "C" {
#endif

#define ARRAY_SIZE( x ) ( sizeof( x ) / sizeof( x[ 0 ] ) )
#define ALLOC_NR( x ) ( ( ( x ) * 16 ) * 3 / 2 )

#define ALLOC_GROW( x, nr, alloc ) \
  do { \
    if ( ( nr ) > alloc ) { \
      if ( ( ALLOC_NR( alloc ) < ( nr ) ) ) { \
        alloc = ( nr ); \
      } \
      else { \
        alloc = ALLOC_NR( alloc ); \
      } \
      x = xrealloc( ( x ), alloc * sizeof( *( x ) ) ); \
    } \
   } while ( 0 )

pthread_t current_thread();        


#ifdef	__cplusplus
}
#endif

#endif	/* ASYNC_UTIL_H */

