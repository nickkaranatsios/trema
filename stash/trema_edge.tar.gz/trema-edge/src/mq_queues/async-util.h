/* 
 * File:   async-util.h
 * Author: co2kara
 *
 * Created on October 26, 2012, 2:03 AM
 */

#ifndef ASYNC_UTIL_H
#define	ASYNC_UTIL_H

#ifdef	__cplusplus
extern "C" {
#endif

#define ARRAY_SIZE( x ) ( sizeof( x ) / sizeof( x[ 0 ] ) )
#define ALLOC_NR( x ) ( ( ( x ) * 16 ) * 3 / 2 )

#define ALLOC_GROW( x, nr, alloc ) \
  do { \
    if ( ( nr ) > alloc ) { \
      if ( ( ALLOC_NR( alloc ) < ( nr ) ) ) { \
        alloc = ( nr ); \
      } \
      else { \
        alloc = ALLOC_NR( alloc ); \
      } \
      x = xrealloc( ( x ), alloc * sizeof( *( x ) ) ); \
    } \
   } while ( 0 )


#define LOCK_OBJ( name ) \
static inline void \
name##_lock( void ) { \
  pthread_mutex_lock( &name##_mutex ); \
}


#define UNLOCK_OBJ( name ) \
static inline void \
name##_unlock( void ) { \
  pthread_mutex_unlock( &name##_mutex ); \
}


#define GET_OBJ_INFO( name ) \
static struct name##_info * \
get_##name##_info() { \
  uint32_t i; \
  uint32_t nr; \
\
  pthread_t self = current_thread(); \
  nr = name##_list.name##s_nr; \
\
  for( i = 0; i < nr; i++ ) { \
    if ( name##_list.name##s[ i ] != NULL ) { \
      if ( name##_list.name##s[ i ]->thread_id == self ) { \
        return name##_list.name##s[ i ]; \
      } \
    } \
  } \
  for ( i = 0; i < nr; i++ ) { \
    if ( name##_list.name##s[ i ] != NULL ) { \
      if ( !name##_list.name##s[ i ]->thread_id ) { \
        return name##_list.name##s[ i ]; \
      } \
    } \
  } \
  return NULL; \
}


#define DELETE_OBJ_INFO( name ) \
static void \
delete_##name##_info( struct name##_info *obj ) { \
  uint32_t i; \
  uint32_t nr; \
\
  nr = name##_list.name##s_nr; \
\
  for ( i = 0; i < nr; i++ ) { \
    if ( name##_list.name##s[ i ] != NULL ) { \
      if ( name##_list.name##s[ i ] == obj ) { \
        xfree( obj ); \
        name##_list.name##s[ i ] = NULL; \
        break; \
      } \
    } \
  } \
}


pthread_t current_thread();        


#ifdef	__cplusplus
}
#endif

#endif	/* ASYNC_UTIL_H */

