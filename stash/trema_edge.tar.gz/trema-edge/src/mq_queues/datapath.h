#ifndef DATAPATH_H
#define DATAPATH_H


struct datapath {
  struct async packetizer;
  const char *qname;
};


#endif
