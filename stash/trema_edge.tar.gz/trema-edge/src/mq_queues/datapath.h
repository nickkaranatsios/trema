#ifndef DATAPATH_H
#define DATAPATH_H


struct datapath {
  struct async packetizer;
  const char *qname;
  uint64_t recv_count;
  uint64_t send_count;
};


#endif
