#ifndef DATAPATH_H
#define DATAPATH_H


struct datapath {
  struct async packetizer;
  const char *qname;
  message_queue *own_queue;
  message_queue *peer_queue;
  uint64_t recv_count;
  uint64_t send_count;
  int efd;
};


#endif
