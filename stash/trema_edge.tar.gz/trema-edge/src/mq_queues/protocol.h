#ifndef PROTOCOL_H
#define PROTOCOL_H


struct protocol {
  struct async packetizer;
  const char *qname;
  void *data;
  uint64_t recv_count;
  uint64_t send_count;
  int fd;
};


#endif
