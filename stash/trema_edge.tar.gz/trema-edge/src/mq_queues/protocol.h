#ifndef PROTOCOL_H
#define PROTOCOL_H


struct protocol {
  struct async packetizer;
  const char *qname;
  void *data;
};


#endif
