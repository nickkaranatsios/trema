#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>
#include <unistd.h>
#include <mqueue.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <poll.h>
#include <stddef.h>
#include "checks.h"
#include "buffer.h"
#include "openflow_message.h"
#include "shell.h"
#include "protocol.h"
#include "datapath.h"
#include "event_handler.h"
#include "log.h"
#include "timer.h"
#include "openflow.h"


#define handle_error( msg ) \
           do { perror( msg ); exit( EXIT_FAILURE ); } while (0)
#define SLEEP_FOREVER() \
  do { \
    sleep( 1 ); \
  } while( 1 )


#ifdef CALLBACK
static void notify_setup( mqd_t *mqdp );

static void
mqueue_callback( union sigval sv ) {
  struct mq_attr attr;
  void *buffer;
  ssize_t num_read;
  mqd_t *mqdp;

  mqdp = sv.sival_ptr;
  if ( mq_getattr( *mqdp, &attr ) == -1 ) {
    handle_error( "mq_getattr:" );
  } 
  buffer = malloc( attr.mq_msgsize );
  if ( buffer != NULL ) {
    notify_setup( mqdp );
    while ( ( num_read = mq_receive( *mqdp, buffer, attr.mq_msgsize, NULL ) ) >= 0 )
      printf( "Read %ld bytes %s\n", ( long ) num_read, ( char * )buffer );
      if ( errno != EAGAIN ) {
        printf( "errno == EAGAIN\n" );
        exit( 0 );
      }
      free( buffer );
      pthread_exit( NULL );
  }
}


static void
notify_setup( mqd_t *mqdp ) {
  struct sigevent notification;

  notification.sigev_notify = SIGEV_THREAD;
  notification.sigev_notify_function = mqueue_callback;
  notification.sigev_notify_attributes = NULL;
  notification.sigev_value.sival_ptr = mqdp;
  if ( mq_notify( *mqdp, &notification ) == -1 ) {
    handle_error( "mq_notify:" );
  }
}
#else

static void
handle_message( mqd_t mqd ) {
  struct mq_attr attr;
  void *buffer;
  ssize_t num_read;

  if ( mq_getattr( mqd, &attr ) == -1 ) {
    handle_error( "mq_getattr:" );
  } 
  buffer = malloc( attr.mq_msgsize );
  if ( buffer != NULL ) {
    while ( ( num_read = mq_receive( mqd, buffer, attr.mq_msgsize, NULL ) ) >= 0 ) {
      printf( "Read %ld bytes %s\n", ( long ) num_read, ( char * )buffer );
      if ( errno != EAGAIN && num_read == -1 ) {
        handle_error( "errno == EAGAIN" );
      }
    }
    free( buffer );
  }
}
#endif


static void
handle_datapath_message( int fd, void *data ) {
  struct mq_attr attr;
  void *buffer;
  ssize_t num_read;

  if ( mq_getattr( fd, &attr ) == -1 ) {
    handle_error( "mq_getattr:" );
  } 
  buffer = malloc( attr.mq_msgsize );
  if ( buffer != NULL ) {
    while ( ( num_read = mq_receive( fd, buffer, attr.mq_msgsize, NULL ) ) >= 0 ) {
      printf( "Read %ld bytes %s\n", ( long ) num_read, ( char * )buffer );
      if ( errno != EAGAIN && num_read == -1 ) {
        handle_error( "errno == EAGAIN" );
      }
    }
    free( buffer );
  }
}


static int
serve_protocol_loop( void *data ) {
  struct protocol *protocol = data;
  struct mq_attr attr;
  const char *name = protocol->qname; 
  mqd_t mqd;
  int oflags = O_CREAT | O_RDWR | O_NONBLOCK;
  mode_t mode = S_IRWXU | S_IRWXG;


  attr.mq_maxmsg = 100;
  attr.mq_msgsize = 1510;
  mqd = mq_open( name, oflags, mode, &attr );
  if ( mqd == ( mqd_t ) -1 )
    handle_error( "mq_open:" );

  set_fd_handler( mqd, handle_datapath_message, &mqd, NULL, NULL );
  set_readable( mqd, true );
#ifdef TEST
  struct pollfd pfd;
  pfd.fd = mqd;
  pfd.events = POLLIN;
  for ( ;; ) {
    if ( poll( &pfd, 1, -1 ) < 0 ) {
      if ( errno != EINTR ) {
        error( "Poll failed resuming: %s", strerror( errno ) ); 
        sleep( 1 );
      }
      continue;
    }
    if ( pfd.revents & POLLIN ) {
      handle_message( mqd );
    }
  } 
#endif
  SLEEP_FOREVER();
  return 0;
}


void
handle_protocol_message( int fd, void *data ) {
 UNUSED( data );

  struct mq_attr attr;
  void *buffer;
  ssize_t num_read;

  if ( mq_getattr( fd, &attr ) == -1 ) {
    handle_error( "mq_getattr:" );
  } 
  buffer = malloc( attr.mq_msgsize );
  if ( buffer != NULL ) {
    while ( ( num_read = mq_receive( fd, buffer, attr.mq_msgsize, NULL ) ) >= 0 ) {
      printf( "Read %ld bytes protocol queue %s\n", ( long ) num_read, ( char * )buffer );
      if ( errno != EAGAIN && num_read == -1 ) {
        handle_error( "errno == EAGAIN" );
      }
    }
    free( buffer );
  }
  const char *buf = "a protocol message";
  unsigned msg_prio = 0;
  char msg_buf [ sizeof( "a protocol message" ) + 4 ];
  int i;
  for ( i = 0; i < 2; i++ ) {
    sprintf( msg_buf, "%s%d", buf, i );  
    size_t msg_len = strlen( msg_buf );
    if ( ( mq_send( fd, msg_buf, msg_len, msg_prio ) ) == -1 )  {
      handle_error( "mq_send:" );
    }
  }
  set_readable( fd, false );
}


static int
serve_datapath_loop( void *data ) {
  struct datapath *datapath = data;
  const char *name = datapath->qname; 
  int oflags = O_RDWR | O_NONBLOCK;
  mode_t mode = S_IRWXU | S_IRWXG;
  mqd_t mqd;

  mqd = mq_open( name, oflags, mode, NULL );
  if ( mqd == ( mqd_t ) -1 )
    handle_error( "mq_open:" );
  const char *buf = "a datapath message";
  unsigned msg_prio = 0;
  char msg_buf [ sizeof( "a datapath message" ) + 4 ];

  set_fd_handler( mqd, handle_protocol_message, NULL, NULL, NULL );
  set_readable( mqd, true );
  int i;
  for ( i = 0; i < 2; i++ ) {
    sprintf( msg_buf, "%s%d", buf, i );  
    size_t msg_len = strlen( msg_buf );
    if ( ( mq_send( mqd, msg_buf, msg_len, msg_prio ) ) == -1 )  {
      handle_error( "mq_send:" );
    }
  }
  SLEEP_FOREVER();
  return mq_close( mqd );
}
  

void
start_protocol( const char *qname ) {
  int ret;
  struct protocol *protocol;

  protocol = ( struct protocol * )malloc( sizeof( *protocol ) );
  protocol->packetizer.proc = serve_protocol_loop;
  protocol->qname = qname;
  protocol->packetizer.data = protocol; 
  ret = start_async( &protocol->packetizer );
  if ( ret < 0 ) {
    error( "failed to start protocol thread" );
  }
}


void
start_datapath( const char *qname ) {
  int ret;

  struct datapath *datapath;
 
  datapath = ( struct datapath * ) malloc( sizeof( *datapath ) );
  datapath->packetizer.proc = serve_datapath_loop;
  datapath->qname = qname;
  datapath->packetizer.data = datapath;
  ret = start_async( &datapath->packetizer );
  if ( ret < 0 ) {
    error( "failed to start datapath thread" );
  }
}

//gcc -std=gnu99 -D_GNU_SOURCE -o queue -g utility.c wrapper.c trema_wrapper.c event_handler.c timer.c log.c doubly_linked_list.c buffer.c openflow_message.c queue.c shell.c -lrt -lpthread -lsqlite3
// gdb queue /mq_queues

int 
main( int argc, char **argv ) {
  mqd_t mqd;

  if ( argc != 2 || strcmp( argv[ 1 ], "--help" ) == 0 ) {
    printf( "usage\n");
    exit( 0 );
  }
  const uint32_t ofp_versions[] = {
    1,
    4
  };
  printf( "%d\n", htonl( (1 << ofp_versions[0] ) | ( 1 << ofp_versions[1])));
  buffer *hello = create_hello_elem_versionbitmap( 1, ofp_versions, sizeof( ofp_versions ) / sizeof( ofp_versions[ 0 ] ) );
  uint32_t check_size = sizeof( struct ofp_hello_elem_header ) + offsetof( struct ofp_hello_elem_versionbitmap, bitmaps );
printf("check_size = %u\n", check_size);
  const char *qname = argv[ 1 ];
  init_timer();
  init_event_handler();
  start_protocol( qname );
  sleep( 10 );
  start_datapath( qname );
  start_event_handler();
  while ( 1 ) {
    sleep( -1 );
  }
}

