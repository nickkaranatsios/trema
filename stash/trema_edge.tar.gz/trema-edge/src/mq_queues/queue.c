#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>
#include <unistd.h>
#include <mqueue.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <poll.h>
#include <stddef.h>
#include <assert.h>
#include <inttypes.h>
#include <getopt.h>
#include "checks.h"
#include "buffer.h"
#include "openflow_message.h"
#include "message_queue.h"
#include "wrapper.h"
#include "async.h"
#include "protocol.h"
#include "datapath.h"
#include "log.h"
#include "openflow.h"
#include "thread-test.h"
#include "timer-test.h"
#include "async-lock.h"
#include "async-util.h"


#define handle_error( msg ) \
           do { perror( msg ); exit( EXIT_FAILURE ); } while (0)
#define SLEEP_FOREVER() \
  do { \
    sleep( 1 ); \
  } while( 1 )


static void
push_message_to_queue( message_queue *queue, int direction ) {
  char buf[ 256 ];
  if ( !direction ) {
    strcpy( buf, "From protocol to datapath message" );
  } else {
    strcpy( buf, "From datapath to protocol message" );
  }
  buffer *queue_buf = alloc_buffer_with_length( strlen( buf ) );
  append_back_buffer( queue_buf, strlen( buf ) );
  strcpy( queue_buf->data, buf );
  bool ret = enqueue_message( queue, queue_buf );
}


void
retrieve_packet_from_datapath( int fd, void *user_data ) {
  assert( fd >= 0 );
  struct protocol *protocol = user_data;
  assert( protocol != NULL );

  uint64_t count = 0;

  ssize_t ret = read( fd, &count, sizeof( uint64_t ) );
  if ( ret < 0 ) {
    if ( ret == EAGAIN || errno == EINTR ) {
      return;
    }
  }
  for ( uint64_t i = 0; i < count; i++ ) {
    buffer *packet = dequeue_message( protocol->own_queue );
    char *msg = packet->data;
    printf( "%s\n", msg );
  }
  push_message_to_queue( protocol->peer_queue, 0 );
  protocol->send_count++;
  new_set_writable( protocol->own_efd, true );
}


void
retrieve_packet_from_protocol( int fd, void *user_data ) {
  assert( fd >= 0 );
  struct datapath *datapath = user_data;
  assert( datapath != NULL );
  uint64_t count = 0;

  ssize_t ret = read( fd, &count, sizeof( uint64_t ) );
  if ( ret < 0 ) {
    if ( ret == EAGAIN || errno == EINTR ) {
      return;
    }
  }
  for ( uint64_t i = 0; i < count; i++ ) {
    buffer *packet = dequeue_message( datapath->own_queue );
    char *msg = packet->data;
    printf( "%s\n", msg );
  }
  push_message_to_queue( datapath->peer_queue, 1 );
  datapath->send_count++;
  new_set_writable( datapath->own_efd, true );
}

void
notify_protocol( int fd, void *user_data ) {
  assert( fd >= 0 );
  struct datapath *datapath = user_data;
  assert( datapath != NULL );

  // write the send count to protocol's event descriptor.
  size_t ret = write( datapath->peer_efd, &datapath->send_count, sizeof( datapath->send_count ) );
  if ( ret < 0 ) {
    if ( ret == EAGAIN || errno == EINTR ) {
      return;
    }
  } else if ( ret != sizeof( datapath->send_count ) ) {
    error( "Failed to notify protocol count= " PRIu64 ",ret = %d", datapath->send_count, ret );
  }
  new_set_writable( fd, false );
  datapath->send_count = 0;
}


void
notify_datapath( int fd, void *user_data ) {
  assert( fd >= 0 );
  struct protocol *protocol = user_data;
  assert( protocol != NULL );

  size_t ret = write( protocol->peer_efd, &protocol->send_count, sizeof( protocol->send_count ) );
  if ( ret < 0 ) {
    if ( ret == EAGAIN || errno == EINTR ) {
      return;
    }
  } else if ( ret != sizeof( protocol->send_count ) ) {
    error( "Failed to notify protocol count= " PRIu64 ",ret = %d", protocol->send_count, ret );
  }
  new_set_writable( fd, false );
  protocol->send_count = 0;
}


static void 
send_message_to_queue( int fd, int direction ) {
  char buf[ 256 ]; 
  unsigned msg_prio = 0;


  if ( !direction ) {
    sprintf( buf, "%s:%d", "From protocol to datapath message", fd );
  } else {
    sprintf( buf, "%s:%d", "From datapath to protocol message", fd );
  }
  size_t msg_len = strlen( buf );
  if ( ( mq_send( fd, buf, msg_len, msg_prio ) ) == -1 )  {
    handle_error( "mq_send:" );
  }
}


#ifdef CALLBACK
static void notify_setup( mqd_t *mqdp );

static void
mqueue_callback( union sigval sv ) {
  struct mq_attr attr;
  void *buffer;
  ssize_t num_read;
  mqd_t *mqdp;

  mqdp = sv.sival_ptr;
  if ( mq_getattr( *mqdp, &attr ) == -1 ) {
    handle_error( "mq_getattr:" );
  } 
  buffer = malloc( attr.mq_msgsize );
  if ( buffer != NULL ) {
    notify_setup( mqdp );
    while ( ( num_read = mq_receive( *mqdp, buffer, attr.mq_msgsize, NULL ) ) >= 0 )
      printf( "Read %ld bytes %s\n", ( long ) num_read, ( char * )buffer );
      if ( errno != EAGAIN ) {
        printf( "errno == EAGAIN\n" );
        exit( 0 );
      }
      free( buffer );
      pthread_exit( NULL );
  }
}


static void
notify_setup( mqd_t *mqdp ) {
  struct sigevent notification;

  notification.sigev_notify = SIGEV_THREAD;
  notification.sigev_notify_function = mqueue_callback;
  notification.sigev_notify_attributes = NULL;
  notification.sigev_value.sival_ptr = mqdp;
  if ( mq_notify( *mqdp, &notification ) == -1 ) {
    handle_error( "mq_notify:" );
  }
}
#else

static void
handle_message( mqd_t mqd ) {
  struct mq_attr attr;
  void *buffer;
  ssize_t num_read;

  if ( mq_getattr( mqd, &attr ) == -1 ) {
    handle_error( "mq_getattr:" );
  } 
  buffer = malloc( attr.mq_msgsize );
  if ( buffer != NULL ) {
    while ( ( num_read = mq_receive( mqd, buffer, attr.mq_msgsize, NULL ) ) >= 0 ) {
      printf( "Read %ld bytes %s\n", ( long ) num_read, ( char * )buffer );
      if ( errno != EAGAIN && num_read == -1 ) {
        handle_error( "errno == EAGAIN" );
      }
    }
    free( buffer );
  }
}
#endif


static void
handle_datapath_message( int fd, void *data ) {
  struct protocol *protocol = data;
  struct mq_attr attr;
  void *buffer;
  ssize_t num_read;
  int dfd;

  if ( mq_getattr( fd, &attr ) == -1 ) {
    handle_error( "mq_getattr:" );
  } 
  buffer = malloc( attr.mq_msgsize );
  if ( buffer != NULL ) {
    while ( ( num_read = mq_receive( fd, buffer, attr.mq_msgsize, NULL ) ) >= 0 ) {
#ifdef TEST
      char desc[ 2 ];
      strncpy( desc, ( char * )buffer + strlen( ( char * ) buffer ) - 1, 1 ); 
      dfd = atoi( desc );
#endif
      printf( "Protocol read from %d %ld bytes: %s\n", fd, ( long ) num_read, ( char * )buffer );
      if ( errno != EAGAIN && num_read == -1 ) {
        handle_error( "errno == EAGAIN" );
      }
      if ( protocol->recv_count++ == 10 ) {
        new_set_writable( fd, false );
      }
    }
    free( buffer );
  }
  send_message_to_queue( fd, 0 );
}

static int
new_serve_protocol_loop( void *data ) {
  struct protocol *protocol = data;
  
  add_thread();
  new_init_timer();
  new_init_event_handler();

  new_set_fd_handler( protocol->own_efd, retrieve_packet_from_datapath, protocol, notify_datapath, protocol );
  new_set_readable( protocol->own_efd, true );
  new_set_writable( protocol->own_efd, true );
  
  // push_message_to_queue( protocol->peer_queue, 0 );
  if ( protocol->recv_count != 10 ) {
    new_start_event_handler();
  }
  return 0;
}

static int
serve_protocol_loop( void *data ) {
  struct protocol *protocol = data;
  struct mq_attr attr;
  const char *name = protocol->qname; 
  mqd_t mqd;
  int oflags = O_CREAT | O_RDWR | O_NONBLOCK;
  mode_t mode = S_IRWXU | S_IRWXG;


  printf( "serve_protocol_loop calling init_thread_test\n" );
  add_thread();
  new_init_timer();
  new_init_event_handler();

  attr.mq_maxmsg = 100;
  attr.mq_msgsize = 1510;
  mqd = mq_open( name, oflags, mode, &attr );
  if ( mqd == ( mqd_t ) -1 )
    handle_error( "mq_open:" );

  new_set_fd_handler( mqd, handle_datapath_message, protocol, NULL, NULL );
  new_set_readable( mqd, true );
  send_message_to_queue( mqd, 0 );
  protocol->fd = mqd;
#ifdef TEST
  struct pollfd pfd;
  pfd.fd = mqd;
  pfd.events = POLLIN;
  for ( ;; ) {
    if ( poll( &pfd, 1, -1 ) < 0 ) {
      if ( errno != EINTR ) {
        error( "Poll failed resuming: %s", strerror( errno ) ); 
        sleep( 1 );
      }
      continue;
    }
    if ( pfd.revents & POLLIN ) {
      handle_message( mqd );
    }
  } 
#endif
  // SLEEP_FOREVER();
  if ( protocol->recv_count != 10 ) {
    new_start_event_handler();
  }
  return 0;
}


void
handle_protocol_message( int fd, void *data ) {
  struct datapath *datapath = data;
  struct mq_attr attr;
  void *buffer;
  ssize_t num_read;
  int pfd;

  if ( mq_getattr( fd, &attr ) == -1 ) {
    handle_error( "mq_getattr:" );
  } 
  buffer = malloc( attr.mq_msgsize );
  if ( buffer != NULL ) {
    while ( ( num_read = mq_receive( fd, buffer, attr.mq_msgsize, NULL ) ) >= 0 ) {
#ifdef TEST
      char desc[ 2 ];
      strncpy( desc, ( char * )buffer + strlen( ( char * ) buffer ) - 1, 1 ); 
      pfd = atoi( desc );
#endif
      printf( "Datapath read from %d %ld bytes: %s\n", fd, ( long ) num_read, ( char * )buffer );
      if ( errno != EAGAIN && num_read == -1 ) {
        handle_error( "errno == EAGAIN" );
      }
      if ( datapath->recv_count++ == 10 ) {
        new_set_writable( fd, false );
      }
    }
    free( buffer );
  }
  send_message_to_queue( fd, 1 );
}

static int
new_serve_datapath_loop( void *data ) {
  struct datapath *datapath = data;

  add_thread();
  new_init_timer();
  new_init_event_handler();

  new_set_fd_handler( datapath->own_efd , retrieve_packet_from_protocol, datapath, notify_protocol, datapath );
  new_set_readable( datapath->own_efd, true );
  new_set_writable( datapath->own_efd, false );
  push_message_to_queue( datapath->peer_queue, 1 );
  datapath->send_count++;
  new_set_writable( datapath->own_efd, true );
  
  new_start_event_handler();
}


static int
serve_datapath_loop( void *data ) {
  struct datapath *datapath = data;
  const char *name = datapath->qname; 
  int oflags = O_RDWR | O_NONBLOCK;
  mode_t mode = S_IRWXU | S_IRWXG;
  mqd_t mqd;

  printf( "serve_datapath_loop calling init_thread_test\n" );
  add_thread();
  new_init_timer();
  new_init_event_handler();
  
  mqd = mq_open( name, oflags, mode, NULL );
  if ( mqd == ( mqd_t ) -1 )
    handle_error( "mq_open:" );


  new_set_fd_handler( mqd, handle_protocol_message, datapath, NULL, NULL );
  new_set_readable( mqd, true );

  send_message_to_queue( mqd, 1 );
  // SLEEP_FOREVER();
  new_start_event_handler();
  return mq_close( mqd );
}
  

pthread_t
start_protocol( const char *qname, message_queue *own_queue, 
        message_queue *peer_queue, int efd[ 2 ] ) {
  int ret;
  struct protocol *protocol;

  protocol = ( struct protocol * )malloc( sizeof( *protocol ) );
  protocol->packetizer.proc = new_serve_protocol_loop;
  protocol->qname = qname;
  protocol->own_queue = own_queue;
  protocol->peer_queue = peer_queue;
  protocol->own_efd  = efd[ 0 ];
  protocol->peer_efd = efd[ 1 ];
  protocol->packetizer.data = protocol; 
  ret = start_async( &protocol->packetizer );
  if ( ret < 0 ) {
    error( "failed to start protocol thread" );
  }
  return protocol->packetizer.tid;
}


pthread_t
start_datapath( const char *qname, message_queue *own_queue, 
        message_queue *peer_queue, int efd[ 2 ] ) {
  int ret;

  struct datapath *datapath;
 
  datapath = ( struct datapath * ) malloc( sizeof( *datapath ) );
  datapath->packetizer.proc = new_serve_datapath_loop;
  datapath->qname = qname;
  datapath->own_queue = own_queue;
  datapath->peer_queue = peer_queue;
  datapath->peer_efd = efd [ 0 ];
  datapath->own_efd = efd [ 1 ];
  datapath->packetizer.data = datapath;
  ret = start_async( &datapath->packetizer );
  if ( ret < 0 ) {
    error( "failed to start datapath thread" );
  }
  return datapath->packetizer.tid;
}

//gcc -std=gnu99 -D_GNU_SOURCE -o queue -g utility.c wrapper.c trema_wrapper.c event_handler.c timer.c log.c doubly_linked_list.c buffer.c openflow_message.c queue.c shell.c -lrt -lpthread -lsqlite3
// gdb queue /mq_queues

typedef struct _match8 {
  uint8_t value;
  uint8_t mask;
  bool valid;
} match8;

typedef struct _match16 {
  uint16_t value;
  uint16_t mask;
  bool valid;
} match16;

static void
find_action( struct ofp_action_header *ac_hdr ) {
  if ( ac_hdr->type == OFPAT_OUTPUT ) {
    struct ofp_action_output *ac_output = ( struct ofp_action_output * ) ac_hdr;
    printf("port %d\n", ac_output->port );
  }
  if ( ac_hdr->type == OFPAT_GROUP ) {
    struct ofp_action_group *ac_group = ( struct ofp_action_group * ) ac_hdr;
    printf("group %d\n", ac_group->group_id );
  }
}

int 
main( int argc, char **argv ) {
  struct ofp_action_output ac_output;
  struct ofp_action_group ac_group;
  ac_output.type = OFPAT_OUTPUT;
  ac_output.len = (uint16_t )sizeof( struct ofp_action_output );
  ac_output.port = 1;
  ac_group.group_id = 2;
  ac_group.type = OFPAT_GROUP;
  ac_group.len = ( uint16_t )sizeof( struct ofp_action_group );
  printf("%d %d %d\n", sizeof(struct ofp_action_header), sizeof( struct ofp_action_output), sizeof( struct ofp_action_group) );
  find_action( ( struct ofp_action_header * )&ac_output );
  find_action( ( struct ofp_action_header * )&ac_group );
  
  mqd_t mqd;

  if ( argc != 2 || strcmp( argv[ 1 ], "--help" ) == 0 ) {
    printf( "usage\n");
    exit( 0 );
  }

#ifdef HELLO
  const uint32_t ofp_versions[] = {
    1,
    4
  };
  printf( "%d\n", htonl( (1 << ofp_versions[0] ) | ( 1 << ofp_versions[1])));
  buffer *hello = create_hello_elem_versionbitmap( 1, ofp_versions, sizeof( ofp_versions ) / sizeof( ofp_versions[ 0 ] ) );
  uint32_t check_size = sizeof( struct ofp_hello_elem_header ) + offsetof( struct ofp_hello_elem_versionbitmap, bitmaps );
  printf("check_size = %u\n", check_size);
#endif

  int efd[ 2 ];
  int i;

  for ( i = 0; i < sizeof( efd ) / sizeof( efd[ 0 ] ); i++ ) {
    efd[ i ] = create_event_fd();
    if ( efd[ i ] == -1 ) {
      error( "failed to create_event_fd %d", errno );
      return efd[ i ];
    }
  }
  message_queue *to_datapath_queue = create_message_queue();
  assert( to_datapath_queue != NULL );
  message_queue *to_protocol_queue = create_message_queue();
  assert( to_protocol_queue != NULL );

  const char *qname = argv[ 1 ];
  pthread_t threads[ 2 ];
  // init_event_handler();
  threads[ 0 ] = start_protocol( qname, to_datapath_queue, to_protocol_queue, efd );
  threads[ 1 ] = start_datapath( qname, to_protocol_queue, to_datapath_queue, efd );
  // start_event_handler();
  for ( i = 0; i < 2; i++ ) {
    if ( pthread_join( threads[ i ], NULL ) ) {
      printf( "failed to join thread %ld\n", threads[ i ] );
    }
  }
  return EXIT_SUCCESS;
}

