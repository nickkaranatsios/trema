#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>
#include <mqueue.h>
#include <fcntl.h>
#include <sys/stat.h>

#define handle_error( msg ) \
           do { perror( msg ); exit( EXIT_FAILURE ); } while (0)

int 
main( int argc, char **argv ) {
  mqd_t mqd;


  if ( argc != 2 || strcmp( argv[ 1 ], "--help" ) == 0 ) {
    printf( "usage\n");
    exit( 0 );
  }
  int oflags = O_RDWR | O_NONBLOCK;
  mode_t mode = S_IRWXU | S_IRWXG;
  
  mqd = mq_open( argv[ 1 ], oflags, mode, NULL );
  if ( mqd == ( mqd_t ) -1 )
    handle_error( "mq_open:" );
  const char *msg_buf = "this is a test";
  size_t msg_len = strlen( msg_buf );
  unsigned msg_prio = 0;
  if ( ( mq_send( mqd, msg_buf, msg_len, msg_prio ) ) == -1 )  {
    handle_error( "mq_send:" );
  }
  mq_close( mqd );
  return 0;
}

