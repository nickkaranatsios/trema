/* 
 * File:   timer-test.h
 * Author: co2kara
 *
 * Created on October 26, 2012, 2:12 AM
 */

#ifndef TIMER_TEST_H
#define TIMER_TEST_H

#ifdef __cplusplus
extern "C" {
#endif

#include "doubly_linked_list.h"


#define VALID_TIMESPEC( _a )                                  \
  ( ( ( _a )->tv_sec > 0 || ( _a )->tv_nsec > 0 ) ? 1 : 0 )

#define ADD_TIMESPEC( _a, _b, _return )                       \
  do {                                                        \
    ( _return )->tv_sec = ( _a )->tv_sec + ( _b )->tv_sec;    \
    ( _return )->tv_nsec = ( _a )->tv_nsec + ( _b )->tv_nsec; \
    if ( ( _return )->tv_nsec >= 1000000000 ) {               \
      ( _return )->tv_sec++;                                  \
      ( _return )->tv_nsec -= 1000000000;                     \
    }                                                         \
  }                                                           \
  while ( 0 )

#define SUB_TIMESPEC( _a, _b, _return )                       \
  do {                                                        \
    ( _return )->tv_sec = ( _a )->tv_sec - ( _b )->tv_sec;    \
    ( _return )->tv_nsec = ( _a )->tv_nsec - ( _b )->tv_nsec; \
    if ( ( _return )->tv_nsec < 0 ) {                         \
      ( _return )->tv_sec--;                                  \
      ( _return )->tv_nsec += 1000000000;                     \
    }                                                         \
  }                                                           \
  while ( 0 )

#define TIMESPEC_LESS_THEN( _a, _b )                          \
  ( ( ( _a )->tv_sec == ( _b )->tv_sec ) ?                    \
    ( ( _a )->tv_nsec < ( _b )->tv_nsec ) :                   \
    ( ( _a )->tv_sec < ( _b )->tv_sec ) )

#define TIMESPEC_TO_MICROSECONDS( _a, _b )                    \
  do {                                                        \
    struct timespec round = { 0, 999 };                       \
    ADD_TIMESPEC( _a, &round, &round );                       \
    ( *( _b ) = ( int ) ( round.tv_sec * 1000000 + round.tv_nsec / 1000 ) ); \
  }                                                           \
  while ( 0 )

typedef void ( *timer_callback )( void *user_data );


typedef struct timer_callback_info {
  timer_callback function;
  struct timespec expires_at;
  struct timespec interval;
  void *user_data;
} timer_callback_info;


struct timer_info {
  dlist_element *timer_callbacks;
  pthread_t thread_id;
};

struct timer_info_list {
  struct timer_info **timers;
  uint32_t timers_nr;
  uint32_t timers_alloc;
};


bool ( *new_init_timer )( void );
bool ( *new_finalize_timer )( void );

void ( *new_execute_timer_events )( int *next_timeout_usec );


#ifdef __cplusplus
}
#endif

#endif /* TIMER_TEST_H */

