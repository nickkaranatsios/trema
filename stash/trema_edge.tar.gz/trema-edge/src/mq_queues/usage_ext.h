#ifndef COMMON_H
#define COMMON_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>
#include <stdarg.h>
#include <stdint.h>
#include <unistd.h>
#include <errno.h>
#include <syslog.h>
#include <arpa/inet.h>
#include <linux/if_ether.h>

#ifdef __GNUC__
#define NORETURN __attribute__((__noreturn__))
#define NORETURN_PTR __attribute__((__noreturn__))
#else
#define NORETURN
#define NORETURN_PTR
#ifndef __attribute__
#define __attribute__(x)
#endif
#endif

#define ARRAY_SIZE(x) (sizeof(x)/sizeof(x[0]))
#define STR_(s) # s
#define STR(s)  STR_(s)
#define NR_FLOW_TABLES 8

#define alloc_nr(x) (((x)+16)*3/2)
#define ALLOC_GROW(x, nr, alloc) \
 do { \
    if ((nr) > alloc) { \
      if (alloc_nr(alloc) < (nr)) \
        alloc = (nr); \
      else \
        alloc = alloc_nr(alloc); \
      x = realloc((x), alloc * sizeof(*(x))); \
    } \
  } while (0)

#define sleep_forever() \
    do { \
        sleep(1); \
    } while(1)
        
extern NORETURN void usage(const char *err);
extern NORETURN void usagef(const char *err, ...) __attribute__((format (printf, 1, 2)));
extern NORETURN void die(const char *err, ...) __attribute__((format(printf, 1, 2)));
extern NORETURN void die_errno(const char *err, ...) __attribute__((format(printf, 1, 2)));
extern void warning(const char *err, ...) __attribute__((format(printf, 1, 2)));
extern void info(const char *err, ...) __attribute__((format(printf, 1, 2)));
extern int error(const char *err, ...) __attribute__((format(printf, 1, 2)));
extern void NORETURN probe_die(const char *err, va_list params);
extern uint64_t htonll(uint64_t n);
extern uint64_t ntohll(uint64_t n);

// dpid.c
struct dpid_info *get_dpid(uint64_t dpid);
uint16_t get_cksum_method(struct dpid_info *di);

// config.c
typedef int (*config_fn_t)(const char *, const char *);
extern int read_config(config_fn_t fn, const char *filename);

// strbuf.c
extern int prefixcmp(const char *str, const char *prefix);
extern int suffixcmp(const char *str, const char *suffix);

// mem_wrapper.c
extern void *xmalloc(size_t size);
extern void *xcalloc(size_t nmemb, size_t size);
extern char *xstrdup(const char *str);
extern char *xstrndup(const char *str, size_t len);

// connect.c
int server_connect(int fd[2], const char *host, uint16_t port);

// remote.c
#define MAX_CONDS 3

// db_wrapper.c
struct db_attr;
extern struct appl_ctx *init();
extern struct appl_ctx *real_connect(struct appl_ctx *appl_ctx);
extern struct appl_ctx *stmt_init(struct appl_ctx *appl_ctx);
extern struct appl_ctx *stmt_prepare(struct appl_ctx *appl_ctx, const char *query);
extern struct appl_ctx *stmt_execute(struct appl_ctx *appl_ctx, int argc, struct db_attr *attr);
extern struct colnames *stmt_fetch(struct appl_ctx *appl_ctx);


extern int query(struct appl_ctx *ap, const char *sql);
extern unsigned long num_rows(struct appl_ctx *appl_ctx);
extern void *fetch_row(struct appl_ctx *ap);

// packet.c
extern ssize_t packet_write(int fd, void *buf, ssize_t len);
extern ssize_t packet_read(int fd, void *buffer, ssize_t count);

#endif
