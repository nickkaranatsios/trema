#include <stdio.h>
#include "ofdp.h"
#include "checks.h"

int
main( int argc, const char **argv ) {
  UNUSED( argc );
  UNUSED( argv );
  return 0;
}
