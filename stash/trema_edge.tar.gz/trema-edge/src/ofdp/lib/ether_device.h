/*
 * Functions for sending/receving Ethernet frames with raw socket interface.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef ETHER_DEVICE_H
#define ETHER_DEVICE_H


#include <stdint.h>
#include <net/if.h>
#include <time.h>
#include "bool.h"
#include "ether.h"
#include "message_queue_datapath.h"
#include "openflow.h"
// #include "chibach.h"


typedef void ( *frame_received_handler )( buffer *frame, void *user_data );


struct buffer_list {
  buffer **entries;
  size_t alloc;
  uint32_t nr;
};


typedef struct {
  char name[ IFNAMSIZ ];
  int ifindex;
  uint8_t hw_addr[ ETH_ADDRLEN ];
  struct {
    bool up;
    bool can_retrieve_link_status;
    bool can_retrieve_pause;
    uint32_t curr;
    uint32_t advertised;
    uint32_t supported;
    uint32_t peer;

    struct timespec pre_calc;
    uint64_t tx_bytes;

    uint32_t curr_speed;
    uint32_t max_speed;
  } status;
  struct {
    uint64_t rx_packets;
    uint64_t tx_packets;
    uint64_t rx_bytes;
    uint64_t tx_bytes;
    uint64_t rx_dropped;
    uint64_t tx_dropped;
    uint64_t rx_errors;
    uint64_t tx_errors;
    uint64_t rx_frame_err;
    uint64_t rx_over_err;
    uint64_t rx_crc_err;
    uint64_t collisions;
    struct timespec init_time;
  } stats;
  int fd;
  size_t max_send_queue;
  size_t max_recv_queue;
  message_queue *send_queue;
  message_queue *recv_queue;
  struct buffer_list send_list; 
  struct buffer_list recv_list;
  bool init_linkup;
  bool init_promisc;
  frame_received_handler received_callback;
  void *received_user_data;
} ether_device;


ether_device *create_ether_device( const char *name, const size_t max_send_queue, const size_t max_recv_queue );
void delete_ether_device( ether_device *device );
bool up_ether_device( ether_device *devive );
bool down_ether_device( ether_device *device );
bool send_frame( ether_device *device, buffer *frame );
bool set_frame_received_handler( ether_device *device, frame_received_handler callback, void *user_data );
bool update_device_status( ether_device *device );
bool update_device_stats( ether_device *device );
short int get_device_flags( const char *name );
bool set_device_flags( const char *name, short int flags );


#endif // ETHER_DEVICE_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
