/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include "oxm_match.h"
#include "ofdp/lib/table_manager_flow.h"
#include "oxm-helper.h"
#include "action-tlv-interface.h"


/*
 * We use assign actions to parse multiple actions as in the case of
 * ofp_instruction_actions but also to parse one action after the other as in
 * the case of openflow_actions. The loop parameter governs this logic. This is
 * done also to avoid having to increment the action pointer to incorrect
 * address.
 */
action_list *
_assign_actions( const struct ofp_action_header *action, bool loop, action_list *action_list ) {
  while( action && action->len >= sizeof( *action ) ) {
    if ( action->type == OFPAT_OUTPUT ) {
      const struct ofp_action_output *action_output = ( const struct ofp_action_output * ) action;
      append_action( action_list, create_action_output( action_output->port, action_output->max_len ) );
    }
    if ( action->type == OFPAT_COPY_TTL_OUT ) {
      append_action( action_list, create_action_copy_ttl_out() );
    }
    if ( action->type == OFPAT_COPY_TTL_IN ) {
      append_action( action_list, create_action_copy_ttl_in() );
    }
    if ( action->type == OFPAT_SET_MPLS_TTL ) {
      const struct ofp_action_mpls_ttl *action_mpls_ttl = ( const struct ofp_action_mpls_ttl * ) action;
      append_action( action_list, create_action_set_mpls_ttl( action_mpls_ttl->mpls_ttl ) );
    }
    if ( action->type == OFPAT_DEC_MPLS_TTL ) {
      append_action( action_list, create_action_decr_mpls_ttl() );
    }
    if ( action->type == OFPAT_SET_NW_TTL ) {
      const struct ofp_action_nw_ttl *action_nw_ttl = ( const struct ofp_action_nw_ttl *) action;
      append_action( action_list, create_action_set_ipv4_ttl( action_nw_ttl->nw_ttl ) );
    }
    if ( action->type == OFPAT_DEC_NW_TTL ) {
      append_action( action_list, create_action_decr_ipv4_ttl() );
    }
    if ( action->type == OFPAT_PUSH_VLAN ) {
      const struct ofp_action_push *action_push = ( const struct ofp_action_push * ) action;
      append_action( action_list, create_action_push_vlan( action_push->ethertype ) );
    }
    if ( action->type == OFPAT_PUSH_MPLS ) {
      const struct ofp_action_push *action_push = ( const struct ofp_action_push * ) action;
      append_action( action_list, create_action_push_mpls( action_push->ethertype ) );
    }
    if ( action->type == OFPAT_PUSH_PBB ) {
      const struct ofp_action_push *action_push = ( const struct ofp_action_push * ) action;
      append_action( action_list, create_action_push_pbb( action_push->ethertype ) );
    }
    if ( action->type == OFPAT_POP_VLAN ) {
      append_action( action_list, create_action_pop_vlan() );
    }
    if ( action->type == OFPAT_POP_MPLS ) {
      const struct ofp_action_pop_mpls *action_pop_mpls = ( const struct ofp_action_pop_mpls * ) action;
      append_action( action_list, create_action_pop_mpls( action_pop_mpls->ethertype ) );
    }
    if ( action->type == OFPAT_POP_PBB ) {
      append_action( action_list, create_action_pop_pbb() );
    }
    if ( action->type == OFPAT_SET_QUEUE ) {
      const struct ofp_action_set_queue *set_queue = ( const struct ofp_action_set_queue * ) action;
      append_action( action_list, create_action_set_queue( set_queue->queue_id ) );
    }
    if ( action->type == OFPAT_SET_FIELD ) {
      const struct ofp_action_set_field *set_field = ( const struct ofp_action_set_field * ) action;
      match *match = init_match();
      assign_match( match, ( oxm_match_header * ) &set_field->field );
      append_action( action_list, create_action_set_field( match ) );
    }
    if ( loop == true ) {
      action = ( const struct ofp_action_header * ) ( ( const char * ) action + action->len );
    } else {
      break;
    }
  }
  return action_list;
}
action_list * ( *assign_actions )( const struct ofp_action_header *action, bool loop, action_list *action_list ) = _assign_actions;


static int
_assign_instructions( instruction_list *ins_list, list_element *element, const uint8_t table_id ) {
  assert( element );
  assert( ins_list );
  int ret = OFDPE_FAILED;

  while ( element != NULL ) {
    const struct ofp_instruction *hdr = ( struct ofp_instruction * ) element->data;
    switch ( hdr->type ) {
      case OFPIT_GOTO_TABLE: {
          ret = append_instruction( ins_list, create_instruction_goto_table( table_id ) );
        }
        break;
      case OFPIT_WRITE_METADATA: {
          const struct ofp_instruction_write_metadata *metadata_ins = ( const struct ofp_instruction_write_metadata * ) hdr;
          ret = append_instruction( ins_list, create_instruction_write_metadata( 
                metadata_ins->metadata, metadata_ins->metadata_mask ) );
        }
        break;
      case OFPIT_WRITE_ACTIONS: {
        const struct ofp_instruction_actions *action_ins = ( const struct ofp_instruction_actions * ) hdr;
        action_list *ac_list = init_action_list();
        ret = append_instruction( ins_list, create_instruction_write_actions( 
                assign_actions( action_ins->actions, true, ac_list ) ) );
        }
        break;
      case OFPIT_APPLY_ACTIONS: {
          const struct ofp_instruction_actions *action_ins = ( const struct ofp_instruction_actions * ) hdr;
          action_list *ac_list = init_action_list();
          ret = append_instruction( ins_list, create_instruction_apply_actions( 
                assign_actions( action_ins->actions, true, ac_list ) ) );
        }
        break;
      case OFPIT_CLEAR_ACTIONS: {
          ret = append_instruction( ins_list, create_instruction_clear_actions() );
        }
        break;
      case OFPIT_METER: {
          const struct ofp_instruction_meter *meter_ins = ( const struct ofp_instruction_meter * ) hdr;
          ret = append_instruction( ins_list, create_instruction_meter( meter_ins->meter_id ) );
        }
        break;
      default:
        break;
    }
    element = element->next;
  }
  return ret;
}
int ( *assign_instructions )( instruction_list *ins_list, list_element *element, uint8_t table_id ) = _assign_instructions;


void
_action_pack( void *dest, action_list **list  ) {
  if ( *list == NULL ) {
    return;
  }
  action_list *item = ( action_list * ) get_first_element( ( dlist_element * ) ( *list ) );
  action *action;
  struct ofp_action_header *ac_hdr = dest;
  while ( item != NULL ) {
    action = item->node;
    if ( action != NULL ) {
      action_tlv_pack( ac_hdr, action );
      ac_hdr = ( struct ofp_action_header * ) ( ( char * ) ac_hdr + ac_hdr->len );
    }
    item = item->next;
  }
}
void ( *action_pack )( void *dest, action_list **list ) = _action_pack;


static action *
find_action_by_type( const struct ofp_action_header *ac_hdr, action_list **list ) {
  action_list *item = ( action_list * ) get_first_element( ( dlist_element * ) ( *list ) );

  action *action = NULL;
  while ( item != NULL ) {
    action = item->node;
    if ( action ) {
      if ( action->type == ac_hdr->type ) {
        break;
      }
    }
    item = item->next;
  }
  return action;
}


action *
_find_action( const struct ofp_action_header *ac_hdr, instruction_list **list ) {
  instruction_list *item = ( instruction_list * ) get_first_element( ( dlist_element * ) ( *list ) );

  instruction *instruction = NULL;
  action *action = NULL;
  while ( item != NULL ) {
    instruction = item->node;
    if ( instruction ) {
      action = find_action_by_type( ac_hdr, &instruction->p_action_list );
      if ( action != NULL ) {
        break;
      }
    }
    item = item->next;
  }
  return action;
}
action * ( *find_action )( const struct ofp_action_header *ac_hdr, instruction_list **list ) = _find_action; 


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
