
/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include "openflow.h"
#include "checks.h"
#include "action-tlv.h"


void pack_action_tlv_set_field( const struct action_tlv_args *args, void *action_ptr );


static struct action_tlv action_tlv_set_field = {
  OFPAT_SET_FIELD,
  ( uint16_t ) 2 * sizeof( uint16_t ),
  pack_action_tlv_set_field
};


void init_action_tlv_set_field( void ) {
  register_action( &action_tlv_set_field );
}


void
pack_action_tlv_set_field( const struct action_tlv_args *args, void *action_ptr ) {
  UNUSED( args );
  struct ofp_action_set_field *ac_set_field = action_ptr;

  ac_set_field->type = action_tlv_set_field.type;
  ac_set_field->len = action_tlv_set_field.len;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
