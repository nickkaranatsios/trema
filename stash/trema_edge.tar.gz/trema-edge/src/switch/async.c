#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include "log.h"
#include "async.h"

#ifdef __GNUC__
#define NORETURN __attribute__((__noreturn__))
#define NORETURN_PTR __attribute__((__noreturn__))
#else
#define NORETURN
#define NORETURN_PTR
#ifndef __attribute__
#define __attribute__(x)
#endif
#endif


static int main_thread_set;
static pthread_t main_thread;
static pthread_key_t async_key;


static NORETURN void 
die_async() {
  struct async *async;

  if ( !pthread_equal( main_thread, pthread_self() ) ) {
    async = pthread_getspecific( async_key );
    if ( async->proc_in >= 0 ) {
      close(async->proc_in);
    }
    if ( async->proc_out >= 0 ) {
      close( async->proc_out );
    }
    pthread_exit( ( void * ) 128 );
  }
  exit( 128 );
}


int
finish_async(struct async *async) {
  void *ret = ( void * ) ( intptr_t ) ( -1 );

  if ( pthread_join( async->tid, &ret ) ) {
    error("pthread_join failed");
  }
  return (int) (intptr_t) ret;
}


void 
*run_thread( void *data ) {
  struct async *async = data;
  intptr_t ret;

  pthread_setspecific( async_key, data );
  ret = async->proc( async->data );
  return ( void * ) ret;
}


int 
start_async( struct async *async ) {
  int err;

  if ( !main_thread_set ) {
    main_thread_set = 1;
    main_thread = pthread_self(); // the thread_id of the calling thread
    pthread_key_create( &async_key, NULL );
  }
  err = pthread_create( &async->tid, NULL, run_thread, async );
  if (!err) {
    return 0;
  } else {
    error( "Can not create thread %s", strerror( err ) );
    return -1;
  }
}
