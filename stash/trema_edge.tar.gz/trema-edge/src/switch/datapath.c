#include <stdlib.h>
#include <pthread.h>
#include <stdbool.h>
#include <unistd.h>
#include "wrapper.h"
#include "ofdp.h"
#include "port_manager.h"

#include "async.h"
#include "parse-options.h"
#include "switch.h"
#include "protocol.h"
#include "datapath.h"
#include "controller_manager.h"


static list_element *
analyze_argument_device_option( char *optarg ) {
  list_element *head = NULL;

  char *save_ptr = NULL;
  char *p = strtok_r( optarg, ",", &save_ptr );

  for (;; ) {
    if ( p == NULL ) {
      break;
    }

    char *p_port = NULL;
    char *p_dev = strtok_r( p, ":", &p_port );

    argument_device_info *dev_info = ( argument_device_info * ) xcalloc( 1, sizeof( argument_device_info ) );
    strncpy( dev_info->device_name, p_dev, IFNAMSIZ - 1 );
    if ( p_port != NULL ) {
      dev_info->port_no = ( uint16_t ) atoi( p_port );
    }
    else {
      dev_info->port_no = 0;
    }

    append_to_tail( &head, dev_info );

    p = strtok_r( NULL, ",", &save_ptr );
  }
  return head;
}


static void 
datapath_packet_in( void *notify_parameter ) {
  notify_parameter_packet_in *packet_in = notify_parameter;
  debug( "reason %d", packet_in->reason );
}

static void
datapath_flow_removed( void *notify_parameter ) {
  notify_parameter_flow_removed *flow_removed = notify_parameter;
  UNUSED( flow_removed );
}

static 
void set_notify_handlers() {
  register_notify_handler_to_controller( NOTIFY_TYPE_PACKET_IN, datapath_packet_in );
  register_notify_handler_to_controller( NOTIFY_TYPE_FLOW_REMOVED, datapath_flow_removed );
}


static bool
add_datapath_ports( list_element *devices_info ) {
  list_element *p;
  OFDPE ret = OFDPE_SUCCESS;

  for( p = devices_info; p != NULL; p = p->next ) {
    argument_device_info *dev = p->data;
    ret = add_port( dev->port_no, dev->device_name );
    if ( ret != OFDPE_SUCCESS ) {
      return false;
    }
  }
  return true;
}


static int
serve_datapath( void *data ) {
  const struct datapath *datapath = data;
  const struct switch_arguments *args = datapath->args;
  ofdp_library_argument *lib_arg;

  list_element *datapath_ports;
  char datapath_ports_args[ PATH_MAX ]; 
  strncpy( datapath_ports_args, args->datapath_ports, strlen( args->datapath_ports ) );
  datapath_ports = analyze_argument_device_option( datapath_ports_args );
  lib_arg = ( ofdp_library_argument *) xmalloc( sizeof( *lib_arg ) );
  set_ofdp_library_argument( lib_arg,
    args->progname, args->log_level, datapath_ports, args->run_as_daemon,
    SWITCH_MTU, NUM_POOL, NUM_CONTROLLER_BUFFER, SELECT_TIMEOUT_USEC, MAX_SEND_QUEUE, MAX_RECV_QUEUE, args->datapath_id );

  OFDPE ret;
  ret = init_datapath( lib_arg );
  if ( ret != OFDPE_SUCCESS ) {
    error( "Init_datapath failed" );
  }
  add_datapath_ports( lib_arg->devices_info );
  set_notify_handlers();
  start_datapath();
  SLEEP_FOREVER();


  return( EXIT_SUCCESS );
}

int
start_async_datapath( struct switch_arguments *args ) {
  int ret;

  struct datapath *datapath;
  
  datapath = ( struct datapath * ) xmalloc( sizeof( *datapath ) );
  datapath->thread.proc = serve_datapath;
  datapath->args = args;
  datapath->thread.data = datapath;
  ret = start_async( &datapath->thread );
  if ( ret < 0 ) {
    error( "Failed to start the datapath thread" );
  }
  return( ret );
}
