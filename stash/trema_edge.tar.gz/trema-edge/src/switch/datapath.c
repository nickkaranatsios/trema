#include <stdlib.h>
#include <pthread.h>
#include "wrapper.h"
#include "ofdp.h"
#include "port_manager.h"

#include "async.h"
#include "parse-options.h"
#include "protocol.h"
#include "datapath.h"


static list_element *
analyze_argument_device_option( char *optarg ) {
  list_element *head = NULL;

  char *save_ptr = NULL;
  char *p = strtok_r( optarg, ",", &save_ptr );

  for (;; ) {
    if ( p == NULL ) {
      break;
    }

    char *p_port = NULL;
    char *p_dev = strtok_r( p, ":", &p_port );

    argument_device_info *dev_info = ( argument_device_info * ) xcalloc( 1, sizeof( argument_device_info ) );
    strncpy( dev_info->device_name, p_dev, IFNAMSIZ - 1 );
    if ( p_port != NULL ) {
      dev_info->port_no = ( uint16_t ) atoi( p_port );
    }
    else {
      dev_info->port_no = 0;
    }

    append_to_tail( &head, dev_info );

    p = strtok_r( NULL, ",", &save_ptr );
  }
  return head;
}


int
start_async_datapath( struct switch_arguments *args ) {
  list_element *datapath_ports;
  char datapath_ports_args[ 256 ]; 

  strncpy( datapath_ports_args, args->datapath_ports, strlen( args->datapath_ports ) - 1 );
  datapath_ports = analyze_argument_device_option( datapath_ports_args );
  ofdp_library_argument lib_arg;

  set_ofdp_library_argument( &lib_arg,
    args->progname, args->log_level, datapath_ports, args->run_as_daemon,
    SWITCH_MTU, NUM_POOL, NUM_CONTROLLER_BUFFER, SELECT_TIMEOUT_USEC, MAX_SEND_QUEUE, MAX_RECV_QUEUE, args->datapath_id );
}
 
