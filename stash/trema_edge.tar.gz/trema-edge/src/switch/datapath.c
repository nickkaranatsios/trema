/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include <stdlib.h>
#include <pthread.h>
#include <stdbool.h>
#include <unistd.h>
#include <assert.h>
#include <inttypes.h>
#include <pthread.h>

#include "wrapper.h"
#include "message_queue.h"
#include "oxm_match.h"
#include "openflow_message.h"
#include "thread-test.h"
#include "timer-test.h"
#include "async-lock.h"
#include "async-util.h"
#include "ofdp.h"
#include "port_manager.h"

#include "async.h"
#include "parse-options.h"
#include "switch.h"
#include "protocol.h"
#include "datapath.h"
#include "controller_manager.h"
#include "table_manager_match.h"


void
notify_protocol( int fd, void *user_data ) {
  assert( fd >= 0 );
  struct datapath *datapath = user_data;
  assert( datapath != NULL );

  ssize_t ret = write( datapath->peer_efd, &datapath->send_count, sizeof( datapath->send_count ) );
  if ( ret < 0 ) {
    if ( ret == EAGAIN || errno == EINTR ) {
      return;
    }
    char buf[ 256 ];
    memset( buf, '\0', sizeof( buf ) );
    char *error_string = strerror_r( errno, buf, sizeof( buf ) - 1 );    
    error( "Failed to notify protocol count= " PRIu64 ", ret = %d errno %s [%d]", datapath->send_count, ret, error_string, errno );
    return;
  } else if ( ret != sizeof( datapath->send_count ) ) {
    error( "Failed to notify protocol count= " PRIu64 ",ret = %d", datapath->send_count, ret );
  }
  datapath->send_count = 0;
  new_set_writable( fd, false );
}


static void
push_datapath_message_to_peer( buffer *packet, struct datapath *datapath ) {
  enqueue_message( datapath->peer_queue, packet );
  datapath->send_count++;
  new_set_writable( datapath->own_efd, true );
}


static void
post_datapath_status ( struct datapath *datapath ) {
  uint32_t buffer_len = sizeof( struct datapath_ctrl );

  buffer *buffer = alloc_buffer_with_length( buffer_len );
  append_back_buffer( buffer, buffer_len );
  struct datapath_ctrl *ctrl = buffer->data;
  ctrl->status = datapath->running;
  push_datapath_message_to_peer( buffer, datapath );
}


static list_element *
analyze_argument_device_option( char *optarg ) {
  list_element *head = NULL;

  char *save_ptr = NULL;
  char *p = strtok_r( optarg, ",", &save_ptr );

  for (;; ) {
    if ( p == NULL ) {
      break;
    }

    char *p_port = NULL;
    char *p_dev = strtok_r( p, ":", &p_port );

    argument_device_info *dev_info = ( argument_device_info * ) xcalloc( 1, sizeof( argument_device_info ) );
    strncpy( dev_info->device_name, p_dev, IFNAMSIZ - 1 );
    if ( p_port != NULL ) {
      dev_info->port_no = ( uint16_t ) atoi( p_port );
    }
    else {
      dev_info->port_no = 0;
    }

    append_to_tail( &head, dev_info );

    p = strtok_r( NULL, ",", &save_ptr );
  }
  return head;
}


static void 
datapath_packet_in( void *notify_parameter, void *user_data ) {
  notify_parameter_packet_in *notifier = notify_parameter;
  assert( user_data );
  struct datapath *datapath = user_data;

#ifdef NK
  should check the buffer_id != OFP_NO_BUFFER
  uint32_t packet_len = sizeof( notify_parameter_packet_in ) + notifier->packet->length;
  buffer *packet = alloc_buffer_with_length( packet_len );
  append_back_buffer( packet, packet_len );
  memcpy( packet->data, notifier, packet_len );
  push_datapath_message_to_peer( packet, datapath );
  if ( reason  == OFPP_NO_MATCH ) create a packet_in with empty oxm_match structure.
#endif
  uint32_t notifier_len = sizeof( struct ofp_header ) + sizeof( *notifier ) + notifier->packet->length;

  buffer *packet = alloc_buffer_with_length( notifier_len );
  append_back_buffer( packet, notifier_len );

  struct ofp_header *hdr = packet->data;
  hdr->length = ( uint16_t ) notifier_len;
  hdr->type = OFPT_PACKET_IN; 

  notify_parameter_packet_in *parameter_packet_in = ( notify_parameter_packet_in * )( ( char * ) packet->data + sizeof( *hdr ) );
  memcpy( parameter_packet_in, notifier, sizeof( *parameter_packet_in ) );
  if ( notifier->packet->length > 0 ) {
    duplicate_buffer( parameter_packet_in->packet );
  }
  push_datapath_message_to_peer( packet, datapath );
}


static void
datapath_flow_removed( void *notify_parameter, void *user_data ) {
  notify_parameter_flow_removed *notifier = notify_parameter;
  assert( user_data );
  struct datapath *datapath = user_data;
  uint32_t notifier_len = sizeof( struct ofp_header ) + sizeof( *notifier );

  buffer *packet = alloc_buffer_with_length( notifier_len );
  append_back_buffer( packet, notifier_len );

  struct ofp_header *hdr = packet->data;
  hdr->length = ( uint16_t ) notifier_len;
  hdr->type = OFPT_FLOW_REMOVED;

  notify_parameter_flow_removed *parameter_flow_removed = ( notify_parameter_flow_removed * )( ( char * ) packet->data + sizeof( *hdr ) );
  memcpy( parameter_flow_removed, notifier, sizeof( *parameter_flow_removed ) );
  push_datapath_message_to_peer( packet, datapath );
}


static void
datapath_port_status( void *notify_parameter, void *user_data ) {
  notify_parameter_port_status *notifier = notify_parameter;
  assert( user_data );
  struct datapath *datapath = user_data;
  uint32_t notifier_len = sizeof( struct ofp_header ) + sizeof( *notifier );

  buffer *packet = alloc_buffer_with_length( notifier_len );
  append_back_buffer( packet, notifier_len );

  struct ofp_header *hdr = packet->data;
  hdr->length = ( uint16_t ) notifier_len;
  hdr->type = OFPT_PORT_STATUS;

  notify_parameter_port_status *parameter_port_status = ( notify_parameter_port_status * )( ( char * ) packet->data + sizeof( *hdr ) );
  memcpy( parameter_port_status, notifier, sizeof( *parameter_port_status ) );
  push_datapath_message_to_peer( packet, datapath );
}


static void
datapath_error( void *notify_parameter, void *user_data ) {
  notify_parameter_error *notifier = notify_parameter;
  assert( user_data );
  struct datapath *datapath = user_data;
  uint32_t notifier_len = sizeof( struct ofp_header ) + sizeof( *notifier ) + notifier->packet->length;

  buffer *packet = alloc_buffer_with_length( notifier_len );
  append_back_buffer( packet, notifier_len );

  struct ofp_header *hdr = packet->data;
  hdr->length = ( uint16_t ) notifier_len;
  hdr->type = OFPT_ERROR;

  notify_parameter_error *parameter_error = ( notify_parameter_error * )( ( char * ) packet->data + sizeof( *hdr ) );
  memcpy( parameter_error, notifier, sizeof( *parameter_error ) );
  if ( notifier->packet->length > 0 ) {
    duplicate_buffer( parameter_error->packet );
  }
  push_datapath_message_to_peer( packet, datapath );
}


static 
void set_notify_handlers( void *user_data ) {
  register_notify_handler_to_controller( NOTIFY_TYPE_PACKET_IN, datapath_packet_in, user_data );
  register_notify_handler_to_controller( NOTIFY_TYPE_FLOW_REMOVED, datapath_flow_removed, user_data );
  register_notify_handler_to_controller( NOTIFY_TYPE_PORT_STATUS, datapath_port_status, user_data );
  register_notify_handler_to_controller( NOTIFY_TYPE_ERROR, datapath_error, user_data );
}


static bool
add_datapath_ports( list_element *devices_info ) {
  list_element *p;
  OFDPE ret = OFDPE_SUCCESS;

  for( p = devices_info; p != NULL; p = p->next ) {
    argument_device_info *dev = p->data;
    ret = add_port( dev->port_no, dev->device_name );
    if ( ret != OFDPE_SUCCESS ) {
      return false;
    }
  }
  return true;
}


static int
serve_datapath( void *data ) {
  struct datapath *datapath = data;
  const struct switch_arguments *args = datapath->args;
  ofdp_library_argument *lib_arg;

  list_element *datapath_ports;
  char datapath_ports_args[ PATH_MAX ]; 
  strncpy( datapath_ports_args, args->datapath_ports, strlen( args->datapath_ports ) );
  // parses a comma separated list of ethernet ports into a linked list.
  datapath_ports = analyze_argument_device_option( datapath_ports_args );
  lib_arg = ( ofdp_library_argument *) xmalloc( sizeof( *lib_arg ) );
  set_ofdp_library_argument( lib_arg,
    args->progname, args->log_level, datapath_ports, args->run_as_daemon,
    SWITCH_MTU, NUM_POOL, NUM_CONTROLLER_BUFFER, SELECT_TIMEOUT_USEC, MAX_SEND_QUEUE, MAX_RECV_QUEUE, args->datapath_id );

  datapath->running = init_datapath( lib_arg );
  xfree( lib_arg );
  if ( datapath->running != OFDPE_SUCCESS ) {
    error( "Init_datapath failed" );
    delete_list( datapath_ports );
    // TODO what error should we return here.
    return -1;
  }
  add_thread();
  new_init_timer();
  new_init_event_handler();
  datapath->own_efd = args->efd[ 1 ];
  datapath->peer_efd = args->efd[ 0 ];
  datapath->peer_queue = args->to_protocol_queue;
  datapath->send_count = 0;
  
  new_set_fd_handler( datapath->own_efd, NULL, NULL, notify_protocol, datapath );
  new_set_writable( datapath->own_efd, false );


  add_datapath_ports( lib_arg->devices_info );
  set_notify_handlers( datapath );
  post_datapath_status( datapath );
  start_datapath();
  return new_start_event_handler();
}


pthread_t
start_async_datapath( struct switch_arguments *args ) {
  int ret;

  struct datapath *datapath;
  
  datapath = ( struct datapath * ) xmalloc( sizeof( *datapath ) );
  datapath->thread.proc = serve_datapath;
  datapath->args = args;
  datapath->thread.data = datapath;
  ret = start_async( &datapath->thread );
  if ( ret < 0 ) {
    error( "Failed to start the datapath thread" );
    return 0;
  }
  return datapath->thread.tid;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
