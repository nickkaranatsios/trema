#ifndef DATAPATH_H
#define DATAPATH_H

#define SWITCH_MTU 1520
#define NUM_POOL   1000

#define NUM_CONTROLLER_BUFFER  100
#define MAX_SEND_QUEUE  400
#define MAX_RECV_QUEUE  400      // NUM_POOL - (NUM_POOL - NUM_CONTROLLER_BUFFER) * x
#define SELECT_TIMEOUT_USEC 100000
#define DATAPATH_ID  1


struct datapath {
  struct async thread;
  message_queue *to_protocol_queue;
  const struct switch_arguments *args; 
  void *data;
};

int start_async_datapath( struct switch_arguments *args );
#endif
