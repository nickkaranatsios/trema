/*
 * Functions for executing OpenFlow actions.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef ACTION_EXECUTOR_H
#define ACTION_EXECUTOR_H


#include "ofdp_common.h"
#include "table_manager.h"
#include "buffer.h"
#include "packet_info.h"


typedef struct {
  action *copy_ttl_in;
  action *pop_mpls;
  action *pop_pbb;
  action *pop_vlan;
  action *push_mpls;
  action *push_pbb;
  action *push_vlan;
  action *copy_ttl_out;
  action *dec_mpls_ttl;
  action *dec_nw_ttl;
  action *set_mpls_ttl;
  action *set_nw_ttl;
  action *set_field;
  action *set_queue;
  action *group;
  action *output;
} action_set;


OFDPE init_action_executor( void );
OFDPE finalize_action_executor( void );
OFDPE ( *execute_action_list )( action_list *p_action_list, buffer *frame );
OFDPE ( *execute_action_set )( action_set *action_set, buffer *frame );
OFDPE ( *execute_action_packet_out )( uint32_t buffer_id, uint32_t in_port, action_list *action_list, buffer *frame );


#endif  // ACTION_EXECUTOR_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
