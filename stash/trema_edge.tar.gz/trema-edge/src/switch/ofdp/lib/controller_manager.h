/*
 * Functions for sending/receving Openflow controller message.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef CONTROLLER_MANAGER_H
#define CONTROLLER_MANAGER_H


#include "ofdp_common.h"
#include "table_manager.h"


typedef enum {
  NOTIFY_TYPE_PACKET_IN,
  NOTIFY_TYPE_FLOW_REMOVED,
  NOTIFY_TYPE_PORT_STATUS,
  NOTIFY_TYPE_ERROR
} nofity_type;


typedef struct {
  uint32_t buffer_id;
  uint8_t reason;
  uint64_t table_id;
  uint64_t cookie;
  match match;
  uint16_t max_len;
  buffer *packet;
} notify_parameter_packet_in;


typedef struct {
  uint64_t cookie;
  uint16_t priority;
  uint8_t reason;
  uint8_t table_id;
  uint32_t duration_sec;
  uint32_t duration_nsec;
  uint16_t idle_timeout;
  uint16_t hard_timeout;
  uint64_t packet_count;
  uint64_t byte_count;
  match match;
} notify_parameter_flow_removed;


typedef struct {
  uint8_t reason;
  struct ofp_port desc;
} notify_parameter_port_status;


typedef struct {
  OFDPE error_code;     // ERROR_OFDPE_*
  buffer *packet;
} notify_parameter_error;


typedef void ( *handler_notify_to_controller )( void *notify_parameter );


OFDPE ( *init_controller_manager )( uint32_t buffer_list_max );
OFDPE ( *finalize_controller_manager )();
OFDPE ( *notify_packet_in )( notify_parameter_packet_in *parameter );
OFDPE ( *notify_flow_removed )( notify_parameter_flow_removed *parameter );
OFDPE ( *notify_port_status )( notify_parameter_port_status *parameter );
OFDPE ( *notify_error )( notify_parameter_error *parameter );
OFDPE ( *register_notify_handler_to_controller )( nofity_type type, handler_notify_to_controller handler );
void ( *execute_external_message )();
OFDPE ( *get_packet_buffer )( uint32_t buffer_id, buffer **buffer );
OFDPE ( *add_port )( uint32_t port, const char *device_name );
OFDPE ( *delete_port )( uint32_t port );


#endif  // CONTROLLER_MANAGER_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
