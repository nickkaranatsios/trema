/*
 * Functions for sending/receving Ethernet frames with raw socket interface.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include <arpa/inet.h>
#include <assert.h>
#include <ctype.h>
#include <errno.h>
#include <inttypes.h>
#include <linux/ethtool.h>
#include <linux/if_ether.h>
#include <linux/if_packet.h>
#include <linux/sockios.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include "utility.h"
#include "checks.h"
#include "ether_device.h"
#include "log.h"
#include "event_handler_datapath.h"
#include "wrapper.h"
#include "packet_buffer_pool.h"
#include "ofdp_common.h"


#define ERROR_STRING_SIZE 128


static uint32_t
make_current_ofp_port_features( uint32_t speed, uint8_t duplex, uint8_t port, uint8_t autoneg,
  uint32_t rx_pause, uint32_t tx_pause ) {
  uint32_t ofp_features = 0;

  if ( ( speed == SPEED_10 ) && ( duplex == DUPLEX_HALF ) ) {
    ofp_features |= OFPPF_10MB_HD;
  }
  if ( ( speed == SPEED_10 ) && ( duplex == DUPLEX_FULL ) ) {
    ofp_features |= OFPPF_10MB_FD;
  }
  if ( ( speed == SPEED_100 ) && ( duplex == DUPLEX_HALF ) ) {
    ofp_features |= OFPPF_100MB_HD;
  }
  if ( ( speed == SPEED_100 ) && ( duplex == DUPLEX_FULL ) ) {
    ofp_features |= OFPPF_100MB_FD;
  }
  if ( ( speed == SPEED_1000 ) && ( duplex == DUPLEX_HALF ) ) {
    ofp_features |= OFPPF_1GB_HD;
  }
  if ( ( speed == SPEED_1000 ) && ( duplex == DUPLEX_FULL ) ) {
    ofp_features |= OFPPF_1GB_FD;
  }
  if ( speed == SPEED_10000 ) {
    ofp_features |= OFPPF_10GB_FD;
  }
  if ( ( port == PORT_TP ) || ( port == PORT_AUI ) || ( port == PORT_BNC ) ) {
    ofp_features |= OFPPF_COPPER;
  }
  if ( port == PORT_FIBRE ) {
    ofp_features |= OFPPF_FIBER;
  }
  if ( autoneg == AUTONEG_ENABLE ) {
    ofp_features |= OFPPF_AUTONEG;
  }
  if ( rx_pause & tx_pause ) {
    ofp_features |= OFPPF_PAUSE;
  }
  else if ( rx_pause | tx_pause ) {
    ofp_features |= OFPPF_PAUSE_ASYM;
  }

  return ofp_features;
}


static uint32_t
make_supported_ofp_port_features( uint32_t features ) {
  uint32_t ofp_features = 0;

  if ( features & SUPPORTED_10baseT_Half ) {
    ofp_features |= OFPPF_10MB_HD;
  }
  if ( features & SUPPORTED_10baseT_Full ) {
    ofp_features |= OFPPF_10MB_FD;
  }
  if ( features & SUPPORTED_100baseT_Half ) {
    ofp_features |= OFPPF_100MB_HD;
  }
  if ( features & SUPPORTED_100baseT_Full ) {
    ofp_features |= OFPPF_100MB_FD;
  }
  if ( features & SUPPORTED_1000baseT_Half ) {
    ofp_features |= OFPPF_1GB_HD;
  }
  if ( features & ( SUPPORTED_1000baseT_Full | SUPPORTED_1000baseKX_Full ) ) {
    ofp_features |= OFPPF_1GB_FD;
  }
  if ( features & ( SUPPORTED_10000baseT_Full | SUPPORTED_10000baseKX4_Full | SUPPORTED_10000baseKR_Full ) ) {
    ofp_features |= OFPPF_10GB_FD;
  }
  if ( features & ( SUPPORTED_TP | SUPPORTED_AUI | SUPPORTED_BNC ) ) {
    ofp_features |= OFPPF_COPPER;
  }
  if ( features & SUPPORTED_FIBRE ) {
    ofp_features |= OFPPF_FIBER;
  }
  if ( features & SUPPORTED_Autoneg ) {
    ofp_features |= OFPPF_AUTONEG;
  }
  if ( features & SUPPORTED_Pause ) {
    ofp_features |= OFPPF_PAUSE;
  }
  if ( features & SUPPORTED_Asym_Pause ) {
    ofp_features |= OFPPF_PAUSE_ASYM;
  }

  return ofp_features;
}


bool
update_device_status( ether_device *device ) {
  assert( device != NULL );
  assert( strlen( device->name ) > 0 );

  int fd = socket( PF_INET, SOCK_DGRAM, 0 );
  if ( fd < 0 ) {
    char error_string[ ERROR_STRING_SIZE ];
    error( "Failed to open a socket ( ret = %d, errno = %s [%d] ).",
      fd, strerror_r( errno, error_string, sizeof( error_string ) ), errno );
    return false;
  }

  struct ifreq ifr;
  memset( &ifr, 0, sizeof( ifr ) );
  strncpy( ifr.ifr_name, device->name, IFNAMSIZ );
  ifr.ifr_name[ IFNAMSIZ - 1 ] = '\0';

  struct ethtool_value ev;
  ev.cmd = ETHTOOL_GLINK;
  ifr.ifr_data = ( char * ) &ev;
  int ret = ioctl( fd, SIOCETHTOOL, &ifr );
  if ( ret == -1 ) {
    char error_string[ ERROR_STRING_SIZE ];
    error( "Failed to retrieve link status of %s ( ret = %d, error = %s [%d] ).",
      device->name, ret, strerror_r( errno, error_string, sizeof( error_string ) ), errno );
    warn( "Assuming link is up ( device = %s ).", device->name );
    device->status.up = true;
  }
  else {
    if ( ev.data > 0 ) {
      device->status.up = true;
    }
    else {
      device->status.up = false;
    }
  }

  struct ethtool_cmd ec;
  memset( &ec, 0, sizeof( struct ethtool_cmd ) );
  if ( device->status.can_retrieve_link_status ) {
    ec.cmd = ETHTOOL_GSET;
    ifr.ifr_data = ( char * ) &ec;
    ret = ioctl( fd, SIOCETHTOOL, &ifr );
    if ( ret == -1 ) {
      char error_string[ ERROR_STRING_SIZE ];
      warn( "Failed to retrieve statuses of %s ( ret = %d, error = %s [%d] ).",
        device->name, ret, strerror_r( errno, error_string, sizeof( error_string ) ), errno );
      warn( "Assuming 100Mbps/Full Duplex/Twisted Pair link ( device = %s ).", device->name );
      ethtool_cmd_speed_set( &ec, SPEED_100 );
      ec.duplex = DUPLEX_FULL;
      ec.port = PORT_TP;
      ec.advertising = SUPPORTED_100baseT_Full | SUPPORTED_TP;
      ec.supported = ADVERTISED_100baseT_Full | ADVERTISED_TP;
      device->status.can_retrieve_link_status = false;
    }
  }

  struct ethtool_pauseparam ep;
  memset( &ep, 0, sizeof( struct ethtool_pauseparam ) );
  if ( device->status.can_retrieve_pause ) {
    ep.cmd = ETHTOOL_GPAUSEPARAM;
    ifr.ifr_data = ( char * ) &ep;
    ret = ioctl( fd, SIOCETHTOOL, &ifr );
    if ( ret == -1 ) {
      char error_string[ ERROR_STRING_SIZE ];
      warn( "Failed to retrieve pause parameters of %s ( ret = %d, error = %s [%d] ).",
        device->name, ret, strerror_r( errno, error_string, sizeof( error_string ) ), errno );
      warn( "Assuming pause is disabled ( device = %s ).", device->name );
      device->status.can_retrieve_pause = false;
    }
  }

  close( fd );

  device->status.curr = make_current_ofp_port_features( ethtool_cmd_speed( &ec ), ec.duplex, ec.port,
    ec.autoneg, ep.rx_pause, ep.tx_pause );
  device->status.advertised = make_supported_ofp_port_features( ec.advertising );
  device->status.supported = make_supported_ofp_port_features( ec.supported );
  device->status.peer = device->status.curr; // FIMXE: how to know the correct value?

  return true;
}


bool
update_device_stats( ether_device *device ) {
  assert( device != NULL );
  assert( strlen( device->name ) > 0 );

  FILE *fh = fopen( "/proc/net/dev", "r" );
  if ( fh == NULL ) {
    error( "Failed to open /proc/net/dev." );
    return false;
  }

  bool found = false;
  while ( 1 ) {
    char buf[ 256 ];
    char *line = fgets( buf, sizeof( buf ), fh );
    if ( line == NULL ) {
      break;
    }
    char *head = strstr( line, device->name );
    if ( head == NULL ) {
      continue;
    }

    head = head + strlen( device->name ) + 1; // skip "  eth0:"
    uint64_t trash;
    int ret = sscanf( head, "%" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64
      " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64
      " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64,
      &device->stats.rx_bytes, &device->stats.rx_packets, &device->stats.rx_errors,
      &device->stats.rx_dropped, &device->stats.rx_over_err, &device->stats.rx_frame_err,
      &trash, &trash, &device->stats.tx_bytes, &device->stats.tx_packets,
      &device->stats.tx_errors, &device->stats.tx_dropped, &trash,
      &device->stats.collisions, &trash, &trash );
    if ( ret != 16 ) {
      error( "Failed to retrieve interface statistics ( ret = %d, device = %s ).", ret, device->name );
      break;
    }
    found = true;
  }

  fclose( fh );

  return found;
}


static void
enable_promiscuous( ether_device *device ) {
  int fd = socket( AF_INET, SOCK_DGRAM, 0 );

  struct ifreq ifr;

  memset( &ifr, 0, sizeof( ifr ) );
  strncpy( ifr.ifr_name, device->name, IFNAMSIZ );
  ifr.ifr_name[ IFNAMSIZ - 1 ] = '\0';

  int ret = ioctl( fd, SIOCGIFFLAGS, &ifr );
  if ( ret == -1 ) {
    char error_string[ ERROR_STRING_SIZE ];
    error( "Failed to get interface flags ( name = %s, ret = %d, errno = %s [%d] ).",
      ifr.ifr_name, ret, strerror_r( errno, error_string, sizeof( error_string ) ), errno );
    close( fd );
    return;
  }

  ifr.ifr_flags |= IFF_PROMISC;
  ret = ioctl( fd, SIOCSIFFLAGS, &ifr );
  if ( ret == -1 ) {
    char error_string[ ERROR_STRING_SIZE ];
    error( "Failed to set interface flags ( name = %s, flags = %#x, ret = %d, errno = %s [%d] ).",
      ifr.ifr_name, ifr.ifr_flags, ret, strerror_r( errno, error_string, sizeof( error_string ) ), errno );
    close( fd );
    return;
  }

  close( fd );
}


static void
disable_promiscuous( ether_device *device ) {
  int fd = socket( AF_INET, SOCK_DGRAM, 0 );

  struct ifreq ifr;

  memset( &ifr, 0, sizeof( ifr ) );
  strncpy( ifr.ifr_name, device->name, IFNAMSIZ );
  ifr.ifr_name[ IFNAMSIZ - 1 ] = '\0';

  int ret = ioctl( fd, SIOCGIFFLAGS, &ifr );
  if ( ret == -1 ) {
    char error_string[ ERROR_STRING_SIZE ];
    error( "Failed to get interface flags ( name = %s, ret = %d, errno = %s [%d] ).",
      ifr.ifr_name, ret, strerror_r( errno, error_string, sizeof( error_string ) ), errno );
    close( fd );
    return;
  }

  ifr.ifr_flags &= ~IFF_PROMISC;
  ret = ioctl( fd, SIOCSIFFLAGS, &ifr );
  if ( ret == -1 ) {
    char error_string[ ERROR_STRING_SIZE ];
    error( "Failed to set interface flags ( name = %s, flags = %#x, ret = %d, errno = %s [%d] ).",
      ifr.ifr_name, ifr.ifr_flags, ret, strerror_r( errno, error_string, sizeof( error_string ) ), errno );
    close( fd );
    return;
  }

  close( fd );
}


static void
handle_received_frames( ether_device *device ) {
  while ( device->recv_queue->length > 0 ) {
    buffer *frame = dequeue_message_datapath( device->recv_queue );
    if ( device->received_callback != NULL ) {
      device->received_callback( frame, device->received_user_data );
    }
  }
}


static void
recv_frame( int fd, void *user_data ) {
  UNUSED( fd );

  ether_device *device = user_data;
  assert( device != NULL );

  /* comment out by isp 2012/09/05
    // all queued messages should be processed before receiving new messages from remote
    if ( device->recv_queue->length > 0 ) {
      return;
    }
  */

  if ( device->max_recv_queue <= device->recv_queue->length ) {
    error( "over max recv queue error.(max=%u, current=%u)", device->max_recv_queue, device->recv_queue->length );
    return;
  }


  static char recv_buf[ 1522 ];
  int count = 0;
  while ( count < 256 ) {
    ssize_t length = recv( device->fd, recv_buf, sizeof( recv_buf ), MSG_DONTWAIT );
    assert( length != 0 );
    if ( length < 0 ) {
      if ( ( errno == EINTR ) || ( errno == EAGAIN ) || ( errno == EWOULDBLOCK ) ) {
        break;
      }
      char error_string[ ERROR_STRING_SIZE ];
      error( "Receive error ( errno = %s [%d] ).", strerror_r( errno, error_string, sizeof( error_string ) ), errno );
      return;
    }

    buffer *frame = allocate_packet_buffer();
    void *p = append_back_buffer_pool_entry( frame, ( size_t ) length );
    if ( p == NULL ) {
      error( "Memory allocation error." );
      if ( frame != NULL ) {
        free_packet_buffer_pool_entry( frame );
      }
      return;
    }
    memcpy( p, recv_buf, ( size_t ) length );
    enqueue_message( device->recv_queue, frame );
    count++;
  }

  handle_received_frames( device );
}


static void
flush_send_queue( int fd, void *user_data ) {
  UNUSED( fd );

  ether_device *device = user_data;
  assert( device != NULL );

  debug( "Flushing send queue ( name = %s, queue length = %d ).", device->name, device->send_queue->length );

  set_writable_datapath( device->fd, false );

  struct sockaddr_ll sll;
  memset( &sll, 0, sizeof( sll ) );
  sll.sll_ifindex = device->ifindex;

  int count = 0;
  buffer *buf = NULL;
  while ( ( buf = peek_message_datapath( device->send_queue ) ) != NULL && count < 256 ) {
    ssize_t length = sendto( device->fd, buf->data, buf->length, MSG_DONTWAIT,
        ( struct sockaddr * ) &sll, sizeof( sll ) );
    if ( length < 0 ) {
      if ( ( errno == EINTR ) || ( errno == EAGAIN ) || ( errno == EWOULDBLOCK ) ) {
        set_writable_datapath( device->fd, true );
        return;
      }
      char error_string[ ERROR_STRING_SIZE ];
      error( "Failed to send a message to ethernet device ( name = %s, errno = %s [%d] ).",
        device->name, strerror_r( errno, error_string, sizeof( error_string ) ), errno );
      return;
    }

    device->status.tx_bytes += ( size_t )length;

    if ( ( size_t ) length < buf->length ) {
      remove_front_buffer_pool_entry( buf, ( size_t ) length );
      set_writable_datapath( device->fd, true );
      return;
    }

    buf = dequeue_message_datapath( device->send_queue );
    free_packet_buffer_pool_entry( buf );
    count++;
  }
}


ether_device *
create_ether_device( const char *name, const size_t max_send_queue, const size_t max_recv_queue ) {
  assert( strlen( name ) > 0 );

  int nfd = socket( PF_INET, SOCK_DGRAM, 0 );
  if ( nfd < 0 ) {
    char error_string[ ERROR_STRING_SIZE ];
    error( "Failed to open a socket ( ret = %d, errno = %s [%d] ).",
      nfd, strerror_r( errno, error_string, sizeof( error_string ) ), errno );
    return NULL;
  }

  struct ifreq ifr;
  memset( &ifr, 0, sizeof( ifr ) );
  strncpy( ifr.ifr_name, name, IFNAMSIZ );
  ifr.ifr_name[ IFNAMSIZ - 1 ] = '\0';
  int ret = ioctl( nfd, SIOCGIFINDEX, &ifr );
  if ( ret == -1 ) {
    char error_string[ ERROR_STRING_SIZE ];
    error( "Failed to retrieve an interface index of %s ( ret = %d, errno = %s [%d] ).",
      name, ret, strerror_r( errno, error_string, sizeof( error_string ) ), errno );
    close( nfd );
    return NULL;
  }
  int ifindex = ifr.ifr_ifindex;

  ret = ioctl( nfd, SIOCGIFHWADDR, &ifr );
  if ( ret == -1 ) {
    char error_string[ ERROR_STRING_SIZE ];
    error( "Failed to retrieve hardware address of %s ( ret = %d, error = %s [%d] ).",
      name, ret, strerror_r( errno, error_string, sizeof( error_string ) ), errno );
    close( nfd );
    return NULL;
  }

  close( nfd );

  int fd = socket( PF_PACKET, SOCK_RAW, htons( ETH_P_ALL ) );
  if ( fd < 0 ) {
    char error_string[ ERROR_STRING_SIZE ];
    error( "Failed to open a socket ( ret = %d, errno = %s [%d] ).",
      fd, strerror_r( errno, error_string, sizeof( error_string ) ), errno );
    return NULL;
  }

  struct sockaddr_ll sll;
  memset( &sll, 0, sizeof( sll ) );
  sll.sll_family = AF_PACKET;
  sll.sll_protocol = htons( ETH_P_ALL );
  sll.sll_ifindex = ifindex;
  ret = bind( fd, ( struct sockaddr * ) &sll, sizeof( sll ) );
  if ( ret < 0 ) {
    char error_string[ ERROR_STRING_SIZE ];
    error( "Failed to bind ( fd = %d, ret = %d, errno = %s [%d] ).",
      fd, ret, strerror_r( errno, error_string, sizeof( error_string ) ), errno );
    close( fd );
    return NULL;
  }

  while ( 1 ) {
    char buf;
    ssize_t length = recv( fd, &buf, 1, MSG_DONTWAIT );
    if ( length <= 0 ) {
      break;
    }
  }

  ether_device *device = xmalloc( sizeof( ether_device ) );
  memset( device, 0, sizeof( ether_device ) );
  strncpy( device->name, name, IFNAMSIZ );
  device->name[ IFNAMSIZ - 1 ] = '\0';
  device->fd = fd;
  device->ifindex = ifindex;
  memcpy( device->hw_addr, ifr.ifr_hwaddr.sa_data, ETH_ADDRLEN );
  device->status.can_retrieve_link_status = true;
  device->status.can_retrieve_pause = true;
  device->send_queue = create_message_queue_datapath();
  device->recv_queue = create_message_queue_datapath();
  device->max_send_queue = max_send_queue;
  device->max_recv_queue = max_recv_queue;

  short int flags = get_device_flags( device->name );
  if ( ( flags & IFF_UP ) == IFF_UP ) {
    device->init_linkup = true;
  } else {
    device->init_linkup = false;
  }
  if ( ( flags & IFF_PROMISC ) == IFF_PROMISC ) {
    device->init_promisc = true;
  } else {
    device->init_promisc = false;
  }

  time_now( &device->status.pre_calc );
  device->status.tx_bytes = 0;

  set_fd_handler_datapath( fd, recv_frame, device, flush_send_queue, device );
  set_readable_datapath( fd, true );

  enable_promiscuous( device );
  up_ether_device( device );
  update_device_status( device );

  return device;
}


void
delete_ether_device( ether_device *device ) {
  assert( device != NULL );

  if ( device->fd >= 0 ) {
    set_readable_datapath( device->fd, false );
    if ( device->send_queue->length > 0 ) {
      set_writable_datapath( device->fd, false );
    }
    delete_fd_handler_datapath( device->fd );
    close( device->fd );
  }

  if(!device->init_promisc) {
    disable_promiscuous( device );
  }
  if(!device->init_linkup) {
    down_ether_device(device);
  }

  delete_message_queue_datapath( device->send_queue );
  delete_message_queue_datapath( device->recv_queue );

  xfree( device );
}


short int
get_device_flags( const char *name ) {
  assert( name != NULL );

  int fd = socket( AF_INET, SOCK_DGRAM, 0 );

  struct ifreq ifr;
  memset( &ifr, 0, sizeof( ifr ) );
  strncpy( ifr.ifr_name, name, IFNAMSIZ );
  ifr.ifr_name[ IFNAMSIZ - 1 ] = '\0';

  int ret = ioctl( fd, SIOCGIFFLAGS, &ifr );
  if ( ret == -1 ) {
    char error_string[ ERROR_STRING_SIZE ];
    error( "Failed to get interface flags ( name = %s, ret = %d, errno = %s [%d] ).",
      ifr.ifr_name, ret, strerror_r( errno, error_string, sizeof( error_string ) ), errno );
  }

  close( fd );

  return ifr.ifr_flags;
}


bool
set_device_flags( const char *name, short int flags ) {
  assert( name != NULL );

  int fd = socket( AF_INET, SOCK_DGRAM, 0 );

  struct ifreq ifr;
  memset( &ifr, 0, sizeof( ifr ) );
  strncpy( ifr.ifr_name, name, IFNAMSIZ );
  ifr.ifr_name[ IFNAMSIZ - 1 ] = '\0';

  ifr.ifr_flags = flags;
  int ret = ioctl( fd, SIOCSIFFLAGS, &ifr );
  if ( ret == -1 ) {
    char error_string[ ERROR_STRING_SIZE ];
    error( "Failed to set interface flags ( name = %s, flags = %#x, ret = %d, errno = %s [%d] ).",
      ifr.ifr_name, ifr.ifr_flags, ret, strerror_r( errno, error_string, sizeof( error_string ) ), errno );
    close( fd );
    return false;
  }

  close( fd );

  return true;
}


bool
up_ether_device( ether_device *device ) {
  assert( device != NULL );
  assert( device->name != NULL );

  short int flags = get_device_flags( device->name );
  if ( ( flags & IFF_UP ) == 0 ) {
    flags |= IFF_UP;
  }
  if ( ( flags & IFF_RUNNING ) == 0 ) {
    flags |= IFF_RUNNING;
  }

  return set_device_flags( device->name, flags );
}


bool
down_ether_device( ether_device *device ) {
  assert( device != NULL );

  assert( device != NULL );
  assert( device->name != NULL );

  short int flags = get_device_flags( device->name );
  if ( flags & IFF_UP ) {
    flags &= ~IFF_UP;
  }
  if ( flags & IFF_RUNNING ) {
    flags &= ~IFF_RUNNING;
  }

  return set_device_flags( device->name, flags );
}


bool
send_frame( ether_device *device, buffer *frame ) {
  assert( device != NULL );
  assert( device->send_queue != NULL );
  assert( frame != NULL );
  assert( frame->length > 0 );

  if ( device->max_send_queue <= device->send_queue->length ) {
    error( "over max send queue error.(max=%u, current=%u)", device->max_send_queue, device->send_queue->length );
    return false;
  }

  bool ret = enqueue_message_datapath( device->send_queue, frame );
  if ( ret == false ) {
    return false;
  }

  if ( ( device->send_queue->length > 0 ) && ( device->fd >= 0 ) ) {
    set_writable_datapath( device->fd, true );
  }

  return true;
}


bool
set_frame_received_handler( ether_device *device, frame_received_handler callback, void *user_data ) {
  assert( device != NULL );
  assert( callback != NULL );

  device->received_callback = callback;
  device->received_user_data = user_data;

  return true;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
