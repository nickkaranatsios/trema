/*
 * Functions for Openflow datapath library main.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef OFDP_H
#define OFDP_H


#include <stdint.h>
#include <string.h>
#include "openflow_wrapper.h"
#include "ofdp_error.h"
#include "linked_list.h"


extern const uint16_t MISS_SEND_LEN;

// Structure of ofdp library arguments
typedef struct {
  const char *program_name;
  const char *loglevel;
  list_element *devices_info;       // data is argument_device_info
  bool is_daemon;
  size_t switch_mtu;
  uint32_t num_pool;
  uint32_t num_controller_buffer;
  uint32_t select_timeout_usec;
  size_t max_send_queue;
  size_t max_recv_queue;
  uint64_t datapath_id;
} ofdp_library_argument;


typedef enum library_status {
  NO_INITIALIZED,
  INITIALIZED,
  STARTED,
  STOPED,
  FINALIZED,
} library_status;


// List of public library function
void set_ofdp_library_argument( ofdp_library_argument *lib_arg, const char *program_name, const char *log_level,
  list_element *devices_info, bool is_daemon, size_t switch_mtu, uint32_t num_pool, uint32_t num_controller_buffer,
  uint32_t select_timeout_usec, size_t max_send_queue, size_t max_recv_queue, uint64_t datapath_id );
OFDPE init_datapath( const ofdp_library_argument *arg );
OFDPE start_datapath( void );
OFDPE stop_datapath( void );
OFDPE finalize_datapath( void );
OFDPE get_switch_features( ofp_switch_features *features );
void dump_switch_features( const ofp_switch_features *features );
OFDPE get_switch_config( ofp_switch_config *config );
OFDPE set_switch_config( ofp_switch_config *config );
void dump_switch_config( const ofp_switch_config *config );
library_status ( *get_library_status )( void );


#endif  // OFDP_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
