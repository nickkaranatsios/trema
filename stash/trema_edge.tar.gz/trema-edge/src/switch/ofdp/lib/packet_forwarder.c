/*
 * Functions for Openflow pipeline processing forwarder.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include "ofdp_common.h"
#include "packet_forwarder.h"
#include "processing_engine.h"
#include "table_manager.h"
#include "packet_buffer_pool.h"
#include "switch_port.h"
#include "linked_list.h"
#include "mutex_lock.h"


static list_element *processing_request_list = NULL;


typedef struct processing_request_entry {
  switch_port *port;
  buffer *parsed_buf;
} processing_request_entry;


static bool
enqueue_processing_list( switch_port *port, buffer *parsed_buf, bool flag_head ) {
  processing_request_entry *entry = xcalloc( 1, sizeof( processing_request_entry ) );

  entry->port = port;
  entry->parsed_buf = parsed_buf;

  if ( flag_head ) {
    return insert_in_front( &processing_request_list, entry );
  }
  else {
    return append_to_tail( &processing_request_list, entry );
  }
}


static processing_request_entry *
_dequeue_processing_list() {
  if ( processing_request_list == NULL ) {
    return NULL;
  }

  list_element *entry = processing_request_list;
  processing_request_list = entry->next;
  processing_request_entry *data = ( processing_request_entry * ) entry->data;
  xfree( entry );

  return data;
}


#ifdef UNIT_TESTING
processing_request_entry * ( *dequeue_processing_list )( void ) = _dequeue_processing_list;
#endif  // UNIT_TESTING


static void
delete_processing_list() {
  for ( list_element *e = processing_request_list; e != NULL; e = e->next ) {
    xfree( e->data );
  }

  delete_list( processing_request_list );
  processing_request_list = NULL;

  return;
}


static unsigned int
_length_of_processing_list() {
  return list_length_of( processing_request_list );
}


#ifdef UNIT_TESTING
unsigned int ( *length_of_processing_list )( void ) = _length_of_processing_list;
#endif  // UNIT_TESTING


/**
 * initialize packet forwarder
 *
 * param nothing
 * return success/failed
 */
OFDPE
init_packet_forwarder( void ) {
  init_pipeline_lock();

  return OFDPE_SUCCESS;
}


/**
 * finalize packet forwarder
 *
 * param nothing
 * return success/failed
 */
OFDPE
finalize_packet_forwarder( void ) {
  delete_processing_list();
  finalize_pipeline_lock();

  return OFDPE_SUCCESS;
}


/**
 * accepting buffer data for pipeline processing
 *
 * param receive switch port infomation
 * param receive buffer data (no operated packet parsing) 
 * return success/failed
 */
OFDPE
accept_recv_data( switch_port *port, buffer *buf ) {
  assert( execute_processing != NULL );

  if ( ( port == NULL ) || ( buf == NULL ) ) {
    error( "Illegal parameter error.(port=%x, buf=%x)", port, buf );
    return ERROR_ILLEGAL_PARAMETER;
  }

  if ( !parse_packet( buf ) ) {
    warn( "parse packet failed." );

    /* NEED: error for controller */
    /* NEED: statistics tx error */
    return OFDPE_FAILED;
  }

    ( ( packet_info * ) buf->user_data )->eth_in_port = port->port_no;

  if ( !enqueue_processing_list( port, buf, false ) ) {
    warn( "enqueue processing list failed." );
    return OFDPE_FAILED;
  }

  for (;; ) {
    if ( _length_of_processing_list() == 0 ) {
      break;
    }

    if ( !trylock_pipeline() ) {
      warn( "trylock_pipeline() execute failed." );
      return ERROR_LOCK;
    }

    processing_request_entry *entry = _dequeue_processing_list();
    if ( entry != NULL ) {
      execute_processing( entry->port, entry->parsed_buf );

      if ( entry->parsed_buf->user_data != NULL ) {
        free_packet_info( entry->parsed_buf );
      }

      free_packet_buffer_pool_entry( entry->parsed_buf );
      xfree( entry );
    }

    if ( !unlock_pipeline() ) {
      warn( "unlock_pipeline() execute error." );
      return ERROR_UNLOCK;
    }
  }

  return OFDPE_SUCCESS;
}


/**
 * enqueueing buffer data for pipeline processing
 *
 * param receive switch port infomation
 * param receive buffer data (must operated packet parsing) 
 * return success/failed
 */
OFDPE
enqueue_head_recv_data( switch_port *port, buffer *parsed_buf ) {
  if ( ( port == NULL ) || ( parsed_buf == NULL ) ) {
    error( "Illegal parameter error.(port=%x, parsed_buf=%x)", port, parsed_buf );
    return ERROR_ILLEGAL_PARAMETER;
  }

  if ( !enqueue_processing_list( port, parsed_buf, true ) ) {
    warn( "enqueue processing list failed." );
    return OFDPE_FAILED;
  }

  return OFDPE_SUCCESS;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
