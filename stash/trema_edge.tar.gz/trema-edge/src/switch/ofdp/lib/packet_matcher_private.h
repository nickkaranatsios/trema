/*
 * Functions for maching packet to flow entry.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef PACKET_MATCHER_PRIVATE_H
#define PACKET_MATCHER_PRIVATE_H


#include "packet_matcher.h"


bool match_packet_8_to_match( const uint8_t x, const match8 y );
bool match_packet_16_to_match( const uint16_t x, const match16 y );
bool match_packet_32_to_match( const uint32_t x, const match32 y );
bool match_packet_64_to_match( const uint64_t x, const match64 y );
bool match_match_8_to_match( const match8 x, const match8 y );
bool match_match_16_to_match( const match16 x, const match16 y );
bool match_match_32_to_match( const match32 x, const match32 y );
bool match_match_64_to_match( const match64 x, const match64 y );
bool compare_match_8_to_match( const match8 x, const match8 y );
bool compare_match_16_to_match( const match16 x, const match16 y );
bool compare_match_32_to_match( const match32 x, const match32 y );
bool compare_match_64_to_match( const match64 x, const match64 y );
void match_builder( match *p_match, const packet_info *packet );


#endif // PACKET_MATCHER_PRIVATE_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
