/*
 * Functions for managing ports.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef PORT_MANAGER_H
#define PORT_MANAGER_H


#include <net/if.h>
#include <stdint.h>
#include "openflow_wrapper.h"
#include "ofdp_common.h"
#include "ether_device.h"
#include "switch_port.h"
#include "packet_info.h"
#include "linked_list.h"
#include "event_handler.h"


// Structure of initialize device infomation
typedef struct {
  char device_name[ IFNAMSIZ ];
  uint32_t port_no;
} argument_device_info;


// List of public library function
OFDPE init_port_manager( const uint32_t select_timeout_usec, const size_t max_send_queue, const size_t max_recv_queue );
OFDPE finalize_port_manager( void );
OFDPE ( *init_device )( argument_device_info *device_info );
OFDPE ( *finalize_device )( const uint32_t port_no );
OFDPE check_socket();
OFDPE ( *send_data )( const uint32_t port_no, buffer *send_buffer );
bool ( *is_device_linkup )( const uint32_t port_no );
OFDPE get_device_statistics( const uint32_t port_no, ofp_port_stats * stats[], int *num_stats );
void dump_port_stats( ofp_port_stats *stats );
OFDPE increment_port_tx_dropped( const uint32_t port_no );
OFDPE update_port_config( const uint32_t port_no, const uint32_t config, const uint32_t mask );
size_t get_switch_mtu( list_element *devices_info );
OFDPE ( *send_for_notify_port_config )( uint32_t port_no, uint8_t reason );
OFDPE calc_bitrate_all_device( void );
bool ( *is_valid_port_no )( const uint32_t port_no );
OFDPE get_port_description( const uint32_t port_no, ofp_port **descriptions, uint32_t *num );


#endif  // PORT_MANAGER_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
