/*
 * Functions for managing switch ports.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#ifndef SWITCH_PORT_H
#define SWITCH_PORT_H


// #include "chibach.h"
#include "ether_device.h"


typedef struct {
  uint32_t port_no;
  struct {
    uint32_t state;
    uint32_t curr;
    uint32_t advertised;
    uint32_t supported;
    uint32_t peer;
  } status;
  uint32_t config;
  ether_device *device;
} switch_port;

typedef void ( *switch_port_walker )( switch_port *port, void *user_data );


void init_switch_port( void );
void finalize_switch_port( void );
switch_port *lookup_switch_port( uint32_t port_no );
switch_port *delete_switch_port( uint32_t port_no );
void foreach_switch_port( switch_port_walker callback, void *user_data );
switch_port *add_switch_port( const char *interface, uint32_t port_no, const size_t max_send_queue, const size_t max_recv_queue );
bool update_switch_port_status( switch_port *port );
bool update_switch_port_config( switch_port *port, uint32_t config, uint32_t mask );
void switch_port_to_ofp_phy_port( struct ofp_port *phy_port, const switch_port *port );


#endif // SWITCH_PORT_H


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
