/*
 * Functions for managing flow entry action buckets.
 *
 * Copyright (C) 2012 NEC Corporation
 * NEC Confidential
 */


#include "table_manager_action_bucket.h"
#include "wrapper.h"
#include "port_manager.h"
#include "table_manager_group.h"

/***
 * Create Action Bucket structyre
 *
 * param weight action bucket weight
 * param watch_port action bucket watch port
 * param watch_group action bucket watch group
 * param actions pointer for action list
 * return pointer for action buckets
 */
bucket *
create_action_bucket( const uint16_t weight, const uint16_t watch_port, const uint32_t watch_group,
  void *actions ) {
  bucket *p_bucket =  ( bucket * ) xmalloc( sizeof( bucket ) );

  if ( p_bucket == NULL ) {
    return p_bucket;
  }
#ifndef UNIT_TESTING
  if ( !is_valid_port_no( watch_port ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_ACTION_BAD_OUT_PORT, NULL );
    return NULL;
  }
  if ( ( watch_group != 0 ) && is_valid_group_no( watch_group ) ) {
    send_for_notify_error( ERROR_OFDPE_BAD_ACTION_BAD_OUT_GROUP, NULL );
    return NULL;
  }
#endif
  p_bucket->weight = weight;
  p_bucket->watch_port = watch_port;
  p_bucket->watch_group = watch_group;
  p_bucket->actions = actions;
  p_bucket->packet_count = 0;
  p_bucket->byte_count = 0;
  return p_bucket;
}

/**
 * delete(free) action bucket
 *
 * param bucket pointer for action bucket to be deleted/freed
 */
void
delete_action_bucket( bucket **bucket ) {
  if ( bucket == NULL ) {
    return;
  }
  if ( *bucket == NULL ) {
    return;
  }
  finalize_action_list( &( ( *bucket )->actions ) );
  xfree( *bucket );
  *bucket = NULL;
}

/***
 * Append action bucket to action bucket list
 *
 * param list pointer for action bucket list
 * param bucket pointer for action bucket
 * return
 */
OFDPE
append_action_bucket( bucket_list *list, bucket *bucket ) {
  dlist_element *retval = insert_after_dlist( ( dlist_element * ) list, ( void * ) bucket );

  if ( retval == NULL ) {
    return ERROR_NO_MEMORY;
  }
  return OFDPE_SUCCESS;
}

/**
 * delete(finalize) action bucket list
 *
 * param list pointer for action bucket list to be deleted
 */
void
delete_action_bucket_list( bucket_list **list ) {
  bucket_list *node = ( bucket_list * ) get_first_element(
      ( dlist_element * ) ( *list ) );

  bucket *p_bucket;

  while ( node != NULL ) {
    p_bucket = node->node;
    if ( p_bucket != NULL ) {
      delete_action_bucket( &p_bucket );
    }
    node = node->next;
  }

  delete_dlist( ( dlist_element * ) ( *list ) );
  *list = NULL;
}

/**
 * remove action bucket from action bucket list
 * param list pointer for action bucket list
 * param bucket pointer for action bucket
 * return
 */
OFDPE
remove_action_bucket( bucket_list *list, bucket *bucket ) {
  bucket_list *node = ( bucket_list * ) find_element( ( dlist_element * ) list,
      ( void * ) bucket );

  if ( node == NULL ) {
    return ERROR_NOT_FOUND;
  }

  delete_action_bucket( &( node->node ) );
  delete_dlist_element( ( dlist_element * ) node );

  return OFDPE_SUCCESS;
}


uint32_t
get_bucket_count( bucket_list *list ) {
  bucket_list *first_node = ( bucket_list * ) get_first_element( ( dlist_element * ) list );
  uint32_t count = 0;
  bucket_list *node = NULL;

  for ( node = first_node->next; node != NULL; count++, node = node->next ) {
  }
  return count;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
*/
