/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <stdint.h>
#include "openflow.h"
#include "ofdp/lib/table_manager_match.h"
#include "oxm.h"


static uint16_t get_match_icmpv4_code_length( const match *match );


static struct oxm oxm_icmpv4_code = {
  OFPXMT_OFB_ICMPV4_CODE,
  ( uint16_t ) sizeof( uint8_t ),
  get_match_icmpv4_code_length
};


void 
init_oxm_icmpv4_code( void ) {
  register_oxm( &oxm_icmpv4_code );
}


static uint16_t
get_match_icmpv4_code_length( const match *match ) {
  uint16_t length = 0;
  
  if ( match->icmpv4_code.valid ) {
    length = oxm_icmpv4_code.length;
  }
  return length;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
