/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <stdint.h>
#include "openflow.h"
#include "ofdp/lib/table_manager_match.h"
#include "oxm.h"


static uint16_t icmpv6_code_length( const match *match );
static void pack_icmpv6_code( const match *match, void *dest );


static struct oxm oxm_icmpv6_code = {
  OFPXMT_OFB_ICMPV6_CODE,
  ( uint16_t ) sizeof( uint8_t ),
  icmpv6_code_length,
  pack_icmpv6_code
};


void 
init_oxm_icmpv6_code( void ) {
  register_oxm( &oxm_icmpv6_code );
}


static uint16_t
icmpv6_code_length( const match *match ) {
  uint16_t length = 0;
  
  if ( match->icmpv6_code.valid ) {
    length = oxm_icmpv6_code.length;
  }
  return length;
}


static void
pack_icmpv6_code( const match *match, void *dest ) {
  struct ofp_match *ofp_match = dest;
  
  if ( match->icmpv6_code.valid ) {
    ofp_match->type = oxm_icmpv6_code.type;
    ofp_match->length = oxm_icmpv6_code.length;
    memcpy( &ofp_match->oxm_fields, &match->icmpv6_code.value, oxm_icmpv6_code.length );
  }
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
