/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <stdint.h>
#include "openflow.h"
#include "ofdp/lib/table_manager_match.h"
#include "oxm.h"


static uint16_t get_match_sctp_dst_length( const match *match );


static struct oxm oxm_sctp_dst = {
  OFPXMT_OFB_SCTP_DST,
  ( uint16_t ) sizeof( uint16_t ),
  get_match_sctp_dst_length
};


void 
init_oxm_sctp_dst( void ) {
  register_oxm( &oxm_sctp_dst );
}


static uint16_t
get_match_sctp_dst_length( const match *match ) {
  uint16_t length = 0;
  
  if ( match->sctp_dst.valid ) {
    length = oxm_sctp_dst.length;
  }
  return length;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
