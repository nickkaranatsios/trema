/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include <stdlib.h>
#include <stdint.h>
#include "wrapper.h"
#include "array-util.h"
#include "ofdp/lib/table_manager_match.h"
#include "oxm.h"
#include "oxm-arp-op.h"
#include "oxm-arp-sha.h"
#include "oxm-arp-spa.h"
#include "oxm-arp-tha.h"
#include "oxm-eth-dst.h"
#include "oxm-eth-src.h"
#include "oxm-eth-type.h"
#include "oxm-icmpv4-code.h"
#include "oxm-icmpv4-type.h"
#include "oxm-icmpv6-code.h"
#include "oxm-icmpv6-type.h"
#include "oxm-in-port.h"
#include "oxm-in-phy-port.h"
#include "oxm-ip-dscp.h"
#include "oxm-ip-ecn.h"
#include "oxm-ip-proto.h"
#include "oxm-ipv4-dst.h"
#include "oxm-ipv4-src.h"
#include "oxm-ipv6-src.h"
#include "oxm-ipv6-dst.h"
#include "oxm-ipv6-exthdr.h"
#include "oxm-ipv6-flabel.h"
#include "oxm-ipv6-nd-sll.h"
#include "oxm-ipv6-nd-target.h"
#include "oxm-ipv6-nd-tll.h"
#include "oxm-metadata.h"
#include "oxm-mpls-bos.h"
#include "oxm-mpls-label.h"
#include "oxm-mpls-tc.h"
#include "oxm-sctp-dst.h"
#include "oxm-sctp-src.h"
#include "oxm-tcp-dst.h"
#include "oxm-tcp-src.h"
#include "oxm-tunnel-id.h"
#include "oxm-udp-dst.h"
#include "oxm-udp-src.h"
#include "oxm-vlan-pcp.h"
#include "oxm-vlan-vid.h"


/*
 * We could have created an array of oxm structures with a match field is the 
 * index. But we chose not because not wanted to restrict ourselves on the 
 * match type value. This introduces a sligtly overhead on searching.
 */
static struct oxm **oxm_arr;
static uint32_t oxm_nr;
static uint32_t oxm_alloc;


void
register_oxm( struct oxm *oxm ) {
  ALLOC_GROW( oxm_arr, oxm_nr + 1, oxm_alloc );
  oxm_arr[ oxm_nr++ ] = oxm;
}


void
init_oxm( void ) {
  init_oxm_arp_op();
  init_oxm_arp_sha();
  init_oxm_arp_spa();
  init_oxm_arp_tha();
  init_oxm_eth_dst();
  init_oxm_eth_src();
  init_oxm_eth_type();
  init_oxm_icmpv4_code();
  init_oxm_icmpv4_type();
  init_oxm_icmpv6_code();
  init_oxm_icmpv6_type();
  init_oxm_in_port();
  init_oxm_in_phy_port();
  init_oxm_ip_dscp();
  init_oxm_ip_ecn();
  init_oxm_ip_proto();
  init_oxm_ipv4_dst();
  init_oxm_ipv4_src();
  init_oxm_ipv6_src();
  init_oxm_ipv6_dst();
  init_oxm_ipv6_exthdr();
  init_oxm_ipv6_flabel();
  init_oxm_ipv6_nd_sll();
  init_oxm_ipv6_nd_target();
  init_oxm_ipv6_nd_tll();
  init_oxm_metadata();
  init_oxm_mpls_bos();
  init_oxm_mpls_label();
  init_oxm_mpls_tc();
  init_oxm_sctp_dst();
  init_oxm_sctp_src();
  init_oxm_tcp_dst();
  init_oxm_tcp_src();
  init_oxm_tunnel_id();
  init_oxm_udp_dst();
  init_oxm_udp_src();
  init_oxm_vlan_pcp();
  init_oxm_vlan_vid();
}


uint16_t
oxm_length( uint16_t type ) {
  for ( uint32_t i = 0; i < oxm_nr; i++ ) {
    if ( oxm_arr[ i ]->type == type ) {
      return oxm_arr[ i ]->length;
    }
  }
  return 0;
}

// TODO how about the mask value length is multipled by 2.
uint16_t
match_to_oxm_length( const match *match ) {
  size_t length = 0;
  size_t tmp_length = 0;

  if ( match->arp_op.valid ) {
    length += sizeof( match->arp_op.value );
  }
  if ( match->arp_sha[ 0 ].valid ) {
    tmp_length = sizeof( match->arp_sha[ 0 ].value ) * ( sizeof( match->arp_sha ) / sizeof( match->arp_sha[ 0 ] ) );
    if ( match->arp_sha[ 0 ].mask != UINT8_MAX ) {
      tmp_length *= 2;
    }
    length += tmp_length;
  }
  if ( match->arp_spa.valid ) {
    tmp_length = sizeof( match->arp_spa.value );
    if ( match->arp_spa.mask != UINT32_MAX ) {
      tmp_length *= 2;
    }
    length += tmp_length;
  }
  if ( match->arp_tha[ 0 ].valid ) {
    tmp_length = sizeof( match->arp_tha[ 0 ].value ) * ( sizeof( match->arp_tha )/ sizeof( match->arp_tha[ 0 ] ) );
    if ( match->arp_tha[ 0 ].mask != UINT8_MAX ) {
      tmp_length *= 2;
    }
    length += tmp_length;
  }
  if ( match->arp_tpa.valid ) {
    tmp_length = sizeof( match->arp_tpa.value );
    if ( match->arp_tpa.mask != UINT32_MAX ) {
      tmp_length *= 2;
    }
    length += tmp_length;
  }
  if ( match->eth_dst[ 0 ].valid ) {
    tmp_length = sizeof( match->eth_dst[ 0 ].value ) * ( sizeof( match->eth_dst ) / sizeof( match->eth_dst[ 0 ] ) );
    if ( match->eth_dst[ 0 ].mask != UINT8_MAX ) {
      tmp_length *= 2;
    }
    length += tmp_length;
  }
  if ( match->eth_src[ 0 ].valid ) {
    tmp_length = sizeof( match->eth_src[ 0 ].value ) * ( sizeof( match->eth_src ) / sizeof( match->eth_src[ 0 ] ) );
    if ( match->eth_src[ 0 ].mask != UINT8_MAX ) {
      tmp_length *= 2;
    }
    length += tmp_length;
  }
  if ( match->eth_type.valid ) {
    length += sizeof( match->eth_type.value );
  }
  if ( match->icmpv4_code.valid ) {
    length += sizeof( match->icmpv4_code.value );
  }
  if ( match->icmpv4_type.valid ) {
    length += sizeof( match->icmpv4_type.value );
  }
  if ( match->icmpv6_code.valid ) {
    length += sizeof( match->icmpv6_code.value );
  }
  if ( match->icmpv6_type.valid ) {
    length += sizeof( match->icmpv6_type.value );
  }
  if ( match->in_phy_port.valid ) {
    length += sizeof( match->in_phy_port.value );
  }
  if ( match->in_port.valid ) {
    length += sizeof( match->in_port.value );
  }
  if ( match->ip_dscp.valid ) {
    length += sizeof( match->ip_dscp.value );
  }
  if ( match->ip_ecn.valid ) {
    length += sizeof( match->ip_ecn.value );
  }
  if ( match->ip_proto.valid ) {
    length += sizeof( match->ip_proto.value );
  }
  if ( match->ipv4_dst.valid ) {
    tmp_length = sizeof( match->ipv4_dst.value );
    if ( match->ipv4_dst.mask != UINT32_MAX ) {
      tmp_length *= 2;
    }
    length += tmp_length;
  }
  if ( match->ipv4_src.valid ) {
    tmp_length = sizeof( match->ipv4_src.value );
    if ( match->ipv4_src.mask != UINT32_MAX ) {
      tmp_length *= 2;
    }
    length += tmp_length;
  }
  if ( match->ipv6_src[ 0 ].valid ) {
    tmp_length = sizeof( match->ipv6_src[ 0 ].value ) * ( sizeof( match->ipv6_src ) / sizeof( match->ipv6_src[ 0 ] ) );
    if ( match->ipv6_src[ 0 ].mask != UINT8_MAX ) {
      tmp_length *= 2;
    }
    length += tmp_length;
  }
  if ( match->ipv6_dst[ 0 ].valid ) {
    tmp_length = sizeof( match->ipv6_dst[ 0 ].value ) * ( sizeof( match->ipv6_dst ) / sizeof( match->ipv6_dst[ 0 ] ) );
    if ( match->ipv6_dst[ 0 ].mask != UINT8_MAX ) {
      tmp_length *= 2;
    }
    length += tmp_length;
  }
  if ( match->ipv6_exthdr.valid ) {
    tmp_length = sizeof( match->ipv6_exthdr.value );
    if ( match->ipv6_exthdr.mask != UINT16_MAX ) {
      tmp_length *= 2;
    }
    length += tmp_length;
  }
  if ( match->ipv6_flabel.valid ) {
    tmp_length = sizeof( match->ipv6_flabel.value );
    if ( match->ipv6_flabel.mask != UINT32_MAX ) {
      tmp_length *= 2;
    }
    length += tmp_length;
  }
  if ( match->ipv6_nd_sll[ 0 ].valid ) {
    length += sizeof( match->ipv6_nd_sll[ 0 ].value ) * ( sizeof( match->ipv6_nd_sll ) / sizeof( match->ipv6_nd_sll[ 0 ] ) );
  }
  if ( match->ipv6_nd_target[ 0 ].valid ) {
    length += sizeof( match->ipv6_nd_target[ 0 ].value ) * ( sizeof( match->ipv6_nd_target ) / sizeof( match->ipv6_nd_target[ 0 ] ) );
  }
  if ( match->ipv6_nd_tll[ 0 ].valid ) {
    length += sizeof( match->ipv6_nd_tll[ 0 ].value ) * ( sizeof( match->ipv6_nd_tll ) / sizeof( match->ipv6_nd_tll[ 0 ] ) );
  }
  if ( match->metadata.valid ){
    tmp_length = sizeof( match->metadata.value );
    if ( match->metadata.mask != UINT64_MAX ) {
      tmp_length *= 2;
    }
    length += tmp_length;
  }
  if ( match->mpls_bos.valid ) {
    length += sizeof( match->mpls_bos.value );
  }
  if ( match->mpls_label.valid ) {
    length += sizeof( match->mpls_label.value );
  }
  if ( match->mpls_tc.valid ) {
    length += sizeof( match->mpls_tc.value );
  }
  if ( match->sctp_dst.valid ) {
    length += sizeof( match->sctp_dst.value );
  }
  if ( match->sctp_src.valid ) {
    length += sizeof( match->sctp_src.value );
  }
  if ( match->tcp_dst.valid ) {
    length += sizeof( match->tcp_dst.value );
  }
  if ( match->tcp_src.valid ) {
    length += sizeof( match->tcp_src.value );
  }
  if ( match->tunnel_id.valid ) {
    tmp_length = sizeof( match->tunnel_id.value );
    if ( match->tunnel_id.mask != UINT64_MAX ) {
      tmp_length *= 2;
    }
    length += tmp_length;
  }
  if ( match->udp_dst.valid ) {
    length += sizeof( match->udp_dst.value );
  }
  if ( match->udp_src.valid ) {
    length += sizeof( match->udp_src.value );
  }
  if ( match->vlan_pcp.valid ) {
    length += sizeof( match->vlan_pcp.value );
  }
  if ( match->vlan_vid.valid ) {
    tmp_length = sizeof( match->vlan_vid.value );
    if ( match->vlan_vid.mask != UINT16_MAX ) {
      tmp_length *= 2;
    }
    length += tmp_length;
  }
  return ( uint16_t ) length;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
