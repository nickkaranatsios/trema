/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include <stdlib.h>
#include <stdint.h>
#include "wrapper.h"
#include "array-util.h"
#include "oxm.h"
#include "oxm-in-port.h"
#include "oxm-in-phy-port.h"


static struct oxm **oxm_arr;
static uint32_t oxm_nr;
static uint32_t oxm_alloc;


void
register_oxm( struct oxm *oxm ) {
  ALLOC_GROW( oxm_arr, oxm_nr + 1, oxm_alloc );
  oxm_arr[ oxm_nr++ ] = oxm;
}


void
init_oxm( void ) {
  init_oxm_in_port();
  init_oxm_in_phy_port();
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
