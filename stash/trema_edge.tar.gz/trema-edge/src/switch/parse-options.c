#ifdef TEST


#include "parse-options.h"
struct switch_argument {
  const char *progname; 
  const char *help;
  const struct option *options;
};


#define SWITCH_COMMON_OPTIONS \
  { "daemonize", no_argument, 0, 'd' }, \
  { "logging_level", required_argument, 0, 'h' }, \
  { "help", no_argument, 0, 'h' }, \
  { 0, 0, 0, 0 }

static char const * const switch_usage[] = {
  "Usage: %s [OPTIONS]",
  "  -i --datapath_id=datapath_id   set datapath_id to a number",
  "  -c --controller=ipv4_addr      set controller's host to connect to",
  "  -p --port=tcp_port             set controller's port to connect to",
  "  -e --ether_ports=ether_devices a comma separated list of ether. devices",
  "  -h --help                      display usage and exit",
  NULL
};

static void
print_help( const char * const *usage ) {
  fprintf( stderr, *usage[ 0 ]++, prog_name );
  while ( *usage && **usage ) {
    fprintf( stderr, "%s", *usage++ );
  }
  exit( 1 );
}
static void 
parse_options( int argc, char **argv ) {
  static struct option long_options[] = {
    { "syslog", optional_argument, 0, 's' },
    { "controller", required_argument, 0, 'c' },
    { "port", optional_argument, 0, 'p' },
    { "ether_ports", required_argument, 0, 'e' },
    { 0, 0, 0, 0 },
  };
  struct char short_options = "";
  struct switch_arguments *args = xmalloc( sizeof( switch_arguments ) );
  
  int c;
  while ( 1 ) {
    int c, index = 0;
    c = getopt_long( argc, argv, short_options, args->options, &index );
    if ( c == -1 ) {
      break;
    }
    switch ( c ) {
      case OPT_PARSE:
        print_usage( args->options, args );
        break;
      case '?':
      case 'h':
        print_help( args, 0 );
        break;
      default:
        if ( args->handler ) {
          ret = args->handler( args, c, optarg );
          if ( ret ) {
            goto error;
          }
        }
        break;
      case 's':
        args->syslog = true;
        break;
      case 'c':
        args->server_ip = ( uint32_t ) atoi( optarg );
        break;
      case 'p':
        args->server_port = ( uint16_t ) atoi( optarg );
        break;
       case 'e'
         // parse a comma separated list of ports.
         if ( optarg != NULL ) {
           char *save_ptr = NULL;
           char *p = strtok_r( optarg, ",", &save_ptr );
           while ( p != NULL ) {
             add_ether_port( p );
             args->
             p = strtok_r( NULL, ",", &save_ptr );
           }
         }
         break;
       default:
       break;
    }


    args->argv = &argv[ optind ];
    args->argc = argc - optind;
    if ( args->checker ) {
     ret = args->checker( args );
    }
#endif
