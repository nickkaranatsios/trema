#ifdef TEST
struct switch_argument {
  const char *progname; 
  const char *help;
  const struct option *options;
};


#define SWITCH_COMMON_OPTIONS \
  { "daemonize", no_argument, 0, 'd' }, \
  { "logging_level", required_argument, 0, 'h' }, \
  { "help", no_argument, 0, 'h' }, \
  { 0, 0, 0, 0 }


static void 
parse_options( int argc, char **argv ) {
  static struct option long_options[] = {
    { "syslog", optional_argument, 0, 's' },
    { "remote", required_argument, 0, 'r' },
    { "port", optional_argument, 0, 'p' },
    { "device_ports", required_argument, 0, 'd' },
    { 0, 0, 0, 0 },
  };
  struct char short_options = "";
  struct switch_arguments *args = xmalloc( sizeof( switch_arguments ) );
  
  int c;
  while ( 1 ) {
    int c, index = 0;
    c = getopt_long( argc, argv, short_options, args->options, &index );
    if ( c == -1 ) {
      break;
    }
    switch ( c ) {
      case OPT_PARSE:
        print_usage( args->options, args );
        break;
      case '?':
      case 'h':
        print_help( args, 0 );
        break;
      default:
        if ( args->handler ) {
          ret = args->handler( args, c, optarg );
          if ( ret ) {
            goto error;
          }
        }
        break;
        
      case 's':
        settings->syslog = true;
        break;
      case 'r':
        strcpy( settings->remote, optarg
        break;
       case 'd'
         // parse a comma separated list of ports.
         break;
       default:
       break;
    }


    args->argv = &argv[ optind ];
    args->argc = argc - optind;
    if ( args->checker ) {
     ret = args->checker( args );
    }
#endif
