static const char switch_usage[] =
"switch [--syslog
static struct settings {
  remote; // the switch_daemon address to connect to.
  port; // switch_daemon port to connect to.
  ports; // a comma separated list of datapath_ports.
  bool syslog;
};
  
static void 
parse_options( int *argc, char **argv ) {
  static struct option long_options[] = {
    { "syslog", optional_argument, 0, 's' },
    { "remote", required_argument, 0, 'r' },
    { "port", optional_argument, 0, 'p' },
    { "device_ports", required_argument, 0, 'd' },
    { 0, 0, 0, 0 },
  };
  struct settings *settings = xmalloc( sizeof( *settings ) );
  
  int c;
  while ( ( c = getopt_long( *argc, *argv, short_options, long_options, NULL ) ) != -1 ) {
    if ( c == -1 ) {
      break;
    }
    switch ( c ) {
      case 's':
        settings->syslog = true;
        break;
      case 'r':
        strcpy( settings->remote, optarg
        break;
       case 'd'
         // parse a comma separated list of ports.
         break;
       default:
       break;
    }
  }
}

