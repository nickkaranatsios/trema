#ifndef PARSE_OPTIONS_H
#define PARSE_OPTIONS_H


struct switch_arguments {
  const char *progname;
  const char *help;
  const char *log_level;
  const struct option *options;
  int ( *handler )( struct switch_arguments *, int, char * );

  const char *datapath_ports;
  uint64_t datapath_id;
  uint32_t server_ip;
  uint16_t server_port;
  
  bool run_as_daemon;
  
  char *const *argv;
  int argc;
}; 

#endif
  
