/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <sys/socket.h>

#include "openflow_switch_interface.h"
#include "log.h"
#include "ofdp.h"
#include "port_manager.h"
#include "ofdp/lib/table_manager_flow.h"
#include "ofdp/lib/action_executor.h"
#include "async.h"
#include "protocol.h"
#include "oxm-helper.h"
#include "action-helper.h"
#include "action-tlv-interface.h"
#include "oxm-interface.h"



static void
_handle_hello( uint32_t transaction_id, uint8_t version, const buffer *version_data, void *user_data ) {
  UNUSED( user_data );
  info( "handle hello received %u %u", transaction_id, version );

  struct ofp_hello_elem_versionbitmap *versionbitmap = ( struct ofp_hello_elem_versionbitmap * ) version_data->data;
  const uint32_t ofp_versions[ 1 ] = { OFP_VERSION };

  uint32_t bitmap = versionbitmap->bitmaps[ 0 ];
  if ( ( bitmap & ( ( uint32_t ) 1 << ofp_versions[ 0 ] ) ) != ( ( uint32_t ) ofp_versions[ 0 ] ) ) {
    buffer *hello_buf = create_hello_elem_versionbitmap( transaction_id, ofp_versions,
      sizeof( ofp_versions ) / sizeof( ofp_versions[ 0 ] ) );
    switch_send_openflow_message( hello_buf );
    free_buffer( hello_buf );
  } else {
    send_error_message( transaction_id, OFPET_HELLO_FAILED, OFPHFC_INCOMPATIBLE );
  }
}
void ( *handle_hello )( uint32_t transaction_id, uint8_t version, const buffer *version_data, void *user_data ) = _handle_hello;


static void
_handle_features_request( uint32_t transaction_id, void *user_data ) {
  assert( user_data );
  struct protocol *protocol = user_data;

  struct ofp_switch_features switch_features;
  memset( &switch_features, 0, sizeof( struct ofp_switch_features ) );
  get_switch_features( &switch_features );
  buffer *features_reply = create_features_reply( transaction_id,
    switch_features.datapath_id,
    switch_features.n_buffers,
    switch_features.n_tables,
    switch_features.auxiliary_id,
    switch_features.capabilities,
    switch_features.reserved );
  switch_send_openflow_message( features_reply );
  free_buffer( features_reply );
  protocol->controller_connected = true;
}
void ( *handle_features_request )( uint32_t transaction_id, void *user_data ) = _handle_features_request;


// protocol to datapath message.
static void
_handle_set_config( uint32_t transaction_id, uint16_t flags, uint16_t miss_send_len, void *user_data ) {
  UNUSED( user_data );

  buffer *buffer = create_set_config( transaction_id, flags, miss_send_len );
  struct ofp_switch_config *switch_config = ( struct ofp_switch_config * ) buffer->data;
  set_switch_config( switch_config );
  free_buffer( buffer );
}
void ( *handle_set_config )( uint32_t transaction_id, uint16_t flags, uint16_t miss_send_len, void *user_data ) = _handle_set_config;


static void
_handle_echo_request( uint32_t transaction_id, const buffer *body, void *user_data ) {
  UNUSED( user_data );
  buffer *echo_reply = create_echo_reply( transaction_id, body );
  switch_send_openflow_message( echo_reply );
  free_buffer( echo_reply );
}
void ( *handle_echo_request )( uint32_t transaction_id, const buffer *body, void *user_data ) = _handle_echo_request;


static void
handle_flow_mod_add( uint32_t transaction_id, uint64_t cookie, uint8_t table_id,
                     uint16_t idle_timeout, uint16_t hard_timeout,
                     uint16_t priority, uint16_t flags, 
                     const oxm_matches *oxm_match,
                     const openflow_instructions *instructions ) {
  
  if ( table_id == OFPTT_ALL ) {
    send_error_message( transaction_id, OFPET_FLOW_MOD_FAILED, OFPFMFC_BAD_TABLE_ID );
    return;
  }
  match *match = NULL;

  match = init_match( );
  if ( oxm_match != NULL && oxm_match->n_matches > 0 ) {
    for ( list_element *e = oxm_match->list; e != NULL; e = e->next ) {
      oxm_match_header *hdr = e->data;
      assign_match( match, hdr );
    }
  }
  flow_entry *entry = NULL;

  entry = lookup_flow_entry_strict( table_id, match, priority );
  if ( entry != NULL ) {
    if ( entry->instructions != NULL ) {
      remove_instructions( &entry->instructions );
    }
    entry->idle_timeout = idle_timeout;
    entry->hard_timeout = hard_timeout;
    entry->flags = flags;
    entry->cookie = cookie;
    update_flow_entry( table_id, entry );
  }
  if ( entry == NULL ) {
    instruction_list *ins_list = NULL;
    if ( instructions != NULL ) {
      ins_list = init_instruction_list( );
      assign_instructions( instructions->list, ins_list, table_id );
    }
    flow_entry *new_entry;
    new_entry = create_flow_entry( match, ins_list, priority, idle_timeout, 
                                   hard_timeout, flags, cookie );
    if ( new_entry != NULL ) {
      if ( append_flow_entry( table_id, new_entry ) != OFDPE_SUCCESS ) {
        /*
         * TODO we should send a more appropriate error once we worked out the
         * datapath errors.
        */
        send_error_message( transaction_id, OFPET_FLOW_MOD_FAILED, OFPFMFC_UNKNOWN );
      }
    }
  }
}


static void
handle_flow_mod_delete( uint32_t transaction_id, uint64_t cookie,
                        uint64_t cookie_mask, uint8_t table_id,
                        uint16_t idle_timeout, uint16_t hard_timeout,
                        uint16_t priority, uint32_t buffer_id,
                        uint32_t out_port, uint32_t out_group,
                        uint16_t flags, const oxm_matches *oxm_match,
                        const openflow_instructions *instructions,
                        bool strict ) {

  UNUSED( transaction_id );
  UNUSED( cookie );
  UNUSED( cookie_mask );
  UNUSED( idle_timeout );
  UNUSED( hard_timeout );
  UNUSED( priority );
  UNUSED( buffer_id );
  UNUSED( out_port );
  UNUSED( out_group );
  UNUSED( flags );
  UNUSED( instructions );
  
  /*
   * TODO At the moment not sure which datapath API to call to delete all flow
   * entries from all tables. Calling lookup_flow_entry_strict() or
   * lookup_flow_entry() one by one maybe the only way to delete all flow
   * entries which seems like an overhead.
   */
  if ( table_id == OFPTT_ALL ) {
    return;
  }
  match *match = init_match( );
  if ( oxm_match != NULL && oxm_match->n_matches > 0 ) {
    for ( list_element *e = oxm_match->list; e != NULL; e = e->next ) {
      oxm_match_header *hdr = e->data;
      assign_match( match, hdr );
    }
  }
  flow_entry *entry = NULL;
  if ( strict ) {
    entry = lookup_flow_entry_strict( table_id, match, priority );
  } else {
    entry = lookup_flow_entry( table_id, match );
  }
  if ( entry ) {
    delete_flow_entry( &entry );
  }
}

static void
_handle_flow_mod( uint32_t transaction_id,
        uint64_t cookie,
        uint64_t cookie_mask,
        uint8_t table_id,
        uint8_t command,
        uint16_t idle_timeout,
        uint16_t hard_timeout,
        uint16_t priority,
        uint32_t buffer_id,
        uint32_t out_port,
        uint32_t out_group,
        uint16_t flags,
        const oxm_matches *match,
        const openflow_instructions *instructions,
        void *user_data
  ) {
  UNUSED( user_data );
  bool strict = false;

  switch ( command ) {
    case OFPFC_ADD:
      handle_flow_mod_add( transaction_id, cookie, table_id,
                           idle_timeout,hard_timeout, priority,
                           flags, match, instructions );
      break;
    case OFPFC_MODIFY:
      break;
    case OFPFC_MODIFY_STRICT:
      break;
    case OFPFC_DELETE:
      handle_flow_mod_delete( transaction_id, cookie, cookie_mask,
                              table_id, idle_timeout, hard_timeout,
                              priority, buffer_id, out_port,
                              out_group, flags, match,
                              instructions, strict );
      break;
    case OFPFC_DELETE_STRICT:
      strict = true;
      handle_flow_mod_delete( transaction_id, cookie, cookie_mask, table_id,
                              idle_timeout, hard_timeout, priority, buffer_id,
                              out_port, out_group, flags, match,
                              instructions, strict );
      break;
    default:
      warn( "Undefined flow mod command type %d", command );
      break;
  }
  
  /*
  * NOTE: An empty flow has n_matches = 0 and list = 0x0
  */
  for ( list_element *e = match->list; e != NULL; e = e->next ) { 
    oxm_match_header *hdr = e->data;

    debug( "field %d has_mask %d length %d ", OXM_FIELD( *hdr ), OXM_HASMASK( *hdr ), OXM_LENGTH( *hdr ) );
  }
}
void ( *handle_flow_mod )( uint32_t transaction_id,
        uint64_t cookie,
        uint64_t cookie_mask,
        uint8_t table_id,
        uint8_t command,
        uint16_t idle_timeout,
        uint16_t hard_timeout,
        uint16_t priority,
        uint32_t buffer_id,
        uint32_t out_port,
        uint32_t out_group,
        uint16_t flags,
        const oxm_matches *match,
        const openflow_instructions *instructions,
        void *user_data) = _handle_flow_mod;


static inline void *
cast_non_const( const void *ptr ) {
  union {
    const void* const_value;
    void *value;
  } ret;
  ret.const_value = ptr;
  return ret.value;
}


static void
_handle_packet_out( uint32_t transaction_id, uint32_t buffer_id, 
                    uint32_t in_port, const openflow_actions *actions,
                    const buffer *frame, void *user_data ) {
  UNUSED( transaction_id );
  UNUSED( user_data );
  assert( actions->list );
  
  action_list *ac_list = init_action_list();
  for ( list_element *e = actions->list; e != NULL; e = e->next ) {
    struct ofp_action_header *ac_hdr = e->data;
    ac_list = assign_actions( ac_hdr, false, ac_list );
  }
  execute_action_packet_out( buffer_id, in_port, 
          ac_list, cast_non_const( frame ) );
  finalize_action_list( &ac_list );
}
void ( *handle_packet_out )( uint32_t transaction_id, uint32_t buffer_id,
                           uint32_t in_port, const openflow_actions *actions,
                           const buffer *frame, void *user_data ) = _handle_packet_out;


static void
_handle_port_mod( uint32_t transaction_id, uint32_t port_no, uint8_t hw_addr[],
                  uint32_t config, uint32_t mask, uint32_t advertise, void *user_data ) {
  UNUSED( hw_addr );
  UNUSED( advertise );
  UNUSED( user_data );
  int ret;
  /*
   * the update_port_config() performs a port lookup.
   */
  ret = update_port_config( port_no, config, mask );
  if ( ret == ERROR_ILLEGAL_PARAMETER ) {
    send_error_message( transaction_id, OFPET_PORT_MOD_FAILED, OFPPMFC_BAD_PORT );
  }
  if ( ret == ERROR_OFDPE_PORT_MOD_FAILED_BAD_CONFIG ) {
    send_error_message( transaction_id, OFPET_PORT_MOD_FAILED, OFPPMFC_BAD_CONFIG );
  }
  /*
   * TODO not sure how to translate the ERROR_UNLOCK error code into one
   * of the port mod failed code type.
   */
}
void ( *handle_port_mod )( uint32_t transaction_id, uint32_t port_no, uint8_t hw_addr[],
  uint32_t config, uint32_t mask, uint32_t advertise, void *user_data ) = _handle_port_mod;


static void
_handle_table_mod( uint32_t transaction_id, uint8_t table_id, uint32_t config,
  void *user_data ) {
  UNUSED( transaction_id );
  UNUSED( table_id );
  UNUSED( config );
  UNUSED( user_data );
}
void ( *handle_table_mod )( uint32_t transaction_id, uint8_t table_id, uint32_t config,
  void *user_data ) = _handle_table_mod;


/*
 * A field by field copy because the flow_stats not aligned to ofp_flow_stats.
 * First argument is source second argument destination.
 * TODO if flow_stats is added a pad2[ 4 ] field all fields upto match can be
 * copied using memcpy.
 */
static void
assign_ofp_flow_stats( struct ofp_flow_stats *fs, const flow_stats *stats ) {
  fs->length = stats->length;
  fs->table_id = stats->table_id;
  fs->duration_sec = stats->duration_sec;
  fs->duration_nsec = stats->duration_nsec;
  fs->priority = stats->priority;
  fs->idle_timeout = stats->idle_timeout;
  fs->hard_timeout = stats->hard_timeout;
  fs->flags = stats->flags;
  fs->cookie = stats->cookie;
  fs->packet_count = stats->packet_count;
  fs->byte_count = stats->byte_count;
}


static void
sum_ofp_aggregate_stats( struct ofp_aggregate_stats_reply *as_reply, const flow_stats *stats ) {
  as_reply->packet_count += stats->packet_count;
  as_reply->packet_count += stats->packet_count;
}


static list_element *
new_list( void ) {
  list_element *list;

  if ( create_list( &list ) == false ) {
    assert( 0 );
  }
  return list;
}


static flow_stats *
retrieve_flow_stats( uint32_t *nr_stats, const uint8_t table_id, const uint32_t out_port, const uint32_t out_group,
  const uint64_t cookie, const uint64_t cookie_mask, const struct ofp_match *ofp_match ) {
  match *flow_match = init_match();
  size_t match_len = ofp_match->length - offsetof( struct ofp_match, oxm_fields );

  // translate the ofp_match to datapath match.
  if ( match_len > 0 ) {
    const oxm_match_header *hdr = ( const oxm_match_header * ) ofp_match->oxm_fields;
    assign_match( flow_match, hdr );
  }

  const flow_stats_request request = {
    .table_id = table_id,
    .out_port = out_port,
    .out_group = out_group,
    .cookie = cookie,
    .cookie_mask = cookie_mask,
    .p_match = flow_match
  };

  flow_stats *stats;
  if ( get_statistics_flow( request, &stats, nr_stats )  == OFDPE_SUCCESS ) {
    return stats;
  }

  return NULL;
}


static struct ofp_aggregate_stats_reply *
request_aggregate_stats( const struct ofp_aggregate_stats_request *req ) {
  uint32_t nr_stats = 0;

  flow_stats *stats = retrieve_flow_stats( &nr_stats, req->table_id, req->out_port, req->out_group, req->cookie,
    req->cookie_mask, &req->match );
  if ( stats && nr_stats > 0 ) {
    struct ofp_aggregate_stats_reply *as_reply = xmalloc( sizeof( *as_reply ) );

    memset( as_reply, 0, sizeof( *as_reply ) );
    for( uint32_t i = 0; i < nr_stats; i++ ) {
      sum_ofp_aggregate_stats( as_reply, &stats[ i ] );
    }
    as_reply->flow_count = nr_stats;
    return as_reply;
  }
  return NULL;
}


/*
 * Set up information to request flow statistics from datapath. The function
 * returns a linked list of ofp_flow_stats objects. If no statistics found an
 * empty list is returned.
 */
static list_element *
request_flow_stats( const struct ofp_flow_stats_request *req ) {
  uint32_t nr_stats = 0;

  flow_stats *stats = retrieve_flow_stats( &nr_stats, req->table_id, req->out_port, req->out_group,
    req->cookie, req->cookie_mask, &req->match );

  list_element *list = new_list();

  if ( stats && nr_stats > 0 ) {
    oxm_matches *oxm_match = create_oxm_matches();

    for ( uint32_t i = 0; i < nr_stats; i++ ) {
      struct ofp_flow_stats *fs = xmalloc( sizeof( *fs ) );

      assign_ofp_flow_stats( fs, &stats[ i ] );
      construct_oxm( oxm_match, stats[ i ].p_match );
      construct_ofp_match( &fs->match, oxm_match );
      append_to_tail( &list, ( void * ) fs );
    }
  }
  return list;
}


/*
 * Request table statistics starting with lower table numbers terminate when an
 * invalid table number is found. Returns an array of ofp_table_stats.
 */
static list_element *
request_table_stats( void ) {
  ofp_table_stats *table_stats = NULL;
  list_element *list = new_list();
  uint8_t i;

  for ( i = 0; i < OFPTT_MAX; i++ ) {
    // the call below returns NULL if an invalid table is found.
    if ( _get_flow_table( i ) ) {
      break;
    }
    get_statistics_table( &table_stats, i );
    append_to_tail( &list, ( void * ) table_stats );
  }
  return list; 
}


static bool
is_any_table_feature_set( const void *feature, size_t feature_size ) {
  void *ret;
  int c = 1;

  ret = memchr( feature, c, feature_size );
  if ( ret == NULL ) {
    return false;
  }
  return true;
}

static bool
is_any_table_feature_instruction_set( const instructions_capabilities *ins_cap ) {
  return is_any_table_feature_set( ins_cap, sizeof( instructions_capabilities ) );
}


static bool
is_any_table_feature_action_set( const actions_capabilities *ac_cap ) {
  return is_any_table_feature_set( ac_cap, sizeof( actions_capabilities ) );
}


static bool
is_any_table_feature_match_set( const match_capabilities *match_cap ) {
  return is_any_table_feature_set( match_cap, sizeof( match_capabilities ) );
}


static size_t
get_table_features_len( const table_features *table_feature ) {
  size_t len = 0;
  size_t table_feature_prop_hdr_len = sizeof( struct ofp_table_feature_prop_header );

  if ( is_any_table_feature_instruction_set( &table_feature->instructions ) ) {
    len += table_feature_prop_hdr_len;
  }
  if ( is_any_table_feature_instruction_set( &table_feature->instructions_miss ) ) {
    len += table_feature_prop_hdr_len;
  }
  if ( is_any_table_feature_action_set( &table_feature->write_actions ) ) {
    len += table_feature_prop_hdr_len;
  }
  if ( is_any_table_feature_action_set( &table_feature->write_actions_miss ) ) {
    len += table_feature_prop_hdr_len;
  }
  if ( is_any_table_feature_action_set( &table_feature->apply_actions ) ) {
    len += table_feature_prop_hdr_len;
  }
  if ( is_any_table_feature_action_set( &table_feature->apply_actions_miss ) ) {
    len += table_feature_prop_hdr_len;
  }
  if ( is_any_table_feature_match_set( &table_feature->matches ) ) {
    len += table_feature_prop_hdr_len;
  }
  if ( is_any_table_feature_match_set( &table_feature->wildcards ) ) {
    len += table_feature_prop_hdr_len;
  }
  if ( is_any_table_feature_match_set( &table_feature->write_setfield ) ) {
    len += table_feature_prop_hdr_len;
  }
  if ( is_any_table_feature_match_set( &table_feature->write_setfield_miss ) ) {
    len += table_feature_prop_hdr_len;
  }
  if ( is_any_table_feature_match_set( &table_feature->apply_setfield ) ) {
    len += table_feature_prop_hdr_len;
  }
  if ( is_any_table_feature_match_set( &table_feature->apply_setfield_miss ) ) {
    len += table_feature_prop_hdr_len;
  }
  if ( table_feature->min_next_table_ids ) {
    len += table_feature_prop_hdr_len;
  }
  if ( table_feature->min_next_table_ids_miss ) {
    len += table_feature_prop_hdr_len;
  }
  return len;
}
    

static struct ofp_table_features *
assign_table_features( const table_features *table_feature ) {
  size_t total_len = sizeof( struct ofp_table_features );

  total_len += get_table_features_len( table_feature );

  struct ofp_table_features *ofp_table_feature = ( struct ofp_table_features * ) xmalloc( total_len );
  ofp_table_feature->table_id = table_feature->table_id;
  strncpy( ofp_table_feature->name, table_feature->name, OFP_MAX_TABLE_NAME_LEN - 1 );
  ofp_table_feature->config = table_feature->config;
  ofp_table_feature->max_entries = table_feature->max_entries;

  size_t prop_hdr_len = sizeof( struct ofp_table_feature_prop_header );
  size_t properties_len = prop_hdr_len;

  if ( is_any_table_feature_instruction_set( &table_feature->instructions ) ) {
    struct ofp_table_feature_prop_instructions *tfpi = ( struct ofp_table_feature_prop_instructions * )( char * )( ofp_table_feature + properties_len  );
    tfpi->type = OFPTFPT_INSTRUCTIONS;
    tfpi->length = ( uint16_t ) prop_hdr_len;
    properties_len += prop_hdr_len;
  }

  if ( is_any_table_feature_instruction_set( &table_feature->instructions_miss ) ) {
    struct ofp_table_feature_prop_instructions *tfpi = ( struct ofp_table_feature_prop_instructions * )( char * )( ofp_table_feature + properties_len  );
    tfpi->type = OFPTFPT_INSTRUCTIONS_MISS;
    tfpi->length = ( uint16_t ) prop_hdr_len;
    properties_len += prop_hdr_len;
  }

  if ( is_any_table_feature_action_set( &table_feature->write_actions ) ) {
    struct ofp_table_feature_prop_actions *tfpa = ( struct ofp_table_feature_prop_actions * )( char * )( ofp_table_feature + properties_len );
    tfpa->type = OFPTFPT_WRITE_ACTIONS;
    tfpa->length = ( uint16_t ) prop_hdr_len;
    properties_len += prop_hdr_len;
  }
  
  if ( is_any_table_feature_action_set( &table_feature->write_actions_miss ) ) {
    struct ofp_table_feature_prop_actions *tfpa = ( struct ofp_table_feature_prop_actions * )( char * )( ofp_table_feature + properties_len );
    tfpa->type = OFPTFPT_WRITE_ACTIONS_MISS;
    tfpa->length = ( uint16_t ) prop_hdr_len;
    properties_len += prop_hdr_len;
  }
  
  if ( is_any_table_feature_action_set( &table_feature->apply_actions ) ) {
    struct ofp_table_feature_prop_actions *tfpa = ( struct ofp_table_feature_prop_actions * )( char * )( ofp_table_feature + properties_len );
    tfpa->type = OFPTFPT_APPLY_ACTIONS;
    tfpa->length = ( uint16_t ) prop_hdr_len;
    properties_len += prop_hdr_len;
  }

  if ( is_any_table_feature_action_set( &table_feature->apply_actions_miss ) ) {
    struct ofp_table_feature_prop_actions *tfpa = ( struct ofp_table_feature_prop_actions * )( char * )( ofp_table_feature + properties_len );
    tfpa->type = OFPTFPT_APPLY_ACTIONS_MISS;
    tfpa->length = ( uint16_t ) prop_hdr_len;
    properties_len += prop_hdr_len;
  }

  if ( is_any_table_feature_match_set( &table_feature->matches ) ) {
    struct ofp_table_feature_prop_oxm *tfpo = ( struct ofp_table_feature_prop_oxm * )( char * )( ofp_table_feature + properties_len );
    tfpo->type = OFPTFPT_MATCH;
    tfpo->length = ( uint16_t ) prop_hdr_len;
    properties_len += prop_hdr_len;
  }

  if ( is_any_table_feature_match_set( &table_feature->wildcards ) ) {
    struct ofp_table_feature_prop_oxm *tfpo = ( struct ofp_table_feature_prop_oxm * )( char * )( ofp_table_feature + properties_len );
    tfpo->type = OFPTFPT_WILDCARDS;
    tfpo->length = ( uint16_t ) prop_hdr_len;
    properties_len += prop_hdr_len;
  }

  if ( is_any_table_feature_match_set( &table_feature->write_setfield ) ) {
    struct ofp_table_feature_prop_oxm *tfpo = ( struct ofp_table_feature_prop_oxm * )( char * )( ofp_table_feature + properties_len );
    tfpo->type = OFPTFPT_WRITE_SETFIELD;
    tfpo->length = ( uint16_t ) prop_hdr_len;
    properties_len += prop_hdr_len;
  }

  if ( is_any_table_feature_match_set( &table_feature->write_setfield_miss ) ) {
    struct ofp_table_feature_prop_oxm *tfpo = ( struct ofp_table_feature_prop_oxm * )( char * )( ofp_table_feature + properties_len );
    tfpo->type = OFPTFPT_WRITE_SETFIELD_MISS;
    tfpo->length = ( uint16_t ) prop_hdr_len;
    properties_len += prop_hdr_len;
  }
  
  if ( is_any_table_feature_match_set( &table_feature->apply_setfield ) ) {
    struct ofp_table_feature_prop_oxm *tfpo = ( struct ofp_table_feature_prop_oxm * )( char * )( ofp_table_feature + properties_len );
    tfpo->type = OFPTFPT_APPLY_SETFIELD;
    tfpo->length = ( uint16_t ) prop_hdr_len;
    properties_len += prop_hdr_len;
  }

  if ( is_any_table_feature_match_set( &table_feature->apply_setfield_miss ) ) {
    struct ofp_table_feature_prop_oxm *tfpo = ( struct ofp_table_feature_prop_oxm * )( char * )( ofp_table_feature + properties_len );
    tfpo->type = OFPTFPT_APPLY_SETFIELD_MISS;
    tfpo->length = ( uint16_t ) prop_hdr_len;
    properties_len += prop_hdr_len;
  }

  if ( table_feature->min_next_table_ids ) {
    struct ofp_table_feature_prop_next_tables *tfpnt = ( struct ofp_table_feature_prop_next_tables * )( char * )( ofp_table_feature + properties_len );
    tfpnt->type = OFPTFPT_NEXT_TABLES;
    tfpnt->length = ( uint16_t ) prop_hdr_len;
    properties_len += prop_hdr_len;
  }

  if ( table_feature->min_next_table_ids_miss ) {
    struct ofp_table_feature_prop_next_tables *tfpnt = ( struct ofp_table_feature_prop_next_tables * )( char * )( ofp_table_feature + properties_len );
    tfpnt->type = OFPTFPT_NEXT_TABLES_MISS;
    tfpnt->length = ( uint16_t ) prop_hdr_len;
  }
  return ofp_table_feature;
}


static list_element *
request_table_features_stats() {
  table_features *table_features = NULL;
  list_element *list = new_list();
  uint8_t i;
  
  for ( i = 0; i < OFPTT_MAX; i++ ) {
    if ( _get_flow_table( i ) ) {
      break;
    }
    if ( get_table_features( i, &table_features ) == OFDPE_SUCCESS ) {
      append_to_tail( &list, ( void * ) assign_table_features );
    } else {
      break;
    }
  }
  return list;
}


static list_element *
request_port_stats( const struct ofp_port_stats_request *ps_req ) {
  ofp_port_stats *port_stats = NULL;
  list_element *list = new_list();
  int port_stats_nr = 0;

  if ( get_device_statistics( ps_req->port_no, &port_stats, &port_stats_nr ) == OFDPE_SUCCESS ) {
    for ( int i = 0; i < port_stats_nr; i++ ) {
      append_to_tail( &list, ( void * ) &port_stats[ i ] );
    }
  }
  return list;
}


static list_element *
request_group_stats( const struct ofp_group_stats_request *gs_req ) {
  ofp_group_stats *group_stats = NULL;
  list_element *list = new_list();
  uint32_t group_stats_nr = 0;

  if ( get_statistics_group( gs_req->group_id, &group_stats, &group_stats_nr ) == OFDPE_SUCCESS ) {
    for ( uint32_t i = 0; i < group_stats_nr; i++ ) {
      append_to_tail( &list, ( void * ) &group_stats[ i ] );
    }
  }
  return list;
}


static uint16_t
action_list_length( action_list **list ) {
  if ( *list == NULL ) {
    return 0;
  }
  uint16_t length = 0;
  action_list *item = ( action_list * ) get_first_element( ( dlist_element * ) ( *list ) );
  action *action;
  while ( item != NULL ) {
    action = item->node;
    if ( action != NULL ) {
      length = ( uint16_t ) ( length + action_tlv_length_by_type( action->type ) );
      if ( action->type == OFPAT_SET_FIELD && action->p_match ) {
        length = ( uint16_t ) ( length + match_length( action->p_match ) );
      }
    }
    item = item->next;
  }
  return length;
}


static uint16_t
bucket_list_length( bucket_list **list ) {
  if ( *list == NULL ) {
    return 0;
  }
  uint16_t length = 0;
  bucket_list *item = ( bucket_list * ) get_first_element( ( dlist_element * ) ( *list ) );
  bucket *bucket;
  while ( item != NULL ) {
    bucket = item->node;
    if ( bucket != NULL ) {
      length = ( uint16_t ) ( length + action_list_length( &bucket->actions ) );
    }
    item = item->next;
  }
  return length;
}


void
pack_bucket( struct ofp_bucket *ofp_bucket, bucket_list **list ) {
  if ( *list == NULL ) {
    return;
  }
  bucket_list *next = ( bucket_list * ) get_first_element( ( dlist_element * ) ( *list ) );
  bucket *bucket;
  uint16_t bucket_length = 0;
  while ( next != NULL ) {
    bucket = next->node;
    if ( bucket != NULL ) {
      bucket_length = ( uint16_t ) ( sizeof( struct ofp_bucket ) + action_list_length( &bucket->actions ) );
      ofp_bucket->weight = bucket->weight;
      ofp_bucket->watch_port = bucket->watch_port;
      ofp_bucket->watch_group = bucket->watch_group;
      void *p = ( char * ) ( ofp_bucket + offsetof( struct ofp_bucket, actions ) );
      action_pack( p, &bucket->actions );
      ofp_bucket = ( struct ofp_bucket * ) ( ( char * )( ofp_bucket + bucket_length ) );
    }
    next = next->next;
  }
}


static list_element *
request_group_desc_stats( void ) {
  group_desc_stats *group_desc_stats = NULL;
  list_element *list = new_list();
  uint16_t group_desc_stats_nr = 0;
  uint16_t length = 0;

  if ( get_group_desc_status( &group_desc_stats, &group_desc_stats_nr ) == OFDPE_SUCCESS ) {
    for ( uint16_t i = 0; i < group_desc_stats_nr; i++ ) {
      length = bucket_list_length( &group_desc_stats[ i ].p_bucket );
      length = ( uint16_t ) ( length + sizeof( struct ofp_group_desc_stats ) );
      buffer *buffer = alloc_buffer_with_length( length );
      append_back_buffer( buffer, length );
      struct ofp_group_desc_stats *stats = buffer->data;
      stats->length = length;
      stats->group_id = group_desc_stats[ i ].group_id;
      stats->type = group_desc_stats[ i ].type;
      void *p = ( char * ) ( stats + offsetof( struct ofp_group_desc_stats, buckets ) );
      pack_bucket( p, &group_desc_stats[ i ].p_bucket );
      append_to_tail( &list, ( void * ) stats );
    }
  }
  return list;
}


#define SEND_STATS( stats_type, transaction_id, flags, list ) \
  buffer *msg = create_##stats_type##_multipart_reply( transaction_id, flags, list ); \
  switch_send_openflow_message( msg ); \
  delete_list( list ); \
  free_buffer( msg );
  


static void
_handle_multipart_request( uint32_t transaction_id, uint16_t type, uint16_t flags, const buffer *body, void *user_data ) {
  UNUSED( user_data );

  switch( type ) {
    case OFPMP_DESC: {
      // TODO not sure how to retrieve such information from datapath maybe need to code.
      break;
    }
    case OFPMP_FLOW: {
      const struct ofp_flow_stats_request *req = ( const struct ofp_flow_stats_request * ) body;

      list_element *list = request_flow_stats( req );
      SEND_STATS( flow, transaction_id, flags, list )
      break;
    }
    case OFPMP_AGGREGATE: {
      const struct ofp_aggregate_stats_request *req = ( const struct ofp_aggregate_stats_request * ) body;

      struct ofp_aggregate_stats_reply *reply = request_aggregate_stats( req );
      if ( reply ) {
        buffer *msg = create_aggregate_multipart_reply( transaction_id, flags, reply->packet_count, reply->byte_count, reply->flow_count );
        switch_send_openflow_message( msg );
        xfree( reply );
        free_buffer( msg );
      }
      break;
    }
    // no request body is included with this type.
    case OFPMP_TABLE: {
      list_element *list = request_table_stats();
      SEND_STATS( table, transaction_id, flags, list )
      break;
    }
    case OFPMP_PORT_STATS: {
      const struct ofp_port_stats_request *ps_req = ( const struct ofp_port_stats_request * ) body;
      list_element *list = request_port_stats( ps_req );
      SEND_STATS( port, transaction_id, flags, list )
      break;
    }
    case OFPMP_QUEUE: {
       const struct ofp_queue_stats_request *qs_req = ( const struct ofp_queue_stats_request * ) body;
       // TODO no support for queue statistics in datapath.
       UNUSED( qs_req );
       break;
    }
    case OFPMP_GROUP: {
      const struct ofp_group_stats_request *gs_req = ( const struct ofp_group_stats_request * ) body;
      list_element *list = request_group_stats( gs_req );
      SEND_STATS( group, transaction_id, flags, list )
      break;
    }
    case OFPMP_GROUP_DESC: {
      list_element *list = request_group_desc_stats();
      SEND_STATS( group_desc, transaction_id, flags, list )
      break;
    }
    case OFPMP_METER: {
      const struct ofp_meter_multipart_request *mm_req = ( const struct ofp_meter_multipart_request * ) body;
      /*
       * TODO Currently this setting not supported by datapath.
      */
      UNUSED( mm_req );
      break;
    }
    case OFPMP_METER_CONFIG: {
      const struct ofp_meter_multipart_request *mm_req = ( const struct ofp_meter_multipart_request * ) body;
      UNUSED( mm_req );
      break;
    }
    case OFPMP_TABLE_FEATURES: {
      const struct ofp_table_features *table_features = ( const struct ofp_table_features * ) body;
      /*
       * TODO Currently the setting of table features not supported by datapath
       * therefore ignored.
       */
      UNUSED( table_features );
      list_element *list = request_table_features_stats();
      SEND_STATS( table_features, transaction_id, flags, list )
      break;
    }
    case OFPMP_EXPERIMENTER: {
      const struct ofp_experimental_multipart_header *em_hdr = ( const struct ofp_experimental_multipart_header * ) body;
      // TODO not supported yet in datapath.
      UNUSED( em_hdr );
      break;
    }
    default:
      break;
  }
}
void ( *handle_multipart_request )( uint32_t transaction_id, uint16_t type, uint16_t flags, const buffer *body, void *user_data ) = _handle_multipart_request;


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
