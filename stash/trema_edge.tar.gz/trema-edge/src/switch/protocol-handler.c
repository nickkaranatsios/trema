/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>

#include "openflow_switch_interface.h"
#include "log.h"
#include "ofdp.h"
#include "port_manager.h"
#include "ofdp/lib/table_manager_match.h"


static void
_handle_hello( uint32_t transaction_id, uint8_t version, const buffer *version_data, void *user_data ) {
  UNUSED( user_data );
  info( "handle hello received %u %u", transaction_id, version );

  struct ofp_hello_elem_versionbitmap *versionbitmap = ( struct ofp_hello_elem_versionbitmap * ) version_data->data;
  const uint32_t ofp_versions[ 1 ] = { OFP_VERSION };

  uint32_t bitmap = versionbitmap->bitmaps[ 0 ];
  if ( ( bitmap & ( ( uint32_t ) 1 << ofp_versions[ 0 ] ) ) != ( ( uint32_t ) ofp_versions[ 0 ] ) ) {
    buffer *hello_buf = create_hello_elem_versionbitmap( transaction_id, ofp_versions,
      sizeof( ofp_versions ) / sizeof( ofp_versions[ 0 ] ) );
    switch_send_openflow_message( hello_buf );
    free_buffer( hello_buf );
  } else {
    send_error_message( transaction_id, OFPET_HELLO_FAILED, OFPHFC_INCOMPATIBLE );
  }
}
void ( *handle_hello )( uint32_t transaction_id, uint8_t version, const buffer *version_data, void *user_data ) = _handle_hello;


static void
_handle_features_request( uint32_t transaction_id, void *user_data ) {
  UNUSED( user_data );

  struct ofp_switch_features switch_features;
  memset( &switch_features, 0, sizeof( struct ofp_switch_features ) );
  get_switch_features( &switch_features );
  buffer *features_reply = create_features_reply( transaction_id,
    switch_features.datapath_id,
    switch_features.n_buffers,
    switch_features.n_tables,
    switch_features.auxiliary_id,
    switch_features.capabilities,
    switch_features.reserved );
  switch_send_openflow_message( features_reply );
  free_buffer( features_reply );
}
void ( *handle_features_request )( uint32_t transaction_id, void *user_data ) = _handle_features_request;


static void
_handle_set_config( uint32_t transaction_id, uint16_t flags, uint16_t miss_send_len, void *user_data ) {
  UNUSED( user_data );

  buffer *buffer = create_set_config( transaction_id, flags, miss_send_len );
  struct ofp_switch_config *switch_config = ( struct ofp_switch_config * ) buffer->data;
  set_switch_config( switch_config );
  free_buffer( buffer );
}
void ( *handle_set_config )( uint32_t transaction_id, uint16_t flags, uint16_t miss_send_len, void *user_data ) = _handle_set_config;


static void
_handle_echo_request( uint32_t transaction_id, const buffer *body, void *user_data ) {
  UNUSED( user_data );
  buffer *echo_reply = create_echo_reply( transaction_id, body );
  switch_send_openflow_message( echo_reply );
  free_buffer( echo_reply );
}
void ( *handle_echo_request )( uint32_t transaction_id, const buffer *body, void *user_data ) = _handle_echo_request;

#define MATCH_ATTR_SET( attr, attr_val ) \
  match->attr.value = attr_val; \
  match->attr.valid = true;


#define MATCH_ATTR_MASK_SET( attr, attr_val, mask_val ) \
  MATCH_ATTR_SET( attr, attr_val ) \
  match->attr.mask = mask_val;


#define MATCH_ARRAY_ATTR_SET( attr, attr_val, size ) \
  for ( uint8_t i = 0; i < ( size ); i++ ) { \
    match->attr[ i ].value = ( attr_val )[ i ]; \
    match->attr[ i ].valid = true; \
  }

#define MATCH_ARRAY_MASK_SET( attr, mask_value, size ) \
  for ( uint8_t i = 0; i < ( size ); i++ ) { \
    match->attr[ i ].mask = ( mask_value )[ i ]; \
  }


static void
assign_sctp_port( oxm_match_header *hdr, match *match ) {
  const uint16_t *value = ( const uint16_t * ) ( ( const char * ) hdr + sizeof( oxm_match_header ) );
  
  if ( *hdr == OXM_OF_SCTP_SRC ) {
    MATCH_ATTR_SET( sctp_src, *value )
  }
  if ( *hdr == OXM_OF_SCTP_DST ) {
    MATCH_ATTR_SET( sctp_dst, *value )
  }
}


static void
assign_udp_port( oxm_match_header *hdr, match *match ) {
  const uint16_t *value = ( const uint16_t * ) ( ( const char * ) hdr + sizeof( oxm_match_header ) );
  
  if ( *hdr == OXM_OF_UDP_SRC ) {
    MATCH_ATTR_SET( udp_src, *value )
  }
  if ( *hdr == OXM_OF_UDP_DST ) {
    MATCH_ATTR_SET( udp_dst, *value )
  }
}

static void
assign_tcp_port( oxm_match_header *hdr, match *match ) {
  const uint16_t *value = ( const uint16_t * ) ( ( const char * ) hdr + sizeof ( oxm_match_header ) );
  
  if ( *hdr == OXM_OF_TCP_SRC ) {
    MATCH_ATTR_SET( tcp_src, *value );
  }
  if ( *hdr == OXM_OF_TCP_DST ) {
    MATCH_ATTR_SET( tcp_dst, *value );
  }
}

static void
assign_ipv4_addr( oxm_match_header *hdr, match *match ) {
  const uint32_t *addr = ( const uint32_t * ) ( ( const uint8_t * ) hdr + sizeof ( oxm_match_header ) );

  switch ( *hdr ) {
    case OXM_OF_IPV4_SRC: {
      MATCH_ATTR_SET( ipv4_src, *addr )
    }
    break;
    case OXM_OF_IPV4_SRC_W: {
      const uint32_t *mask = ( const uint32_t * ) ( ( const uint8_t * ) addr + sizeof( uint32_t ) );
      MATCH_ATTR_MASK_SET( ipv4_src, *addr, *mask )
    }
    break;
    case OXM_OF_IPV4_DST: {
      MATCH_ATTR_SET( ipv4_dst, *addr )
    }
    break;
    case OXM_OF_IPV4_DST_W: {
      const uint32_t *mask = ( const uint32_t * ) ( ( const uint8_t * ) addr + sizeof( uint32_t ) );
      MATCH_ATTR_MASK_SET( ipv4_dst, *addr, *mask )
    }
    break;
    default:
      assert( 0 );
    break;
  }
}

static void
assign_vlan_vid( oxm_match_header *hdr, match *match ) {
  const uint16_t *value = ( const uint16_t * ) ( ( const char * ) hdr + sizeof ( oxm_match_header ) );

  if ( *hdr == OXM_OF_VLAN_VID ) {
    MATCH_ATTR_SET( vlan_vid, *value )
  }
  if ( *hdr == OXM_OF_VLAN_VID_W ) {
    const uint16_t *mask = ( const uint16_t * ) ( ( const char * ) value + sizeof ( uint16_t ) );
    MATCH_ATTR_MASK_SET( vlan_vid, *value, *mask )
  }
}

static void
assign_ether_addr( oxm_match_header *hdr, match *match ) {
  const uint8_t *addr = ( const uint8_t * ) hdr + sizeof ( oxm_match_header );
  const uint8_t *mask;
  
  switch( * hdr ) {
    case OXM_OF_ETH_DST:
      MATCH_ARRAY_ATTR_SET( eth_dst, addr, ETH_ADDRLEN )
      break;
    case OXM_OF_ETH_DST_W:
      mask = addr + ( sizeof ( uint8_t ) * ETH_ADDRLEN );
      MATCH_ARRAY_ATTR_SET( eth_dst, addr, ETH_ADDRLEN )
      MATCH_ARRAY_MASK_SET( eth_dst, mask, ETH_ADDRLEN )
      break;
    case OXM_OF_ETH_SRC:
      MATCH_ARRAY_ATTR_SET( eth_src, addr, ETH_ADDRLEN );
      break;
    case OXM_OF_ETH_SRC_W:
      mask = addr + ( sizeof ( uint8_t ) * ETH_ADDRLEN );
      MATCH_ARRAY_ATTR_SET( eth_src, addr, ETH_ADDRLEN )
      MATCH_ARRAY_MASK_SET( eth_src, mask, ETH_ADDRLEN )
      break;
    default:
      assert( 0 );
      break;
  }
}

static void
assign_metadata( oxm_match_header *hdr, match *match ) {
  const uint64_t *value = ( const uint64_t * ) ( ( const char * ) hdr + sizeof ( oxm_match_header ) );
  
  if ( *hdr == OXM_OF_METADATA ) {
    MATCH_ATTR_SET( metadata, *value )
  }
  if ( *hdr == OXM_OF_METADATA_W ) {
    value = ( const uint64_t * ) ( ( const char * ) hdr + sizeof ( oxm_match_header ) );
    const uint64_t *mask = ( const uint64_t * ) ( ( const char * ) value + sizeof ( uint64_t ) );
    MATCH_ATTR_MASK_SET( metadata, *value, *mask )
  }
}

static void
assign_match( oxm_match_header *hdr, match *match ) {
  switch( *hdr ) {
    case OXM_OF_IN_PORT: {
      const uint32_t *value = ( const uint32_t * ) ( ( const char * ) hdr + sizeof( oxm_match_header ) );
      MATCH_ATTR_SET( in_port, *value )
    }
    break;
    case OXM_OF_IN_PHY_PORT: {
      const uint32_t *value = ( const uint32_t * ) ( ( const char * ) hdr + sizeof( oxm_match_header ) );
      MATCH_ATTR_SET( in_phy_port, *value );
    }
    break;
    case OXM_OF_METADATA:
    case OXM_OF_METADATA_W: {
      assign_metadata( hdr, match );
    }
    break;
    case OXM_OF_ETH_DST:
    case OXM_OF_ETH_DST_W:
    case OXM_OF_ETH_SRC:
    case OXM_OF_ETH_SRC_W: {
      assign_ether_addr( hdr, match );
    }
    break;
    case OXM_OF_ETH_TYPE: {
      const uint16_t *value = ( const uint16_t * ) ( ( const char * ) hdr + sizeof( oxm_match_header ) );
      MATCH_ATTR_SET( eth_type, *value )
    }
    case OXM_OF_VLAN_VID:
    case OXM_OF_VLAN_VID_W: {
      assign_vlan_vid( hdr, match );
    }
    break;
    case OXM_OF_VLAN_PCP: {
      const uint8_t *value = ( const uint8_t * ) hdr + sizeof( oxm_match_header );
      MATCH_ATTR_SET( vlan_pcp, * value )
    }
    break;
    case OXM_OF_IP_DSCP: {
      const uint8_t *value = ( const uint8_t * ) hdr + sizeof( oxm_match_header );
      MATCH_ATTR_SET( ip_dscp, *value )
    }
    break;
    case OXM_OF_IP_ECN: {
      const uint8_t *value = ( const uint8_t * ) hdr + sizeof( oxm_match_header );
      MATCH_ATTR_SET( ip_ecn, *value )
    }
    case OXM_OF_IP_PROTO: {
      const uint8_t *value = ( const uint8_t * ) hdr + sizeof( oxm_match_header );
      MATCH_ATTR_SET( ip_proto, *value )
    }
    break;
    case OXM_OF_IPV4_SRC:
    case OXM_OF_IPV4_SRC_W:
    case OXM_OF_IPV4_DST:
    case OXM_OF_IPV4_DST_W: {
      assign_ipv4_addr( hdr, match );
    }
    break;
    case OXM_OF_TCP_SRC:
    case OXM_OF_TCP_DST: {
      assign_tcp_port( hdr, match );
    }
    break;
    case OXM_OF_UDP_SRC:
    case OXM_OF_UDP_DST: {
      assign_udp_port( hdr, match );
    }
    break;
    case OXM_OF_SCTP_SRC:
    case OXM_OF_SCTP_DST: {
      assign_sctp_port( hdr, match );
    }
    break;
    case OXM_OF_ICMPV4_TYPE: {
      const uint8_t *value = ( const uint8_t * ) hdr + sizeof( oxm_match_header );
      MATCH_ATTR_SET( icmpv4_type, *value )
    }
    break;
    case OXM_OF_ICMPV4_CODE: {
      const uint8_t *value = ( const uint8_t * ) hdr + sizeof( oxm_match_header );
      MATCH_ATTR_SET( icmpv4_code, *value )
    }
    break;
    case OXM_OF_ARP_OP: {
      const uint16_t *value = ( const uint16_t * ) ( ( const char * ) hdr + sizeof ( oxm_match_header ) );
      MATCH_ATTR_SET( arp_op, *value )
    }
    break;
    default:
    break;
  }
}

static void
handle_flow_mod_delete( uint32_t transaction_id, uint64_t cookie, 
                        uint64_t cookie_mask, uint8_t table_id,
                        uint16_t idle_timeout, uint16_t hard_timeout,
                        uint16_t priority, uint32_t buffer_id,
                        uint32_t out_port, uint32_t out_group,
                        uint16_t flags, const oxm_matches *oxm_match,
                        const openflow_instructions *instructions, 
                        bool strict ) {

  UNUSED( transaction_id );
  UNUSED( cookie );
  UNUSED( cookie_mask );
  UNUSED( table_id );
  UNUSED( idle_timeout );
  UNUSED( hard_timeout );
  UNUSED( priority );
  UNUSED( buffer_id );
  UNUSED( out_port );
  UNUSED( out_group );
  UNUSED( flags );
  UNUSED( oxm_match );
  UNUSED( instructions );
  UNUSED( strict );
  
  if ( oxm_match != NULL && oxm_match->n_matches > 0 ) {
    match *match = init_match();
    for ( list_element *e = oxm_match->list; e != NULL; e = e->next ) {
      oxm_match_header *hdr = e->data;
      assign_match( hdr, match );
    }
  }
}

static void
_handle_flow_mod( uint32_t transaction_id,
        uint64_t cookie,
        uint64_t cookie_mask,
        uint8_t table_id,
        uint8_t command,
        uint16_t idle_timeout,
        uint16_t hard_timeout,
        uint16_t priority,
        uint32_t buffer_id,
        uint32_t out_port,
        uint32_t out_group,
        uint16_t flags,
        const oxm_matches *match,
        const openflow_instructions *instructions,
        void *user_data
  ) {
  UNUSED( user_data );
  bool strict = false;

  switch ( command ) {
    case OFPFC_ADD:
      break;
    case OFPFC_MODIFY:
      break;
    case OFPFC_MODIFY_STRICT:
      break;
    case OFPFC_DELETE:
      handle_flow_mod_delete( transaction_id, cookie, cookie_mask, table_id,
                              idle_timeout, hard_timeout, priority, buffer_id,
                              out_port, out_group, flags, match,
                              instructions, strict );
      break;
    case OFPFC_DELETE_STRICT:
      strict = true;
      handle_flow_mod_delete( transaction_id, cookie, cookie_mask, table_id,
                              idle_timeout, hard_timeout, priority, buffer_id,
                              out_port, out_group, flags, match,
                              instructions, strict );
      break;
    default:
      warn( "Undefined flow mod command type %d", command );
      break;
  }
  
  /*
  * NOTE: An empty flow has n_matches = 0 and list = 0x0
  */
  for ( list_element *e = match->list; e != NULL; e = e->next ) { 
    oxm_match_header *hdr = e->data;

    debug( "field %d has_mask %d length %d ", OXM_FIELD( *hdr ), OXM_HASMASK( *hdr ), OXM_LENGTH( *hdr ) );
  }
}
void ( *handle_flow_mod )( uint32_t transaction_id,
        uint64_t cookie,
        uint64_t cookie_mask,
        uint8_t table_id,
        uint8_t command,
        uint16_t idle_timeout,
        uint16_t hard_timeout,
        uint16_t priority,
        uint32_t buffer_id,
        uint32_t out_port,
        uint32_t out_group,
        uint16_t flags,
        const oxm_matches *match,
        const openflow_instructions *instructions,
        void *user_data) = _handle_flow_mod;


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
