/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <sys/socket.h>

#include "openflow_switch_interface.h"
#include "log.h"
#include "ofdp.h"
#include "port_manager.h"
#include "ofdp/lib/table_manager_flow.h"
#include "oxm-helper.h"
#include "action-helper.h"



static void
_handle_hello( uint32_t transaction_id, uint8_t version, const buffer *version_data, void *user_data ) {
  UNUSED( user_data );
  info( "handle hello received %u %u", transaction_id, version );

  struct ofp_hello_elem_versionbitmap *versionbitmap = ( struct ofp_hello_elem_versionbitmap * ) version_data->data;
  const uint32_t ofp_versions[ 1 ] = { OFP_VERSION };

  uint32_t bitmap = versionbitmap->bitmaps[ 0 ];
  if ( ( bitmap & ( ( uint32_t ) 1 << ofp_versions[ 0 ] ) ) != ( ( uint32_t ) ofp_versions[ 0 ] ) ) {
    buffer *hello_buf = create_hello_elem_versionbitmap( transaction_id, ofp_versions,
      sizeof( ofp_versions ) / sizeof( ofp_versions[ 0 ] ) );
    switch_send_openflow_message( hello_buf );
    free_buffer( hello_buf );
  } else {
    send_error_message( transaction_id, OFPET_HELLO_FAILED, OFPHFC_INCOMPATIBLE );
  }
}
void ( *handle_hello )( uint32_t transaction_id, uint8_t version, const buffer *version_data, void *user_data ) = _handle_hello;


static void
_handle_features_request( uint32_t transaction_id, void *user_data ) {
  UNUSED( user_data );

  struct ofp_switch_features switch_features;
  memset( &switch_features, 0, sizeof( struct ofp_switch_features ) );
  get_switch_features( &switch_features );
  buffer *features_reply = create_features_reply( transaction_id,
    switch_features.datapath_id,
    switch_features.n_buffers,
    switch_features.n_tables,
    switch_features.auxiliary_id,
    switch_features.capabilities,
    switch_features.reserved );
  switch_send_openflow_message( features_reply );
  free_buffer( features_reply );
}
void ( *handle_features_request )( uint32_t transaction_id, void *user_data ) = _handle_features_request;


// protocol to datapath message.
static void
_handle_set_config( uint32_t transaction_id, uint16_t flags, uint16_t miss_send_len, void *user_data ) {
  UNUSED( user_data );

  buffer *buffer = create_set_config( transaction_id, flags, miss_send_len );
  struct ofp_switch_config *switch_config = ( struct ofp_switch_config * ) buffer->data;
  set_switch_config( switch_config );
  free_buffer( buffer );
}
void ( *handle_set_config )( uint32_t transaction_id, uint16_t flags, uint16_t miss_send_len, void *user_data ) = _handle_set_config;


static void
_handle_echo_request( uint32_t transaction_id, const buffer *body, void *user_data ) {
  UNUSED( user_data );
  buffer *echo_reply = create_echo_reply( transaction_id, body );
  switch_send_openflow_message( echo_reply );
  free_buffer( echo_reply );
}
void ( *handle_echo_request )( uint32_t transaction_id, const buffer *body, void *user_data ) = _handle_echo_request;


static void
handle_flow_mod_add( uint64_t cookie, uint8_t table_id,
                     uint16_t idle_timeout, uint16_t hard_timeout,
                     uint16_t priority, uint16_t flags, 
                     const oxm_matches *oxm_match,
                     const openflow_instructions *instructions ) {
  match *match = NULL;

  if ( oxm_match != NULL && oxm_match->n_matches > 0 ) {
    match = init_match( );
    for ( list_element *e = oxm_match->list; e != NULL; e = e->next ) {
      oxm_match_header *hdr = e->data;
      assign_match( hdr, match );
    }
  }
  
  instruction_list *ins_list = NULL;
  if ( instructions != NULL ) {
    ins_list = init_instruction_list();
    assign_instructions( instructions->list, ins_list, table_id );
  }

  flow_entry *entry = NULL;
  // can only call lookup_flow_entry_strict if oxm is not null.
  if ( match != NULL ) {
    entry = lookup_flow_entry_strict( table_id, match, priority );
    if ( entry != NULL ) {
      if ( entry->instructions != NULL ) {
        remove_instructions( &entry->instructions );
      }
      entry->idle_timeout = idle_timeout;
      entry->hard_timeout = hard_timeout;
      entry->flags = flags;
      entry->cookie = cookie;
      update_flow_entry( table_id, entry );
    }
  }
  if ( entry == NULL ) {
    flow_entry *new_entry;
    new_entry = create_flow_entry( match, ins_list, priority, idle_timeout, 
                                   hard_timeout, flags, cookie );
    if ( new_entry != NULL ) {
      append_flow_entry( table_id, new_entry );
    }
  }
}


static void
handle_flow_mod_delete( uint32_t transaction_id, uint64_t cookie,
                        uint64_t cookie_mask, uint8_t table_id,
                        uint16_t idle_timeout, uint16_t hard_timeout,
                        uint16_t priority, uint32_t buffer_id,
                        uint32_t out_port, uint32_t out_group,
                        uint16_t flags, const oxm_matches *oxm_match,
                        const openflow_instructions *instructions,
                        bool strict ) {

  UNUSED( transaction_id );
  UNUSED( cookie );
  UNUSED( cookie_mask );
  UNUSED( table_id );
  UNUSED( idle_timeout );
  UNUSED( hard_timeout );
  UNUSED( priority );
  UNUSED( buffer_id );
  UNUSED( out_port );
  UNUSED( out_group );
  UNUSED( flags );
  UNUSED( oxm_match );
  UNUSED( instructions );
  UNUSED( strict );
  
  if ( oxm_match != NULL && oxm_match->n_matches > 0 ) {
    match *match = init_match();
    for ( list_element *e = oxm_match->list; e != NULL; e = e->next ) {
      oxm_match_header *hdr = e->data;
      assign_match( hdr, match );
    }
  }
}

static void
_handle_flow_mod( uint32_t transaction_id,
        uint64_t cookie,
        uint64_t cookie_mask,
        uint8_t table_id,
        uint8_t command,
        uint16_t idle_timeout,
        uint16_t hard_timeout,
        uint16_t priority,
        uint32_t buffer_id,
        uint32_t out_port,
        uint32_t out_group,
        uint16_t flags,
        const oxm_matches *match,
        const openflow_instructions *instructions,
        void *user_data
  ) {
  UNUSED( user_data );
  bool strict = false;

  switch ( command ) {
    case OFPFC_ADD:
      handle_flow_mod_add( cookie, table_id, idle_timeout,
                           hard_timeout, priority, flags,
                           match, instructions );
      break;
    case OFPFC_MODIFY:
      break;
    case OFPFC_MODIFY_STRICT:
      break;
    case OFPFC_DELETE:
      handle_flow_mod_delete( transaction_id, cookie, cookie_mask,
                              table_id, idle_timeout, hard_timeout,
                              priority, buffer_id, out_port,
                              out_group, flags, match,
                              instructions, strict );
      break;
    case OFPFC_DELETE_STRICT:
      strict = true;
      handle_flow_mod_delete( transaction_id, cookie, cookie_mask, table_id,
                              idle_timeout, hard_timeout, priority, buffer_id,
                              out_port, out_group, flags, match,
                              instructions, strict );
      break;
    default:
      warn( "Undefined flow mod command type %d", command );
      break;
  }
  
  /*
  * NOTE: An empty flow has n_matches = 0 and list = 0x0
  */
  for ( list_element *e = match->list; e != NULL; e = e->next ) { 
    oxm_match_header *hdr = e->data;

    debug( "field %d has_mask %d length %d ", OXM_FIELD( *hdr ), OXM_HASMASK( *hdr ), OXM_LENGTH( *hdr ) );
  }
}
void ( *handle_flow_mod )( uint32_t transaction_id,
        uint64_t cookie,
        uint64_t cookie_mask,
        uint8_t table_id,
        uint8_t command,
        uint16_t idle_timeout,
        uint16_t hard_timeout,
        uint16_t priority,
        uint32_t buffer_id,
        uint32_t out_port,
        uint32_t out_group,
        uint16_t flags,
        const oxm_matches *match,
        const openflow_instructions *instructions,
        void *user_data) = _handle_flow_mod;


static void
_handle_packet_out( uint32_t transaction_id, uint32_t buffer_id, 
                    uint32_t in_port, openflow_actions *actions,
                    buffer *frame, void *user_data ) {
  
}
void ( *handle_packet_out( uint32_t transaction_id, uint32_t buffer_id,
                           uint32_t in_port, openflow_actions *actions,
                           buffer *frame, void *user_data ) = _handle_packet_out;

/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
