/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <sys/socket.h>

#include "openflow_switch_interface.h"
#include "log.h"
#include "ofdp.h"
#include "port_manager.h"
#include "ofdp/lib/table_manager_flow.h"
#include "ofdp/lib/action_executor.h"
#include "async.h"
#include "protocol.h"
#include "oxm-helper.h"
#include "action-helper.h"



static void
_handle_hello( uint32_t transaction_id, uint8_t version, const buffer *version_data, void *user_data ) {
  UNUSED( user_data );
  info( "handle hello received %u %u", transaction_id, version );

  struct ofp_hello_elem_versionbitmap *versionbitmap = ( struct ofp_hello_elem_versionbitmap * ) version_data->data;
  const uint32_t ofp_versions[ 1 ] = { OFP_VERSION };

  uint32_t bitmap = versionbitmap->bitmaps[ 0 ];
  if ( ( bitmap & ( ( uint32_t ) 1 << ofp_versions[ 0 ] ) ) != ( ( uint32_t ) ofp_versions[ 0 ] ) ) {
    buffer *hello_buf = create_hello_elem_versionbitmap( transaction_id, ofp_versions,
      sizeof( ofp_versions ) / sizeof( ofp_versions[ 0 ] ) );
    switch_send_openflow_message( hello_buf );
    free_buffer( hello_buf );
  } else {
    send_error_message( transaction_id, OFPET_HELLO_FAILED, OFPHFC_INCOMPATIBLE );
  }
}
void ( *handle_hello )( uint32_t transaction_id, uint8_t version, const buffer *version_data, void *user_data ) = _handle_hello;


static void
_handle_features_request( uint32_t transaction_id, void *user_data ) {
  assert( user_data );
  struct protocol *protocol = user_data;

  struct ofp_switch_features switch_features;
  memset( &switch_features, 0, sizeof( struct ofp_switch_features ) );
  get_switch_features( &switch_features );
  buffer *features_reply = create_features_reply( transaction_id,
    switch_features.datapath_id,
    switch_features.n_buffers,
    switch_features.n_tables,
    switch_features.auxiliary_id,
    switch_features.capabilities,
    switch_features.reserved );
  switch_send_openflow_message( features_reply );
  free_buffer( features_reply );
  protocol->controller_connected = true;
}
void ( *handle_features_request )( uint32_t transaction_id, void *user_data ) = _handle_features_request;


// protocol to datapath message.
static void
_handle_set_config( uint32_t transaction_id, uint16_t flags, uint16_t miss_send_len, void *user_data ) {
  UNUSED( user_data );

  buffer *buffer = create_set_config( transaction_id, flags, miss_send_len );
  struct ofp_switch_config *switch_config = ( struct ofp_switch_config * ) buffer->data;
  set_switch_config( switch_config );
  free_buffer( buffer );
}
void ( *handle_set_config )( uint32_t transaction_id, uint16_t flags, uint16_t miss_send_len, void *user_data ) = _handle_set_config;


static void
_handle_echo_request( uint32_t transaction_id, const buffer *body, void *user_data ) {
  UNUSED( user_data );
  buffer *echo_reply = create_echo_reply( transaction_id, body );
  switch_send_openflow_message( echo_reply );
  free_buffer( echo_reply );
}
void ( *handle_echo_request )( uint32_t transaction_id, const buffer *body, void *user_data ) = _handle_echo_request;


static void
handle_flow_mod_add( uint32_t transaction_id, uint64_t cookie, uint8_t table_id,
                     uint16_t idle_timeout, uint16_t hard_timeout,
                     uint16_t priority, uint16_t flags, 
                     const oxm_matches *oxm_match,
                     const openflow_instructions *instructions ) {
  
  if ( table_id == OFPTT_ALL ) {
    send_error_message( transaction_id, OFPET_FLOW_MOD_FAILED, OFPFMFC_BAD_TABLE_ID );
    return;
  }
  match *match = NULL;

  match = init_match( );
  if ( oxm_match != NULL && oxm_match->n_matches > 0 ) {
    for ( list_element *e = oxm_match->list; e != NULL; e = e->next ) {
      oxm_match_header *hdr = e->data;
      assign_match( hdr, match );
    }
  }
  flow_entry *entry = NULL;

  entry = lookup_flow_entry_strict( table_id, match, priority );
  if ( entry != NULL ) {
    if ( entry->instructions != NULL ) {
      remove_instructions( &entry->instructions );
    }
    entry->idle_timeout = idle_timeout;
    entry->hard_timeout = hard_timeout;
    entry->flags = flags;
    entry->cookie = cookie;
    update_flow_entry( table_id, entry );
  }
  if ( entry == NULL ) {
    instruction_list *ins_list = NULL;
    if ( instructions != NULL ) {
      ins_list = init_instruction_list( );
      assign_instructions( instructions->list, ins_list, table_id );
    }
    flow_entry *new_entry;
    new_entry = create_flow_entry( match, ins_list, priority, idle_timeout, 
                                   hard_timeout, flags, cookie );
    if ( new_entry != NULL ) {
      if ( append_flow_entry( table_id, new_entry ) != OFDPE_SUCCESS ) {
        /*
         * TODO we should send a more appropriate error once we worked out the
         * datapath errors.
        */
        send_error_message( transaction_id, OFPET_FLOW_MOD_FAILED, OFPFMFC_UNKNOWN );
      }
    }
  }
}


static void
handle_flow_mod_delete( uint32_t transaction_id, uint64_t cookie,
                        uint64_t cookie_mask, uint8_t table_id,
                        uint16_t idle_timeout, uint16_t hard_timeout,
                        uint16_t priority, uint32_t buffer_id,
                        uint32_t out_port, uint32_t out_group,
                        uint16_t flags, const oxm_matches *oxm_match,
                        const openflow_instructions *instructions,
                        bool strict ) {

  UNUSED( transaction_id );
  UNUSED( cookie );
  UNUSED( cookie_mask );
  UNUSED( idle_timeout );
  UNUSED( hard_timeout );
  UNUSED( priority );
  UNUSED( buffer_id );
  UNUSED( out_port );
  UNUSED( out_group );
  UNUSED( flags );
  UNUSED( instructions );
  
  /*
   * TODO At the moment not sure which datapath API to call to delete all flow
   * entries from all tables. Calling lookup_flow_entry_strict() or
   * lookup_flow_entry() one by one maybe the only way to delete all flow
   * entries which seems like an overhead.
   */
  if ( table_id == OFPTT_ALL ) {
    return;
  }
  match *match = init_match( );
  if ( oxm_match != NULL && oxm_match->n_matches > 0 ) {
    for ( list_element *e = oxm_match->list; e != NULL; e = e->next ) {
      oxm_match_header *hdr = e->data;
      assign_match( hdr, match );
    }
  }
  flow_entry *entry = NULL;
  if ( strict ) {
    entry = lookup_flow_entry_strict( table_id, match, priority );
  } else {
    entry = lookup_flow_entry( table_id, match );
  }
  if ( entry ) {
    delete_flow_entry( &entry );
  }
}

static void
_handle_flow_mod( uint32_t transaction_id,
        uint64_t cookie,
        uint64_t cookie_mask,
        uint8_t table_id,
        uint8_t command,
        uint16_t idle_timeout,
        uint16_t hard_timeout,
        uint16_t priority,
        uint32_t buffer_id,
        uint32_t out_port,
        uint32_t out_group,
        uint16_t flags,
        const oxm_matches *match,
        const openflow_instructions *instructions,
        void *user_data
  ) {
  UNUSED( user_data );
  bool strict = false;

  switch ( command ) {
    case OFPFC_ADD:
      handle_flow_mod_add( transaction_id, cookie, table_id,
                           idle_timeout,hard_timeout, priority,
                           flags, match, instructions );
      break;
    case OFPFC_MODIFY:
      break;
    case OFPFC_MODIFY_STRICT:
      break;
    case OFPFC_DELETE:
      handle_flow_mod_delete( transaction_id, cookie, cookie_mask,
                              table_id, idle_timeout, hard_timeout,
                              priority, buffer_id, out_port,
                              out_group, flags, match,
                              instructions, strict );
      break;
    case OFPFC_DELETE_STRICT:
      strict = true;
      handle_flow_mod_delete( transaction_id, cookie, cookie_mask, table_id,
                              idle_timeout, hard_timeout, priority, buffer_id,
                              out_port, out_group, flags, match,
                              instructions, strict );
      break;
    default:
      warn( "Undefined flow mod command type %d", command );
      break;
  }
  
  /*
  * NOTE: An empty flow has n_matches = 0 and list = 0x0
  */
  for ( list_element *e = match->list; e != NULL; e = e->next ) { 
    oxm_match_header *hdr = e->data;

    debug( "field %d has_mask %d length %d ", OXM_FIELD( *hdr ), OXM_HASMASK( *hdr ), OXM_LENGTH( *hdr ) );
  }
}
void ( *handle_flow_mod )( uint32_t transaction_id,
        uint64_t cookie,
        uint64_t cookie_mask,
        uint8_t table_id,
        uint8_t command,
        uint16_t idle_timeout,
        uint16_t hard_timeout,
        uint16_t priority,
        uint32_t buffer_id,
        uint32_t out_port,
        uint32_t out_group,
        uint16_t flags,
        const oxm_matches *match,
        const openflow_instructions *instructions,
        void *user_data) = _handle_flow_mod;


static inline void *
cast_non_const( const void *ptr ) {
  union {
    const void* const_value;
    void *value;
  } ret;
  ret.const_value = ptr;
  return ret.value;
}


static void
_handle_packet_out( uint32_t transaction_id, uint32_t buffer_id, 
                    uint32_t in_port, const openflow_actions *actions,
                    const buffer *frame, void *user_data ) {
  UNUSED( transaction_id );
  UNUSED( user_data );
  assert( actions->list );
  
  action_list *ac_list = init_action_list();
  for ( list_element *e = actions->list; e != NULL; e = e->next ) {
    struct ofp_action_header *ac_hdr = e->data;
    ac_list = assign_actions( ac_hdr, false, ac_list );
  }
  execute_action_packet_out( buffer_id, in_port, 
          ac_list, cast_non_const( frame ) );
  finalize_action_list( &ac_list );
}
void ( *handle_packet_out )( uint32_t transaction_id, uint32_t buffer_id,
                           uint32_t in_port, const openflow_actions *actions,
                           const buffer *frame, void *user_data ) = _handle_packet_out;


static void
_handle_port_mod( uint32_t transaction_id, uint32_t port_no, uint8_t hw_addr[],
                  uint32_t config, uint32_t mask, uint32_t advertise, void *user_data ) {
  UNUSED( hw_addr );
  UNUSED( advertise );
  UNUSED( user_data );
  int ret;
  /*
   * the update_port_config() performs a port lookup.
   */
  ret = update_port_config( port_no, config, mask );
  if ( ret == ERROR_ILLEGAL_PARAMETER ) {
    send_error_message( transaction_id, OFPET_PORT_MOD_FAILED, OFPPMFC_BAD_PORT );
  }
  if ( ret == ERROR_OFDPE_PORT_MOD_FAILED_BAD_CONFIG ) {
    send_error_message( transaction_id, OFPET_PORT_MOD_FAILED, OFPPMFC_BAD_CONFIG );
  }
  /*
   * TODO not sure how to translate the ERROR_UNLOCK error code into one
   * of the port mod failed code type.
   */
}
void ( *handle_port_mod )( uint32_t transaction_id, uint32_t port_no, uint8_t hw_addr[],
  uint32_t config, uint32_t mask, uint32_t advertise, void *user_data ) = _handle_port_mod;


static void
_handle_table_mod( uint32_t transaction_id, uint8_t table_id, uint32_t config,
  void *user_data ) {
  UNUSED( transaction_id );
  UNUSED( table_id );
  UNUSED( config );
  UNUSED( user_data );
}
void ( *handle_table_mod )( uint32_t transaction_id, uint8_t table_id, uint32_t config,
  void *user_data ) = _handle_table_mod;


/*
 * A field by field copy because the flow_stats not aligned to ofp_flow_stats.
 * First argument is source second argument destination.
 * TODO if flow_stats is added a pad2[ 4 ] field all fields upto match can be
 * copied using memcpy.
 */
static void
copy_flow_stats_to_ofp( const flow_stats *stats, struct ofp_flow_stats *fs ) {
  fs->length = stats->length;
  fs->table_id = stats->table_id;
  fs->duration_sec = stats->duration_sec;
  fs->duration_nsec = stats->duration_nsec;
  fs->priority = stats->priority;
  fs->idle_timeout = stats->idle_timeout;
  fs->hard_timeout = stats->hard_timeout;
  fs->flags = stats->flags;
  fs->cookie = stats->cookie;
  fs->packet_count = stats->packet_count;
  fs->byte_count = stats->byte_count;
}


/*
 * Set up information to request flow statistics from datapath. The function
 * returns a linked list of ofp_flow_stats objects. If no statistics found an
 * empty list is returned.
 */
static list_element *
request_flow_stats( const struct ofp_flow_stats_request *fs_req ) {
  match *flow_match = init_match();
  size_t match_len = fs_req->match.length - offsetof( struct ofp_match, oxm_fields ); 

  // translate the ofp_match to datapath match.
  if ( match_len > 0 ) {
    const oxm_match_header *hdr = ( const oxm_match_header * ) fs_req->match.oxm_fields;
    assign_match( hdr, flow_match );
  }
  const flow_stats_request request = {
    .table_id = fs_req->table_id,
    .out_port = fs_req->out_port,
    .out_group = fs_req->out_group,
    .cookie = fs_req->cookie,
    .cookie_mask = fs_req->cookie_mask,
    .p_match = flow_match
  };

  flow_stats *stats;
  uint32_t stats_nr = 0;
  list_element *list;

  if ( create_list( &list ) == false ) {
    assert( 0 );
  }

  // request flow stats and assign to list
  if ( get_statistics_flow( request, &stats, &stats_nr )  == OFDPE_SUCCESS ) {
    oxm_matches *oxm_match = create_oxm_matches();

    for ( uint32_t i = 0; i < stats_nr; i++ ) {
      struct ofp_flow_stats *fs = xmalloc( sizeof( *fs ) );

      copy_flow_stats_to_ofp( &stats[ i ], fs );
      construct_oxm( oxm_match, stats[ i ].p_match );
      construct_ofp_match( &fs->match, oxm_match );
      // TODO check if append_to_tail copies the buffer threfore can determine
      // when to free.
      append_to_tail( &list, ( void * ) fs );
    }
  }
  return list;
}


/*
 * Request table statistics starting with lower table numbers terminate when an
 * invalid table number is found. Returns an array of ofp_table_stats.
 */
static list_element *
request_table_stats( void ) {
  ofp_table_stats *table_stats = NULL;
  list_element *list;
  uint8_t i;

  if ( create_list( &list ) == false ) {
    assert( 0 );
  }
  for ( i = 0; i < OFPTT_MAX; i++ ) {
    // the call below returns NULL if an invalid table is found.
    if ( _get_flow_table( i ) ) {
      break;
    }
    get_statistics_table( &table_stats, i );
    append_to_tail( &list, ( void * ) table_stats );
  }
  return list; 
}


static void
_handle_multipart_request( uint32_t transaction_id, uint16_t type, uint16_t flags, const buffer *body, void *user_data ) {
  switch( type ) {
    case OFPMP_FLOW: {
      const struct ofp_flow_stats_request *fs_req = ( const struct ofp_flow_stats_request * ) body;

      list_element *list = request_flow_stats( fs_req );
      buffer *msg = create_flow_multipart_reply( transaction_id, flags, list );
      switch_send_openflow_message( msg );
      delete_list( list );
      free_buffer( msg );
      break;
    }
    case OFPMP_AGGREGATE: {
      const struct ofp_aggregate_stats_request *as_req = ( const struct ofp_aggregate_stats_request * ) body;
      break;
    }
    // no request body is included with this type.
    case OFPMP_TABLE: {
      list_element *list = request_table_stats();
      buffer *msg = create_table_multipart_reply( transaction_id, flags, list );
      switch_send_openflow_message( msg );
      delete_list( list );
      free_buffer( msg );
      break;
    }
    case OFPMP_PORT_STATS: {
      const struct ofp_port_stats_request *ps_req = ( const struct ofp_port_stats_request * ) body;
      break;
    }
    case OFPMP_QUEUE: {
       const struct ofp_queue_stats_request *qs_req = ( const struct ofp_queue_stats_request * ) body;
       break;
    }
    case OFPMP_GROUP: {
      const struct ofp_group_stats_request *gs_req = ( const struct ofp_group_stats_request * ) body;
      break;
    }
    case OFPMP_METER: {
      const struct ofp_meter_multipart_request *mm_req = ( const struct ofp_meter_multipart_request * ) body;
      break;
    }
    case OFPMP_METER_CONFIG: {
      const struct ofp_meter_multipart_request *mm_req = ( const struct ofp_meter_multipart_request * ) body;
      break;
    }
    case OFPMP_TABLE_FEATURES: {
      const struct ofp_table_features *table_features = ( const struct ofp_table_features * ) body;
      list_element *list = request_table_features_stats();
      break;
    }
    case OFPMP_EXPERIMENTER: {
      const struct ofp_experimental_multipart_header *em_hdr = ( const struct ofp_experimental_multipart_header * ) body;
      break;
    }
    default:
      break;
  }
}
void ( *handle_multipart_request )( uint32_t transaction_id, uint16_t type, uint16_t flags, const buffer *body, void *user_data ) = _handle_multipart_request;


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
