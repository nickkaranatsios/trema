/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <assert.h>
#include <errno.h>
#include <inttypes.h>

#include "wrapper.h"
#include "checks.h"
#include "openflow_switch_interface.h"
#include "log.h"
#include "bool.h"
#include "thread-test.h"
#include "timer-test.h"
#include "async-lock.h"
#include "async-util.h"

#include "async.h"
#include "parse-options.h"
#include "protocol.h"


void
retrieve_packet_from_datapath( int fd, void *user_data ) {
  assert( fd >= 0 );
  assert( user_data != NULL );
}


void
notify_datapath( int fd, void *user_data ) {
  assert( fd >= 0 );
  struct protocol *protocol = user_data;
  assert( protocol != NULL );

  ssize_t ret = write( protocol->peer_efd, &protocol->send_count, sizeof( protocol->send_count ) );
  if ( ret < 0 ) {
    if ( ret == EAGAIN || errno == EINTR ) {
      return;
    }
  } else if ( ret != sizeof( protocol->send_count ) ) {
    error( "Failed to notify protocol count= " PRIu64 ",ret = %d", protocol->send_count, ret );
  }
  new_set_writable( fd, false );
  protocol->send_count = 0;
}


static void
handle_hello( uint32_t transaction_id, uint8_t version, const buffer *version_data, void *user_data ) {
  UNUSED( user_data );
  info( "handle hello received %u %u", transaction_id, version );

  struct ofp_hello_elem_versionbitmap *versionbitmap = ( struct ofp_hello_elem_versionbitmap * ) version_data->data;
  const uint32_t ofp_versions[ 1 ] = { OFP_VERSION };

  uint32_t bitmap = versionbitmap->bitmaps[ 0 ];
  if ( ( bitmap & ( ( uint32_t ) 1 << ofp_versions[ 0 ] ) ) != ( ( uint32_t ) ofp_versions[ 0 ] ) ) {
    buffer *hello_buf = create_hello_elem_versionbitmap( transaction_id, ofp_versions,
      sizeof( ofp_versions ) / sizeof( ofp_versions[ 0 ] ) );
    switch_send_openflow_message( hello_buf );
  } else {
    send_error_message( transaction_id, OFPET_HELLO_FAILED, OFPHFC_INCOMPATIBLE );
  }
}


static void
handle_features_request( uint32_t transaction_id, void *user_data ) {
  struct protocol *protocol = user_data;
  assert( protocol != NULL );

  buffer *buffer = alloc_buffer_with_length( sizeof( struct ofp_switch_features ) );
  struct ofp_switch_features *switch_features = buffer->data;
  switch_features->header.type = OFPT_FEATURES_REQUEST;
  switch_features->header.xid = transaction_id;

  enqueue_message( protocol->peer_queue, buffer );
  protocol->send_count++;
  new_set_writable( protocol->own_efd, true );
}

static void
handle_controller_connected( void *user_data ) {
  set_hello_handler( handle_hello, user_data );
  set_features_request_handler( handle_features_request, user_data );
}


static int
serve_protocol( void *data ) {
  struct protocol *protocol = data;
  int ret;

  add_thread();
  new_init_timer();
  new_init_event_handler();

  const struct switch_arguments *args = protocol->args;
  protocol->own_efd = args->efd[ 0 ];
  protocol->peer_efd = args->efd[ 1 ];
  protocol->input_queue = args->to_protocol_queue;
  protocol->peer_queue = args->to_datapath_queue;
  protocol->send_count = 0;

  new_set_fd_handler( protocol->own_efd, retrieve_packet_from_datapath, protocol, notify_datapath, protocol );
  new_set_readable( protocol->own_efd, true );
  new_set_writable( protocol->own_efd, true );

  ret = init_openflow_switch_interface( args->datapath_id, args->server_ip, args->server_port );
  if ( ret == false ) {
    finish_async( &protocol->thread );
  }
  set_controller_connected_handler( handle_controller_connected, protocol );

  return new_start_event_handler();
}


pthread_t
start_async_protocol( struct switch_arguments *args ) {
  struct protocol *protocol;
  int ret;

  protocol = ( struct protocol * )xmalloc( sizeof( *protocol ) );  
  protocol->thread.proc = serve_protocol;
  protocol->args = args;
  protocol->thread.data = protocol;
  ret = start_async( &protocol->thread );
  if ( ret < 0 ) {
    error( "Failed to start the protocol thread" );
    return EXIT_FAILURE;
  }
  return ( protocol->thread.tid );  
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
