#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include "wrapper.h"
#include "checks.h"
#include "openflow_switch_interface.h"
#include "event_handler.h"
#include "log.h"

#include "async.h"
#include "parse-options.h"
#include "protocol.h"


static int
serve_protocol( void *data ) {
  const struct protocol *protocol = data;

  init_openflow_switch_interface( protocol->args->datapath_id, protocol->args->server_ip, protocol->args->server_port );
  start_event_handler();
  return ( 0 );
}


int
start_async_protocol( struct switch_arguments *args ) {
  struct protocol *protocol;
  int ret;

  protocol = ( struct protocol * )xmalloc( sizeof( *protocol ) );  
  protocol->thread.proc = serve_protocol;
  protocol->args = args;
  protocol->thread.data = protocol;
  ret = start_async( &protocol->thread );
  if ( ret < 0 ) {
    error( "Failed to start the protocol thread" );
  }
  return ( ret );  
}
