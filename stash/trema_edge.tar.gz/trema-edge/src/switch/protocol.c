/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <assert.h>
#include <errno.h>
#include <inttypes.h>

#include "wrapper.h"
#include "checks.h"
#include "openflow_switch_interface.h"
#include "log.h"
#include "bool.h"
#include "thread-test.h"
#include "timer-test.h"
#include "async-lock.h"
#include "async-util.h"

#include "async.h"
#include "parse-options.h"
#include "protocol.h"
#include "protocol-handler.h"
#include "ofdp/lib/controller_manager.h"
#include "ofdp/lib/ofdp_error.h"
#include "oxm-helper.h"
#include "action-tlv.h"


static void
handle_datapath_packet_in( buffer *datapath_pkt, struct protocol *protocol ) {
  notify_parameter_packet_in *packet_in_notifier = 
    ( notify_parameter_packet_in *)( ( char * ) datapath_pkt->data + sizeof( struct ofp_header ) );
  oxm_matches *oxm_match = create_oxm_matches();
  if ( packet_in_notifier->reason != OFPR_NO_MATCH ) {
    construct_oxm( oxm_match, &packet_in_notifier->match );
  }
  if ( packet_in_notifier->buffer_id != OFP_NO_BUFFER ) {
    protocol->buffer_id = packet_in_notifier->buffer_id;
  }
  buffer *packet_in = create_packet_in( 0,
    packet_in_notifier->buffer_id,
    packet_in_notifier->max_len,
    packet_in_notifier->reason,
    ( uint8_t ) packet_in_notifier->table_id,
    packet_in_notifier->cookie,
    oxm_match,
    packet_in_notifier->packet );
  delete_oxm_matches( oxm_match );
  switch_send_openflow_message( packet_in );
  free_buffer( packet_in );
  if ( packet_in_notifier->packet && packet_in_notifier->packet->length > 0 ){
    free_buffer( packet_in_notifier->packet );
  }
  free_buffer( datapath_pkt );
}


static void
handle_datapath_port_status( buffer *datapath_pkt, const struct protocol *protocol ) {
  UNUSED( protocol );
  notify_parameter_port_status *port_status_notifier = 
    ( notify_parameter_port_status * )( ( char * ) datapath_pkt->data + sizeof( struct ofp_header ) );

  buffer *port_status = create_port_status( 0, port_status_notifier->reason,
    port_status_notifier->desc );
  switch_send_openflow_message( port_status );
  free_buffer( port_status );
  free_buffer( datapath_pkt );
}


static void
handle_datapath_flow_removed( buffer *datapath_pkt, const struct protocol *protocol ) {
  UNUSED( protocol );
  notify_parameter_flow_removed *flow_removed_notifier =
    ( notify_parameter_flow_removed * )( ( char * ) datapath_pkt->data + sizeof( struct ofp_header ) );

  oxm_matches *oxm_match = create_oxm_matches();
  construct_oxm( oxm_match, &flow_removed_notifier->match );
  buffer *flow_removed = create_flow_removed( 0,
    flow_removed_notifier->cookie,
    flow_removed_notifier->priority,
    flow_removed_notifier->reason,
    flow_removed_notifier->table_id,
    flow_removed_notifier->duration_sec,
    flow_removed_notifier->duration_nsec,
    flow_removed_notifier->idle_timeout,
    flow_removed_notifier->hard_timeout,
    flow_removed_notifier->packet_count,
    flow_removed_notifier->byte_count,
    oxm_match );
  switch_send_openflow_message( flow_removed );
  delete_oxm_matches( oxm_match );
  free_buffer( flow_removed );
  free_buffer( datapath_pkt );
}


static void
handle_datapath_error( buffer *datapath_pkt, const struct protocol *protocol ) {
  UNUSED( protocol );
  notify_parameter_error *error_notifier = 
    ( notify_parameter_error * )( ( char * ) datapath_pkt->data + sizeof( struct ofp_header ) );
  
  int datapath_type;
  int datapath_code;
  get_ofp_error( error_notifier->error_code, &datapath_type, &datapath_code );
  if ( datapath_type != ofp_error_type_unknown && datapath_code != ofp_error_type_unknown ) {
    uint16_t type = ( uint16_t ) datapath_type;
    uint16_t code = ( uint16_t ) datapath_code;

    buffer *error = create_error( 0, type, code, error_notifier->packet );
    switch_send_openflow_message( error );
    free_buffer( error );
  } else {
    error( "Failed to translate datapath error %d", error_notifier->error_code );
  }
  if ( error_notifier->packet && error_notifier->packet->length > 0 ) {
    free_buffer( error_notifier->packet );
  }
  free_buffer( datapath_pkt );
}


static void
handle_datapath_opf_packet( buffer *packet, struct protocol *protocol ) {
  struct ofp_header *header = packet->data;

  switch( header->type ) {
    case OFPT_PACKET_IN:
      handle_datapath_packet_in( packet, protocol );
      break;
    case OFPT_PORT_STATUS:
      handle_datapath_port_status( packet, protocol );
      break;
    case OFPT_FLOW_REMOVED:
      handle_datapath_flow_removed( packet, protocol );
      break;
    case OFPT_ERROR:
      handle_datapath_error( packet, protocol );
      break;
    default:
      warn( "Unhandled datapath packet %d", header->type );
      break;
  }
}


static void
handle_controller_connected( void *user_data ) {
  set_hello_handler( handle_hello, user_data );
  set_features_request_handler( handle_features_request, user_data );
  set_set_config_handler( handle_set_config, user_data );
  set_echo_request_handler( handle_echo_request, user_data );
  set_flow_mod_handler( handle_flow_mod, user_data );
  set_packet_out_handler( handle_packet_out, user_data );
  set_port_mod_handler( handle_port_mod, user_data );
  set_table_mod_handler( handle_table_mod, user_data );
  set_multipart_request_handler( handle_multipart_request, user_data );
}


static void 
handle_datapath_ctrl_packet( buffer *packet, struct protocol *protocol ) {
  free_buffer( packet );
  /*
   * At the moment don't care what the status is from datapath
   * just that the initialization is completed and should be only one.
   */
   
  int ret;

  const struct switch_arguments *args = protocol->args;
  ret = init_openflow_switch_interface( args->datapath_id, args->server_ip, args->server_port );
  if ( ret == false ) {
    finish_async( &protocol->thread );
  }
  set_controller_connected_handler( handle_controller_connected, protocol );
}


void
handle_datapath_packet( buffer *packet, struct protocol *protocol ) {
  if ( packet->length > sizeof( struct ofp_header ) ) {
    // if not connected to controller discard packet_in
    if ( protocol->controller_connected == true ) {
      handle_datapath_opf_packet(packet, protocol);
    }
  } else {
    handle_datapath_ctrl_packet( packet, protocol );
  }
}


void
retrieve_packet_from_datapath( int fd, void *user_data ) {
  assert( fd >= 0 );
  assert( user_data != NULL );
  struct protocol *protocol = user_data;

  uint64_t count = 0;

  ssize_t ret = read( fd, &count, sizeof( uint64_t ) );
  if ( ret < 0 ) {
    if ( ret != EAGAIN || errno == EINTR ) {
      return;
    }
    char buf[ 256 ];
    memset( buf, '\0', sizeof( buf ) );
    char *error_string = strerror_r( errno, buf, sizeof( buf ) - 1 );    
    error( "Failed to retrieve packet from datapath errno %s [%d]", error_string, errno );
    count = 0;
  }
  for ( uint64_t i = 0; i < count; i++ ) {
    buffer *packet = dequeue_message( protocol->input_queue );
    assert( packet != NULL );
    handle_datapath_packet( packet, protocol );
  }
}


static int
serve_protocol( void *data ) {
  struct protocol *protocol = data;

  add_thread();
  new_init_timer();
  new_init_event_handler();
  init_actions();

  const struct switch_arguments *args = protocol->args;
  protocol->own_efd = args->efd[ 0 ];
  protocol->input_queue = args->to_protocol_queue;

  new_set_fd_handler( protocol->own_efd, retrieve_packet_from_datapath, protocol, NULL, NULL );
  new_set_readable( protocol->own_efd, true );

  return new_start_event_handler();
}


pthread_t
start_async_protocol( struct switch_arguments *args ) {
  struct protocol *protocol;
  int ret;

  protocol = ( struct protocol * )xmalloc( sizeof( *protocol ) );  
  protocol->thread.proc = serve_protocol;
  protocol->args = args;
  protocol->thread.data = protocol;
  protocol->controller_connected = false;
  ret = start_async( &protocol->thread );
  if ( ret < 0 ) {
    error( "Failed to start the protocol thread" );
    return EXIT_FAILURE;
  }
  return ( protocol->thread.tid );  
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
