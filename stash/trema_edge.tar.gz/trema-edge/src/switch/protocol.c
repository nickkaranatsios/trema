#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include "wrapper.h"
#include "checks.h"
#include "openflow_switch_interface.h"
#include "log.h"
#include "bool.h"

#include "async.h"
#include "parse-options.h"
#include "protocol.h"

static void
handle_hello( uint32_t transaction_id, uint8_t version, void *user_data ) {
  UNUSED( user_data );
  info( "handle hello received %u %u", transaction_id, version );
}

static void
handle_controller_connected( void *user_data ) {
  set_hello_handler( handle_hello, user_data );
}


static int
serve_protocol( void *data ) {
  struct protocol *protocol = data;
  int ret;

  ret = init_openflow_switch_interface( protocol->args->datapath_id, protocol->args->server_ip, protocol->args->server_port );
  if ( ret == false ) {
    finish_async( &protocol->thread );
  }
  set_controller_connected_handler( handle_controller_connected, protocol );
  return ( 0 );
}


int
start_async_protocol( struct switch_arguments *args ) {
  struct protocol *protocol;
  int ret;

  protocol = ( struct protocol * )xmalloc( sizeof( *protocol ) );  
  protocol->thread.proc = serve_protocol;
  protocol->args = args;
  protocol->thread.data = protocol;
  ret = start_async( &protocol->thread );
  if ( ret < 0 ) {
    error( "Failed to start the protocol thread" );
  }
  return ( ret );  
}
