/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <assert.h>
#include <errno.h>
#include <inttypes.h>

#include "wrapper.h"
#include "checks.h"
#include "openflow_switch_interface.h"
#include "log.h"
#include "bool.h"
#include "thread-test.h"
#include "timer-test.h"
#include "async-lock.h"
#include "async-util.h"

#include "async.h"
#include "parse-options.h"
#include "protocol.h"
#include "protocol-handler.h"
#include "ofdp/lib/controller_manager.h"

static void
construct_oxm_match( oxm_matches *oxm_match, match *match ) {
  if ( match->in_port.valid == true ) {
    append_oxm_match_in_port( oxm_match, match->in_port.value );
  }
  if ( match->in_phy_port.valid == true ) {
    append_oxm_match_in_phy_port( oxm_match, match->in_phy_port.value );
  }
  if ( match->eth_type.valid == true ) {
    append_oxm_match_eth_type( oxm_match, match->eth_type.value );
  }
  if ( match->ip_proto.valid == true ) {
    append_oxm_match_ip_proto( oxm_match, match->ip_proto.value );
  }
  append_oxm_match_vlan_vid( oxm_match, match->vlan_vid.value, match->vlan_vid.mask );
  if ( match->vlan_pcp.valid == true ) {
    append_oxm_match_vlan_pcp( oxm_match, match->vlan_pcp.value );
  }
  if ( match->icmpv4_type.valid == true ) {
    append_oxm_match_icmpv4_type( oxm_match, match->icmpv4_type.value );
  }
  if ( match->icmpv6_type.valid == true ) {
    append_oxm_match_icmpv6_type( oxm_match, match->icmpv6_type.value );
  }
  if ( match->arp_op.valid == true ) {
    append_oxm_match_arp_op( oxm_match, match->arp_op.value );
  }
  append_oxm_match_arp_sha( oxm_match, &match->arp_sha[ 0 ].value, &match->arp_sha[ 0 ].mask );
  append_oxm_match_arp_spa( oxm_match, match->arp_spa.value, match->arp_spa.mask );
  append_oxm_match_arp_tha( oxm_match, &match->arp_tha[ 0 ].value, &match->arp_tha[ 0 ].mask );
  append_oxm_match_arp_tpa( oxm_match, match->arp_tpa.value, match->arp_tpa.mask );
  append_oxm_match_eth_dst( oxm_match, &match->eth_dst[ 0 ].value, &match->eth_dst[ 0 ].mask );
  append_oxm_match_eth_src( oxm_match, &match->eth_src[ 0 ].value, &match->eth_dst[ 0 ].mask );
  if ( match->icmpv4_code.valid == true ) {
    append_oxm_match_icmpv4_code( oxm_match, match->icmpv4_code.value );
  }
  if ( match->icmpv6_code.valid == true ) {
    append_oxm_match_icmpv6_code( oxm_match, match->icmpv6_type.value );
  }
  if ( match->ip_dscp.valid == true ) {
    append_oxm_match_ip_dscp( oxm_match, match->ip_dscp.value );
  }
  if ( match->ip_ecn.valid == true ) {
    append_oxm_match_ip_ecn( oxm_match, match->ip_ecn.value ) ;
  }
  append_oxm_match_ipv4_dst( oxm_match, match->ipv4_dst.value, match->ipv4_dst.mask );
  append_oxm_match_ipv4_src( oxm_match, match->ipv4_src.value, match->ipv4_src.mask );
  struct in6_addr ipv6_addr, ipv6_mask;
  memcpy( &ipv6_addr.s6_addr, &match->ipv6_src[ 0 ].value, IPV6_ADDRLEN );
  memcpy( &ipv6_mask.s6_addr, &match->ipv6_src[ 0 ].mask , IPV6_ADDRLEN );
  append_oxm_match_ipv6_src( oxm_match, ipv6_addr, ipv6_mask );

  memcpy( &ipv6_addr.s6_addr, &match->ipv6_dst[ 0 ].value, IPV6_ADDRLEN );
  memcpy( &ipv6_mask.s6_addr, &match->ipv6_dst[ 0 ].mask, IPV6_ADDRLEN );
  append_oxm_match_ipv6_dst( oxm_match, ipv6_addr, ipv6_mask );
  append_oxm_match_ipv6_dst( oxm_match, ipv6_addr, ipv6_mask );
  append_oxm_match_ipv6_exthdr( oxm_match, match->ipv6_exthdr.value, match->ipv6_exthdr.mask );
  append_oxm_match_ipv6_flabel( oxm_match, match->ipv6_flabel.value, match->ipv6_flabel.mask );
  if ( match->ipv6_nd_sll[ 0 ].valid == true ) {
    append_oxm_match_ipv6_nd_sll( oxm_match, &match->ipv6_nd_sll[ 0 ].value );
  }
  if ( match->ipv6_nd_target[ 0 ].valid == true ) {
     memcpy( &ipv6_addr.s6_addr, &match->ipv6_nd_target[ 0 ].value, IPV6_ADDRLEN );
    append_oxm_match_ipv6_nd_target( oxm_match, ipv6_addr );
  }
  if ( match->ipv6_nd_tll[ 0 ].valid == true ) {
    append_oxm_match_ipv6_nd_tll( oxm_match, &match->ipv6_nd_tll[ 0 ].value );
  }
  append_oxm_match_metadata( oxm_match, match->metadata.value, match->metadata.mask );
  if ( match->mpls_bos.valid == true ) {
    append_oxm_match_mpls_bos( oxm_match, match->mpls_bos.value );
  }
  if ( match->mpls_label.valid == true ) {
    append_oxm_match_mpls_label( oxm_match, match->mpls_label.value );
  }
  if ( match->mpls_tc.valid == true ) {
    append_oxm_match_mpls_tc( oxm_match, match->mpls_tc.value );
  }
  if ( match->sctp_dst.valid == true ) {
    append_oxm_match_sctp_dst( oxm_match, match->sctp_dst.value );
  }
  if ( match->sctp_src.valid == true ) {
    append_oxm_match_sctp_src( oxm_match, match->sctp_src.value );
  }
  if ( match->tcp_dst.valid == true ) {
    append_oxm_match_tcp_dst( oxm_match, match->tcp_dst.value );
  }
  if ( match->tcp_src.valid == true ) {
    append_oxm_match_tcp_src( oxm_match, match->tcp_src.value );
  }
  append_oxm_match_tunnel_id( oxm_match, match->tunnel_id.value, match->tunnel_id.mask );
  if ( match->udp_dst.valid == true ) {
    append_oxm_match_udp_dst( oxm_match, match->udp_dst.value );
  }
  if ( match->udp_src.valid == true ) {
    append_oxm_match_udp_src( oxm_match, match->udp_src.value );
  }
}


void
handle_datapath_packet_in( buffer *datapath_pkt, const struct protocol *protocol ) {
  UNUSED( protocol );
  notify_parameter_packet_in *packet_in_notifier = 
    ( notify_parameter_packet_in *) ( ( char *)datapath_pkt->data + sizeof( struct ofp_header ) );
  oxm_matches *oxm_match = create_oxm_matches();
  if ( packet_in_notifier->reason != OFPR_NO_MATCH ) {
    construct_oxm_match( oxm_match, &packet_in_notifier->match );
  }
  buffer *packet_in = create_packet_in( 0,
    packet_in_notifier->buffer_id,
    packet_in_notifier->max_len,
    packet_in_notifier->reason,
    ( uint8_t ) packet_in_notifier->table_id,
    packet_in_notifier->cookie,
    oxm_match,
    packet_in_notifier->packet );
  delete_oxm_matches( oxm_match );
  switch_send_openflow_message( packet_in );
  free_buffer( packet_in );
  if ( packet_in_notifier->packet && packet_in_notifier->packet->length > 0 ){
    free_buffer( packet_in_notifier->packet );
  }
  free_buffer( datapath_pkt );
}


static void
handle_datapath_opf_packet( buffer *packet, struct protocol *protocol ) {
  struct ofp_header *header = packet->data;

  switch( header->type ) {
    case OFPT_PACKET_IN:
      handle_datapath_packet_in( packet, protocol );
      break;
    default:
      warn( "Unhandled datapath packet %d", header->type );
      break;
  }
}


static void
handle_controller_connected( void *user_data ) {
  struct protocol *protocol = user_data;
  
  protocol->controller_connected = true;
  set_hello_handler( handle_hello, user_data );
  set_features_request_handler( handle_features_request, user_data );
  set_set_config_handler( handle_set_config, user_data );
  set_echo_request_handler( handle_echo_request, user_data );
  set_flow_mod_handler( handle_flow_mod, user_data );
}


static void 
handle_datapath_ctrl_packet( buffer *packet, struct protocol *protocol ) {
  UNUSED( packet );
  /*
   * At the moment don't care what the status is from datapath
   * just that the initialization is completed and should be only one.
   */
   
  int ret;

  const struct switch_arguments *args = protocol->args;
  ret = init_openflow_switch_interface( args->datapath_id, args->server_ip, args->server_port );
  if ( ret == false ) {
    finish_async( &protocol->thread );
  }
  set_controller_connected_handler( handle_controller_connected, protocol );
}


void
handle_datapath_packet( buffer *packet, struct protocol *protocol ) {
  if ( packet->length > sizeof( struct ofp_header ) ) {
    // if not connected to controller discard packet_in
    if ( protocol->controller_connected == true ) {
      handle_datapath_opf_packet(packet, protocol);
    }
  } else {
    handle_datapath_ctrl_packet( packet, protocol );
  }
}


void
retrieve_packet_from_datapath( int fd, void *user_data ) {
  assert( fd >= 0 );
  assert( user_data != NULL );
  struct protocol *protocol = user_data;

  uint64_t count = 0;

  ssize_t ret = read( fd, &count, sizeof( uint64_t ) );
  if ( ret < 0 ) {
    if ( ret != EAGAIN || errno == EINTR ) {
      return;
    }
    char buf[ 256 ];
    memset( buf, '\0', sizeof( buf ) );
    char *error_string = strerror_r( errno, buf, sizeof( buf ) - 1 );    
    error( "Failed to retrieve packet from datapath errno %s [%d]", error_string, errno );
    count = 0;
  }
  for ( uint64_t i = 0; i < count; i++ ) {
    buffer *packet = dequeue_message( protocol->input_queue );
    assert( packet != NULL );
    handle_datapath_packet( packet, protocol );
  }
}


static int
serve_protocol( void *data ) {
  struct protocol *protocol = data;

  add_thread();
  new_init_timer();
  new_init_event_handler();

  const struct switch_arguments *args = protocol->args;
  protocol->own_efd = args->efd[ 0 ];
  protocol->input_queue = args->to_protocol_queue;

  new_set_fd_handler( protocol->own_efd, retrieve_packet_from_datapath, protocol, NULL, NULL );
  new_set_readable( protocol->own_efd, true );

  return new_start_event_handler();
}


pthread_t
start_async_protocol( struct switch_arguments *args ) {
  struct protocol *protocol;
  int ret;

  protocol = ( struct protocol * )xmalloc( sizeof( *protocol ) );  
  protocol->thread.proc = serve_protocol;
  protocol->args = args;
  protocol->thread.data = protocol;
  protocol->controller_connected = false;
  ret = start_async( &protocol->thread );
  if ( ret < 0 ) {
    error( "Failed to start the protocol thread" );
    return EXIT_FAILURE;
  }
  return ( protocol->thread.tid );  
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
