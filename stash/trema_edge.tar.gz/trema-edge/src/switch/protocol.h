#ifndef PROTOCOL_H
#define PROTOCOL_H


struct protocol {
  struct async thread;
  const struct switch_arguments *args;
  void *data;
};

int start_async_protocol( struct switch_arguments *args );

#endif
