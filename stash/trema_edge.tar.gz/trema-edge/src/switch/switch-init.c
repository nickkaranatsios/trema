#ifdef TEST
#include "parse-options.h"

static const struct option long_options[] = {
  SWITCH_COMMON_OPTIONS
};


static struct switch_arguments args = {
  .progname = "switch",
  .help = "\
--server=host\n\
--server_port=port\n\
--datapath_ports=[<interface,number>:<interface,number>]",
  .options = switch_long_options,
  .handler = parse_switch_options,
  .verifer = NULL,
};
#endif
