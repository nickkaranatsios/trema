/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include <inttypes.h>
#include <string.h>
#include <assert.h>
#include <pthread.h>
#include <errno.h>
#include "log.h"
#include "async-util.h"
#include "parse-options.h"
#ifdef TEST

static const struct option long_options[] = {
  SWITCH_COMMON_OPTIONS
};


static struct switch_arguments args = {
  .progname = "switch",
  .help = "\
--server=host\n\
--server_port=port\n\
--datapath_ports=[<interface,number>:<interface,number>]",
  .options = switch_long_options,
  .handler = parse_switch_options,
  .verifer = NULL,
};
#endif


int
init_args( struct switch_arguments *args ) {
  int efd[ 2 ];
  uint32_t i;

  for ( i = 0; i < sizeof( efd ) / sizeof( efd[ 0 ] ); i++ ) {
    efd[ i ] = create_event_fd();
    if ( efd[ i ] == -1 ) {
      error( "failed to create_event_fd %d", errno );
      return efd[ i ];
    }
  }
  memcpy( args->efd, efd, sizeof( efd ) );
  args->to_datapath_queue = create_message_queue();
  assert( args->to_datapath_queue != NULL );
  args->to_protocol_queue = create_message_queue();
  assert( args->to_protocol_queue != NULL );

  return 0;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
