/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <inttypes.h>
#include <string.h>
#include <assert.h>
#include <pthread.h>
#include <errno.h>
#include <signal.h>
#include "daemon.h"
#include "wrapper.h"
#include "log.h"
#include "async-util.h"
#include "parse-options.h"


static const char *
get_switch_home( void ) {
  return getenv( "SWITCH_HOME" );
}


char *
get_switch_tmp( void ) {
  const char *tmp = get_switch_home();
  char path[ PATH_MAX ];

  if ( tmp == NULL ) {
    tmp = "/tmp";
  }
  snprintf( path, PATH_MAX, "%s/tmp", tmp );
  return xstrdup( path );
}


static char *
get_switch_log( void ) {
  char path[ PATH_MAX ];

  sprintf( path, "%s/log", get_switch_tmp() );
  return xstrdup( path );
}


static void
ignore_sigpipe( void ) {
  struct sigaction sigpipe_ignore;

  memset( &sigpipe_ignore, 0, sizeof( struct sigaction ) );
  sigpipe_ignore.sa_handler = SIG_IGN;
  sigaction( SIGPIPE, &sigpipe_ignore, NULL );
}


struct switch_arguments *
init_parse_args( int argc, char **argv ) {
  struct switch_arguments *args = xmalloc( sizeof( struct switch_arguments ) );

  parse_options( args, argc, argv );
  int efd[ 2 ];
  uint32_t i;

  for ( i = 0; i < sizeof( efd ) / sizeof( efd[ 0 ] ); i++ ) {
    efd[ i ] = create_event_fd();
    if ( efd[ i ] == -1 ) {
      error( "failed to create_event_fd %d", errno );
      xfree( args );
      return NULL;
    }
  }
  memcpy( args->efd, &efd, sizeof( efd ) );
  args->to_protocol_queue = create_message_queue();
  assert( args->to_protocol_queue != NULL );
  init_log( args->progname, get_switch_log(), args->run_as_daemon );
  ignore_sigpipe();
#ifdef NOT_TESTED
  if ( args->run_as_daemon == true ) {
    daemonize( get_switch_home() );
  }
#endif

  return args;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
