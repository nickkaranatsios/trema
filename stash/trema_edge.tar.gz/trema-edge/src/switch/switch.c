#include <stdio.h>
#include "trema.h"
#include "ofdp.h"
#include "checks.h"


static void
init_switch( int argc, char **argv ) {

}


int
main( int argc, char **argv ) {
  init_trema( &argc, &argv );
  init_switch( &argc, &argv );
  start_trema();

  return 0;
}
