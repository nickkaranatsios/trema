/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <unistd.h>
#include <pthread.h>
#include "ofdp.h"
#include "checks.h"
#include "wrapper.h"
#include "messenger.h"
#include "openflow_switch_interface.h"
#include "message_queue.h"
#include "log.h"
#include "parse-options.h"
#include "async.h"
#include "protocol.h"
#include "datapath.h"
#include "switch.h"
#include "switch-init.h"


static struct switch_arguments args = {
  .progname = "switch",
  .help = "",
  .log_level = "info",
  .datapath_ports = "lo:1",
//  .options = switch_long_options,
  .datapath_id = 1,
  .server_ip = 0x7f000001,
  .server_port = 6633,
  .run_as_daemon = false,
//.handler = parse_switch_opts
};


char *
get_switch_tmp() {
  const char *tmp = getenv( "SWITCH_HOME" );
  char path[ PATH_MAX ];

  if ( tmp == NULL ) {
    tmp = "/tmp";
  }
  snprintf( path, PATH_MAX, "%s/tmp", tmp );
  return xstrdup( path );
}

static int
init_switch( int argc, char **argv ) {
  UNUSED( argc );
  UNUSED( argv );
  init_messenger( get_switch_tmp() );
  return init_args( &args );
}


static void
run_switch( void ) {
  pthread_t threads[ 2 ];
  int i;

  threads[ 0 ] = start_async_protocol( &args );
  threads[ 1 ] = start_async_datapath( &args );
  for ( i = 0; i < 2; i++ ) {
    if ( pthread_join( threads[ i ], NULL ) ) {
      error( "Failed to join a thread %d", threads[ i ] );
      break;
    }
  }
}

static void
stop_switch( void ) {
  finalize_openflow_switch_interface();
}


int
main( int argc, char **argv ) {
  if ( !init_switch( argc, argv ) ) {
    run_switch();
    stop_switch();
  }
  return EXIT_SUCCESS;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
