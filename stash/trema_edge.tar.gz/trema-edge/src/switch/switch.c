/*
 * This is the main switch program. It acts as a wrapper between two modules.
 * A protocol and a datapath. Those two modules implemented as a two seperate
 * threads. The protocol thread would either receive message from controller
 * or the datapath thread. If a message received from the controller needs
 * to be handled by the datapath it would translate the message and call the
 * appropriate datapath function to execute it. In other cases it might simply
 * return a reply back to controller. Messages received from the datapath are
 * via a message queue.
 * The build.rb script creates the switch executable under objects/switch
 * The executable name is switch and to avoid name clashing with the previous
 * switch_manager/switch program the switch_manager/switch has been renamed to
 * switch_manager/switch_daemon.
 * The switch program can be run using the following steps:
 * 1). export SWITCH_HOME to where the top trema-edge repository resides.
 * If it is trema-edge export SWITCH_HOME=~/trema-edge
 * 2) ./objects/switch/switch.
 * The switch accepts a number of arguments but it can run from the default
 * arguments.
 * Some examples of running and specifying arguments are:
 * ./objects/switch/switch --datapath_id 10 --server_ip 10.10.10.1
 *   --server_port 6333
 * This would create and use a datapath_id of 10 attempt to connect to
 * controller with ip address 10.10.10.1 using the port 6333.
 *
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <unistd.h>
#include <pthread.h>
#include "messenger.h"
#include "openflow_switch_interface.h"
#include "message_queue.h"
#include "log.h"
#include "async.h"
#include "parse-options.h"
#include "protocol.h"
#include "datapath.h"
#include "switch.h"
#include "switch-init.h"


static struct switch_arguments *
init_switch( int argc, char **argv ) {
  init_messenger( get_switch_tmp() );
  return init_parse_args( argc, argv );
}


static void
run_switch( struct switch_arguments *args ) {
  pthread_t threads[ 2 ];
  int i;

  threads[ 0 ] = start_async_protocol( args );
  threads[ 1 ] = start_async_datapath( args );
  for ( i = 0; i < 2; i++ ) {
    if ( pthread_join( threads[ i ], NULL ) ) {
      error( "Failed to join a thread %d", threads[ i ] );
      break;
    }
  }
}

static void
stop_switch( struct switch_arguments *args ) {
  finalize_openflow_switch_interface();
  if ( args->to_protocol_queue != NULL ) {
    delete_message_queue( args->to_protocol_queue );
  }
}


int
main( int argc, char **argv ) {
  struct switch_arguments *args;

  if ( ( args = init_switch( argc, argv ) ) != NULL ) {
    run_switch( args );
    stop_switch( args );
  }
  return EXIT_SUCCESS;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
