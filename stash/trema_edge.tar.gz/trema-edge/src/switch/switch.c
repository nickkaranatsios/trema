/*
 * Copyright (C) 2008-2012 NEC Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <unistd.h>
#include <pthread.h>
#include "messenger.h"
#include "openflow_switch_interface.h"
#include "message_queue.h"
#include "log.h"
#include "async.h"
#include "parse-options.h"
#include "protocol.h"
#include "datapath.h"
#include "switch.h"
#include "switch-init.h"


static struct switch_arguments *
init_switch( int argc, char **argv ) {
  init_messenger( get_switch_tmp() );
  return init_parse_args( argc, argv );
}


static void
run_switch( struct switch_arguments *args ) {
  pthread_t threads[ 2 ];
  int i;

  threads[ 0 ] = start_async_protocol( args );
  threads[ 1 ] = start_async_datapath( args );
  for ( i = 0; i < 2; i++ ) {
    if ( pthread_join( threads[ i ], NULL ) ) {
      error( "Failed to join a thread %d", threads[ i ] );
      break;
    }
  }
}

static void
stop_switch( struct switch_arguments *args ) {
  finalize_openflow_switch_interface();
  if ( args->to_protocol_queue != NULL ) {
    delete_message_queue( args->to_protocol_queue );
  }
}


int
main( int argc, char **argv ) {
  struct switch_arguments *args;

  if ( ( args = init_switch( argc, argv ) ) != NULL ) {
    run_switch( args );
    stop_switch( args );
  }
  return EXIT_SUCCESS;
}


/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
