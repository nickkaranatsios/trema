#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <unistd.h>
#include "ofdp.h"
#include "checks.h"
#include "wrapper.h"
#include "messenger.h"
#include "timer.h"
#include "openflow_switch_interface.h"
#include "parse-options.h"
#include "async.h"
#include "protocol.h"
#include "switch.h"


static struct switch_arguments args = {
  .progname = "switch",
  .help = "",
  .log_level = "info",
  .datapath_ports = "eth0:1";
//  .options = switch_long_options,
  .datapath_id = 1,
  .server_ip = 0x7f000001,
  .server_port = 6633,
  .run_as_daemon = false,
//.handler = parse_switch_opts
};


void
run_datapath() {
//  init_datapath();
}



char *
get_switch_tmp() {
  const char *tmp = getenv( "SWITCH_HOME" );
  char path[ PATH_MAX ];

  if ( tmp == NULL ) {
    tmp = "/tmp";
  }
  snprintf( path, PATH_MAX, "%s/tmp", tmp );
  return xstrdup( path );
}

static void
init_switch( int argc, char **argv ) {
  UNUSED( argc );
  UNUSED( argv );
  init_messenger( get_switch_tmp() );
  init_timer();
  start_async_protocol( &args );
//  parse_options( argc, argv );
  run_datapath();
}


int
main( int argc, char **argv ) {
  init_switch( argc, argv );
  SLEEP_FOREVER();
  
  finalize_openflow_switch_interface();
//  start_trema();

  return EXIT_SUCCESS;
}
