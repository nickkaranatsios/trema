#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <unistd.h>
#include "ofdp.h"
#include "checks.h"
#include "wrapper.h"
#include "messenger.h"
#include "timer.h"
#include "event_handler.h"
#include "openflow_switch_interface.h"
#include "parse-options.h"
#include "async.h"
#include "protocol.h"
#include "datapath.h"
#include "switch.h"


static struct switch_arguments args = {
  .progname = "switch",
  .help = "",
  .log_level = "info",
  .datapath_ports = "lo:1",
//  .options = switch_long_options,
  .datapath_id = 1,
  .server_ip = 0x7f000001,
  .server_port = 6633,
  .run_as_daemon = false,
//.handler = parse_switch_opts
};


char *
get_switch_tmp() {
  const char *tmp = getenv( "SWITCH_HOME" );
  char path[ PATH_MAX ];

  if ( tmp == NULL ) {
    tmp = "/tmp";
  }
  snprintf( path, PATH_MAX, "%s/tmp", tmp );
  return xstrdup( path );
}

static void
init_switch( int argc, char **argv ) {
  UNUSED( argc );
  UNUSED( argv );
  init_timer();
  init_messenger( get_switch_tmp() );
  start_async_protocol( &args );
  start_async_datapath( &args );
}


static void
run_switch() {
  start_event_handler();
}

static void
stop_switch() {
  finalize_openflow_switch_interface();
}


int
main( int argc, char **argv ) {
  init_switch( argc, argv );
  run_switch();
  stop_switch();
  return EXIT_SUCCESS;
}
