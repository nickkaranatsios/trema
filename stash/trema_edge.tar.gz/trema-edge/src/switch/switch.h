#ifndef SWITCH_H
#define SWITCH_H


#define SLEEP_FOREVER() \
  do { \
    sleep( 1 ); \
  } while( 1 ) 
  

#endif
