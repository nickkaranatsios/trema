/*
 * cli define header .
 *
 * Author: Isamu Ohkuchi
 */

#ifndef _CLI_DEFILE_H
#define _CLI_DEFILE_H

/************************************************************************
 * ENUM
 ************************************************************************/
typedef enum cli_mode {
  CLI_NONE,
  CLI_ADMINMODE,
  CLI_CONFIGMODE,
  CLI_VHOSTMODE,
  CLI_MODEMAX
} ECLI_MODE;

typedef enum cli_result {
  CLI_OK,
  CLI_NEXTCHAIN,
  CLI_NG,
  CLI_NOHIT,
  CLI_HIT,
  CLI_SLICE_HIT,
  CLI_CONTINUE,
  CLI_NG_EXIT_ERRORLOG,
} ECLI_RESULT;

typedef enum cli_bool {
  CLI_FALSE,
  CLI_TRUE
} ECLI_BOOL;

typedef enum cli_alarm_kind {
  CLI_FIRST,
  CLI_SECOND,
} ECLI_ALARM_KIND;

typedef enum cli_command_kind {
  CLI_GLOBAL_COMMAND,
  CLI_MODE_COMMAND
} ECLI_COMMAND_KIND;

typedef enum cli_check_digit_kind {
  CLI_CHECK_STRING = 0x01,
  CLI_CHECK_ASCII  = 0x02,
  CLI_CHECK_LNUM   = 0x04,
  CLI_CHECK_XDIGIT = 0x08,
  CLI_CHECK_DIGIT  = 0x10
} ECLI_CHECK_DIGITKIND;

typedef enum cli_enable {
  CLI_ENABLE = 1,
  CLI_DISABLE
} ECLI_ENABLE;

typedef enum cli_vhost_status {
  CLI_VHOST_UP,
  CLI_VHOST_DOWN,
  CLI_VHOST_UNKNOWN
} ECLI_VHOST_STATUS;


typedef enum cli_send_option_kind {
  CLI_SEND_OPTION_KIND_L2MACSRC,
  CLI_SEND_OPTION_KIND_L2MACDST,
  CLI_SEND_OPTION_KIND_ARPMACSRC,
  CLI_SEND_OPTION_KIND_ARPMACDST,
  CLI_SEND_OPTION_KIND_IPSRC,
  CLI_SEND_OPTION_KIND_IPDST,
  CLI_SEND_OPTION_KIND_PORTSRC,
  CLI_SEND_OPTION_KIND_PORTDST,
  CLI_SEND_OPTION_KIND_PAYLOAD
} ECLI_SEND_OPTION_KIND;


typedef enum cli_send_status {
  CLI_SEND_STATUS_NODOING = 0x01,
  CLI_SEND_STATUS_DOING
} ECLI_SEND_STATUS;

typedef enum cli_static_arp_action_kind {
  CLI_STATIC_ARP_SET = 0x00,
  CLI_STATIC_ARP_DEL = 0x01
} ECLI_STATIC_ARP_KIND;

typedef enum cli_exec_kind {
  CLI_EXEC_ENTER,
  CLI_EXEC_TAB
} ECLI_EXEC_KIND;


/************************************************************************
 * DEFINE
 ************************************************************************/
#define CLI_TIMEOUT_FIRST                       15
#define CLI_TIMEOUT_SECOND                      1
#define CLI_ARPCACHE_DEFAULT                    30
#define CLI_HISTORY_FILE                        "vhost_cli_history"
#define CLI_HISTORY_MAX                         100
#define CLI_VLAN_MAX                            4096
#define CLI_PACKET_LENGTH_MINIMUM               64
#define CLI_PACKET_OPTION_MAX                   40
#define CLI_SAVEFILE_SIZE                       256
#define CLI_SAVEFILE_NAME                       "default.conf"
#define CLI_SAVEFILE_TIME                       "Time"

#if __BYTE_ORDER == __LITTLE_ENDIAN
#define CLI_VLAN_MASK                           0x0FFF
#define CLI_CFI_MASK                            0x1000
#define CLI_COS_MASK                            0xE000
#define CLI_COS_SHIFT                           0x0D
#define CLI_VLAN_SHIFT                          0x00
#else
#define CLI_VLAN_MASK                           0xFFF0
#define CLI_CFI_MASK                            0x0008
#define CLI_COS_MASK                            0x0007
#define CLI_COS_SHIFT                           0x00
#define CLI_VLAN_SHIFT                          0x03
#endif

#define CLI_PROMPT_ADMIN                        "# "
#define CLI_PROMPT_CONFIG                       "(config)# "
#define CLI_PROMPT_VHOST                        "(config-%s)# "

#define CLI_REGEX_MAC                           "^([0-9a-fA-F]{2}[:]){5}([0-9a-fA-F]{2})$"
#define CLI_REGEX_IP                            "^([0-9]{1,3}[.])([0-9]{1,3}[.])([0-9]{1,3}[.])([0-9]{1,3})$"
#define CLI_EXIT_COMMAND                        "!"

#define CLI_ERROR_SYNTAX                        "Syntax error ( %s ).\n"
#define CLI_ERROR_SYSCALL                       "%s\n"
#define CLI_ERROR_LOGIC                         "Logic error.\n"
#define CLI_ERROR_HOSTNAME                      "Hostname is length over.\n"
#define CLI_ERROR_LENGTHERROR                   "Length error( %s ).\n"
#define CLI_ERROR_CONFIG_SET_NG                 "Config set error.\n"
#define CLI_ERROR_CONFIG_DELETE_NG              "Config delete error.\n"
#define CLI_ERROR_NOTFIND_CONTROLLER            "Controller is not find( %s )."
#define CLI_ERROR_CLEAR_NG                      "Clear error.\n"
#define CLI_ERROR_SEND_NOHOST                   "Destination Host Unreachable ( %s ).\n"
#define CLI_ERROR_SEND_ERR_VHOST                "Vhost is not received.\n"
#define CLI_ERROR_VHOSTRUNNING                  "Vhost is running ( %s ).\n"
#define CLI_ERROR_VHOSTNOTRUNNING               "Vhost is not running ( %s ).\n"
#define CLI_ERROR_VHOSTNOTSTART                 "Vhost daemon is not starting.\n"
#define CLI_ERROR_SHORTAGE_PARAMS               "Configuration parameter not set ( %s ).\n"
#define CLI_ERROR_UNKNOWN_COMMAND               "Command syntax error. ( %s ).\n"
#define CLI_ERROR_SET_STATIC_ARP                "Don't set static arp ( vhost:%s ).\n"
#define CLI_ERROR_START_VHOST                   "Don't start vhost ( %s ).\n"
#define CLI_ERROR_VHOST_ERR                     "The abnormalities in a state of VHOST.\n"
#define CLI_ERROR_CONFIGNOTEXIST                "VHOST does not exist. ( %s )\n"
#define CLI_ERROR_CONFIGNOCONTROLLERTEXIST      "Controller does not exist.\n"
#define CLI_ERROR_CANCELKEY_NOT_ENABLE          "<cancel key> is not enable\n"
#define CLI_ERROR_CONFIGNOTRUNNING              "Config is not running.\n"
#define CLI_ERROR_DEVICE_OPENERROR              "Device access error.\n"
#define CLI_ERROR_DUPLICATE_NG                  "IP Address duplicate NG. ( %s )\n"
#define CLI_ERRROR_RANGE                        "Outside of the range.\n"

#define CLI_MESSAGE_COMPLETE                    "Complete.\n"
#define CLI_MESSAGE_COMPLETE_CANCEL             "Complete. <cancel key> is %d\n"

/************************************************************************
 * Command word
 ************************************************************************/
#define _CLI_WORD_VHOSTNAME                     "<vhost name>"
#define CLI_WORD_CR                             "<cr>"
#define CLI_WORD_SEND                           "send"
#define CLI_WORD_CANCEL                         "cancel"
#define CLI_WORD_CONFIG                         "config"
#define CLI_WORD_EXIT                           "exit"
#define CLI_WORD_SHOW                           "show"
#define CLI_WORD_START                          "start"
#define CLI_WORD_STOP                           "stop"
#define CLI_WORD_VHOST                          "vhost"
#define CLI_WORD_BACKGROUND                     "background"
#define CLI_WORD_L2TYPE                         "l2type"
#define CLI_WORD_ETHER                          "ether"
#define CLI_WORD_MACSRC                         "mac_src"
#define CLI_WORD_MACDST                         "mac_dst"
#define _CLI_WORD_MACADDRESS                    "<mac address>"
#define CLI_WORD_INCREMENT                      "increment"
#define _CLI_WORD_COUNT                         "<count>"
#define CLI_WORD_DECREMENT                      "decrement"
#define CLI_WORD_RANDOM                         "random"
#define _CLI_WORD_MASK                          "<mask>"
#define CLI_WORD_ETHERTYPE                      "ethertype"
#define _CLI_WORD_ETHERTYPE                     "<ether type>"
#define CLI_WORD_VLAN                           "vlan"
#define CLI_WORD_COS                            "cos"
#define _CLI_WORD_COS                           "<cos>"
#define CLI_WORD_VLANID                         "vlanid"
#define _CLI_WORD_VLANID                        "<vlan id>"
#define CLI_WORD_L3TYPE                         "l3type"
#define CLI_WORD_ARP                            "arp"
#define CLI_WORD_HARDTYPE                       "hard_type"
#define _CLI_WORD_HEADWARETYPE                  "<hardware type>"
#define CLI_WORD_PROTOCOLTYPE                   "protocol_type"
#define _CLI_WORD_PROTOCOLTYPE                  "<protocol type>"
#define CLI_WORD_OPERATIONCODE                  "operation_code"
#define _CLI_WORD_OPERATIONCODE                 "<operation code>"
#define CLI_WORD_IPSRC                          "ip_src"
#define _CLI_WORD_IPADDRESS                     "<ip address>"
#define CLI_WORD_IPDST                          "ip_dst"
#define CLI_WORD_IP                             "ip"
#define CLI_WORD_TOS                            "tos"
#define _CLI_WORD_TOS                           "<tos>"
#define CLI_WORD_ID                             "id"
#define _CLI_WORD_ID                            "<id>"
#define CLI_WORD_FLAG                           "flag"
#define _CLI_WORD_FLAG                          "<flag>"
#define CLI_WORD_FLAGOFFSET                     "flagoffset"
#define _CLI_WORD_OFFSET                        "<offset>"
#define CLI_WORD_TTL                            "ttl"
#define _CLI_WORD_TTL                           "<ttl>"
#define CLI_WORD_PROTOCOLNUM                    "protocol_num"
#define _CLI_WORD_PROTOCOLNUM                   "<protocol num>"
#define CLI_WORD_UDP                            "udp"
#define CLI_WORD_PORTSRC                        "port_src"
#define _CLI_WORD_PORT                          "<port>"
#define CLI_WORD_PORTDST                        "port_dst"
#define CLI_WORD_PAYLOAD                        "payload"
#define _CLI_WORD_DATA                          "<data>"
#define CLI_WORD_PPS                            "pps"
#define _CLI_WORD_PPS                           "<pps>"
#define CLI_WORD_DURATION                       "duration"
#define _CLI_WORD_DURATION                      "<duration>"
#define CLI_WORD_LENGTH                         "length"
#define _CLI_WORD_LENGTH                        "<length>"
#define CLI_WORD_PACKETNUM                      "packet_num"
#define _CLI_WORD_PACKETNUM                     "<num>"
#define _CLI_WORD_CANCELKEY                     "<cancel key>"
#define CLI_WORD_ALL                            "all"
#define _CLI_WORD_FILE                          "<file>"
#define __CLI_WORD_FILE                         "[file]"
#define CLI_WORD_ARP                            "arp"
#define CLI_WORD_CLEAR                          "clear"
#define CLI_WORD_STATISTICS                     "statistics"
#define CLI_WORD_IPADDR                         "ip_addr"
#define CLI_WORD_MACADDR                        "mac_addr"
#define CLI_WORD_NO                             "no"
#define CLI_WORD_CONTROLLER                     "controller"
#define _CLI_WORD_CONTROLLERNAME                "<controller name>"
#define CLI_WORD_MODE                           "mode"
#define CLI_WORD_RAWGENERATION                  "raw_generation_mode"
#define CLI_WORD_HOSTEMULATION                  "host_emulation_mode"
#define CLI_WORD_NETWORK                        "network"
#define CLI_WORD_PROMISC                        "promisc"
#define CLI_WORD_NOPROMISC                      "no_promisc"
#define CLI_WORD_ARPCACHE                       "arp_cache"
#define _CLI_WORD_TIME                          "<time>"
#define CLI_WORD_STATIC                         "static"
#define CLI_WORD_IPADDRESS                      "ip_address"
#define CLI_WORD_MACADDRESS                     "mac_address"
#define CLI_WORD_MASK                           "mask"
#define _CLI_WORD_SUBNETMASK                    "<subnet mask>"
#define CLI_WORD_INTERFACE                      "interface"
#define CLI_WORD_RECV                           "recv"
#define _CLI_WORD_DEVICE                        "<device>"
#define CLI_WORD_SEND                           "send"
#define CLI_WORD_OPTION                         "option"
#define _CLI_WORD_OPTION                        "<option data>"
#define CLI_WORD_COUNT_LIMIT                    "count_limit"
#define _CLI_WORD_COUNT_LIMIT                   "<count_limit>"
#define CLI_WORD_SAVE                           "save"

/************************************************************************
 * MACRO
 ************************************************************************/
#ifdef DBG
#define MCLI_LOG( arg )         ( printf( "%s:%04d  ", __FILE__, __LINE__ ), printf arg )
#define MCLI_ERROR( arg )       ( printf( "\n%s:%04d  ", __FILE__, __LINE__ ), printf arg )
#else
#define MCLI_LOG( arg )
#define MCLI_ERROR( arg )       ( printf arg )
#endif

#endif // _CLI_DEFILE_H

/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
