/*
 * cli extern header .
 *
 * Author: Isamu Ohkuchi
 */

#ifndef _CLI_EXTERN_H
#define _CLI_EXTERN_H


#include "cli_define.h"
#include "cli_struct.h"

extern char                         cli_prompt[ 128 ];
extern int                          cli_mode;
extern const char                   **cli_command_word;
extern const clictrl_cmdchain_t     *cli_chain[ CLI_MODEMAX ];
extern ECLI_SEND_STATUS             cli_send_status;
extern const clictrl_cmdchain_t     clidata_admin_chain[ 9 ];
extern const char                   *clidata_admin_word[ 256 ];
extern clictrl_cmdchain_t           clidata_config_chain[ 7 ];
extern const char                   *clidata_config_word[ 64 ];
extern clictrl_cmdchain_t           clidata_vhost_chain[ 14 ];
extern const char                   *clidata_vhost_word[ 64 ];
extern const char                   *clidata_admin_end[ 64 ];
extern int                          cli_socket_fd;
extern char                         cli_ttyname[ 64 ];
extern clictrl_cmdchain_t           clidata_base_chain[ CLI_MODEMAX ];
extern const char                   *cli_word_notcompare_word[];
extern char                         cli_vhost_name[ NAME_SIZE ];

/************************************************************************
 * Function
 ************************************************************************/
extern ECLI_RESULT cli_check_variable_parameter( const char * );
extern ECLI_RESULT cli_check_digit( ECLI_CHECK_DIGITKIND, u_char * );
extern ECLI_RESULT cli_do_admin_cancel_vhostword( void * );
extern ECLI_RESULT cli_do_command_exit();
extern ECLI_RESULT cli_do_admin_start_all();
extern ECLI_RESULT cli_do_admin_stop_all();
extern ECLI_RESULT cli_do_admin_configure();
extern ECLI_RESULT cli_do_admin_stop_vhost();
extern ECLI_RESULT cli_do_admin_start_vhost();
extern ECLI_RESULT cli_set_admin_cancel_vhost_key( void * );
extern ECLI_RESULT cli_set_admin_vhost( void * );
extern ECLI_RESULT cli_set_admin_payload( void * );
extern ECLI_RESULT cli_set_admin_increment( void * );
extern ECLI_RESULT cli_set_admin_decrement( void * );
extern ECLI_RESULT cli_set_admin_random( void * );
extern ECLI_RESULT cli_set_admin_source_port_number( void * );
extern ECLI_RESULT cli_set_admin_destination_port_number( void * );
extern ECLI_RESULT cli_set_admin_flag( void * );
extern ECLI_RESULT cli_set_admin_tos( void * );
extern ECLI_RESULT cli_set_admin_ttl( void * );
extern ECLI_RESULT cli_set_admin_id( void * );
extern ECLI_RESULT cli_set_admin_flagoffset( void * );
extern ECLI_RESULT cli_set_admin_protocolnum( void * );
extern ECLI_RESULT cli_set_admin_ipsrc( void * );
extern ECLI_RESULT cli_set_admin_ipdst( void * );
extern ECLI_RESULT cli_set_admin_mac_src( void * );
extern ECLI_RESULT cli_set_admin_mac_dst( void * );
extern ECLI_RESULT cli_set_admin_cos( void * );
extern ECLI_RESULT cli_set_admin_vlanid( void * );
extern ECLI_RESULT cli_set_admin_backgroud();
extern ECLI_RESULT cli_set_admin_send();
extern ECLI_RESULT cli_set_admin_udp();
extern ECLI_RESULT cli_set_admin_cancel( void * );
extern ECLI_RESULT cli_set_admin_start( void * );
extern ECLI_RESULT cli_set_admin_stop( void * );
extern ECLI_RESULT cli_set_admin_pps( void * );
extern ECLI_RESULT cli_set_admin_duration( void * );
extern ECLI_RESULT cli_set_admin_length( void * );
extern ECLI_RESULT cli_set_admin_packetnum( void * );
extern ECLI_RESULT cli_set_macaddress( char *, char * );
extern ECLI_RESULT cli_set_ipaddress( char *, u_int * );
extern ECLI_RESULT cli_set_admin_ethertype( void * );
extern ECLI_RESULT cli_do_config_no_vhost();
extern ECLI_RESULT cli_do_config_no_vhost_all();
extern ECLI_RESULT cli_do_config_no_controller();
extern ECLI_RESULT cli_do_config_no_controller_all();
extern ECLI_RESULT cli_do_config_vhost();
extern ECLI_RESULT cli_do_config_controller();
extern ECLI_RESULT cli_set_config_vhost( void * );
extern ECLI_RESULT cli_set_config_controller( void * );
extern ECLI_RESULT cli_set_config_controller_ip( void * );
extern ECLI_RESULT cli_do_vhost_hostemulation();
extern ECLI_RESULT cli_do_vhost_arpcache();
extern ECLI_RESULT cli_do_vhost_static_arp();
extern ECLI_RESULT cli_do_vhost_ipaddress();
extern ECLI_RESULT cli_do_vhost_subnetmask();
extern ECLI_RESULT cli_do_vhost_l2type_vlan();
extern ECLI_RESULT cli_do_vhost_ether();
extern ECLI_RESULT cli_do_vhost_interface_send();
extern ECLI_RESULT cli_do_vhost_rawgeneration();
extern ECLI_RESULT cli_set_vhost_arpcache( void * );
extern ECLI_RESULT cli_set_vhost_controller( void * );
extern ECLI_RESULT cli_do_vhost_macaddress();
extern ECLI_RESULT cli_set_vhost_macaddress( void * );
extern ECLI_RESULT cli_set_vhost_interface_recv( void * );
extern ECLI_RESULT cli_do_vhost_interface_recv();
extern ECLI_RESULT cli_set_vhost_interface_send( void * );
extern ECLI_RESULT cli_do_vhost_no_mode();
extern ECLI_RESULT cli_set_vhost_ipaddress( void * );
extern ECLI_RESULT cli_set_vhost_subnetmask( void * );
extern ECLI_RESULT cli_set_vhost_l2type_vlan( void * );
extern ECLI_RESULT cli_do_vhost_controller();
extern ECLI_RESULT cli_do_vhost_no_static_arp();
extern ECLI_RESULT cli_do_vhost_no_promisc();
extern ECLI_RESULT cli_do_vhost_no_arpcache();
extern ECLI_RESULT cli_do_vhost_no_ipaddress();
extern ECLI_RESULT cli_do_vhost_no_mask();
extern ECLI_RESULT cli_do_vhost_no_l2type();
extern ECLI_RESULT cli_do_vhost_no_interface();
extern ECLI_RESULT cli_do_vhost_no_controller();
extern ECLI_RESULT cli_do_vhost_no_macaddress();
extern ECLI_RESULT cli_do_vhost_promisc();
extern ECLI_RESULT cli_do_show_config();
extern ECLI_RESULT cli_do_show_vhost();
extern ECLI_RESULT cli_do_show_statistics_all();
extern ECLI_RESULT cli_set_statistics_vhostname( void * );
extern ECLI_RESULT cli_do_show_statistics_vhostname();
extern ECLI_RESULT cli_set_statistics_vhostname_file( void * );
extern ECLI_RESULT cli_do_show_statistics_vhostname_file();
extern ECLI_RESULT cli_do_clear_arp_all();
extern ECLI_RESULT cli_do_clear_arp_vhostname();
extern ECLI_RESULT cli_set_clear_arp_vhostname( void * );
extern ECLI_RESULT cli_set_clear_arp_ipaddress( void * );
extern ECLI_RESULT cli_set_clear_arp_macaddress( void * );
extern ECLI_RESULT cli_do_clear_arp_macaddress();
extern ECLI_RESULT cli_do_show_arp_all();
extern ECLI_RESULT cli_set_arp_vhostname( void * );
extern ECLI_RESULT cli_do_show_arp_vhostname();
extern ECLI_RESULT cli_do_clear_statistics_all();
extern ECLI_RESULT cli_set_clear_stat_vhost( void * );
extern ECLI_RESULT cli_do_clear_stat_vhost( void * );
extern ECLI_RESULT cli_do_clear_statistics_recv();
extern ECLI_RESULT cli_do_clear_statistics_send();
extern ECLI_RESULT cli_do_clear_statistics_vhost();
extern ECLI_RESULT cli_set_admin_mac_address( void * );
extern ECLI_RESULT cli_set_admin_ip_address( void * );
extern ECLI_RESULT cli_check_regexp( const char *, char * );
extern ECLI_RESULT cli_set_show_statistics_all();
extern ECLI_RESULT cli_set_show_statistics_vhost( void * );
extern ECLI_RESULT cli_set_admin_source_ip_address( void * );
extern ECLI_RESULT cli_set_admin_destination_ip_address( void * );
extern ECLI_RESULT cli_set_admin_option( void * );
extern ECLI_RESULT cli_set_admin_hardware_type( void * );
extern ECLI_RESULT cli_set_admin_protocol_type( void * );
extern ECLI_RESULT cli_set_admin_operation_code( void * );
extern ECLI_RESULT cli_set_admin_arp_source_mac_address( void * );
extern ECLI_RESULT cli_set_admin_arp_destination_mac_address( void * );
extern ECLI_RESULT cli_set_admin_l3type_ip();
extern ECLI_RESULT cli_set_admin_l3type_arp();
extern ECLI_RESULT cli_set_admin_source_mac_address( void * );
extern ECLI_RESULT cli_set_admin_destination_mac_address( void * );
extern ECLI_RESULT cli_set_admin_ether_type( void * );
extern ECLI_RESULT cli_set_admin_countlimit( void * );
extern ECLI_RESULT cli_do_show_vhost_config();
extern ECLI_RESULT cli_do_show_vhost_individual_config( FILE *, config_vhost_information_t * );
extern ECLI_RESULT cli_do_clear_statistics_all_recv();
extern ECLI_RESULT cli_do_clear_statistics_all_send();
extern ECLI_RESULT cli_do_send();
extern ECLI_RESULT cli_set_admin_vlantype();
extern ECLI_RESULT cli_set_admin_payload_random( void * );
extern ECLI_VHOST_STATUS cli_get_vhost_status( char * );
extern ECLI_RESULT cli_send_to_config( config_cmd_interface_t *interface );
extern void cli_do_word_init( void );
extern ECLI_RESULT cli_do_noconfig( ECONFIG_COMMAND );
extern ECLI_RESULT cli_do_func( ECLI_RESULT ( *func )(), char * );
extern ECLI_RESULT cli_do_admin_cancel_vhost_key();
extern ECLI_RESULT cli_do_special_command( char * );
extern ECLI_RESULT cli_set_admin_l2type_vlan();
extern ECLI_RESULT cli_set_admin_l2type_ether();
extern void cli_control_signal_alarm_init( void );
extern ECLI_RESULT cli_set_config_savefile( void * );
extern ECLI_RESULT cli_do_config_savefile();
extern ECLI_RESULT cli_do_config_save();
extern ECLI_RESULT cli_do_show_running_config( FILE * );
extern void cli_control_set_alarm( char * );

#endif  // _CLI_EXTERN_H

/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
