/*
 * cli structure header .
 *
 * Author: Isamu Ohkuchi
 */


#ifndef _CLI_STRUCT_H
#define _CLI_STRUCT_H

#include "configif.h"

/************************************************************************
 * Config
 ************************************************************************/
typedef struct cliconfig_static_arp {
  char          ip_address[ IP_SIZE ];
  char          mac_address[ MAC_SIZE ];
  void          *next_chain;
} cli_static_arp_t;

typedef struct cliconfig_controller {
  char          controller_name[ NAME_SIZE ];
  char          ip_address[ IP_SIZE ];
  void          *next_chain;
} cliconfig_controller_t;


/************************************************************************
 * Controll
 ************************************************************************/
typedef struct clictrl_cmdchain {
  const char    *str;
  void          *word;
  void          *help;
  void          *next_chain;
  ECLI_RESULT   ( *tab_func )( void * );
  ECLI_RESULT   ( *do_func )( void * );
} clictrl_cmdchain_t;


#endif // _CLI_STRUCT_H

/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
