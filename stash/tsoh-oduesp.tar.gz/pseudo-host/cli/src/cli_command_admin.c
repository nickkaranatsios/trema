#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <time.h>

#include "packet.h"
#include "configif.h"
#include "cmn.h"
#include "com_socket.h"
#include "vhost_interface.h"
#include "config_lib.h"

#include "cli_define.h"
#include "cli_struct.h"
#include "cli_extern.h"

char cli_vhostname[ NAME_SIZE ];
static char cli_macaddress[ MAC_SIZE ];
static u_int cli_ipaddress;
u_int cli_cancel_key;
static ECLI_SEND_OPTION_KIND cli_send_option_kind;
ECLI_SEND_STATUS cli_send_status = CLI_SEND_STATUS_NODOING;

static VHOST_SEND_REQUEST_BLOCK cli_send_request;
static char *cli_payload;
static char *cli_payload_mask;

int cli_show_statistics_kind;
char cli_show_statistics_filename[ 256 ];

extern ECLI_RESULT cli_sent_to_recv_common_net( u_int, char *, int, char *, int );

/************************************************************************
 * Common
 ************************************************************************/
void
cli_do_word_init() {
  if ( cli_mode == CLI_ADMINMODE ) {
    cli_command_word = clidata_admin_word;
  }
  else if ( cli_mode == CLI_CONFIGMODE ) {
    cli_command_word = clidata_config_word;
  }
  else if ( cli_mode == CLI_VHOSTMODE ) {
    cli_command_word = clidata_vhost_word;
  }
  return;
}


ECLI_RESULT
cli_set_admin_vhost( void *vhost_name ) {
  memset( cli_vhostname, 0x00, sizeof( cli_vhostname ) );

  if ( strlen( vhost_name ) > MAX_VHOST_NAME_LENGTH ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_VHOSTNAME ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  if ( CLI_OK != cli_check_digit( CLI_CHECK_LNUM, ( u_char * ) vhost_name ) ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_VHOSTNAME ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  strncpy( cli_vhostname, vhost_name, sizeof( cli_vhostname ) );

  cli_do_word_init();

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_mac_address( void *mac_address ) {
  ECLI_RESULT result;

  result = cli_set_macaddress( ( char * ) mac_address, cli_macaddress );
  if ( result != CLI_OK ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_MACADDRESS ) );
    return CLI_NG_EXIT_ERRORLOG;
  }
  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_ip_address( void *ip_address ) {
  ECLI_RESULT result;

  result = cli_set_ipaddress( ( char * ) ip_address, &cli_ipaddress );
  if ( result != CLI_OK ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_IPADDRESS ) );
    return CLI_NG_EXIT_ERRORLOG;
  }
  return CLI_OK;
}


char *
cli_get_all_active_vhostname( u_int ipv4, u_int *vhost_num ) {
  int socket_fd;
  int result;
  char *vhost_name_list;
  u_int length, count;
  VHOST_STATUS_REQUEST_BLOCK vhost_status_request;
  VHOST_STATUS_ANSWER_BLOCK vhost_status_response;
  PACKET_HEADER packet_header;

  memset( &vhost_status_request, 0x00, sizeof( vhost_status_request ) );
  memset( &vhost_status_response, 0x00, sizeof( vhost_status_response ) );
  memset( &packet_header, 0x00, sizeof( packet_header ) );

  packet_header.size = htonl( sizeof( packet_header ) + sizeof( vhost_status_request ) );
  packet_header.packet_num = htonl( 0x01 );
  vhost_status_request.header.length = htonl( sizeof( vhost_status_request ) );
  vhost_status_request.header.command_code = htonl( VHOST_STATUS_REQUEST );
  vhost_status_request.request_code = htonl( VHOST_STATUS_REQUEST_ALL );

  // vhost connect
  socket_fd = com_socket_connect( ipv4, CLI_INTERFACE_PORT );
  if ( socket_fd < 0 ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
    return NULL;
  }

  result = com_socket_send( socket_fd, ( u_char * ) &packet_header, sizeof( packet_header ) );
  if ( result != TRUE ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
    com_socket_close( socket_fd );
    return NULL;
  }

  result = com_socket_send( socket_fd, ( u_char * ) &vhost_status_request, sizeof( vhost_status_request ) );
  if ( result != TRUE ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
    com_socket_close( socket_fd );
    return NULL;
  }

  result = com_socket_receive( socket_fd, ( u_char * ) &packet_header, sizeof( packet_header ) );
  if ( result != TRUE ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
    com_socket_close( socket_fd );
    return NULL;
  }

  result = com_socket_receive( socket_fd, ( u_char * ) &vhost_status_response, sizeof( vhost_status_response ) );
  if ( result != TRUE ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
    com_socket_close( socket_fd );
    return NULL;
  }

  vhost_name_list = calloc( htonl( vhost_status_response.vhost_num ) * ( MAX_VHOST_NAME_LENGTH + sizeof( int ) ), sizeof( char ) );
  if ( vhost_name_list == NULL ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
    return NULL;
  }

  // set vhost num
  *vhost_num = htonl( vhost_status_response.vhost_num );

  // get all active vhost
  for ( length = 0, count = 0; count < *vhost_num; length += ( u_int ) ( MAX_VHOST_NAME_LENGTH + sizeof( int ) ), count++ ) {
    result = com_socket_receive( socket_fd, ( u_char * ) &vhost_name_list[ length ], MAX_VHOST_NAME_LENGTH );
    if ( result != TRUE ) {
      MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
      com_socket_close( socket_fd );
      free( vhost_name_list );
      return NULL;
    }
  }

  com_socket_close( socket_fd );

  return vhost_name_list;
}


ECLI_VHOST_STATUS
cli_get_vhost_status( char *vhost_name ) {
  u_int ipv4;
  char ip_str[ IP_SIZE ] = "";
  ECLI_RESULT result;
  VHOST_STATUS_REQUEST_BLOCK vhost_status_request;
  VHOST_STATUS_ANSWER_BLOCK vhost_status_response;
  ECLI_VHOST_STATUS status;
  ECONFIG_RESULT config_result;
  int socket_fd;
  PACKET_HEADER packet_header;
  char *vhost_name_list;

  memset( &packet_header, 0x00, sizeof( packet_header ) );

  config_result = config_get_vhost_ipaddress( vhost_name, ip_str );
  if ( config_result != CONFIG_OK ) {
    return CLI_VHOST_DOWN;
  }

  memset( &vhost_status_request, 0x00, sizeof( vhost_status_request ) );
  memset( &vhost_status_response, 0x00, sizeof( vhost_status_response ) );

  vhost_status_request.header.length = htonl( sizeof( vhost_status_request ) );
  vhost_status_request.header.command_code = htonl( VHOST_STATUS_REQUEST );
  strcpy( ( char * ) vhost_status_request.header.vhost_name, vhost_name );
  vhost_status_request.request_code = htonl( VHOST_STATUS_REQUEST_VHOST );

  ipv4 = htonl( inet_addr( ip_str ) );

  socket_fd = com_socket_connect( ipv4, CLI_INTERFACE_PORT );
  if ( socket_fd < 0 ) {
    return CLI_VHOST_UNKNOWN;
  }

  packet_header.size = htonl( sizeof( packet_header ) + sizeof( vhost_status_request ) );
  packet_header.packet_num = htonl( 0x01 );

  result = com_socket_send( socket_fd, ( u_char * ) &packet_header, sizeof( packet_header ) );
  if ( result != TRUE ) {
    com_socket_close( socket_fd );
    return CLI_VHOST_UNKNOWN;
  }

  result = com_socket_send( socket_fd, ( u_char * ) &vhost_status_request, sizeof( vhost_status_request ) );
  if ( result != TRUE ) {
    com_socket_close( socket_fd );
    return CLI_VHOST_UNKNOWN;
  }

  result = com_socket_receive( socket_fd, ( u_char * ) &packet_header, sizeof( packet_header ) );
  if ( result != TRUE ) {
    com_socket_close( socket_fd );
    return CLI_VHOST_UNKNOWN;
  }

  result = com_socket_receive( socket_fd, ( u_char * ) &vhost_status_response, sizeof( vhost_status_response ) );
  if ( result != TRUE ) {
    com_socket_close( socket_fd );
    return CLI_VHOST_UNKNOWN;
  }

  if ( ntohl( vhost_status_response.vhost_num ) == 0x00 ) {
    status = CLI_VHOST_DOWN;
  }
  else {
    status = CLI_VHOST_UP;

    vhost_name_list = calloc( ntohl( vhost_status_response.vhost_num ) * MAX_VHOST_NAME_LENGTH, sizeof( char ) );
    if ( vhost_name_list == NULL ) {
      MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
      com_socket_close( socket_fd );
      return CLI_VHOST_UNKNOWN;
    }

    result = com_socket_receive( socket_fd, ( u_char * ) vhost_name_list, ntohl( vhost_status_response.vhost_num ) * MAX_VHOST_NAME_LENGTH );
    if ( result != TRUE ) {
      com_socket_close( socket_fd );
      free( vhost_name_list );
      return CLI_VHOST_UNKNOWN;
    }
    free( vhost_name_list );
  }

  com_socket_close( socket_fd );

  return status;
}


ECLI_RESULT
cli_sent_to_recv_common_net( u_int ipv4, char *send_message, int send_size, char *recv_message, int recv_size ) {
  int socket_fd;
  int result;
  PACKET_HEADER packet_header;

  memset( &packet_header, 0x00, sizeof( packet_header ) );

  // vhost connect
  socket_fd = com_socket_connect( ipv4, CLI_INTERFACE_PORT );
  if ( socket_fd < 0 ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  packet_header.size = htonl( ( u_int ) sizeof( packet_header ) + ( u_int ) send_size );
  packet_header.packet_num = htonl( 0x01 );

  result = com_socket_send( socket_fd, ( u_char * ) &packet_header, sizeof( packet_header ) );
  if ( result != TRUE ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
    com_socket_close( socket_fd );
    return CLI_NG_EXIT_ERRORLOG;
  }

  result = com_socket_send( socket_fd, ( u_char * ) send_message, ( size_t ) send_size );
  if ( result != TRUE ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
    com_socket_close( socket_fd );
    return CLI_NG_EXIT_ERRORLOG;
  }

  result = com_socket_receive( socket_fd, ( u_char * ) &packet_header, sizeof( packet_header ) );
  if ( result != TRUE ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
    com_socket_close( socket_fd );
    return CLI_NG_EXIT_ERRORLOG;
  }

  result = com_socket_receive( socket_fd, ( u_char * ) recv_message, ( size_t ) recv_size );
  if ( result != TRUE ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
    com_socket_close( socket_fd );
    return CLI_NG_EXIT_ERRORLOG;
  }

  com_socket_close( socket_fd );

  return CLI_OK;
}


/************************************************************************
 * Cancel
 ************************************************************************/
ECLI_RESULT
cli_do_admin_cancel_vhost_key() {
  char ip_address[ IP_SIZE ] = "";
  VHOST_SEND_CANCEL_REQUEST_BLOCK cancel_request;
  VHOST_SEND_CANCEL_ANSWER_BLOCK cancel_response;
  ECLI_VHOST_STATUS vhost_status;
  u_int ipv4;
  ECLI_RESULT result;
  ECONFIG_RESULT config_result;

  // check vhost status
  vhost_status = cli_get_vhost_status( cli_vhostname );
  if ( vhost_status == CLI_VHOST_DOWN ) {
    MCLI_ERROR( ( CLI_ERROR_VHOSTNOTRUNNING, cli_vhostname ) );
    cli_do_word_init();
    return CLI_NG_EXIT_ERRORLOG;
  }
  else if ( vhost_status == CLI_VHOST_UNKNOWN ) {
    cli_do_word_init();
    return CLI_NG_EXIT_ERRORLOG;
  }

  config_result = config_get_vhost_ipaddress( cli_vhostname, ip_address );
  if ( config_result != CONFIG_OK ) {
    MCLI_ERROR( ( "%s", CLI_ERROR_CONFIGNOTEXIST ) );
    cli_do_word_init();
    return CLI_NG_EXIT_ERRORLOG;
  }

  cancel_request.header.length = htonl( sizeof( VHOST_SEND_CANCEL_REQUEST_BLOCK ) );
  cancel_request.header.command_code = htonl( VHOST_SEND_CANCEL_REQUEST );
  strcpy( ( char * ) cancel_request.header.vhost_name, cli_vhostname );
  cancel_request.cancel_number = htonl( cli_cancel_key );

  ipv4 = htonl( inet_addr( ip_address ) );
  result = cli_sent_to_recv_common_net( ipv4, ( char * ) &cancel_request, sizeof( cancel_request ),
                                        ( char * ) &cancel_response, sizeof( cancel_response ) );
  if ( result != CLI_OK ) {
    return CLI_NG_EXIT_ERRORLOG;
  }

  if ( cancel_response.result != RESULT_OK ) {
    MCLI_ERROR( ( "%s", CLI_ERROR_VHOST_ERR ) );
    cli_do_word_init();
    return CLI_NG_EXIT_ERRORLOG;
  }
  else {
    printf( "%s", CLI_MESSAGE_COMPLETE );
  }

  cli_do_word_init();

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_cancel_vhost_key( void *key ) {
  // check parameter
  if ( CLI_OK != cli_check_digit( CLI_CHECK_LNUM, ( u_char * ) key ) ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_CANCELKEY ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  cli_cancel_key = ( u_int ) strtoul( ( char * ) key, NULL, 0 );

  return 0;
}


/************************************************************************
 * Start
 ************************************************************************/
ECLI_RESULT
cli_check_vhost_start_parameter( config_vhost_db_vhost_detail_t *vhost_info ) {
  if ( vhost_info->mode.enable == CONFIG_ENABLE ) {
    if ( vhost_info->mode.mode == CONFIG_HOST_EMULATION_MODE ) {
      // host emulation mode

      if ( vhost_info->ip_addr.enable != CONFIG_ENABLE ) {
        MCLI_ERROR( ( CLI_ERROR_SHORTAGE_PARAMS, CLI_WORD_IPADDRESS ) );
        return CLI_NG;
      }

      if ( vhost_info->mac_addr.enable != CONFIG_ENABLE ) {
        MCLI_ERROR( ( CLI_ERROR_SHORTAGE_PARAMS, CLI_WORD_MACADDRESS ) );
        return CLI_NG;
      }

      if ( vhost_info->mask.enable != CONFIG_ENABLE ) {
        MCLI_ERROR( ( CLI_ERROR_SHORTAGE_PARAMS, CLI_WORD_MASK ) );
        return CLI_NG;
      }
    }
    else {
      // raw packet generation mode
    }
  }

  if ( vhost_info->interface.enable != CONFIG_ENABLE ) {
    MCLI_ERROR( ( CLI_ERROR_SHORTAGE_PARAMS, CLI_WORD_INTERFACE ) );
    return CLI_NG;
  }

  if ( vhost_info->controller.enable != CONFIG_ENABLE ) {
    MCLI_ERROR( ( CLI_ERROR_SHORTAGE_PARAMS, CLI_WORD_CONTROLLER ) );
    return CLI_NG;
  }
  return CLI_OK;
}


ECLI_RESULT
cli_start_vhost( char *vhost_name ) {
  char ip_address[ IP_SIZE ] = "";
  VHOST_CREATE_REQUEST_BLOCK create_request;
  VHOST_CREATE_ANSWER_BLOCK create_response;
  u_int ipv4;
  int socket_net_fd;
  int result;
  VHOST_STATIC_ARP_REQUEST_BLOCK_POINTER static_arp_request_p;
  VHOST_STATIC_ARP_ANSWER_BLOCK static_arp_response;
  u_int count;
  config_vhost_information_t *vhost_information;
  config_static_arp_t *static_arp_information;
  u_int static_arp_num;
  PACKET_HEADER packet_header;
  ECLI_VHOST_STATUS status;

  memset( &create_request, 0x00, sizeof( create_request ) );
  memset( &create_response, 0x00, sizeof( create_response ) );
  memset( &packet_header, 0x00, sizeof( packet_header ) );

  // vhost running check
  status = cli_get_vhost_status( vhost_name );
  if ( status == CLI_VHOST_UP ) {
    MCLI_ERROR( ( CLI_ERROR_VHOSTRUNNING, cli_vhostname ) );
    return CLI_NG_EXIT_ERRORLOG;
  }
  else if ( status == CLI_VHOST_UNKNOWN ) {
    MCLI_ERROR( ( CLI_ERROR_VHOSTNOTSTART ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  vhost_information = config_get_vhost_information( vhost_name );
  if ( vhost_information == NULL ) {
    MCLI_ERROR( ( CLI_ERROR_CONFIGNOTEXIST, vhost_name ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  // configuration check
  result = cli_check_vhost_start_parameter( &vhost_information->vhost_info );
  if ( result != CLI_OK ) {
    free( vhost_information );
    return CLI_NG_EXIT_ERRORLOG;
  }

  create_request.header.length = htonl( sizeof( create_request ) );
  create_request.header.command_code = htonl( VHOST_CREATE_REQUEST );
  strcpy( ( char * ) create_request.header.vhost_name, vhost_information->vhost_name );

  result = config_get_vhost_ipaddress( vhost_name, ip_address );
  if ( result != CONFIG_OK ) {
    MCLI_ERROR( ( CLI_ERROR_CONFIGNOTEXIST, vhost_name ) );
    return CLI_NG_EXIT_ERRORLOG;
  }
  // mode
  if ( vhost_information->vhost_info.mode.enable == CONFIG_ENABLE ) {
    if ( vhost_information->vhost_info.mode.mode == CONFIG_RAW_GENERATION_MODE ) {
      create_request.generator_mode = htonl( RAW_GENERATOR_MODE );          // 0: raw genetator mode
    }
    else {
      create_request.generator_mode = htonl( HOST_EMURATOR_MODE );          // 1: host generator mode
    }
  }
  else {
    create_request.generator_mode = htonl( RAW_GENERATOR_MODE );        // 0: raw genetator mode
  }

  // promisc
  if ( vhost_information->vhost_info.promisc.enable == CONFIG_ENABLE ) {
    create_request.promisc_mode = Mhtons( PACKET_MODE_PROMISC );         // 1:promisc
  }
  else {
    create_request.promisc_mode = Mhtons( PACKET_MODE_DEFAULT );         // 0:no promisc
  }

  // l2type
  if ( vhost_information->vhost_info.l2type.enable == CONFIG_ENABLE ) {
    if ( vhost_information->vhost_info.l2type.l2type == CONFIG_L2TYPEETHER ) {
      create_request.l2_type = Mhtons( PACKET_TYPE_DIX );        // 0: DIX
    }
    else {
      create_request.l2_type = Mhtons( PACKET_TYPE_8021Q );          // 1: 802.1Q
      create_request.vlan_id = Mhtons( vhost_information->vhost_info.l2type.vlanid );
    }
  }
  else {
    create_request.l2_type = Mhtons( PACKET_TYPE_DIX );      // 0: DIX
  }

  // interface
  if ( vhost_information->vhost_info.interface.enable == CONFIG_ENABLE ) {
    strcpy( ( char * ) create_request.receive_interface, vhost_information->vhost_info.interface.recv_device );

    if ( vhost_information->vhost_info.interface.send_enable == CONFIG_ENABLE ) {
      strcpy( ( char * ) create_request.send_interface, vhost_information->vhost_info.interface.send_device );
    }
    else {
      strcpy( ( char * ) create_request.send_interface, vhost_information->vhost_info.interface.recv_device );
    }
  }
  // ip_address
  if ( vhost_information->vhost_info.ip_addr.enable == CONFIG_ENABLE ) {
    create_request.ip_address = inet_addr( vhost_information->vhost_info.ip_addr.ip_address );
  }
  // mask
  if ( vhost_information->vhost_info.mask.enable == CONFIG_ENABLE ) {
    cli_set_ipaddress( vhost_information->vhost_info.mask.mask, ( u_int * ) &create_request.netmask );
  }
  // mac_address
  if ( vhost_information->vhost_info.mac_addr.enable == CONFIG_ENABLE ) {
    cli_set_macaddress( vhost_information->vhost_info.mac_addr.mac_address, ( char * ) create_request.mac_address );
  }
  // arp_cache
  if ( vhost_information->vhost_info.arpcache.enable == CONFIG_ENABLE ) {
    create_request.arp_cache_time = Mhtons( vhost_information->vhost_info.arpcache.time );
  }
  else {
    create_request.arp_cache_time = Mhtons( CLI_ARPCACHE_DEFAULT );
  }

  ipv4 = htonl( inet_addr( ip_address ) );
  socket_net_fd = com_socket_connect( ipv4, CLI_INTERFACE_PORT );
  if ( socket_net_fd < 0 ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
    free( vhost_information );
    return CLI_NG_EXIT_ERRORLOG;
  }

  packet_header.size = htonl( sizeof( packet_header ) + sizeof( create_request ) );
  packet_header.packet_num = htonl( 0x01 );

  result = com_socket_send( socket_net_fd, ( u_char * ) &packet_header, sizeof( packet_header ) );
  if ( result != TRUE ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
    com_socket_close( socket_net_fd );
    free( vhost_information );
    return CLI_NG_EXIT_ERRORLOG;
  }

  result = com_socket_send( socket_net_fd, ( u_char * ) &create_request, sizeof( create_request ) );
  if ( result != TRUE ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
    com_socket_close( socket_net_fd );
    free( vhost_information );
    return CLI_NG_EXIT_ERRORLOG;
  }

  result = com_socket_receive( socket_net_fd, ( u_char * ) &packet_header, sizeof( packet_header ) );
  if ( result != TRUE ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
    com_socket_close( socket_net_fd );
    free( vhost_information );
    return CLI_NG_EXIT_ERRORLOG;
  }

  result = com_socket_receive( socket_net_fd, ( u_char * ) &create_response, sizeof( create_response ) );
  if ( result != TRUE ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
    com_socket_close( socket_net_fd );
    free( vhost_information );
    return CLI_NG_EXIT_ERRORLOG;
  }

  // check result
  if ( create_response.result != RESULT_OK ) {
    MCLI_ERROR( ( CLI_ERROR_DEVICE_OPENERROR ) );
    com_socket_close( socket_net_fd );
    free( vhost_information );
    return CLI_NG_EXIT_ERRORLOG;
  }

  // static arp
  memset( &static_arp_response, 0x00, sizeof( static_arp_response ) );

  static_arp_information = config_get_static_arp_information( vhost_name, &static_arp_num );
  if ( static_arp_information == NULL ) {
    com_socket_close( socket_net_fd );
    free( vhost_information );
    return CLI_NG_EXIT_ERRORLOG;
  }

  MCLI_LOG( ( "static_arp_num      : %d\n", static_arp_num ) );
  static_arp_request_p = calloc( sizeof( VHOST_STATIC_ARP_REQUEST_BLOCK ) * static_arp_num, sizeof( char ) );
  if ( static_arp_request_p == NULL ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
    com_socket_close( socket_net_fd );
    free( vhost_information );
    free( static_arp_information );
    return CLI_NG_EXIT_ERRORLOG;
  }

  // send vhost ( static arp )
  for ( count = 0; count < static_arp_num; count++ ) {
    static_arp_request_p[ count ].header.length = htonl( sizeof( VHOST_STATIC_ARP_REQUEST_BLOCK ) );
    static_arp_request_p[ count ].header.command_code = htonl( VHOST_STATIC_ARP_REQUEST );
    strcpy( ( char * ) &static_arp_request_p[ count ].header.vhost_name, vhost_name );

    cli_set_macaddress( static_arp_information[ count ].mac_address, ( char * ) &static_arp_request_p[ count ].mac_address );
    static_arp_request_p[ count ].ipv4_address = inet_addr( static_arp_information[ count ].ip_address );
  }
  packet_header.size = htonl( ( u_int ) sizeof( packet_header ) + ( u_int ) sizeof( VHOST_STATIC_ARP_REQUEST_BLOCK ) * static_arp_num );
  packet_header.packet_num = htonl( static_arp_num );

  while ( 1 ) {
    if ( static_arp_num == 0 ) {
      break;
    }

    result = com_socket_send( socket_net_fd, ( u_char * ) &packet_header, sizeof( packet_header ) );
    if ( result != TRUE ) {
      MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
      break;
    }

    result = com_socket_send( socket_net_fd, ( u_char * ) static_arp_request_p, sizeof( VHOST_STATIC_ARP_REQUEST_BLOCK ) * static_arp_num );
    if ( result != TRUE ) {
      MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
      break;
    }

    result = com_socket_receive( socket_net_fd, ( u_char * ) &packet_header, sizeof( packet_header ) );
    if ( result != TRUE ) {
      MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
      break;
    }

    for ( count = 0; count < ntohl( packet_header.packet_num ); count++ ) {
      result = com_socket_receive( socket_net_fd, ( u_char * ) &static_arp_response, sizeof( static_arp_response ) );
      if ( result != TRUE ) {
        MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
        break;
      }

      if ( static_arp_response.result != RESULT_OK ) {
        MCLI_ERROR( ( CLI_ERROR_VHOST_ERR ) );
        break;
      }
    }
    break;
  }
  com_socket_close( socket_net_fd );
  free( vhost_information );
  free( static_arp_information );
  free( static_arp_request_p );

  if ( ( result != TRUE ) || ( static_arp_response.result != RESULT_OK ) ) {
    return CLI_NG_EXIT_ERRORLOG;
  }
  return CLI_OK;
}


ECLI_RESULT
cli_do_admin_start_all() {
  u_int count;
  config_vhost_information_t *vhost_information;
  u_int vhost_num;
  ECLI_VHOST_STATUS status;

  // vhost configuration information
  vhost_information = config_get_all_vhost_information( &vhost_num );
  if ( vhost_information == NULL ) {
    return CLI_OK;
  }

  for ( count = 0; count < vhost_num; count++ ) {
    // create vhost
    status = cli_get_vhost_status( vhost_information[ count ].vhost_name );
    if ( status == CLI_VHOST_DOWN ) {
      cli_start_vhost( vhost_information[ count ].vhost_name );
    }
  }
  free( vhost_information );
  cli_do_word_init();

  printf( CLI_MESSAGE_COMPLETE );

  return CLI_OK;
}


ECLI_RESULT
cli_do_admin_start_vhost() {
  ECLI_RESULT result;

  result = cli_start_vhost( cli_vhostname );
  if ( result != CLI_OK ) {
    return result;
  }

  cli_do_word_init();

  printf( CLI_MESSAGE_COMPLETE );

  return CLI_OK;
}


/************************************************************************
 * Stop
 ************************************************************************/
ECLI_RESULT
cli_stop_vhost( char *vhost_name ) {
  VHOST_STOP_REQUEST_BLOCK stop_request;
  VHOST_STOP_ANSWER_BLOCK stop_response;
  char ip_address[ IP_SIZE ];
  u_int ipv4;
  ECLI_RESULT result;
  ECONFIG_RESULT config_result;
  ECLI_VHOST_STATUS status;

  memset( &stop_request, 0x00, sizeof( stop_request ) );
  memset( &stop_response, 0x00, sizeof( stop_response ) );

  status = cli_get_vhost_status( vhost_name );
  if ( status != CLI_VHOST_UP ) {
    MCLI_ERROR( ( CLI_ERROR_VHOSTNOTRUNNING, vhost_name ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  config_result = config_get_vhost_ipaddress( vhost_name, ip_address );
  if ( config_result != CONFIG_OK ) {
    MCLI_ERROR( ( "%s", CLI_ERROR_CONFIGNOTEXIST ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  stop_request.header.length = htonl( sizeof( stop_request ) );
  stop_request.header.command_code = htonl( VHOST_STOP_REQUEST );
  strcpy( ( char * ) stop_request.header.vhost_name, vhost_name );

  ipv4 = htonl( inet_addr( ip_address ) );
  result = cli_sent_to_recv_common_net( ipv4, ( char * ) &stop_request, sizeof( stop_request ), ( char * ) &stop_response, sizeof( stop_response ) );
  if ( result != CLI_OK ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
    return CLI_NG_EXIT_ERRORLOG;
  }
  if ( stop_response.result != RESULT_OK ) {
    MCLI_ERROR( ( "%s", CLI_ERROR_VHOST_ERR ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  return CLI_OK;
}


ECLI_RESULT
cli_do_admin_stop_all() {
  config_cmd_interface_t interface;
  u_int ipv4;
  VHOST_STATUS_REQUEST_BLOCK status_request;
  VHOST_STATUS_ANSWER_BLOCK status_response;
  char *vhost_list;
  u_int vhost_num;
  u_int count, vhost_count;
  config_controller_detail_t *controller_information;
  u_int controller_num;

  memset( &interface, 0x00, sizeof( interface ) );
  memset( &status_request, 0x00, sizeof( status_request ) );
  memset( &status_response, 0x00, sizeof( status_response ) );

  status_request.header.length = htonl( sizeof( status_request ) );
  status_request.header.command_code = htonl( VHOST_STATUS_REQUEST );

  controller_information = config_get_controller_information( &controller_num );
  if ( controller_information == NULL ) {
    printf( CLI_MESSAGE_COMPLETE );
    return CLI_OK;
  }

  for ( count = 0; count < controller_num; count++ ) {
    ipv4 = htonl( inet_addr( controller_information[ count ].ip_address ) );
    vhost_list = cli_get_all_active_vhostname( ipv4, &vhost_num );
    if ( vhost_list == NULL ) {
      free( controller_information );
      printf( CLI_MESSAGE_COMPLETE );
      return CLI_OK;
    }

    // stop vhost
    for ( vhost_count = 0; vhost_count < vhost_num; vhost_count++ ) {
      cli_stop_vhost( &vhost_list[ vhost_count * ( MAX_VHOST_NAME_LENGTH + sizeof( int ) ) ] );
    }
    free( vhost_list );
  }
  free( controller_information );
  cli_do_word_init();

  printf( CLI_MESSAGE_COMPLETE );

  return CLI_OK;
}


ECLI_RESULT
cli_do_admin_stop_vhost() {
  ECLI_RESULT result;

  result = cli_stop_vhost( cli_vhostname );
  if ( result == CLI_OK ) {
    printf( CLI_MESSAGE_COMPLETE );
  }

  cli_do_word_init();

  return result;
}


/************************************************************************
 * Configure
 ************************************************************************/
ECLI_RESULT
cli_do_admin_configure() {
  char path[ 108 ] = "";

  cli_mode = CLI_CONFIGMODE;
  cli_command_word = clidata_config_word;
  strncpy( cli_prompt, CLI_PROMPT_CONFIG, sizeof( cli_prompt ) );

  // vhost connect
  sprintf( path, "%s%s", TMP_DIR, CONNECT_PATH );
  cli_socket_fd = com_socket_unix_connect( path );
  if ( cli_socket_fd < 0 ) {
    MCLI_ERROR( ( CLI_ERROR_CONFIGNOTRUNNING ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  return CLI_OK;
}


/************************************************************************
 * Send
 ************************************************************************/
ECLI_RESULT
cli_do_send() {
  char ip_address[ IP_SIZE ];
  u_int ipv4 = 0;
  ECLI_RESULT result;
  int socket_fd = 0;
  COMMAND_PACKET_HEADER packet_command_header;
  VHOST_SEND_NG_INFORMATION_BLOCK send_ng_information_block;
  VHOST_SEND_END_RESPONSE_BLOCK send_end_response_block;
  VHOST_SEND_ANSWER_BLOCK send_answer_block;
  struct in_addr inet_address;
  char *inet_string;
  u_int count = 0;
  PACKET_HEADER packet_header;
  ECONFIG_RESULT config_result;
  ECLI_VHOST_STATUS status;

  memset( &send_ng_information_block, 0x00, sizeof( send_ng_information_block ) );
  memset( &send_end_response_block, 0x00, sizeof( send_end_response_block ) );
  memset( &send_answer_block, 0x00, sizeof( send_answer_block ) );
  memset( &packet_header, 0x00, sizeof( packet_header ) );
  memset( &packet_command_header, 0x00, sizeof( packet_command_header ) );
  memset( &inet_address, 0x00, sizeof( inet_address ) );

  status = cli_get_vhost_status( cli_vhostname );
  if ( status != CLI_VHOST_UP ) {
    MCLI_ERROR( ( CLI_ERROR_VHOSTNOTRUNNING, cli_vhostname ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  // send status change.
  cli_send_status = CLI_SEND_STATUS_DOING;

  config_result = config_get_vhost_ipaddress( cli_vhostname, ip_address );
  if ( config_result != CONFIG_OK ) {
    // send status change.
    cli_send_status = CLI_SEND_STATUS_NODOING;
    MCLI_ERROR( ( "%s", CLI_ERROR_CONFIGNOTEXIST ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  cli_send_request.header.length = htonl( ( u_int ) sizeof( cli_send_request ) + ntohl( cli_send_request.send_request_data.payload_length ) );
  cli_send_request.header.command_code = htonl( VHOST_SEND_REQUEST );
  strcpy( ( char * ) cli_send_request.header.vhost_name, cli_vhostname );

  ipv4 = htonl( inet_addr( ip_address ) );

  // vhost connect
  socket_fd = com_socket_connect( ipv4, CLI_INTERFACE_PORT );
  if ( socket_fd < 0 ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
    cli_send_status = CLI_SEND_STATUS_NODOING;
    return CLI_NG_EXIT_ERRORLOG;
  }

  MCLI_LOG( ( "response_type           : %08x\n", ntohl( cli_send_request.send_request_data.response_type ) ) );
  MCLI_LOG( ( "layer_2_type            : %04x\n", Mntohs( cli_send_request.send_request_data.layer_2_type ) ) );
  MCLI_LOG( ( "vlan_infomation         : %04x\n", Mntohs( cli_send_request.send_request_data.vlan_information ) ) );
  MCLI_LOG( ( "source_mac_address      : %02x:%02x:%02x:%02x:%02x:%02x\n", cli_send_request.send_request_data.source_mac_address[ 0 ],
                                          cli_send_request.send_request_data.source_mac_address[ 1 ],
                                          cli_send_request.send_request_data.source_mac_address[ 2 ],
                                          cli_send_request.send_request_data.source_mac_address[ 3 ],
                                          cli_send_request.send_request_data.source_mac_address[ 4 ],
                                          cli_send_request.send_request_data.source_mac_address[ 5 ] ) );
  MCLI_LOG( ( "destination_mac_address : %02x:%02x:%02x:%02x:%02x:%02x\n", cli_send_request.send_request_data.destination_mac_address[ 0 ],
                                          cli_send_request.send_request_data.destination_mac_address[ 1 ],
                                          cli_send_request.send_request_data.destination_mac_address[ 2 ],
                                          cli_send_request.send_request_data.destination_mac_address[ 3 ],
                                          cli_send_request.send_request_data.destination_mac_address[ 4 ],
                                          cli_send_request.send_request_data.destination_mac_address[ 5 ] ) );
  MCLI_LOG( ( "source_mac_mask         : %02x:%02x:%02x:%02x:%02x:%02x\n", cli_send_request.send_request_data.source_mac_mask[ 0 ],
                                          cli_send_request.send_request_data.source_mac_mask[ 1 ],
                                          cli_send_request.send_request_data.source_mac_mask[ 2 ],
                                          cli_send_request.send_request_data.source_mac_mask[ 3 ],
                                          cli_send_request.send_request_data.source_mac_mask[ 4 ],
                                          cli_send_request.send_request_data.source_mac_mask[ 5 ] ) );
  MCLI_LOG( ( "destination_mac_mask    : %02x:%02x:%02x:%02x:%02x:%02x\n", cli_send_request.send_request_data.destination_mac_mask[ 0 ],
                                          cli_send_request.send_request_data.destination_mac_mask[ 1 ],
                                          cli_send_request.send_request_data.destination_mac_mask[ 2 ],
                                          cli_send_request.send_request_data.destination_mac_mask[ 3 ],
                                          cli_send_request.send_request_data.destination_mac_mask[ 4 ],
                                          cli_send_request.send_request_data.destination_mac_mask[ 5 ] ) );
  MCLI_LOG( ( "mac_type                : %08x\n", Mntohs( cli_send_request.send_request_data.mac_type ) ) );
  MCLI_LOG( ( "ether_type              : %08x\n", Mntohs( cli_send_request.send_request_data.ether_type ) ) );
  MCLI_LOG( ( "layer_3_type            : %08x\n", Mntohs( cli_send_request.send_request_data.layer_3_type ) ) );
  MCLI_LOG( ( "hardware_type           : %08x\n", Mntohs( cli_send_request.send_request_data.hardware_type ) ) );
  MCLI_LOG( ( "protocol_type           : %08x\n", Mntohs( cli_send_request.send_request_data.protocol_type ) ) );
  MCLI_LOG( ( "operation_code          : %08x\n", Mntohs( cli_send_request.send_request_data.operation_code ) ) );
  MCLI_LOG( ( "arp_source_mac_address  : %02x:%02x:%02x:%02x:%02x:%02x\n", cli_send_request.send_request_data.arp_source_mac_address[ 0 ],
                                          cli_send_request.send_request_data.arp_source_mac_address[ 1 ],
                                          cli_send_request.send_request_data.arp_source_mac_address[ 2 ],
                                          cli_send_request.send_request_data.arp_source_mac_address[ 3 ],
                                          cli_send_request.send_request_data.arp_source_mac_address[ 4 ],
                                          cli_send_request.send_request_data.arp_source_mac_address[ 5 ] ) );
  MCLI_LOG( ( "arp_destination_mac_address : %02x:%02x:%02x:%02x:%02x:%02x\n", cli_send_request.send_request_data.arp_destination_mac_address[ 0 ],
                                          cli_send_request.send_request_data.arp_destination_mac_address[ 1 ],
                                          cli_send_request.send_request_data.arp_destination_mac_address[ 2 ],
                                          cli_send_request.send_request_data.arp_destination_mac_address[ 3 ],
                                          cli_send_request.send_request_data.arp_destination_mac_address[ 4 ],
                                          cli_send_request.send_request_data.arp_destination_mac_address[ 5 ] ) );
  MCLI_LOG( ( "arp_mac_type      : %08x\n", Mntohs( cli_send_request.send_request_data.arp_mac_type ) ) );
  MCLI_LOG( ( "arp_source_mac_mask     : %02x:%02x:%02x:%02x:%02x:%02x\n", cli_send_request.send_request_data.arp_source_mac_mask[ 0 ],
                                          cli_send_request.send_request_data.arp_source_mac_mask[ 1 ],
                                          cli_send_request.send_request_data.arp_source_mac_mask[ 2 ],
                                          cli_send_request.send_request_data.arp_source_mac_mask[ 3 ],
                                          cli_send_request.send_request_data.arp_source_mac_mask[ 4 ],
                                          cli_send_request.send_request_data.arp_source_mac_mask[ 5 ] ) );
  MCLI_LOG( ( "arp_destination_mac_mask: %02x:%02x:%02x:%02x:%02x:%02x\n", cli_send_request.send_request_data.arp_destination_mac_mask[ 0 ],
                                          cli_send_request.send_request_data.arp_destination_mac_mask[ 1 ],
                                          cli_send_request.send_request_data.arp_destination_mac_mask[ 2 ],
                                          cli_send_request.send_request_data.arp_destination_mac_mask[ 3 ],
                                          cli_send_request.send_request_data.arp_destination_mac_mask[ 4 ],
                                          cli_send_request.send_request_data.arp_destination_mac_mask[ 5 ] ) );
  MCLI_LOG( ( "source_ip_address       : %08x\n", ntohl( cli_send_request.send_request_data.source_ip_address ) ) );
  MCLI_LOG( ( "destination_ip_address  : %08x\n", ntohl( cli_send_request.send_request_data.destination_ip_address ) ) );
  MCLI_LOG( ( "ip_type                 : %08x\n", Mntohs( cli_send_request.send_request_data.ip_type ) ) );
  MCLI_LOG( ( "layer_2_pad             : %08x\n", Mntohs( cli_send_request.send_request_data.layer_2_pad ) ) );
  MCLI_LOG( ( "source_ip_address_mask  : %08x\n", ntohl( cli_send_request.send_request_data.source_ip_address_mask ) ) );
  MCLI_LOG( ( "destination_ip_address_mask: %08x\n", ntohl( cli_send_request.send_request_data.destination_ip_address_mask ) ) );
  MCLI_LOG( ( "tos                     : %08x\n", cli_send_request.send_request_data.tos ) );
  MCLI_LOG( ( "flags                   : %08x\n", cli_send_request.send_request_data.flags ) );
  MCLI_LOG( ( "id                      : %08x\n", Mntohs( cli_send_request.send_request_data.id ) ) );
  MCLI_LOG( ( "flagment_offset         : %08x\n", Mntohs( cli_send_request.send_request_data.flagment_offset ) ) );
  MCLI_LOG( ( "ttl                     : %08x\n", cli_send_request.send_request_data.ttl ) );
  MCLI_LOG( ( "protocol_number         : %08x\n", cli_send_request.send_request_data.protocol_number ) );
  MCLI_LOG( ( "option_length           : %08x\n", Mntohs( cli_send_request.send_request_data.option_length ) ) );
  MCLI_LOG( ( "option\n" ) );
  MCLI_LOG( ( "source_port_number      : %08x\n", Mntohs( cli_send_request.send_request_data.source_port_number ) ) );
  MCLI_LOG( ( "destination_port_number : %08x\n", Mntohs( cli_send_request.send_request_data.destination_port_number ) ) );
  MCLI_LOG( ( "udp_type                : %08x\n", Mntohs( cli_send_request.send_request_data.udp_type ) ) );
  MCLI_LOG( ( "layer_4_pad             : %08x\n", Mntohs( cli_send_request.send_request_data.layer_4_pad ) ) );
  MCLI_LOG( ( "source_port_number_mask : %08x\n", Mntohs( cli_send_request.send_request_data.source_port_number_mask ) ) );
  MCLI_LOG( ( "destination_port_number_mask: %08x\n", Mntohs( cli_send_request.send_request_data.destination_port_number_mask ) ) );
  MCLI_LOG( ( "duration                : %08x\n", ntohl( cli_send_request.send_request_data.duration ) ) );
  MCLI_LOG( ( "packet_par_second       : %08x\n", ntohl( cli_send_request.send_request_data.packet_par_second ) ) );
  MCLI_LOG( ( "packet_num              : %08x\n", ntohl( cli_send_request.send_request_data.packet_num ) ) );
  MCLI_LOG( ( "packet_length           : %08x\n", ntohl( cli_send_request.send_request_data.packet_length ) ) );
  MCLI_LOG( ( "payload_pattern         : %08x\n", ntohl( cli_send_request.send_request_data.payload_pattern ) ) );
  MCLI_LOG( ( "payload_length          : %08x\n", ntohl( cli_send_request.send_request_data.payload_length ) ) );
  MCLI_LOG( ( "payload_mask_length     : %08x\n", ntohl( cli_send_request.send_request_data.payload_mask_length ) ) );
  MCLI_LOG( ( "payload_count           : %08x\n", ntohl( cli_send_request.send_request_data.payload_count ) ) );
  MCLI_LOG( ( "payload_limit           : %08x\n", ntohl( cli_send_request.send_request_data.payload_limit ) ) );
  MCLI_LOG( ( "\n" ) );

  packet_header.size
    = htonl( ( u_int ) sizeof( packet_header ) + ( u_int ) sizeof( cli_send_request ) + ntohl( cli_send_request.send_request_data.payload_length )
    + ntohl( cli_send_request.send_request_data.payload_mask_length ) );
  packet_header.packet_num = htonl( 0x01 );

  result = com_socket_send( socket_fd, ( u_char * ) &packet_header, sizeof( packet_header ) );
  if ( result != TRUE ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );

    // send status change.
    cli_send_status = CLI_SEND_STATUS_NODOING;

    return CLI_NG_EXIT_ERRORLOG;
  }

  result = com_socket_send( socket_fd, ( u_char * ) &cli_send_request, sizeof( cli_send_request ) );
  if ( result != TRUE ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
    com_socket_close( socket_fd );

    // send status change.
    cli_send_status = CLI_SEND_STATUS_NODOING;

    return CLI_NG_EXIT_ERRORLOG;
  }

  if ( ntohl( cli_send_request.send_request_data.payload_length ) > 0 ) {
    result = com_socket_send( socket_fd, ( u_char * ) cli_payload, ntohl( cli_send_request.send_request_data.payload_length ) );
    if ( result != TRUE ) {
      MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
      com_socket_close( socket_fd );

      // send status change.
      cli_send_status = CLI_SEND_STATUS_NODOING;

      return CLI_NG_EXIT_ERRORLOG;
    }
    free( cli_payload );
    cli_payload = NULL;
  }
  if ( ntohl( cli_send_request.send_request_data.payload_mask_length ) > 0 ) {
    result = com_socket_send( socket_fd, ( u_char * ) cli_payload_mask, ntohl( cli_send_request.send_request_data.payload_mask_length ) );
    if ( result != TRUE ) {
      MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
      com_socket_close( socket_fd );

      // send status change.
      cli_send_status = CLI_SEND_STATUS_NODOING;

      return CLI_NG_EXIT_ERRORLOG;
    }
    free( cli_payload );
    cli_payload = NULL;
  }

  while ( 1 ) {
    result = com_socket_receive( socket_fd, ( u_char * ) &packet_header, sizeof( packet_header ) );
    if ( result != TRUE ) {
      MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
      com_socket_close( socket_fd );
      return CLI_NG_EXIT_ERRORLOG;
    }

    for ( count = 0; count < ( ntohl( packet_header.size ) - sizeof( packet_header ) ); ) {
      result = com_socket_data_copy( socket_fd, ( u_char * ) &packet_command_header, sizeof( packet_command_header ) );
      if ( result != TRUE ) {
        MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
        com_socket_close( socket_fd );
        cli_send_status = CLI_SEND_STATUS_NODOING;
        return CLI_NG_EXIT_ERRORLOG;
      }

      if ( ntohl( packet_command_header.command_code ) == VHOST_SEND_INCOMPLETEL_NOTICE ) {
        result = com_socket_receive( socket_fd, ( u_char * ) &send_ng_information_block, sizeof( send_ng_information_block ) );
        if ( result != TRUE ) {
          MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
          com_socket_close( socket_fd );
          cli_send_status = CLI_SEND_STATUS_NODOING;
          return CLI_NG_EXIT_ERRORLOG;
        }

        memcpy( &inet_address, &send_ng_information_block.ipv4_address, sizeof( struct in_addr ) );
        inet_string = inet_ntoa( inet_address );
        printf( CLI_ERROR_SEND_NOHOST, inet_string );
      }
      else if ( ntohl( packet_command_header.command_code ) == VHOST_SEND_RESPONCE ) {
        result = com_socket_receive( socket_fd, ( u_char * ) &send_end_response_block, sizeof( send_end_response_block ) );
        if ( result != TRUE ) {
          MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
          com_socket_close( socket_fd );
          cli_send_status = CLI_SEND_STATUS_NODOING;
          return CLI_NG_EXIT_ERRORLOG;
        }
        // clear cancel key
        cli_send_status = CLI_SEND_STATUS_NODOING;
        com_socket_close( socket_fd );

        if ( ntohl( cli_send_request.send_request_data.response_type ) == 0x01 ) {
          printf( CLI_MESSAGE_COMPLETE_CANCEL, cli_cancel_key );
        }
        else {
          printf( CLI_MESSAGE_COMPLETE );
        }
        cli_cancel_key = 0x00;

        return CLI_OK;
      }
      else if ( ntohl( packet_command_header.command_code ) == VHOST_SEND_ANSWER ) {
        result = com_socket_receive( socket_fd, ( u_char * ) &send_answer_block, sizeof( send_answer_block ) );
        if ( result != TRUE ) {
          MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
          com_socket_close( socket_fd );
          // send status change.
          cli_send_status = CLI_SEND_STATUS_NODOING;
          return CLI_NG_EXIT_ERRORLOG;
        }

        if ( ntohl( send_answer_block.result ) != REQUEST_OK ) {
          MCLI_ERROR( ( CLI_ERROR_VHOST_ERR ) );
          com_socket_close( socket_fd );
          cli_send_status = CLI_SEND_STATUS_NODOING;
          return CLI_NG_EXIT_ERRORLOG;
        }
        cli_cancel_key = ntohl( send_answer_block.send_number );
      }
      count += ntohl( packet_command_header.length );
    }
  }

  // send status change.
  cli_send_status = CLI_SEND_STATUS_NODOING;

  com_socket_close( socket_fd );

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_digit( char *token, int *set_data, int check_key, int check_size ) {
  u_int data;

  if ( CLI_OK != cli_check_digit( check_key, ( u_char * ) token ) ) {
    return CLI_NG;
  }

  data = ( u_int ) strtoul( ( char * ) token, NULL, 0 );

  if ( check_size == sizeof( int ) ) {
    *set_data = ( int ) htonl( data );
  }
  else if ( check_size == sizeof( short ) ) {
    *set_data = Mhtons( ( u_short ) data );
  }
  else if ( check_size == sizeof( char ) ) {
    *set_data = ( int ) data;
  }
  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_l2type_vlan() {
  cli_send_request.send_request_data.layer_2_type = Mhtons( PACKET_TYPE_8021Q );
  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_l2type_ether() {
  cli_send_request.send_request_data.layer_2_type = Mhtons( PACKET_TYPE_DIX );
  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_udp() {
  // set udp protocol number
  cli_send_request.send_request_data.protocol_number = 17;
  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_countlimit( void *count ) {
  u_int data;

  if ( CLI_OK != cli_check_digit( CLI_CHECK_XDIGIT, ( u_char * ) count ) ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_VHOSTNAME ) );
    return CLI_NG_EXIT_ERRORLOG;
  }
  data = ( u_int ) strtoul( ( char * ) count, NULL, 0 );

  if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_L2MACSRC ) {
    memcpy( &cli_send_request.send_request_data.source_mac_mask[ 5 ], &data, sizeof( data ) );
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_L2MACDST ) {
    memcpy( &cli_send_request.send_request_data.destination_mac_mask[ 5 ], &data, sizeof( data ) );
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_ARPMACSRC ) {
    memcpy( &cli_send_request.send_request_data.arp_source_mac_mask[ 5 ], &data, sizeof( data ) );
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_ARPMACDST ) {
    memcpy( &cli_send_request.send_request_data.arp_destination_mac_mask[ 5 ], &data, sizeof( data ) );
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_IPSRC ) {
    cli_send_request.send_request_data.source_ip_address_mask = htonl( data );
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_IPDST ) {
    cli_send_request.send_request_data.destination_ip_address_mask = htonl( data );
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_PORTSRC ) {
    cli_send_request.send_request_data.source_port_number_mask = Mhtons( ( u_short ) data );
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_PORTDST ) {
    cli_send_request.send_request_data.destination_port_number_mask = Mhtons( ( u_short ) data );
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_PAYLOAD ) {
    cli_send_request.send_request_data.payload_limit = htonl( data );
  }

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_vlantype() {
  cli_send_request.send_request_data.vlan_type = Mhtons( VHOST_SEND_REQUEST_VLAN_ENABLE );
  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_send() {
  memset( &cli_send_request.send_request_data, 0x00, sizeof( cli_send_request.send_request_data ) );

  cli_send_request.send_request_data.ether_type = Mhtons( 0x0800 );
  cli_send_request.send_request_data.hardware_type = Mhtons( 0x0001 );
  cli_send_request.send_request_data.protocol_type = Mhtons( 0x0800 );
  cli_send_request.send_request_data.operation_code = Mhtons( 0x01 );
  cli_send_request.send_request_data.protocol_number = 0x04;
  cli_send_request.send_request_data.packet_par_second = htonl( 0x01 );
  cli_send_request.send_request_data.packet_length = htonl( 64 );
  cli_send_request.send_request_data.packet_num = htonl( 0x01 );
  cli_send_request.send_request_data.duration = htonl( 0x00 );
  cli_send_request.send_request_data.vlan_type = Mhtons( VHOST_SEND_REQUEST_VLAN_DISABLE );

  if ( cli_payload != NULL ) {
    free( cli_payload );
    cli_payload = NULL;
  }

  if ( cli_payload_mask != NULL ) {
    free( cli_payload_mask );
    cli_payload_mask = NULL;
  }

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_backgroud() {
  cli_send_request.send_request_data.response_type = htonl( 0x01 );

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_cos( void *cos ) {
  u_char data;
  u_short ntohl_vlanid;

  data = ( u_char ) strtoul( ( char * ) cos, NULL, 0 );
  if ( data > 0x07 ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_COS ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  ntohl_vlanid = Mntohs( cli_send_request.send_request_data.vlan_information );
  ntohl_vlanid = ( u_short ) ( ntohl_vlanid & ~CLI_COS_MASK );
  ntohl_vlanid = ( u_short ) ( ntohl_vlanid | ( data << CLI_COS_SHIFT ) );

  cli_send_request.send_request_data.vlan_information = Mhtons( ntohl_vlanid );

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_vlanid( void *vlanid ) {
  u_short data;
  u_short ntohl_vlanid;

  data = ( u_short ) strtoul( ( char * ) vlanid, NULL, 0 );
  if ( ( data > 0xFFF ) && ( data > CLI_VLAN_MAX ) ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_VLANID ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  ntohl_vlanid = Mntohs( cli_send_request.send_request_data.vlan_information );
  ntohl_vlanid = ( u_short ) ( ntohl_vlanid & ~CLI_VLAN_MASK );
  ntohl_vlanid = ( u_short ) ( ntohl_vlanid | ( data << CLI_VLAN_SHIFT ) );
  cli_send_request.send_request_data.vlan_information = Mhtons( ntohl_vlanid );

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_source_mac_address( void *mac_address ) {
  ECLI_RESULT result;

  result = cli_set_macaddress( ( char * ) mac_address, ( char * ) cli_send_request.send_request_data.source_mac_address );
  if ( result != CLI_OK ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_MACADDRESS ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  cli_send_option_kind = CLI_SEND_OPTION_KIND_L2MACSRC;

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_destination_mac_address( void *mac_address ) {
  ECLI_RESULT result;

  result = cli_set_macaddress( ( char * ) mac_address, ( char * ) cli_send_request.send_request_data.destination_mac_address );
  if ( result != CLI_OK ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_MACADDRESS ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  cli_send_option_kind = CLI_SEND_OPTION_KIND_L2MACDST;

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_ether_type( void *ethertype ) {
  ECLI_RESULT result;

  result = cli_set_admin_digit( ethertype, ( int * ) &cli_send_request.send_request_data.ether_type,
    CLI_CHECK_XDIGIT, sizeof( cli_send_request.send_request_data.ether_type ) );

  if ( result != CLI_OK ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_ETHERTYPE ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_l3type_arp() {
  cli_send_request.send_request_data.layer_3_type = Mhtons( 0x01 );
  cli_send_request.send_request_data.ether_type = Mhtons( 0x0806 );

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_l3type_ip() {
  cli_send_request.send_request_data.layer_3_type = Mhtons( 0x00 );

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_hardware_type( void *hardware_type ) {
  ECLI_RESULT result;

  result = cli_set_admin_digit( hardware_type, ( int * ) &cli_send_request.send_request_data.hardware_type,
    CLI_CHECK_XDIGIT, sizeof( cli_send_request.send_request_data.hardware_type ) );

  if ( result != CLI_OK ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_HEADWARETYPE ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_protocol_type( void *protocol_type ) {
  ECLI_RESULT result;

  result = cli_set_admin_digit( protocol_type, ( int * ) &cli_send_request.send_request_data.protocol_type,
    CLI_CHECK_XDIGIT, sizeof( cli_send_request.send_request_data.protocol_type ) );

  if ( result != CLI_OK ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_PROTOCOLTYPE ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_operation_code( void *operation_code ) {
  ECLI_RESULT result;

  result = cli_set_admin_digit( operation_code, ( int * ) &cli_send_request.send_request_data.operation_code,
    CLI_CHECK_XDIGIT, sizeof( cli_send_request.send_request_data.operation_code ) );

  if ( result != CLI_OK ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_OPERATIONCODE ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_arp_source_mac_address( void *mac_address ) {
  ECLI_RESULT result;

  result = cli_set_macaddress( ( char * ) mac_address, ( char * ) cli_send_request.send_request_data.arp_source_mac_address );
  if ( result != CLI_OK ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_MACADDRESS ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  cli_send_option_kind = CLI_SEND_OPTION_KIND_ARPMACSRC;

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_arp_destination_mac_address( void *mac_address ) {
  ECLI_RESULT result;

  result = cli_set_macaddress( ( char * ) mac_address, ( char * ) cli_send_request.send_request_data.arp_destination_mac_address );
  if ( result != CLI_OK ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_MACADDRESS ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  cli_send_option_kind = CLI_SEND_OPTION_KIND_ARPMACDST;

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_source_ip_address( void *ip_address ) {
  ECLI_RESULT result;

  result = cli_set_ipaddress( ( char * ) ip_address, ( u_int * ) &cli_send_request.send_request_data.source_ip_address );
  if ( result != CLI_OK ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_IPADDRESS ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  cli_send_option_kind = CLI_SEND_OPTION_KIND_IPSRC;

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_destination_ip_address( void *ip_address ) {
  ECLI_RESULT result;

  result = cli_set_ipaddress( ( char * ) ip_address, ( u_int * ) &cli_send_request.send_request_data.destination_ip_address );
  if ( result != CLI_OK ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_IPADDRESS ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  cli_send_option_kind = CLI_SEND_OPTION_KIND_IPDST;

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_tos( void *tos ) {
  ECLI_RESULT result;

  result = cli_set_admin_digit( tos, ( int * ) &cli_send_request.send_request_data.tos,
    CLI_CHECK_XDIGIT, sizeof( cli_send_request.send_request_data.tos ) );

  if ( result != CLI_OK ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_TOS ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_flag( void *flag ) {
  ECLI_RESULT result;

  result = cli_set_admin_digit( flag, ( int * ) &cli_send_request.send_request_data.flags,
    CLI_CHECK_XDIGIT, sizeof( cli_send_request.send_request_data.flags ) );

  if ( result != CLI_OK ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_FLAG ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_flagoffset( void *flagoffset ) {
  ECLI_RESULT result;

  result = cli_set_admin_digit( flagoffset, ( int * ) &cli_send_request.send_request_data.flagment_offset,
    CLI_CHECK_XDIGIT, sizeof( cli_send_request.send_request_data.flagment_offset ) );

  if ( result != CLI_OK ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_OFFSET ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_protocolnum( void *protocol_num ) {
  ECLI_RESULT result;

  result = cli_set_admin_digit( protocol_num, ( int * ) &cli_send_request.send_request_data.protocol_number,
    CLI_CHECK_XDIGIT, sizeof( cli_send_request.send_request_data.protocol_number ) );

  if ( result != CLI_OK ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_PROTOCOLNUM ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_ttl( void *ttl ) {
  ECLI_RESULT result;

  result = cli_set_admin_digit( ttl, ( int * ) &cli_send_request.send_request_data.ttl,
    CLI_CHECK_XDIGIT, sizeof( cli_send_request.send_request_data.ttl ) );

  if ( result != CLI_OK ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_TTL ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  return CLI_OK;
}


u_int
cli_set_admin_data( u_char *option, u_char *data ) {
  u_int count, set_count = 0;
  u_char digit1, digit2;
  u_char tmp;

  if ( strncmp( ( char * ) option, "0x", 2 ) == 0 ) {
    count = 2;
  }
  else {
    count = 0;
  }

  for (; count < strlen( ( char * ) option ); count += 2 ) {
    if ( CLI_OK != cli_check_digit( CLI_CHECK_XDIGIT, &option[ count ] ) ) {
      break;
    }
    tmp = option[ count ];
    digit1 = ( u_char ) strtoul( ( char * ) &tmp, NULL, 16 );
    tmp = option[ count + 1 ];
    digit2 = ( u_char ) strtoul( ( char * ) &tmp, NULL, 16 );

    data[ set_count ] = 0;
    data[ set_count ] = ( u_char ) ( digit1 << 4 );
    data[ set_count ] |= digit2;

    set_count++;
  }

  return set_count;
}


ECLI_RESULT
cli_set_admin_option( void *option ) {
  u_short option_length;
  int result;
  char *option_address = option;
  int start_point;

  result = cli_check_digit( CLI_CHECK_XDIGIT, option );
  if ( result != CLI_OK ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_OPTION ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  if ( strncmp( option, "0x", strlen( "0x" ) ) == 0 ) {
    start_point = 0x02;
  }
  else {
    start_point = 0x00;
  }

  if ( strlen( &option_address[ start_point ] ) > ( CLI_PACKET_OPTION_MAX * 2 ) ) {
    MCLI_ERROR( ( CLI_ERRROR_RANGE ) );
    return CLI_NG;
  }

  option_length = ( u_short ) cli_set_admin_data( ( u_char * ) option, ( u_char * ) &cli_send_request.send_request_data.option[ 0 ] );
  cli_send_request.send_request_data.option_length = Mhtons( option_length );

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_payload( void *payload ) {
  u_int length;
  ECLI_RESULT result;

  result = cli_check_digit( CLI_CHECK_XDIGIT, ( u_char * ) payload );
  if ( result != CLI_OK ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_DATA ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  if ( cli_payload != NULL ) {
    free( cli_payload );
    cli_payload = NULL;
  }

  cli_payload = calloc( strlen( payload ) + 1, sizeof( char ) );
  if ( cli_payload == NULL ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_DATA ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  length = cli_set_admin_data( ( u_char * ) payload, ( u_char * ) cli_payload );
  cli_send_request.send_request_data.payload_length = htonl( length );

  cli_send_option_kind = CLI_SEND_OPTION_KIND_PAYLOAD;

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_source_port_number( void *port_number ) {
  ECLI_RESULT result;

  result = cli_set_admin_digit( port_number, ( int * ) &cli_send_request.send_request_data.source_port_number,
    CLI_CHECK_XDIGIT, sizeof( cli_send_request.send_request_data.source_port_number ) );

  if ( result != CLI_OK ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_PORT ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  cli_send_option_kind = CLI_SEND_OPTION_KIND_PORTSRC;

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_destination_port_number( void *destination_port_number ) {
  ECLI_RESULT result;

  result = cli_set_admin_digit( destination_port_number, ( int * ) &cli_send_request.send_request_data.destination_port_number,
    CLI_CHECK_XDIGIT, sizeof( cli_send_request.send_request_data.destination_port_number ) );

  if ( result != CLI_OK ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_PORT ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  cli_send_option_kind = CLI_SEND_OPTION_KIND_PORTDST;

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_pps( void *pps ) {
  ECLI_RESULT result;

  result = cli_set_admin_digit( pps, ( int * ) &cli_send_request.send_request_data.packet_par_second,
    CLI_CHECK_XDIGIT, sizeof( cli_send_request.send_request_data.packet_par_second ) );

  if ( result != CLI_OK ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_PPS ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_duration( void *duration ) {
  ECLI_RESULT result;

  result = cli_set_admin_digit( duration, ( int * ) &cli_send_request.send_request_data.duration,
    CLI_CHECK_XDIGIT, sizeof( cli_send_request.send_request_data.duration ) );

  if ( result != CLI_OK ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_DURATION ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_length( void *length ) {
  ECLI_RESULT result;
  u_int len;

  result = cli_set_admin_digit( length, ( int * ) &len,
    CLI_CHECK_XDIGIT, sizeof( cli_send_request.send_request_data.packet_length ) );

  if ( ntohl( len ) < CLI_PACKET_LENGTH_MINIMUM ) {
    MCLI_ERROR( ( CLI_ERRROR_RANGE ) );
    return CLI_NG_EXIT_ERRORLOG;
  }
  cli_send_request.send_request_data.packet_length = len;

  if ( result != CLI_OK ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_LENGTH ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_packetnum( void *packetnum ) {
  ECLI_RESULT result;

  result = cli_set_admin_digit( packetnum, ( int * ) &cli_send_request.send_request_data.packet_num,
    CLI_CHECK_XDIGIT, sizeof( cli_send_request.send_request_data.packet_num ) );

  if ( result != CLI_OK ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_PACKETNUM ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_increment( void *count ) {
  u_int data;

  if ( CLI_OK != cli_check_digit( CLI_CHECK_XDIGIT, ( u_char * ) count ) ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_COUNT ) );
    return CLI_NG_EXIT_ERRORLOG;
  }
  data = ( u_int ) strtoul( ( char * ) count, NULL, 0 );

  if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_L2MACSRC ) {
    cli_send_request.send_request_data.mac_type = Mhtons( cli_send_request.send_request_data.mac_type | SOURCE_TYPE_INCREMENT );
    cli_send_request.send_request_data.source_mac_counut = htonl( data );
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_L2MACDST ) {
    cli_send_request.send_request_data.mac_type = Mhtons( cli_send_request.send_request_data.mac_type | DESTINATION_TYPE_INCREMENT );
    cli_send_request.send_request_data.destination_mac_counut = htonl( data );
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_ARPMACSRC ) {
    cli_send_request.send_request_data.arp_mac_type = Mhtons( cli_send_request.send_request_data.arp_mac_type | SOURCE_TYPE_INCREMENT );
    cli_send_request.send_request_data.arp_source_mac_count = htonl( data );
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_ARPMACDST ) {
    cli_send_request.send_request_data.arp_mac_type = Mhtons( cli_send_request.send_request_data.arp_mac_type | DESTINATION_TYPE_INCREMENT );
    cli_send_request.send_request_data.arp_destination_mac_count = htonl( data );
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_IPSRC ) {
    cli_send_request.send_request_data.ip_type = Mhtons( cli_send_request.send_request_data.ip_type | SOURCE_TYPE_INCREMENT );
    cli_send_request.send_request_data.source_ip_address_add_count = htonl( data );
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_IPDST ) {
    cli_send_request.send_request_data.ip_type = Mhtons( cli_send_request.send_request_data.ip_type | DESTINATION_TYPE_INCREMENT );
    cli_send_request.send_request_data.destination_ip_address_add_count = htonl( data );
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_PORTSRC ) {
    cli_send_request.send_request_data.udp_type = Mhtons( cli_send_request.send_request_data.udp_type | SOURCE_TYPE_INCREMENT );
    cli_send_request.send_request_data.source_port_number_add_count = Mhtons( ( u_short ) data );
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_PORTDST ) {
    cli_send_request.send_request_data.udp_type = Mhtons( cli_send_request.send_request_data.udp_type | DESTINATION_TYPE_INCREMENT );
    cli_send_request.send_request_data.destination_port_number_add_count = Mhtons( ( u_short ) data );
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_PAYLOAD ) {
    cli_send_request.send_request_data.payload_pattern = htonl( cli_send_request.send_request_data.payload_pattern | VHOST_PAYLOAD_INCREMENT );
    cli_send_request.send_request_data.payload_count = htonl( data );
  }

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_decrement( void *count ) {
  u_int data;

  if ( CLI_OK != cli_check_digit( CLI_CHECK_XDIGIT, ( u_char * ) count ) ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_COUNT ) );
    return CLI_NG_EXIT_ERRORLOG;
  }
  data = ( u_int ) strtoul( ( char * ) count, NULL, 0 );

  if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_L2MACSRC ) {
    cli_send_request.send_request_data.mac_type = Mhtons( cli_send_request.send_request_data.mac_type | SOURCE_TYPE_DECREMENT );
    cli_send_request.send_request_data.source_mac_counut = htonl( data );
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_L2MACDST ) {
    cli_send_request.send_request_data.mac_type = Mhtons( cli_send_request.send_request_data.mac_type | DESTINATION_TYPE_DECREMENT );
    cli_send_request.send_request_data.destination_mac_counut = htonl( data );
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_ARPMACSRC ) {
    cli_send_request.send_request_data.arp_mac_type = Mhtons( cli_send_request.send_request_data.arp_mac_type | SOURCE_TYPE_DECREMENT );
    cli_send_request.send_request_data.arp_source_mac_count = htonl( data );
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_ARPMACDST ) {
    cli_send_request.send_request_data.arp_mac_type = Mhtons( cli_send_request.send_request_data.arp_mac_type | DESTINATION_TYPE_DECREMENT );
    cli_send_request.send_request_data.arp_destination_mac_count = htonl( data );
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_IPSRC ) {
    cli_send_request.send_request_data.ip_type = Mhtons( cli_send_request.send_request_data.ip_type | SOURCE_TYPE_DECREMENT );
    cli_send_request.send_request_data.source_ip_address_add_count = htonl( data );
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_IPDST ) {
    cli_send_request.send_request_data.ip_type = Mhtons( cli_send_request.send_request_data.ip_type | DESTINATION_TYPE_DECREMENT );
    cli_send_request.send_request_data.destination_ip_address_add_count = htonl( data );
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_PORTSRC ) {
    cli_send_request.send_request_data.udp_type = Mhtons( cli_send_request.send_request_data.udp_type | SOURCE_TYPE_DECREMENT );
    cli_send_request.send_request_data.source_port_number_add_count = Mhtons( ( u_short ) data );
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_PORTDST ) {
    cli_send_request.send_request_data.udp_type = Mhtons( cli_send_request.send_request_data.udp_type | DESTINATION_TYPE_DECREMENT );
    cli_send_request.send_request_data.destination_port_number_add_count = Mhtons( ( u_short ) data );
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_PAYLOAD ) {
    cli_send_request.send_request_data.payload_pattern = htonl( cli_send_request.send_request_data.payload_pattern | VHOST_PAYLOAD_DECREMENT );
    cli_send_request.send_request_data.payload_count = htonl( data );
  }

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_random( void *mask ) {
  u_int data;
  u_int length;
  ECLI_RESULT result;

  if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_L2MACSRC ) {
    cli_send_request.send_request_data.mac_type = Mhtons( cli_send_request.send_request_data.mac_type | SOURCE_TYPE_RANDOM );
    result = cli_set_macaddress( mask, ( char * ) &cli_send_request.send_request_data.source_mac_mask );
    if ( result != CLI_OK ) {
      MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_MASK ) );
      return CLI_NG_EXIT_ERRORLOG;
    }
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_L2MACDST ) {
    cli_send_request.send_request_data.mac_type = Mhtons( cli_send_request.send_request_data.mac_type | DESTINATION_TYPE_RANDOM );
    result = cli_set_macaddress( mask, ( char * ) &cli_send_request.send_request_data.destination_mac_mask );
    if ( result != CLI_OK ) {
      MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_MASK ) );
      return CLI_NG_EXIT_ERRORLOG;
    }
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_ARPMACSRC ) {
    cli_send_request.send_request_data.arp_mac_type = Mhtons( cli_send_request.send_request_data.arp_mac_type | SOURCE_TYPE_RANDOM );
    result = cli_set_macaddress( mask, ( char * ) &cli_send_request.send_request_data.arp_source_mac_mask );
    if ( result != CLI_OK ) {
      MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_MASK ) );
      return CLI_NG_EXIT_ERRORLOG;
    }
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_ARPMACDST ) {
    cli_send_request.send_request_data.arp_mac_type = Mhtons( cli_send_request.send_request_data.arp_mac_type | DESTINATION_TYPE_RANDOM );
    result = cli_set_macaddress( mask, ( char * ) &cli_send_request.send_request_data.arp_destination_mac_mask );
    if ( result != CLI_OK ) {
      MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_MASK ) );
      return CLI_NG_EXIT_ERRORLOG;
    }
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_IPSRC ) {
    cli_send_request.send_request_data.ip_type = Mhtons( cli_send_request.send_request_data.ip_type | SOURCE_TYPE_RANDOM );
    result = cli_set_ipaddress( mask, &cli_send_request.send_request_data.source_ip_address_mask );
    if ( result != CLI_OK ) {
      MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_MASK ) );
      return CLI_NG_EXIT_ERRORLOG;
    }
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_IPDST ) {
    cli_send_request.send_request_data.ip_type = Mhtons( cli_send_request.send_request_data.ip_type | DESTINATION_TYPE_RANDOM );
    result = cli_set_ipaddress( mask, &cli_send_request.send_request_data.destination_ip_address_mask );
    if ( result != CLI_OK ) {
      MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_MASK ) );
      return CLI_NG_EXIT_ERRORLOG;
    }
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_PORTSRC ) {
    if ( CLI_OK != cli_check_digit( CLI_CHECK_XDIGIT, ( u_char * ) mask ) ) {
      MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_MASK ) );
      return CLI_NG_EXIT_ERRORLOG;
    }

    cli_send_request.send_request_data.udp_type = Mhtons( cli_send_request.send_request_data.udp_type | SOURCE_TYPE_RANDOM );
    data = ( u_short ) strtoul( ( char * ) mask, NULL, 0 );
    cli_send_request.send_request_data.source_port_number_mask = Mhtons( ( u_short ) data );
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_PORTDST ) {
    if ( CLI_OK != cli_check_digit( CLI_CHECK_XDIGIT, ( u_char * ) mask ) ) {
      MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_MASK ) );
      return CLI_NG_EXIT_ERRORLOG;
    }

    cli_send_request.send_request_data.udp_type = Mhtons( cli_send_request.send_request_data.udp_type | DESTINATION_TYPE_RANDOM );
    data = ( u_short ) strtoul( ( char * ) mask, NULL, 0 );
    cli_send_request.send_request_data.destination_port_number_mask = Mhtons( ( u_short ) data );
  }
  else if ( cli_send_option_kind == CLI_SEND_OPTION_KIND_PAYLOAD ) {
    cli_send_request.send_request_data.payload_pattern = htonl( cli_send_request.send_request_data.payload_pattern | VHOST_PAYLOAD_RANDOM );

    if ( cli_payload_mask != NULL ) {
      free( cli_payload_mask );
      cli_payload_mask = NULL;
    }

    cli_payload_mask = calloc( strlen( ( char * ) mask ) + 1, sizeof( char ) );
    if ( cli_payload_mask == NULL ) {
      MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_MASK ) );
      return CLI_NG_EXIT_ERRORLOG;
    }
    length = cli_set_admin_data( ( u_char * ) mask, ( u_char * ) cli_payload_mask );
    cli_send_request.send_request_data.payload_mask_length = htonl( length );
  }

  return CLI_OK;
}


ECLI_RESULT
cli_set_admin_id( void *id ) {
  ECLI_RESULT result;

  result = cli_set_admin_digit( id, ( int * ) &cli_send_request.send_request_data.id,
    CLI_CHECK_XDIGIT, sizeof( cli_send_request.send_request_data.id ) );

  if ( result != CLI_OK ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_ID ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  return CLI_OK;
}


/************************************************************************
 * show
 ************************************************************************/
// show config
ECLI_RESULT
cli_do_show_running_config( FILE *fp ) {
  config_cmd_interface_t interface;
  u_int count;
  config_controller_detail_t *controller_information;
  u_int controller_num;
  config_vhost_information_t *vhost_information;
  u_int vhost_num;
  time_t current_time;
  char current_date[ 64 ] = "";
  struct tm local_time;

  memset( &interface, 0x00, sizeof( interface ) );

  // print format header
  current_time = time( NULL );
  localtime_r( &current_time, &local_time );
  strftime( current_date, ( strlen( current_date ) - 1 ), "%Y/%m/%d %H:%M:%S", &local_time );
  fprintf( fp, "Time        :%s \n", current_date );

  controller_information = config_get_controller_information( &controller_num );
  if ( controller_information == NULL ) {
    return CLI_OK;
  }
  // show !
  fprintf( fp, "!\n" );

  // controller configuration information
  for ( count = 0; count < controller_num; count++ ) {
    fprintf( fp, "controller %s %s\n", controller_information[ count ].controller_name, controller_information[ count ].ip_address );
  }
  free( controller_information );

  // vhost configuration information
  vhost_information = config_get_all_vhost_information( &vhost_num );
  if ( vhost_information == NULL ) {
    return CLI_OK;
  }

  for ( count = 0; count < vhost_num; count++ ) {
    fprintf( fp, "!\n" );
    cli_do_show_vhost_individual_config( fp, &vhost_information[ count ] );
  }
  fprintf( fp, "!\n" );
  free( vhost_information );

  return CLI_OK;
}


ECLI_RESULT
cli_do_show_config() {
  FILE *fp;

  fp = fopen( cli_ttyname, "w" );
  if ( fp == NULL ) {
    return CLI_NG;
  }
  cli_do_show_running_config( fp );

  fclose( fp );

  return CLI_OK;
}


ECLI_RESULT
cli_set_statistics_vhostname_file( void *file_name ) {
  strncpy( cli_show_statistics_filename, file_name, sizeof( cli_show_statistics_filename ) - 1 );

  return CLI_OK;
}


ECLI_RESULT
cli_set_show_statistics_all() {
  cli_show_statistics_kind = 0x00;

  return CLI_OK;
}


ECLI_RESULT
cli_set_show_statistics_vhost( void *vhost_name ) {
  memset( cli_vhostname, 0x00, sizeof( cli_vhostname ) );

  if ( strlen( vhost_name ) > MAX_VHOST_NAME_LENGTH ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, "vhostname" ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  strncpy( cli_vhostname, vhost_name, sizeof( cli_vhostname ) );
  cli_show_statistics_kind = 0x01;

  cli_do_word_init();

  return CLI_OK;
}


/************************************************************************
 * clear
 ************************************************************************/
ECLI_RESULT
cli_do_clear_arp_all() {
  u_int count, vhost_count;
  VHOST_DYNAMIC_ARP_CLEAR_REQUEST_BLOCK clear_arp_request;
  VHOST_DYNAMIC_ARP_CLEAR_ANSWER_BLOCK clear_arp_response;
  u_int ipv4;
  config_controller_detail_t *controller_information;
  u_int controller_num;
  char *vhost_list = NULL;
  u_int vhost_num;
  int result;

  controller_information = config_get_controller_information( &controller_num );
  if ( controller_information == NULL ) {
    MCLI_ERROR( ( "%s", CLI_ERROR_CONFIGNOTEXIST ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  // controller configuration information
  for ( count = 0; count < controller_num; count++ ) {
    ipv4 = htonl( inet_addr( controller_information[ count ].ip_address ) );

    // get active vhost list
    vhost_list = cli_get_all_active_vhostname( ipv4, &vhost_num );
    if ( vhost_list == NULL ) {
      continue;
    }

    for ( vhost_count = 0; vhost_count < vhost_num; vhost_count++ ) {
      clear_arp_request.header.length = htonl( sizeof( clear_arp_request ) );
      clear_arp_request.header.command_code = htonl( VHOST_DYNAMIC_ARP_CLEAR_REQUEST );
      strcpy( ( char * ) clear_arp_request.header.vhost_name, &vhost_list[ ( long unsigned int ) vhost_count * ( MAX_VHOST_NAME_LENGTH + sizeof( int ) ) ] );

      // delete set parameter
      clear_arp_request.mode = Mhtons( VHOST_DYNAMIC_ARP_CLEAR_ALL );

      result = cli_sent_to_recv_common_net( ipv4, ( char * ) &clear_arp_request, sizeof( clear_arp_request ), ( char * ) &clear_arp_response,
        sizeof( clear_arp_response ) );
      if ( result != CLI_OK ) {
        MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
      }
      if ( clear_arp_response.result != RESULT_OK ) {
        MCLI_ERROR( ( "%s", CLI_ERROR_VHOST_ERR ) );
      }
    }
    free( vhost_list );
  }

  free( controller_information );
  printf( CLI_MESSAGE_COMPLETE );

  return CLI_OK;
}


ECLI_RESULT
cli_do_clear_arp_vhostname() {
  int result;
  char ip_address[ IP_SIZE ] = "";
  u_int ipv4;
  VHOST_DYNAMIC_ARP_CLEAR_REQUEST_BLOCK clear_arp_request;
  VHOST_DYNAMIC_ARP_CLEAR_ANSWER_BLOCK clear_arp_response;
  ECLI_VHOST_STATUS vhost_status;
  ECONFIG_RESULT config_result;

  // check vhost status
  vhost_status = cli_get_vhost_status( cli_vhostname );
  if ( vhost_status == CLI_VHOST_DOWN ) {
    MCLI_ERROR( ( CLI_ERROR_VHOSTNOTRUNNING, cli_vhostname ) );
    return CLI_NG_EXIT_ERRORLOG;
  }
  else if ( vhost_status == CLI_VHOST_UNKNOWN ) {
    return CLI_NG_EXIT_ERRORLOG;
  }

  config_result = config_get_vhost_ipaddress( cli_vhostname, ip_address );
  if ( config_result != CONFIG_OK ) {
    MCLI_ERROR( ( "%s", CLI_ERROR_LOGIC ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  clear_arp_request.header.length = htonl( sizeof( clear_arp_request ) );
  clear_arp_request.header.command_code = htonl( VHOST_DYNAMIC_ARP_CLEAR_REQUEST );
  strcpy( ( char * ) clear_arp_request.header.vhost_name, cli_vhostname );

  // delete set parameter
  clear_arp_request.mode = Mhtons( VHOST_DYNAMIC_ARP_CLEAR_ALL );        // 1: all

  ipv4 = htonl( inet_addr( ip_address ) );
  result
    = cli_sent_to_recv_common_net( ipv4, ( char * ) &clear_arp_request, sizeof( clear_arp_request ), ( char * ) &clear_arp_response,
    sizeof( clear_arp_response ) );
  if ( CLI_OK != result ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
    return CLI_NG_EXIT_ERRORLOG;
  }
  if ( clear_arp_response.result != RESULT_OK ) {
    MCLI_ERROR( ( "%s", CLI_ERROR_VHOST_ERR ) );
    return CLI_NG_EXIT_ERRORLOG;
  }
  printf( CLI_MESSAGE_COMPLETE );

  return CLI_OK;
}


ECLI_RESULT
cli_do_clear_arp_macaddress() {
  int result;
  char ip_address[ IP_SIZE ] = "";
  u_int ipv4;
  VHOST_DYNAMIC_ARP_CLEAR_REQUEST_BLOCK clear_arp_request;
  VHOST_DYNAMIC_ARP_CLEAR_ANSWER_BLOCK clear_arp_response;
  ECLI_VHOST_STATUS vhost_status;
  ECONFIG_RESULT config_result;

  // check vhost status
  vhost_status = cli_get_vhost_status( cli_vhostname );
  if ( vhost_status == CLI_VHOST_DOWN ) {
    MCLI_ERROR( ( CLI_ERROR_VHOSTNOTRUNNING, cli_vhostname ) );
    return CLI_NG_EXIT_ERRORLOG;
  }
  else if ( vhost_status == CLI_VHOST_UNKNOWN ) {
    return CLI_NG_EXIT_ERRORLOG;
  }

  config_result = config_get_vhost_ipaddress( cli_vhostname, ip_address );
  if ( config_result != CONFIG_OK ) {
    MCLI_ERROR( ( "%s", CLI_ERROR_LOGIC ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  clear_arp_request.header.length = htonl( sizeof( clear_arp_request ) );
  clear_arp_request.header.command_code = htonl( VHOST_DYNAMIC_ARP_CLEAR_REQUEST );
  strcpy( ( char * ) clear_arp_request.header.vhost_name, cli_vhostname );

  // delete set parameter
  clear_arp_request.mode = Mhtons( VHOST_DYNAMIC_ARP_INDIVIDUALLY );    // 0: individually
  clear_arp_request.ipv4_address = cli_ipaddress;
  memcpy( clear_arp_request.mac_address, cli_macaddress, 6 );

  ipv4 = htonl( inet_addr( ip_address ) );
  result
    = cli_sent_to_recv_common_net( ipv4, ( char * ) &clear_arp_request, sizeof( clear_arp_request ), ( char * ) &clear_arp_response,
    sizeof( clear_arp_response ) );
  if ( CLI_OK != result ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
    return CLI_NG_EXIT_ERRORLOG;
  }
  if ( clear_arp_response.result != RESULT_OK ) {
    MCLI_ERROR( ( "%s", CLI_ERROR_VHOST_ERR ) );
    return CLI_NG_EXIT_ERRORLOG;
  }
  printf( CLI_MESSAGE_COMPLETE );

  return CLI_OK;
}


ECLI_RESULT
cli_do_clear_statistics_all_common( int type ) {
  u_int count, vhost_count;
  VHOST_STATISTICS_CLEAR_REQUEST_BLOCK clear_statistics_request;
  VHOST_STATISTICS_CLEAR_ANSWER_BLOCK clear_statistics_response;
  u_int ipv4;
  config_controller_detail_t *controller_information;
  u_int controller_num;
  char *vhost_list = NULL;
  u_int vhost_num;
  int result;

  controller_information = config_get_controller_information( &controller_num );
  if ( controller_information == NULL ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
    return CLI_NG_EXIT_ERRORLOG;
  }
  // controller configuration information
  for ( count = 0; count < controller_num; count++ ) {
    ipv4 = htonl( inet_addr( controller_information[ count ].ip_address ) );

    // get active vhost list
    vhost_list = cli_get_all_active_vhostname( ipv4, &vhost_num );
    if ( vhost_list == NULL ) {
      continue;
    }

    for ( vhost_count = 0; vhost_count < vhost_num; vhost_count++ ) {
      clear_statistics_request.header.length = htonl( sizeof( clear_statistics_request ) );
      clear_statistics_request.header.command_code = htonl( VHOST_STATISTICS_CLEAR_REQUEST );
      strcpy( ( char * ) clear_statistics_request.header.vhost_name,
        &vhost_list[ ( long unsigned int ) vhost_count * ( MAX_VHOST_NAME_LENGTH + sizeof( int ) ) ] );

      // delete set parameter
      clear_statistics_request.type = htonl( ( u_int ) type );

      result = cli_sent_to_recv_common_net( ipv4, ( char * ) &clear_statistics_request, sizeof( clear_statistics_request ),
        ( char * ) &clear_statistics_response, sizeof( clear_statistics_response ) );
      if ( result != CLI_OK ) {
        MCLI_ERROR( ( "%s", CLI_ERROR_SYSCALL ) );
      }
      if ( clear_statistics_response.result != RESULT_OK ) {
        MCLI_ERROR( ( "%s (%s)", CLI_ERROR_VHOST_ERR, clear_statistics_request.header.vhost_name ) );
      }
    }
    free( vhost_list );
  }

  free( controller_information );

  printf( CLI_MESSAGE_COMPLETE );

  return CLI_OK;
}


ECLI_RESULT
cli_do_clear_statistics_all() {
  cli_do_clear_statistics_all_common( VHOST_STATISTICS_CLEAR_ALL );
  return CLI_OK;
}


ECLI_RESULT
cli_do_clear_statistics_all_recv() {
  cli_do_clear_statistics_all_common( VHOST_STATISTICS_CLEAR_RECEIVE );
  return CLI_OK;
}


ECLI_RESULT
cli_do_clear_statistics_all_send() {
  cli_do_clear_statistics_all_common( VHOST_STATISTICS_CLEAR_SEND );
  return CLI_OK;
}


ECLI_RESULT
cli_do_clear_statistics_vhost_common( int type ) {
  int result;
  char ip_address[ IP_SIZE ] = "";
  u_int ipv4;
  VHOST_STATISTICS_CLEAR_REQUEST_BLOCK clear_statistics_request;
  VHOST_STATISTICS_CLEAR_ANSWER_BLOCK clear_statistics_response;
  ECLI_VHOST_STATUS vhost_status;
  ECONFIG_RESULT config_result;

  // check vhost status
  vhost_status = cli_get_vhost_status( cli_vhostname );
  if ( ( vhost_status == CLI_VHOST_DOWN ) || ( vhost_status == CLI_VHOST_UNKNOWN ) ) {
    MCLI_ERROR( ( CLI_ERROR_VHOSTNOTRUNNING, cli_vhostname ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  config_result = config_get_vhost_ipaddress( cli_vhostname, ip_address );
  if ( config_result != CONFIG_OK ) {
    MCLI_ERROR( ( CLI_ERROR_LOGIC ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  clear_statistics_request.header.length = htonl( sizeof( clear_statistics_request ) );
  clear_statistics_request.header.command_code = htonl( VHOST_STATISTICS_CLEAR_REQUEST );
  strcpy( ( char * ) clear_statistics_request.header.vhost_name, cli_vhostname );

  // delete set parameter
  clear_statistics_request.type = htonl( ( u_int ) type );    // 0x00: send only, 0x01:receive only, 0x02:both

  ipv4 = htonl( inet_addr( ip_address ) );
  result
    = cli_sent_to_recv_common_net( ipv4, ( char * ) &clear_statistics_request, sizeof( clear_statistics_request ),
    ( char * ) &clear_statistics_response, sizeof( clear_statistics_response ) );
  if ( CLI_OK != result ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
    return CLI_NG_EXIT_ERRORLOG;
  }
  if ( clear_statistics_response.result != RESULT_OK ) {
    MCLI_ERROR( ( CLI_ERROR_VHOST_ERR ) );
    return CLI_NG_EXIT_ERRORLOG;
  }
  printf( CLI_MESSAGE_COMPLETE );

  return CLI_OK;
}


ECLI_RESULT
cli_do_clear_statistics_vhost() {
  cli_do_clear_statistics_vhost_common( VHOST_STATISTICS_CLEAR_ALL );

  return CLI_OK;
}


ECLI_RESULT
cli_do_clear_statistics_recv() {
  cli_do_clear_statistics_vhost_common( VHOST_STATISTICS_CLEAR_RECEIVE );
  return CLI_OK;
}


ECLI_RESULT
cli_do_clear_statistics_send() {
  cli_do_clear_statistics_vhost_common( VHOST_STATISTICS_CLEAR_SEND );
  return CLI_OK;
}


/************************************************************************
 * exit
 ************************************************************************/
ECLI_RESULT
cli_do_command_exit() {
  if ( cli_mode == CLI_ADMINMODE ) {
    exit( 1 );
  }
  else if ( cli_mode == CLI_CONFIGMODE ) {
    cli_mode = CLI_ADMINMODE;
    cli_command_word = clidata_admin_word;
    com_socket_close( cli_socket_fd );
    memset( cli_prompt, '\0', sizeof( cli_prompt ) );
    strncpy( cli_prompt, CLI_PROMPT_ADMIN, sizeof( cli_prompt ) );
  }
  else if ( cli_mode == CLI_VHOSTMODE ) {
    cli_mode = CLI_CONFIGMODE;
    cli_command_word = clidata_config_word;
    memset( cli_prompt, '\0', sizeof( cli_prompt ) );
    strncpy( cli_prompt, CLI_PROMPT_CONFIG, sizeof( cli_prompt ) );
  }

  return CLI_OK;
}
