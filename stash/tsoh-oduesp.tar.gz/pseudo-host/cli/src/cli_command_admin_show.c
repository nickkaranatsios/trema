#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/tcp.h>
#include <net/if_arp.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <net/ethernet.h>
#include <inttypes.h>

#include "cmn.h"
#include "cli_define.h"
#include "cli_struct.h"
#include "cli_extern.h"
#include "config_lib.h"
#include "packet.h"
#include "com_socket.h"
#include "vhost_interface.h"

#define SHOW_VHOST_IP_ADDRESS_PRINT_OFFSET      24
#define SHOW_VHOST_MAC_ADDRESS_PRINT_OFFSET     40
#define SHOW_VHOST_STATUS_PRINT_OFFSET          62
#define SHOW_VHOST_RUNNING_MESSAGE              "Running"
#define SHOW_VHOST_STOP_MESSAGE                 "Stopped"
#define SHOW_ARP_MAC_ADDRESS_OFFSET             28
#define SHOW_ARP_EXPIRE_OFFSET                  60
#define MAX_PAYLOAD_DISPLAY_LENGTH              20

extern char cli_vhostname[ NAME_SIZE ];
extern char cli_show_statistics_filename[ 256 ];
extern int cli_show_statistics_kind;

/******************************************************************************
 * common function                                                            *
 ******************************************************************************/
void
cli_binmac2macstr( u_char *mac_address_bin, char *mac_address_string ) {
  int lp;
  int length = 0;

  for ( lp = 0; lp < ( ETH_ALEN - 1 ); lp++ ) {
    length += sprintf( ( char * ) ( mac_address_string + length ), "%02x:", mac_address_bin[ lp ] );
  }
  sprintf( ( char * ) ( mac_address_string + length ), "%02x", mac_address_bin[ ( ETH_ALEN - 1 ) ] );
  return;
}


void
cli_make_arp_header( FILE *fp, u_char *packet ) {
  struct arphdr *arp_header = ( struct arphdr * ) packet;
  u_char *arp_data = packet + sizeof( struct arphdr );
  u_char mac_destination_address[ 64 ];
  char mac_destination_address_string[ 64 ];
  u_char mac_source_address[ 64 ];
  char mac_source_address_string[ 64 ];
  u_char inet_destination_address_buffer[ 128 ];
  u_char inet_source_address_buffer[ 128 ];
  char *ip_string_pointer;
  struct in_addr inet_source_address;
  struct in_addr inet_destination_address;

  memset( mac_source_address, '\0', sizeof( mac_source_address ) );
  memset( mac_source_address_string, '\0', sizeof( mac_source_address_string ) );
  memset( mac_destination_address, '\0', sizeof( mac_destination_address ) );
  memset( mac_destination_address_string, '\0', sizeof( mac_destination_address_string ) );
  memset( inet_destination_address_buffer, '\0', sizeof( inet_destination_address_buffer ) );
  memset( inet_source_address_buffer, '\0', sizeof( inet_source_address_buffer ) );

  memcpy( mac_source_address, arp_data, MAC_ADDRESS_LENGTH );
  arp_data += MAC_ADDRESS_LENGTH;

  memcpy( &inet_source_address, arp_data, sizeof( struct in_addr ) );
  arp_data += sizeof( struct in_addr );

  memcpy( mac_destination_address, arp_data, MAC_ADDRESS_LENGTH );
  arp_data += MAC_ADDRESS_LENGTH;

  memcpy( &inet_destination_address, arp_data, sizeof( struct in_addr ) );

  ip_string_pointer = inet_ntoa( inet_source_address );
  memcpy( inet_source_address_buffer, ip_string_pointer, strlen( ip_string_pointer ) );

  ip_string_pointer = inet_ntoa( inet_destination_address );
  memcpy( inet_destination_address_buffer, ip_string_pointer, strlen( ip_string_pointer ) );

  cli_binmac2macstr( mac_source_address, mac_source_address_string );
  cli_binmac2macstr( mac_destination_address, mac_destination_address_string );
  fprintf( fp, "%d,0x%04x,%d,%d,%d,",
           Mntohs( arp_header->ar_hrd ),
           Mntohs( arp_header->ar_pro ),
           arp_header->ar_hln,
           arp_header->ar_pln,
           Mntohs( arp_header->ar_op ) );

  fprintf( fp, "%s,%s,%s,%s,",
           mac_source_address_string, inet_source_address_buffer,
           mac_destination_address_string, inet_destination_address_buffer );
  return;
}


void
cli_decode_statistics_buffer( VHOST_STATISTICS_ANSWER_BLOCK_POINTER statistics_answer, FILE *fp ) {
  u_int packet_num;
  u_int lp;
  u_int lp2;
  u_short ether_type;
  u_int payload_offset;
  u_int payload_display_length;
  u_int header_length;
  u_int record_infomation;
  u_int display_type;
  u_int packet_length;
  char receive_analyze_buffer[ 128 ];
  char vhost_name[ MAX_VHOST_NAME_LENGTH + 4 ];
  char mac_address_string[ 64 ];
  u_char *packet_offset;
  char *ip_string_pointer;
  struct vlan_ether_header *vlan_ether_herader;
  struct ether_header *ether_header;
  struct iphdr ip_header;
  struct udphdr udp_header;
  VHOST_STATISTICS_DATA_POINTER statistics_packet_header;
  struct in_addr inet_source_address;
  struct in_addr inet_destination_address;
  char inet_destination_address_buffer[ 128 ];
  char inet_source_address_buffer[ 128 ];

  memset( vhost_name, '\0', sizeof( vhost_name ) );
  memcpy( vhost_name, statistics_answer->header.vhost_name, MAX_VHOST_NAME_LENGTH );

  if ( fp == NULL ) {
    printf( "Virtual Host ID  : %s\n", vhost_name );
  }

  packet_num = ntohl( statistics_answer->statistics_all_number );
  statistics_packet_header = ( VHOST_STATISTICS_DATA_POINTER ) ( ( u_char * ) statistics_answer + sizeof( VHOST_STATISTICS_ANSWER_BLOCK ) );

  record_infomation = 0;
  display_type = VHOST_STATISTICS_TYPE_SEND;

  for ( lp = 0; lp < packet_num; lp++ ) {
    if ( fp != NULL ) {
      fprintf( fp, "%s,", vhost_name );
    }
    if ( ntohl( statistics_packet_header->packet_type ) == VHOST_STATISTICS_TYPE_SEND ) {
      if ( fp == NULL ) {
        printf( "Send Information :\n" );
        record_infomation += 1;
      }
      else {
        fprintf( fp, "send," );
      }
    }
    else {
      if ( display_type != VHOST_STATISTICS_TYPE_RECEIVE ) {
        display_type = VHOST_STATISTICS_TYPE_RECEIVE;
        record_infomation = 0;
      }
      if ( fp == NULL ) {
        printf( "Receive Information :\n" );
      }
      else {
        fprintf( fp, "receive," );
      }
      record_infomation += 1;
    }

    if ( fp == NULL ) {
      printf( "  Record:%d\n", record_infomation );
    }

    memset( receive_analyze_buffer, '\0', sizeof( receive_analyze_buffer ) );
    memcpy( receive_analyze_buffer, ( u_char * ) ( ( u_char * ) statistics_packet_header + sizeof( VHOST_STATISTICS_DATA ) ),
            sizeof( receive_analyze_buffer ) );

    packet_offset = ( u_char * ) ( u_char * ) statistics_packet_header + sizeof( VHOST_STATISTICS_DATA );

    ether_header = ( struct ether_header * ) receive_analyze_buffer;

    memset( mac_address_string, '\0', sizeof( mac_address_string ) );
    cli_binmac2macstr( ether_header->ether_shost, mac_address_string );
    if ( fp == NULL ) {
      printf( "  Source MAC     : %s\n", mac_address_string );
    }
    else {
      fprintf( fp, "%s,", mac_address_string );
    }

    memset( mac_address_string, '\0', sizeof( mac_address_string ) );
    cli_binmac2macstr( ether_header->ether_dhost, mac_address_string );
    if ( fp == NULL ) {
      printf( "  Destination MAC: %s\n", mac_address_string );
    }
    else {
      fprintf( fp, "%s,", mac_address_string );
    }

    payload_offset = 0;
    if ( ether_header->ether_type == Mntohs( ETH_P_8021Q ) ) {
      vlan_ether_herader = ( struct vlan_ether_header * ) receive_analyze_buffer;
      ether_type = Mntohs( vlan_ether_herader->h_vlan_encapsulated_proto );
      if ( fp == NULL ) {
        printf( "  Ether Type     : 0x%04x\n", Mntohs( vlan_ether_herader->h_vlan_encapsulated_proto ) );
        printf( "  Cos            : 0x%02x\n", ( ( Mntohs( vlan_ether_herader->h_vlan_TCI ) & 0xE000 ) >> 13 ) );
        printf( "  Vlan ID        : 0x%04x\n", ( Mntohs( vlan_ether_herader->h_vlan_TCI ) & 0xFFF ) );
      }
      else {
        fprintf( fp, "0x%04x,0x%02x,0x%04x,",
          Mntohs( vlan_ether_herader->h_vlan_encapsulated_proto ),
          ( ( Mntohs( vlan_ether_herader->h_vlan_TCI ) & 0xE000 ) >> 13 ),
          ( Mntohs( vlan_ether_herader->h_vlan_TCI ) & 0xFFF ) );
      }
      payload_offset = sizeof( struct vlan_ether_header );
    }
    else {
      ether_type = Mntohs( ether_header->ether_type );
      if ( fp == NULL ) {
        printf( "  Ether Type     : 0x%04x\n", Mntohs( ether_header->ether_type ) );
        printf( "  Cos            : -\n" );
        printf( "  Vlan ID        : -\n" );
      }
      else {
        fprintf( fp, "0x%04x,,,", Mntohs( ether_header->ether_type ) );
      }
      payload_offset = sizeof( struct ether_header );
    }

    header_length = 0;
    if ( statistics_packet_header->ip_header_offset != 0 ) {
      memcpy( &ip_header, &receive_analyze_buffer[ ntohl( statistics_packet_header->ip_header_offset ) ], sizeof( struct iphdr ) );
      memcpy( &inet_source_address, &ip_header.saddr, sizeof( struct in_addr ) );
      memcpy( &inet_destination_address, &ip_header.daddr, sizeof( struct in_addr ) );
      memset( inet_source_address_buffer, '\0', sizeof( inet_source_address_buffer ) );
      memset( inet_destination_address_buffer, '\0', sizeof( inet_destination_address_buffer ) );
      ip_string_pointer = inet_ntoa( inet_source_address );
      memcpy( inet_source_address_buffer, ip_string_pointer, strlen( ip_string_pointer ) );
      ip_string_pointer = inet_ntoa( inet_destination_address );
      memcpy( inet_destination_address_buffer, ip_string_pointer, strlen( ip_string_pointer ) );

      if ( fp == NULL ) {
        printf( "  ToS            : 0x%04x\n", ip_header.tos );
        printf( "  ID             : 0x%04x\n", Mntohs( ip_header.id ) );
        printf( "  Flag           : 0x%02x\n", ( ( ( Mntohs( ip_header.frag_off ) & 0xF000 ) >> 12 ) & 0xFF ) );
        printf( "  FlagOffset     : 0x%04x\n", ( Mntohs( ip_header.frag_off ) & 0x0FFF ) );
        printf( "  TTL            : 0x%02x\n", ( ip_header.ttl & 0xFF ) );
        printf( "  Protocol Num   : 0x%02x\n", ( ip_header.protocol & 0xFF ) );
        printf( "  Source IP      : %s\n", inet_source_address_buffer );
        printf( "  Destination IP : %s\n", inet_destination_address_buffer );
      }
      else {
        fprintf( fp, ",,,,,,,,," );
        fprintf( fp, "0x%04x,0x%04x,0x%02x,0x%04x,0x%02x,0x%02x,%s,%s,",
                 ip_header.tos,
                 Mntohs( ip_header.id ),
                 ( ( ( Mntohs( ip_header.frag_off ) & 0xF000 ) >> 12 ) & 0xFF ),
                 ( Mntohs( ip_header.frag_off ) & 0x0FFF ),
                 ( ip_header.ttl & 0xFF ),
                 ( ip_header.protocol & 0xFF ),
                 inet_source_address_buffer, inet_destination_address_buffer );
      }
      header_length = ( u_int ) ( ip_header.ihl * 4 );
      if ( header_length != sizeof( struct iphdr ) ) {
        if ( fp == NULL ) {
          printf( "  Option         : 0x" );
          for ( lp2 = 0; lp2 < ( header_length - sizeof( struct iphdr ) ); lp2++ ) {
            printf( "%02x", ( receive_analyze_buffer[ ( ntohl( statistics_packet_header->ip_header_offset ) + sizeof( struct iphdr ) + lp2 ) ] & 0xFF ) );
          }
          printf( "\n" );
        }
        else {
          fprintf( fp, "0x" );
          for ( lp2 = 0; lp2 < ( header_length - sizeof( struct iphdr ) ); lp2++ ) {
            fprintf( fp, "%02x", ( receive_analyze_buffer[ ( ntohl( statistics_packet_header->ip_header_offset ) + sizeof( struct iphdr ) + lp2 ) ] & 0xFF ) );
          }
          fprintf( fp, "," );
        }
      }
      else {
        if ( fp == NULL ) {
          printf( "    Option         : -\n" );
        }
        else {
          fprintf( fp, "," );
        }
      }
      payload_offset = ntohl( statistics_packet_header->ip_header_offset ) + header_length;
    }
    else {
      if ( fp == NULL ) {
        printf( "  ToS            : -\n" );
        printf( "  ID             : -\n" );
        printf( "  Flag           : -\n" );
        printf( "  FlagOffset     : -\n" );
        printf( "  TTL            : -\n" );
        printf( "  Protocol Num   : -\n" );
        printf( "  Source IP      : -\n" );
        printf( "  Destination IP : -\n" );
        printf( "  Option         : -\n" );
      }
      else {
        if ( ether_type == ETH_P_ARP ) {
          cli_make_arp_header( fp, ( u_char * ) ( packet_offset + payload_offset ) );
          payload_offset += ( ( u_int ) sizeof( struct in_addr ) * 2 ) + ( MAC_ADDRESS_LENGTH * 2 ) + ( u_int ) sizeof( struct arphdr );
        }
        else {
          fprintf( fp, ",,,,,,,,," );
        }
        fprintf( fp, ",,,,,,,,," );
      }
    }

    if ( statistics_packet_header->udp_header_offset != 0 ) {
      payload_offset = ntohl( statistics_packet_header->udp_header_offset ) + ( u_int ) sizeof( struct udphdr );
      memcpy( &udp_header, &receive_analyze_buffer[ ntohl( statistics_packet_header->udp_header_offset ) ], sizeof( struct udphdr ) );
      if ( fp == NULL ) {
        printf( "  Source Port      : 0x%04x\n", Mntohs( udp_header.source ) );
        printf( "  Destination Port : 0x%04x\n", Mntohs( udp_header.dest ) );
      }
      else {
        fprintf( fp, "0x%04x,0x%04x,", Mntohs( udp_header.source ), Mntohs( udp_header.dest ) );
      }
    }
    else {
      if ( fp == NULL ) {
        printf( "  Source Port      : -\n" );
        printf( "  Destination Port : -\n" );
      }
      else {
        fprintf( fp, ",," );
      }
    }

    packet_length = ntohl( statistics_packet_header->packet_length );
    if ( packet_length > payload_offset ) {
      if ( fp == NULL ) {
        printf( "  Payload          : 0x" );
        if ( MAX_PAYLOAD_DISPLAY_LENGTH > ( packet_length - payload_offset ) ) {
          payload_display_length = packet_length - payload_offset;
        }
        else {
          payload_display_length = MAX_PAYLOAD_DISPLAY_LENGTH;
        }
        for ( lp2 = 0; lp2 < payload_display_length; lp2++ ) {
          printf( "%02x", ( receive_analyze_buffer[ ( payload_offset + lp2 ) ] & 0xFF ) );
        }
        printf( "[0x%08x]\n", ntohl( statistics_packet_header->payload_hash ) );
      }
      else {
        packet_offset += payload_offset;
        fprintf( fp, "0x" );
        for ( lp2 = 0; lp2 < ( packet_length - payload_offset ); lp2++, packet_offset++ ) {
          fprintf( fp, "%02x", ( *packet_offset & 0xFF ) );
        }
      }
    }
    else {
      if ( fp == NULL ) {
        printf( "  Payload          : \n" );
      }
    }

    if ( fp == NULL ) {
      if ( ntohl( statistics_packet_header->packet_type ) == VHOST_STATISTICS_TYPE_SEND ) {
        printf( "    TX Byte      : %8" SCNd64 " byte\n", ntohll( statistics_packet_header->packet_data_byte ) );
        printf( "    TX Packets   : %8" SCNd64 "\n", ntohll( statistics_packet_header->packet_number ) );
      }
      else {
        printf( "    RX Byte      : %8" SCNd64 " byte\n",  ntohll( statistics_packet_header->packet_data_byte ) );
        printf( "    RX Packets   : %8" SCNd64 "\n", ntohll( statistics_packet_header->packet_number ) );
      }
    }
    else {
      fprintf( fp, ",%" SCNd64 ",%" SCNd64 "\n",
               ntohll( statistics_packet_header->packet_data_byte ),
               ntohll( statistics_packet_header->packet_number ) );
    }

    statistics_packet_header = ( VHOST_STATISTICS_DATA_POINTER ) ( ( u_char * ) statistics_packet_header
      + ntohl( statistics_packet_header->data_length ) );
  }
  return;
}


config_vhost_information_t *
cli_search_vhost_name( config_vhost_information_t *vhost_information, u_int vhost_max_num, char *vhost_name ) {
  u_int lp;
  config_vhost_information_t *current_vhost_information = vhost_information;

  for ( lp = 0; lp < vhost_max_num; lp++, current_vhost_information++ ) {
    if ( ( memcmp( current_vhost_information->vhost_name, vhost_name, strlen( vhost_name ) ) == 0 )
       && ( strlen( vhost_name ) == strlen( current_vhost_information->vhost_name ) ) ) {
      return current_vhost_information;
    }
  }
  return NULL;
}


config_vhost_information_t *
cli_get_vhost_from_controller( config_vhost_information_t *vhost_information, u_int vhost_num, char *controller_name, u_int *controller_vhost_num ) {
  u_int lp;
  u_int search_num = 0;
  config_vhost_information_t *result_vhost_information;
  config_vhost_information_t *current_result_vhost_information;
  config_vhost_information_t *current_vhost_information = vhost_information;

  *controller_vhost_num = 0;
  for ( lp = 0; lp < vhost_num; lp++, current_vhost_information++ ) {
    if ( ( memcmp( current_vhost_information->vhost_info.controller.controller_name, controller_name, strlen( controller_name ) ) == 0 )
       && ( strlen( controller_name ) == strlen( current_vhost_information->vhost_info.controller.controller_name ) ) ) {
      search_num += 1;
    }
  }

  if ( search_num == 0 ) {
    return NULL;
  }

  result_vhost_information = ( config_vhost_information_t * ) calloc( search_num, sizeof( config_vhost_information_t ) );
  if ( result_vhost_information == NULL ) {
    return NULL;
  }

  current_result_vhost_information = result_vhost_information;
  current_vhost_information = vhost_information;
  for ( lp = 0; lp < vhost_num; lp++, current_vhost_information++ ) {
    if ( ( memcmp( current_vhost_information->vhost_info.controller.controller_name, controller_name, strlen( controller_name ) ) == 0 )
       && ( strlen( controller_name ) == strlen( current_vhost_information->vhost_info.controller.controller_name ) ) ) {
      memcpy( current_result_vhost_information, current_vhost_information, sizeof( config_vhost_information_t ) );
      current_result_vhost_information += 1;
    }
  }

  *controller_vhost_num = search_num;
  return result_vhost_information;
}


void
cli_show_arp_detail( int socket_fd ) {
  VHOST_ARP_GET_ANSWER_BLOCK_POINTER vhost_arp_answer_pointer;
  VHOST_ARP_CONTROL_BLOCK_POINTER vhost_arp_control_pointer;
  int rc;
  char vhost_name[ MAX_VHOST_NAME_LENGTH + 4 ];
  char mac_address_string[ 64 ];
  u_int total_size;
  char print_buffer[ 256 ];
  char print_buffer_work[ 32 ];
  char *inet_string;
  u_char *receive_buffer;
  u_int receive_size;
  uint64_t max_arp_num;
  u_int arp_num;
  u_short vlan_id;
  struct in_addr inet_address;

  rc = com_socket_data_copy( socket_fd, ( u_char * ) &receive_size, sizeof( receive_size ) );
  if ( rc != TRUE ) {
    com_socket_close( socket_fd );
    return;
  }

  total_size = ntohl( receive_size );
  receive_buffer = ( u_char * ) calloc( 1, total_size );
  if ( receive_buffer == NULL ) {
    com_socket_close( socket_fd );
    return;
  }

  rc = com_socket_receive( socket_fd, receive_buffer, total_size );
  if ( rc != TRUE ) {
    free( receive_buffer );
    com_socket_close( socket_fd );
    return;
  }

  vhost_arp_answer_pointer = ( VHOST_ARP_GET_ANSWER_BLOCK_POINTER ) ( ( u_char * ) receive_buffer + sizeof( PACKET_HEADER ) );

  max_arp_num = ntohll( vhost_arp_answer_pointer->arp_total );
  vhost_arp_control_pointer = ( VHOST_ARP_CONTROL_BLOCK_POINTER ) ( ( u_char * ) vhost_arp_answer_pointer
    + sizeof( VHOST_ARP_GET_ANSWER_BLOCK ) );
  memset( vhost_name, '\0', sizeof( vhost_name ) );
  memcpy( vhost_name, vhost_arp_answer_pointer->header.vhost_name, MAX_VHOST_NAME_LENGTH );
  printf( "Virtual Host Name  : %s\n", vhost_name );
  // print running vhost
  printf( "  IP Address                MAC Address                     Expire\n" );

  for ( arp_num = 0; arp_num < max_arp_num; arp_num++, vhost_arp_control_pointer++ ) {
    memset( print_buffer, '\0', sizeof( print_buffer ) );

    memcpy( &inet_address, &vhost_arp_control_pointer->ipv4_address, sizeof( struct in_addr ) );
    inet_string = inet_ntoa( inet_address );

    sprintf( print_buffer, "  %s", inet_string );

    if ( strlen( print_buffer ) < SHOW_ARP_MAC_ADDRESS_OFFSET ) {
      memset( ( void * ) &print_buffer[ strlen( print_buffer ) ], ' ', SHOW_ARP_MAC_ADDRESS_OFFSET - strlen( print_buffer ) );
    }
    memset( mac_address_string, '\0', sizeof( mac_address_string ) );

    cli_binmac2macstr( vhost_arp_control_pointer->mac_address, mac_address_string );
    strcat( print_buffer, mac_address_string );

    if ( strlen( print_buffer ) < SHOW_ARP_EXPIRE_OFFSET ) {
      memset( ( void * ) &print_buffer[ strlen( print_buffer ) ], ' ', SHOW_ARP_EXPIRE_OFFSET - strlen( print_buffer ) );
    }

    vlan_id = Mntohs( vhost_arp_control_pointer->vlan_id );
    if ( ( vlan_id & VHOST_ARP_INFORMATION_STATIC_ARP_ENTRY ) == VHOST_ARP_INFORMATION_STATIC_ARP_ENTRY ) {
      strcat( print_buffer, "static" );
    }
    else {
      memset( print_buffer_work, '\0', sizeof( print_buffer_work ) );
      sprintf( print_buffer_work, "%d", ntohl( vhost_arp_control_pointer->arp_expire_time ) );
      strcat( print_buffer, print_buffer_work );
    }
    printf( "%s\n", print_buffer );
  }

  free( receive_buffer );
  return;
}


void
cli_get_statistics_detail( int socket_fd, FILE *fp ) {
  VHOST_STATISTICS_ANSWER_BLOCK_POINTER vhost_statistics_answer_pointer;
  int rc;
  u_int total_size;
  u_char *receive_buffer;
  u_int receive_size;

  rc = com_socket_data_copy( socket_fd, ( u_char * ) &receive_size, sizeof( receive_size ) );
  if ( rc != TRUE ) {
    com_socket_close( socket_fd );
    return;
  }

  total_size = ntohl( receive_size );
  receive_buffer = ( u_char * ) calloc( 1, total_size );
  if ( receive_buffer == NULL ) {
    com_socket_close( socket_fd );
    return;
  }

  rc = com_socket_receive( socket_fd, receive_buffer, total_size );
  if ( rc != TRUE ) {
    free( receive_buffer );
    com_socket_close( socket_fd );
    return;
  }
  vhost_statistics_answer_pointer = ( VHOST_STATISTICS_ANSWER_BLOCK_POINTER ) ( ( u_char * ) receive_buffer + sizeof( PACKET_HEADER ) );

  cli_decode_statistics_buffer( vhost_statistics_answer_pointer, fp );

  free( receive_buffer );
  return;
}


void
cli_get_statistics_all( FILE *fp ) {
  config_controller_detail_t *controller;
  config_controller_detail_t *current_controller;
  config_vhost_information_t *vhost_information;
  config_vhost_information_t *controller_vhost_information;
  config_vhost_information_t *current_vhost_information;
  u_char *send_buffer;
  u_int controller_vhost_num;
  int rc;
  u_int total_size;
  u_int vhost_num;
  u_int vhost_max_num;
  int socket_fd;
  u_int controller_max_num;
  u_int controller_num;
  struct tm local_time;
  time_t current_time;
  char current_date[ 32 ];

  PACKET_HEADER_POINTER packet_header;
  VHOST_STATISTICS_REQUEST_BLOCK_POINTER statistics_request_pointer;

  current_time = time( NULL );

  controller = config_get_controller_information( &controller_max_num );
  current_controller = controller;

  // print format header
  if ( fp == NULL ) {
    localtime_r( &current_time, &local_time );
    memset( current_date, '0', sizeof( current_date ) );
    strftime( current_date, ( sizeof( current_date ) - 1 ), "%Y/%m/%d %H:%M:%S", &local_time );
    printf( "Time        :%s \n", current_date );
    if ( controller == NULL ) {
      return;
    }
  }

  vhost_information = config_get_all_vhost_information( &vhost_max_num );

  for ( controller_num = 0; controller_num < controller_max_num; controller_num++, current_controller++ ) {
    controller_vhost_information = cli_get_vhost_from_controller( vhost_information, vhost_max_num,
                                                                  current_controller->controller_name, &controller_vhost_num );
    if ( controller_vhost_num == 0 ) {
      continue;
    }
    // create command
    total_size = ( u_int ) sizeof( PACKET_HEADER ) + ( controller_vhost_num * ( ( u_int ) sizeof( VHOST_STATISTICS_REQUEST_BLOCK ) ) );
    send_buffer = ( u_char * ) calloc( 1, total_size );

    if ( send_buffer == NULL ) {
      continue;
    }

    packet_header = ( PACKET_HEADER_POINTER ) send_buffer;
    statistics_request_pointer = ( VHOST_STATISTICS_REQUEST_BLOCK_POINTER ) ( ( u_char * ) send_buffer + sizeof( PACKET_HEADER ) );

    packet_header->size = htonl( total_size );
    packet_header->packet_num = htonl( controller_vhost_num );          // only request
    current_vhost_information = controller_vhost_information;

    for ( vhost_num = 0; vhost_num < controller_vhost_num; vhost_num++, current_vhost_information++, statistics_request_pointer++ ) {
      statistics_request_pointer->header.command_code = htonl( VHOST_STATISTICS_GET_REQUEST );
      statistics_request_pointer->header.length = htonl( sizeof( VHOST_STATISTICS_REQUEST_BLOCK ) );
      memcpy( statistics_request_pointer->header.vhost_name, current_vhost_information->vhost_name, MAX_VHOST_NAME_LENGTH );
    }

    socket_fd = com_socket_connect( htonl( ( u_int ) inet_addr( current_controller->ip_address ) ), CLI_INTERFACE_PORT );
    if ( socket_fd < 0 ) {
      free( controller_vhost_information );
      free( send_buffer );
      continue;
    }
    rc = com_socket_send( socket_fd, send_buffer, total_size );
    if ( rc != TRUE ) {
      free( controller_vhost_information );
      free( send_buffer );
      com_socket_close( socket_fd );
      continue;
    }

    free( send_buffer );

    for ( vhost_num = 0; vhost_num < controller_vhost_num; vhost_num++ ) {
      cli_get_statistics_detail( socket_fd, fp );
    }
    free( controller_vhost_information );
    com_socket_close( socket_fd );
  }

  free( controller );
  free( vhost_information );
  return;
}


void
cli_get_statistics_one( char *vhost_name, FILE *fp ) {
  char ip_address[ IP_SIZE + 1 ];
  u_char send_buffer[ 256 ];
  int rc;
  u_int total_size;
  int socket_fd;
  u_int controller_max_num;
  u_int controller_num;
  struct tm local_time;
  time_t current_time;
  char current_date[ 32 ];
  config_vhost_information_t *vhost_information;
  config_controller_detail_t *controller;
  config_controller_detail_t *current_controller;

  PACKET_HEADER_POINTER packet_header;
  VHOST_STATISTICS_REQUEST_BLOCK_POINTER statistics_request_pointer;

  vhost_information = config_get_vhost_information( cli_vhostname );
  if ( vhost_information == NULL ) {
    return;
  }
  controller = config_get_controller_information( &controller_max_num );
  if ( controller == NULL ) {
    free( vhost_information );
    return;
  }
  current_controller = controller;
  for ( controller_num = 0; controller_num < controller_max_num; controller_num++, current_controller++ ) {
    if ( ( memcmp( vhost_information->vhost_info.controller.controller_name, current_controller->controller_name,
      strlen( current_controller->controller_name ) ) == 0 )
       && ( strlen( current_controller->controller_name )
      == strlen( vhost_information->vhost_info.controller.controller_name ) ) ) {
      memcpy( ip_address, current_controller->ip_address, IP_SIZE );
      break;
    }
  }
  free( controller );
  free( vhost_information );

  current_time = time( NULL );

  if ( fp == NULL ) {
    // print format header
    localtime_r( &current_time, &local_time );
    memset( current_date, '\0', sizeof( current_date ) );
    strftime( current_date, ( sizeof( current_date ) - 1 ), "%Y/%m/%d %H:%M:%S", &local_time );
    printf( "Time        :%s \n", current_date );
  }

  memset( send_buffer, '\0', sizeof( send_buffer ) );

  total_size = sizeof( PACKET_HEADER ) + sizeof( VHOST_STATISTICS_REQUEST_BLOCK );

  packet_header = ( PACKET_HEADER_POINTER ) send_buffer;
  statistics_request_pointer = ( VHOST_STATISTICS_REQUEST_BLOCK_POINTER ) ( ( u_char * ) send_buffer + sizeof( PACKET_HEADER ) );

  packet_header->size = htonl( total_size );
  packet_header->packet_num = htonl( 1 );       // only request

  statistics_request_pointer->header.command_code = htonl( VHOST_STATISTICS_GET_REQUEST );
  statistics_request_pointer->header.length = htonl( sizeof( VHOST_STATISTICS_REQUEST_BLOCK ) );
  memcpy( statistics_request_pointer->header.vhost_name, vhost_name, MAX_VHOST_NAME_LENGTH );

  socket_fd = com_socket_connect( htonl( ( u_int ) inet_addr( ip_address ) ), CLI_INTERFACE_PORT );
  if ( socket_fd < 0 ) {
    return;
  }
  rc = com_socket_send( socket_fd, send_buffer, total_size );
  if ( rc != TRUE ) {
    return;
  }

  cli_get_statistics_detail( socket_fd, fp );
  com_socket_close( socket_fd );
  return;
}


void
cli_display_stop_vhost( config_vhost_information_t *controller_vhost_information, u_int controller_vhost_num ) {
  char print_buffer[ 256 ];
  u_int vhost_num;

  // print stop vhost
  for ( vhost_num = 0; vhost_num < controller_vhost_num; vhost_num++ ) {
    // already print
    if ( controller_vhost_information[ vhost_num ].vhost_name[ 0 ] == '\0' ) {
      continue;
    }
    memset( print_buffer, '\0', sizeof( print_buffer ) );

    sprintf( print_buffer,  "%s", controller_vhost_information[ vhost_num ].vhost_name );
    if ( strlen( print_buffer ) < SHOW_VHOST_IP_ADDRESS_PRINT_OFFSET ) {
      memset( &print_buffer[ strlen( print_buffer ) ], ' ', SHOW_VHOST_IP_ADDRESS_PRINT_OFFSET - strlen( print_buffer ) );
    }
    strcat( print_buffer, controller_vhost_information[ vhost_num ].vhost_info.ip_addr.ip_address );
    if ( strlen( print_buffer ) < SHOW_VHOST_MAC_ADDRESS_PRINT_OFFSET ) {
      memset( &print_buffer[ strlen( print_buffer ) ], ' ', SHOW_VHOST_MAC_ADDRESS_PRINT_OFFSET - strlen( print_buffer ) );
    }

    strcat( print_buffer, controller_vhost_information[ vhost_num ].vhost_info.mac_addr.mac_address );
    if ( strlen( print_buffer ) < SHOW_VHOST_STATUS_PRINT_OFFSET ) {
      memset( &print_buffer[ strlen( print_buffer ) ], ' ', SHOW_VHOST_STATUS_PRINT_OFFSET - strlen( print_buffer ) );
    }
    strcat( print_buffer, SHOW_VHOST_STOP_MESSAGE );
    printf( "%s\n", print_buffer );
  }
  return;
}


/******************************************************************************
 * command interface                                                          *
 ******************************************************************************/
ECLI_RESULT
cli_do_show_vhost() {
  config_controller_detail_t *controller;
  config_controller_detail_t *current_controller;
  config_vhost_information_t *vhost_information;
  config_vhost_information_t *controller_vhost_information;
  config_vhost_information_t *current_vhost_information;
  char print_buffer[ 256 ];
  u_int controller_vhost_num;
  int rc;
  u_int total_size;
  u_int vhost_num;
  u_int vhost_max_num;
  int socket_fd;
  u_int controller_max_num;
  u_int controller_num;
  struct tm local_time;
  time_t current_time;
  char current_date[ 32 ];
  u_char send_buffer[ 256 ];
  u_char *receive_buffer;
  u_char *vhost_name_pointer;
  u_int receive_size;
  char vhost_name[ MAX_VHOST_NAME_LENGTH + 4 ];
  u_int max_vhost_num;

  PACKET_HEADER_POINTER packet_header = ( PACKET_HEADER_POINTER ) send_buffer;
  VHOST_STATUS_REQUEST_BLOCK_POINTER status_request_pointer = ( VHOST_STATUS_REQUEST_BLOCK_POINTER ) &send_buffer[ sizeof( PACKET_HEADER ) ];
  VHOST_STATUS_ANSWER_BLOCK_POINTER vhost_status_answer_pointer;

  // create command
  memset( send_buffer, '\0', sizeof( send_buffer ) );

  packet_header->size = htonl( sizeof( PACKET_HEADER ) + sizeof( VHOST_STATUS_REQUEST_BLOCK ) );
  packet_header->packet_num = htonl( 1 );       // only request

  status_request_pointer->header.command_code = htonl( VHOST_STATUS_REQUEST );
  status_request_pointer->header.length = htonl( sizeof( VHOST_STATUS_REQUEST_BLOCK ) );
  status_request_pointer->request_code = htonl( VHOST_STATUS_REQUEST_ALL );

  current_time = time( NULL );

  controller = config_get_controller_information( &controller_max_num );
  current_controller = controller;

  // print format header
  localtime_r( &current_time, &local_time );
  memset( current_date, '\0', sizeof( current_date ) );
  strftime( current_date, ( sizeof( current_date ) - 1 ), "%Y/%m/%d %H:%M:%S", &local_time );
  printf( "Time        : %s \n", current_date );
  printf( "Virtual Host Name       IP Address      MAC Address           Status\n" );
  if ( controller == NULL ) {
    return CLI_OK;
  }

  vhost_information = config_get_all_vhost_information( &vhost_max_num );

  for ( controller_num = 0; controller_num < controller_max_num; controller_num++, current_controller++ ) {
    controller_vhost_information = cli_get_vhost_from_controller( vhost_information, vhost_max_num,
                                                                  current_controller->controller_name, &controller_vhost_num );
    if ( controller_vhost_num == 0 ) {
      continue;
    }

    socket_fd = com_socket_connect( htonl( ( u_int ) inet_addr( current_controller->ip_address ) ), CLI_INTERFACE_PORT );
    if ( socket_fd < 0 ) {
      cli_display_stop_vhost( controller_vhost_information, controller_vhost_num );
      free( controller_vhost_information );
      continue;
    }
    rc = com_socket_send( socket_fd, ( u_char * ) send_buffer, sizeof( PACKET_HEADER ) + sizeof( VHOST_STATUS_REQUEST_BLOCK ) );
    if ( rc != TRUE ) {
      cli_display_stop_vhost( controller_vhost_information, controller_vhost_num );
      free( controller_vhost_information );
      com_socket_close( socket_fd );
      continue;
    }

    rc = com_socket_data_copy( socket_fd, ( u_char * ) &receive_size, sizeof( receive_size ) );
    if ( rc != TRUE ) {
      cli_display_stop_vhost( controller_vhost_information, controller_vhost_num );
      free( controller_vhost_information );
      com_socket_close( socket_fd );
      continue;
    }

    total_size = htonl( receive_size );
    receive_buffer = ( u_char * ) calloc( 1, total_size );
    if ( receive_buffer == NULL ) {
      cli_display_stop_vhost( controller_vhost_information, controller_vhost_num );
      free( controller_vhost_information );
      com_socket_close( socket_fd );
      continue;
    }
    rc = com_socket_receive( socket_fd, receive_buffer, total_size );
    if ( rc != TRUE ) {
      cli_display_stop_vhost( controller_vhost_information, controller_vhost_num );
      free( receive_buffer );
      free( controller_vhost_information );
      com_socket_close( socket_fd );
      continue;
    }
    com_socket_close( socket_fd );

    packet_header = ( PACKET_HEADER_POINTER ) receive_buffer;
    vhost_status_answer_pointer = ( VHOST_STATUS_ANSWER_BLOCK_POINTER ) ( ( u_char * ) receive_buffer + sizeof( PACKET_HEADER ) );

    max_vhost_num = htonl( vhost_status_answer_pointer->vhost_num );
    vhost_name_pointer = ( u_char * ) vhost_status_answer_pointer + sizeof( VHOST_STATUS_ANSWER_BLOCK );

    // print running vhost
    for ( vhost_num = 0; vhost_num < max_vhost_num; vhost_num++ ) {
      memset( vhost_name, '\0', sizeof( vhost_name ) );
      memcpy( vhost_name, vhost_name_pointer, MAX_VHOST_NAME_LENGTH );
      vhost_name_pointer += MAX_VHOST_NAME_LENGTH;

      current_vhost_information = cli_search_vhost_name( controller_vhost_information, controller_vhost_num, vhost_name );
      if ( current_vhost_information == NULL ) {
        continue;
      }
      memset( print_buffer, '\0', sizeof( print_buffer ) );

      sprintf( print_buffer,  "%s", vhost_name );
      if ( strlen( print_buffer ) < SHOW_VHOST_IP_ADDRESS_PRINT_OFFSET ) {
        memset( ( void * ) &print_buffer[ strlen( print_buffer ) ], ' ', SHOW_VHOST_IP_ADDRESS_PRINT_OFFSET - strlen( print_buffer ) );
      }
      strcat( print_buffer, current_vhost_information->vhost_info.ip_addr.ip_address );
      if ( strlen( print_buffer ) < SHOW_VHOST_MAC_ADDRESS_PRINT_OFFSET ) {
        memset( &print_buffer[ strlen( print_buffer ) ], ' ', SHOW_VHOST_MAC_ADDRESS_PRINT_OFFSET - strlen( print_buffer ) );
      }

      strcat( print_buffer, current_vhost_information->vhost_info.mac_addr.mac_address );
      if ( strlen( print_buffer ) < SHOW_VHOST_STATUS_PRINT_OFFSET ) {
        memset( &print_buffer[ strlen( print_buffer ) ], ' ', SHOW_VHOST_STATUS_PRINT_OFFSET - strlen( print_buffer ) );
      }
      strcat( print_buffer, SHOW_VHOST_RUNNING_MESSAGE );
      current_vhost_information->vhost_name[ 0 ] = '\0';
      printf( "%s\n", print_buffer );
    }
    cli_display_stop_vhost( controller_vhost_information, controller_vhost_num );
    free( controller_vhost_information );

    free( receive_buffer );
  }

  free( controller );
  free( vhost_information );
  return CLI_OK;
}


ECLI_RESULT
cli_do_show_statistics_all() {
  cli_get_statistics_all( NULL );

  return CLI_OK;
}


ECLI_RESULT
cli_do_show_statistics_vhostname() {
  cli_get_statistics_one( cli_vhostname, NULL );
  return CLI_OK;
}


ECLI_RESULT
cli_do_show_statistics_vhostname_file() {
  FILE *fp;

  fp = fopen( cli_show_statistics_filename, "w" );
  if ( fp == NULL ) {
    return CLI_NG;
  }
  fprintf( fp, "VHOSTname,send/receive,Source MAC Address,Destination MAC Address,Ether Type,CoS,VLAN ID," );
  fprintf( fp,
    "HardType,Protocol Type,HardwareLength,ProtocolLength,Operation Code,source MAC Address,Source IP Address,Distination MAC Address,Distination IP Address," );
  fprintf( fp, "ToS,ID,Flag,FlagOffset,TTL,Protocol Number,Source IP Address,Destination IP Address,IP Option" );
  fprintf( fp, ",UDP Source Port, UDP Destination Port,Payload,TX/RX Byte, TX/RX Packets\n" );
  if ( cli_show_statistics_kind == 0 ) {
    cli_get_statistics_all( fp );
  }
  else {
    cli_get_statistics_one( cli_vhostname, fp );
  }

  fclose( fp );
  return CLI_OK;
}


ECLI_RESULT
cli_do_show_arp_all() {
  config_controller_detail_t *controller;
  config_controller_detail_t *current_controller;
  config_vhost_information_t *vhost_information;
  config_vhost_information_t *controller_vhost_information;
  config_vhost_information_t *current_vhost_information;
  u_char *send_buffer;
  u_int controller_vhost_num;
  int rc;
  u_int total_size;
  u_int vhost_num;
  u_int vhost_max_num;
  int socket_fd;
  u_int controller_max_num;
  u_int controller_num;
  struct tm local_time;
  time_t current_time;
  char current_date[ 32 ];

  PACKET_HEADER_POINTER packet_header;
  VHOST_ARP_GET_REQUEST_BLOCK_POINTER arp_request_pointer;

  current_time = time( NULL );

  controller = config_get_controller_information( &controller_max_num );
  current_controller = controller;

  // print format header
  localtime_r( &current_time, &local_time );
  memset( current_date, '\0', sizeof( current_date ) );
  strftime( current_date, ( sizeof( current_date ) - 1 ), "%Y/%m/%d %H:%M:%S", &local_time );
  printf( "Time        :%s \n", current_date );
  if ( controller == NULL ) {
    return CLI_OK;
  }

  vhost_information = config_get_all_vhost_information( &vhost_max_num );

  for ( controller_num = 0; controller_num < controller_max_num; controller_num++, current_controller++ ) {
    controller_vhost_information = cli_get_vhost_from_controller( vhost_information, vhost_max_num,
                                                                  current_controller->controller_name, &controller_vhost_num );
    if ( controller_vhost_num == 0 ) {
      continue;
    }
    // create command
    total_size = ( u_int ) sizeof( PACKET_HEADER ) + ( controller_vhost_num * ( ( u_int ) sizeof( VHOST_ARP_GET_REQUEST_BLOCK ) ) );
    send_buffer = ( u_char * ) calloc( 1, total_size );

    if ( send_buffer == NULL ) {
      continue;
    }

    packet_header = ( PACKET_HEADER_POINTER ) send_buffer;
    arp_request_pointer = ( VHOST_ARP_GET_REQUEST_BLOCK_POINTER ) ( ( u_char * ) send_buffer + sizeof( PACKET_HEADER ) );

    packet_header->size = htonl( total_size );
    packet_header->packet_num = htonl( controller_vhost_num );          // only request
    current_vhost_information = controller_vhost_information;

    for ( vhost_num = 0; vhost_num < controller_vhost_num; vhost_num++, current_vhost_information++, arp_request_pointer++ ) {
      arp_request_pointer->header.command_code = htonl( VHOST_ARP_INFORMATION_REQUEST );
      arp_request_pointer->header.length = htonl( sizeof( VHOST_ARP_GET_REQUEST_BLOCK ) );
      memcpy( arp_request_pointer->header.vhost_name, current_vhost_information->vhost_name, MAX_VHOST_NAME_LENGTH );
    }

    socket_fd = com_socket_connect( htonl( ( u_int ) inet_addr( current_controller->ip_address ) ), CLI_INTERFACE_PORT );
    if ( socket_fd < 0 ) {
      free( controller_vhost_information );
      free( send_buffer );
      continue;
    }
    rc = com_socket_send( socket_fd, send_buffer, total_size );
    if ( rc != TRUE ) {
      free( controller_vhost_information );
      free( send_buffer );
      com_socket_close( socket_fd );
      continue;
    }

    free( send_buffer );

    for ( vhost_num = 0; vhost_num < controller_vhost_num; vhost_num++ ) {
      cli_show_arp_detail( socket_fd );
    }
    free( controller_vhost_information );
    com_socket_close( socket_fd );
  }

  free( controller );
  free( vhost_information );
  return CLI_OK;
}


ECLI_RESULT
cli_do_show_arp_vhostname() {
  char ip_address[ IP_SIZE + 1 ];
  u_char send_buffer[ 256 ];
  int rc;
  u_int total_size;
  u_int controller_max_num;
  u_int controller_num;
  int socket_fd;
  struct tm local_time;
  time_t current_time;
  char current_date[ 32 ];
  config_vhost_information_t *vhost_information;
  config_controller_detail_t *controller;
  config_controller_detail_t *current_controller;

  PACKET_HEADER_POINTER packet_header;
  VHOST_ARP_GET_REQUEST_BLOCK_POINTER arp_request_pointer;

  vhost_information = config_get_vhost_information( cli_vhostname );
  if ( vhost_information == NULL ) {
    return CLI_NG;
  }

  controller = config_get_controller_information( &controller_max_num );
  if ( controller == NULL ) {
    free( vhost_information );
    return CLI_NG;
  }
  current_controller = controller;
  for ( controller_num = 0; controller_num < controller_max_num; controller_num++, current_controller++ ) {
    if ( ( memcmp( vhost_information->vhost_info.controller.controller_name, current_controller->controller_name,
      strlen( current_controller->controller_name ) ) == 0 )
       && ( strlen( current_controller->controller_name )
      == strlen( vhost_information->vhost_info.controller.controller_name ) ) ) {
      memcpy( ip_address, current_controller->ip_address, IP_SIZE );

      break;
    }
  }

  free( controller );
  free( vhost_information );

  current_time = time( NULL );

  // print format header
  memset( current_date, '\0', sizeof( current_date ) );
  localtime_r( &current_time, &local_time );
  strftime( current_date, ( sizeof( current_date ) - 1 ), "%Y/%m/%d %H:%M:%S", &local_time );
  printf( "Time        :%s \n", current_date );

  memset( send_buffer, '\0', sizeof( send_buffer ) );

  total_size = sizeof( PACKET_HEADER ) + sizeof( VHOST_ARP_GET_REQUEST_BLOCK );

  packet_header = ( PACKET_HEADER_POINTER ) send_buffer;
  arp_request_pointer = ( VHOST_ARP_GET_REQUEST_BLOCK_POINTER ) ( ( u_char * ) send_buffer + sizeof( PACKET_HEADER ) );

  packet_header->size = htonl( total_size );
  packet_header->packet_num = htonl( 1 );       // only request

  arp_request_pointer->header.command_code = htonl( VHOST_ARP_INFORMATION_REQUEST );
  arp_request_pointer->header.length = htonl( sizeof( VHOST_ARP_GET_REQUEST_BLOCK ) );
  memcpy( arp_request_pointer->header.vhost_name, cli_vhostname, MAX_VHOST_NAME_LENGTH );

  socket_fd = com_socket_connect( htonl( ( u_int ) inet_addr( ip_address ) ), CLI_INTERFACE_PORT );
  if ( socket_fd < 0 ) {
    return CLI_OK;
  }
  rc = com_socket_send( socket_fd, send_buffer, total_size );
  if ( rc != TRUE ) {
    return CLI_OK;
  }

  cli_show_arp_detail( socket_fd );
  com_socket_close( socket_fd );

  return CLI_OK;
}
