#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
#include <sys/stat.h>

#include "cli_define.h"
#include "cli_struct.h"
#include "cli_extern.h"

#include "packet.h"
#include "configif.h"
#include "cmn.h"
#include "com_socket.h"
#include "config_lib.h"

static char cli_controller_name[ CONTROLLER_NAME_SIZE + 1 ] = "";
static char cli_controller_ip[ IP_SIZE ] = "";
static char cli_save_file[ CLI_SAVEFILE_SIZE ] = "";

ECLI_RESULT
cli_send_to_config( config_cmd_interface_t *interface ) {
  int result;
  char path[ 108 ] = "";
  int count = 3;
  struct timespec sleep_timevalue;

  while ( 1 ) {
    result = com_socket_send( cli_socket_fd, ( u_char * ) interface, sizeof( config_cmd_interface_t ) );
    if ( result != TRUE ) {
      if ( count > 0 ) {
        sleep_timevalue.tv_sec = 0x01;
        sleep_timevalue.tv_nsec = 0x00;
        nanosleep( &sleep_timevalue, NULL );
        sprintf( path, "%s%s", TMP_DIR, CONNECT_PATH );
        cli_socket_fd = com_socket_unix_connect( path );
        count--;
        continue;
      }
      MCLI_ERROR( ( CLI_ERROR_CONFIGNOTRUNNING ) );
      return CLI_NG_EXIT_ERRORLOG;
    }

    result = com_socket_receive( cli_socket_fd, ( u_char * ) interface, sizeof( config_cmd_interface_t ) );
    if ( result != TRUE ) {
      MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
      return CLI_NG_EXIT_ERRORLOG;
    }
    break;
  }

  return CLI_OK;
}


ECLI_RESULT
cli_do_noconfig( ECONFIG_COMMAND command ) {
  config_cmd_interface_t interface;
  ECLI_RESULT result;

  memset( &interface, 0x00, sizeof( interface ) );

  // set config parameter
  interface.head.command = command;
  strcpy( interface.head.vhost_name, cli_vhost_name );
  interface.head.set_kind = CONFIG_DELETE;

  result = cli_send_to_config( &interface );
  if ( result != CLI_OK ) {
    cli_do_word_init();
    return result;
  }

  // initialize word chain
  cli_do_word_init();

  return CLI_OK;
}


ECLI_RESULT
cli_do_config_vhost() {
  config_cmd_interface_t interface;
  int result;

  memset( &interface, 0x00, sizeof( interface ) );

  // send config
  interface.head.command = CONFIG_VHOST_REQUEST;
  interface.head.set_kind = CONFIG_ADD;
  strcpy( interface.command.config_vhost.kind.add.vhost_name, cli_vhost_name );

  result = cli_send_to_config( &interface );
  if ( result != CLI_OK ) {
    cli_do_word_init();
    return result;
  }

  if ( interface.head.result != CONFIG_OK ) {
    MCLI_ERROR( ( CLI_ERROR_CONFIG_SET_NG ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  memset( cli_prompt, 0x00, sizeof( cli_prompt ) );
  sprintf( cli_prompt, CLI_PROMPT_VHOST, ( char * ) cli_vhost_name );

  cli_mode = CLI_VHOSTMODE;
  cli_command_word = clidata_vhost_word;

  // initialize word chain
  cli_do_word_init();

  return CLI_OK;
}


ECLI_RESULT
cli_set_config_vhost( void *vhost_name ) {
  if ( strlen( vhost_name ) > 32 ) {
    MCLI_ERROR( ( CLI_ERROR_LENGTHERROR, ( char * ) vhost_name ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  if ( CLI_OK != cli_check_digit( CLI_CHECK_LNUM, ( u_char * ) vhost_name ) ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_VHOSTNAME ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  memset( cli_vhost_name, 0x00, sizeof( cli_vhost_name ) );
  sprintf( cli_vhost_name, "%s", ( char * ) vhost_name );

  return CLI_OK;
}


ECLI_RESULT
cli_do_config_no_vhost() {
  config_cmd_interface_t interface;
  int result;
  ECLI_VHOST_STATUS status;

  status = cli_get_vhost_status( cli_vhost_name );
  if ( status == CLI_VHOST_UP ) {
    MCLI_ERROR( ( CLI_ERROR_VHOSTRUNNING, cli_vhost_name ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  memset( &interface, 0x00, sizeof( interface ) );

  // send config
  interface.head.command = CONFIG_VHOST_REQUEST;
  interface.head.set_kind = CONFIG_DELETE;
  interface.command.config_vhost.kind.del.kind = CONFIG_INDIVIDUAL;
  strcpy( interface.command.config_vhost.kind.del.vhost_name, cli_vhost_name );

  result = cli_send_to_config( &interface );
  if ( result != CLI_OK ) {
    cli_do_word_init();
    return result;
  }

  if ( interface.head.result != CONFIG_OK ) {
    MCLI_ERROR( ( CLI_ERROR_CONFIG_DELETE_NG ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  // initialize word chain
  cli_do_word_init();

  return CLI_OK;
}


ECLI_RESULT
cli_do_config_no_vhost_all() {
  config_vhost_information_t *vhost_information;
  u_int vhost_num;
  u_int count;

  vhost_information = config_get_all_vhost_information( &vhost_num );
  if ( vhost_information == NULL ) {
    return CLI_NG_EXIT_ERRORLOG;
  }

  for ( count = 0; count < vhost_num; count++ ) {
    strcpy( cli_vhost_name, vhost_information[ count ].vhost_name );
    cli_do_config_no_vhost( NULL );
  }
  free( vhost_information );

  // initialize word chain
  cli_do_word_init();

  return CLI_OK;
}


ECLI_RESULT
cli_do_config_controller() {
  config_cmd_interface_t interface;
  int result;

  memset( &interface, 0x00, sizeof( interface ) );

  // send config
  interface.head.command = CONFIG_CONTROLLER_REQUEST;
  interface.head.set_kind = CONFIG_ADD;
  strcpy( interface.command.config_controller.kind.add.controller_name, cli_controller_name );
  strcpy( interface.command.config_controller.kind.add.ip_address, cli_controller_ip );

  result = cli_send_to_config( &interface );
  if ( result != CLI_OK ) {
    return result;
  }

  if ( interface.head.result == CONFIG_NG ) {
    MCLI_ERROR( ( CLI_ERROR_CONFIG_SET_NG ) );
    return CLI_NG_EXIT_ERRORLOG;
  }
  else if ( interface.head.result == CONFIG_DUPLICATE_NG ) {
    MCLI_ERROR( ( CLI_ERROR_DUPLICATE_NG, cli_controller_ip ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  // initialize word chain
  cli_do_word_init();

  return CLI_OK;
}


ECLI_RESULT
cli_set_config_controller_ip( void *ip_address ) {
  if ( strlen( ip_address ) > IP_SIZE ) {
    MCLI_ERROR( ( CLI_ERROR_LENGTHERROR, ( char * ) ip_address ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  if ( CLI_OK != cli_check_regexp( CLI_REGEX_IP, ip_address ) ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_IPADDRESS ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  memset( cli_controller_ip, 0x00, sizeof( cli_controller_ip ) );
  strcpy( cli_controller_ip, ip_address );

  return CLI_OK;
}


ECLI_RESULT
cli_set_config_controller( void *controller_name ) {
  if ( strlen( controller_name ) > CONTROLLER_NAME_SIZE ) {
    MCLI_ERROR( ( CLI_ERROR_LENGTHERROR, ( char * ) controller_name ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  if ( CLI_OK != cli_check_digit( CLI_CHECK_LNUM, ( u_char * ) controller_name ) ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_CONTROLLERNAME ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  memset( cli_controller_name, 0x00, sizeof( cli_controller_name ) );
  strcpy( cli_controller_name, controller_name );

  return CLI_OK;
}


ECLI_RESULT
cli_do_config_no_controller() {
  config_cmd_interface_t interface;
  int result;

  memset( &interface, 0x00, sizeof( interface ) );

  // send config
  interface.head.command = CONFIG_CONTROLLER_REQUEST;
  interface.head.set_kind = CONFIG_DELETE;
  interface.command.config_controller.kind.del.kind = CONFIG_INDIVIDUAL;
  strcpy( interface.command.config_controller.kind.del.controller_name, cli_controller_name );

  result = cli_send_to_config( &interface );
  if ( result != CLI_OK ) {
    cli_do_word_init();
    return result;
  }

  // initialize word chain
  cli_do_word_init();

  return CLI_OK;
}


ECLI_RESULT
cli_do_config_no_controller_all() {
  config_cmd_interface_t interface;
  int result;

  memset( &interface, 0x00, sizeof( interface ) );

  // send config
  interface.head.command = CONFIG_CONTROLLER_REQUEST;
  interface.head.set_kind = CONFIG_DELETE;
  interface.command.config_controller.kind.del.kind = CONFIG_ALL;

  result = cli_send_to_config( &interface );
  if ( result != CLI_OK ) {
    cli_do_word_init();
    return result;
  }
  // initialize word chain
  cli_do_word_init();

  return CLI_OK;
}


ECLI_RESULT
cli_write_savefile( char *filename ) {
  FILE *fp;

  fp = fopen( filename, "w" );
  if ( fp == NULL ) {
    return CLI_NG;
  }
  cli_do_show_running_config( fp );

  fclose( fp );
  chmod( filename, 0777 );

  return CLI_OK;
}


ECLI_RESULT
cli_do_config_save() {
  char filename[ CLI_SAVEFILE_SIZE ];

  memset( filename, '\0', sizeof( filename ) );
  sprintf( filename, "%s%s", TMP_DIR, CLI_SAVEFILE_NAME );
  return cli_write_savefile( filename );
}


ECLI_RESULT
cli_set_config_savefile( void *file ) {
  if ( CLI_SAVEFILE_SIZE <= strlen( file ) ) {
    MCLI_ERROR( ( CLI_ERROR_UNKNOWN_COMMAND, __CLI_WORD_FILE ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  memset( cli_save_file, '\0', sizeof( cli_save_file ) );
  strcpy( cli_save_file, file );

  return CLI_OK;
}


ECLI_RESULT
cli_do_config_savefile() {
  return cli_write_savefile( cli_save_file );
}
