#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

#include "readline/readline.h"
#include "readline/history.h"

#include "cmn.h"
#include "cli_define.h"
#include "cli_struct.h"
#include "cli_extern.h"

static int history_num = 0;

void
cli_addition_history( char *command ) {
  HIST_ENTRY *history = NULL;
  char file[ 128 ] = "";

  add_history( command );

  sprintf( file, "%s%s", TMP_DIR, CLI_HISTORY_FILE );
  write_history( file );

  if ( ++history_num > CLI_HISTORY_MAX ) {
    history = remove_history( 0 );
    free( history );
  }

  return;
}


void
cli_set_word_initial() {
  cli_do_word_init();
  return;
}


ECLI_RESULT
cli_get_command_information( char *command, clictrl_cmdchain_t *get_chain, ECLI_EXEC_KIND kind ) {
  char *analysis_command;
  char *token, *re_p;
  int count = 0;
  const clictrl_cmdchain_t *chain;
  ECLI_RESULT result = CLI_NOHIT;
  ECLI_RESULT ret = CLI_OK;
  ECLI_RESULT check_result = CLI_OK;
  char *find_string;
  u_int last_string_pointer = 0;

  chain = ( const clictrl_cmdchain_t * ) cli_chain[ cli_mode ];

  memcpy( get_chain, chain, sizeof( clictrl_cmdchain_t ) );
  cli_set_word_initial( command );

  analysis_command = calloc( ( strlen( command ) + 1 ), sizeof( char ) );
  if ( analysis_command == NULL ) {
    return CLI_NG;
  }
  strncpy( analysis_command, command, strlen( command ) );

  find_string = strrchr( command, ' ' );
  if ( find_string != NULL ) {
    last_string_pointer = ( u_int ) ( find_string - command );
  }

  token = ( char * ) strtok_r( analysis_command, " ", &re_p );
  while ( token != NULL && chain[ count ].str != NULL ) {
    result = CLI_NOHIT;

    do {
      if ( ( ( strncmp( chain[ count ].str, token, strlen( chain[ count ].str ) ) == 0 )
           && ( strncmp( chain[ count ].str, token, strlen( token ) ) == 0 ) )
         || ( CLI_NEXTCHAIN == ( check_result = cli_check_variable_parameter( chain[ count ].str ) ) ) ) {

        result = CLI_HIT;

        ret = cli_do_func( chain[ count ].tab_func, token );
        if ( ret != CLI_OK ) {
          if ( kind == CLI_EXEC_TAB ) {
            printf( "%s%s", cli_prompt, command );
          }
          free( analysis_command );
          return CLI_NG;
        }

        if ( !( ( kind == CLI_EXEC_TAB )
              && ( ( last_string_pointer == ( u_int ) ( token - analysis_command - 1 ) )
                 && ( strcmp( token, &command[ last_string_pointer + 1 ] ) == 0 )
                 && ( CLI_NEXTCHAIN == check_result ) ) ) ) {
          memcpy( get_chain, &chain[ count ], sizeof( clictrl_cmdchain_t ) );
          cli_command_word = ( const char ** ) chain[ count ].word;
          chain = chain[ count ].next_chain;
          count = 0;
        }

        if ( chain == NULL ) {
          free( analysis_command );
          return CLI_HIT;
        }
        break;
      }
      else if ( strncmp( chain[ count ].str, token, strlen( token ) ) == 0 ) {
        // match partial
        free( analysis_command );
        return CLI_SLICE_HIT;
      }
      count++;
    } while ( chain[ count ].str != NULL );

    // check word hit.
    if ( result != CLI_HIT ) {
      break;
    }

    token = strtok_r( NULL, " ", &re_p );
  }

  if ( ( result == CLI_NOHIT ) && ( strlen( command ) > 0 ) ) {
    if ( kind == CLI_EXEC_TAB ) {
      printf("\n") ;
    }
    cli_command_word = clidata_admin_end;
    MCLI_ERROR( ( CLI_ERROR_UNKNOWN_COMMAND, token ) );
    if ( kind == CLI_EXEC_TAB ) {
      printf( "%s%s", cli_prompt, command );
    }
  }

  free( analysis_command );

  return result;
}


ECLI_RESULT
cli_do_command( char *command ) {
  ECLI_RESULT result = CLI_NG;
  clictrl_cmdchain_t chain;

  result = cli_get_command_information( command, &chain, CLI_EXEC_ENTER );
  if ( result != CLI_HIT ) {
    return CLI_NG_EXIT_ERRORLOG;
  }

  if ( chain.do_func != NULL ) {
    result = cli_do_func( chain.do_func, command );
  }
  else {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, command ) );
  }
  return result;
}


ECLI_RESULT
cli_check_duplicate( const char *name ) {
  struct readline_state sp;
  char *buffer;
  char *token, *resp_p;
  const char *no_check_word[ 128 ] = { CLI_WORD_INCREMENT, CLI_WORD_DECREMENT, CLI_WORD_RANDOM,
                                       CLI_WORD_MACSRC, CLI_WORD_MACDST, CLI_WORD_COUNT_LIMIT, _CLI_WORD_COUNT,
                                       _CLI_WORD_MASK, _CLI_WORD_MACADDRESS, _CLI_WORD_COUNT_LIMIT, "" };
  int count = 0;

  // no_check_work check
  while ( 1 ) {
    if ( !strcmp( no_check_word[ count ], name ) ) {
      return CLI_OK;
    }
    if ( !strcmp( no_check_word[ count ], "" ) ) {
      break;
    }
    count++;
  }

  // get readline information
  rl_save_state( &sp );

  buffer = calloc( strlen( sp.buffer ) + 1, sizeof( char ) );
  if ( buffer == NULL ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
    return CLI_NG;
  }
  strcpy( buffer, sp.buffer );

  token = strtok_r( buffer, " ", &resp_p );
  while ( token != NULL ) {
    if ( !strcmp( token, name ) ) {
      free( buffer );
      return CLI_HIT;
    }

    token = strtok_r( NULL, " ", &resp_p );
  }
  free( buffer );

  return CLI_NOHIT;
}


char *
cli_get_word( const char *text, int state ) {
  static size_t length;
  static int index;
  const char *name;

  if ( state == 0 ) {
    length = strlen( text );
    index = 0;
  }

  while ( ( name = cli_command_word[ index ] ) ) {
    index++;

    if ( cli_check_duplicate( name ) == CLI_HIT ) {
      continue;
    }

    if ( !strncmp( text, name, length ) ) {
      return strdup( name );
    }
  }

  return NULL;
}


char **
cli_do_tab_button( char *text, int start, int end ) {
  ECLI_RESULT result;
  clictrl_cmdchain_t chain;
  struct readline_state sp;
  int none;

  none = start;
  none = end;
  none = none;

  rl_save_state( &sp );

  result = cli_get_command_information( sp.buffer, &chain, CLI_EXEC_TAB );
  if ( result == CLI_HIT ) {
    cli_command_word = ( const char ** ) chain.word;
  }
  else if ( result == CLI_NG ) {
    return NULL;
  }

  return ( char ** ) rl_completion_matches( text, cli_get_word );
}
