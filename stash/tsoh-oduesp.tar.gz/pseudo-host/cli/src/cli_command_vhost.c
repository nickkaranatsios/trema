#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <arpa/inet.h>
#include <errno.h>

#include "cli_define.h"
#include "cli_struct.h"
#include "cli_extern.h"

#include "packet.h"
#include "configif.h"
#include "config_lib.h"
#include "com_socket.h"
#include "vhost_interface.h"

static u_short cli_arp_cache_time;
static char cli_ip_address[ IP_SIZE ] = "";
static char cli_mask[ IP_SIZE ] = "";
static char cli_controller_name[ CONTROLLER_NAME_SIZE + 1 ] = "";
static char cli_mac_address[ MAC_SIZE ] = "";
static u_short cli_vlanid;
static char cli_recv_device[ NAME_SIZE + 1 ] = "";
static char cli_send_device[ NAME_SIZE + 1 ] = "";


ECLI_RESULT
cli_do_static_arp_request( u_short mode, char *vhost_name, char *static_arp_ip_address, char *static_arp_mac_address ) {
  ECLI_VHOST_STATUS vhost_status;
  VHOST_STATIC_ARP_REQUEST_BLOCK static_arp_request;
  VHOST_STATIC_ARP_ANSWER_BLOCK static_arp_response;
  PACKET_HEADER packet_header;
  int sockfd;
  u_int ipv4;
  char ip_address[ IP_SIZE ] = "";
  ECLI_RESULT result;

  memset( &static_arp_request, 0x00, sizeof( static_arp_request ) );
  memset( &static_arp_response, 0x00, sizeof( static_arp_response ) );
  memset( &packet_header, 0x00, sizeof( packet_header ) );

  // set vhost
  vhost_status = cli_get_vhost_status( vhost_name );
  if ( vhost_status == CLI_VHOST_UP ) {
    // get ip_address
    result = config_get_vhost_ipaddress( vhost_name, ip_address );
    if ( result != CLI_OK ) {
      cli_do_word_init();
      return CLI_NG;
    }
    ipv4 = htonl( inet_addr( ip_address ) );
    sockfd = com_socket_connect( ipv4, CLI_INTERFACE_PORT );
    if ( sockfd < 0 ) {
      cli_do_word_init();
      return CLI_NG;
    }

    packet_header.size = htonl( sizeof( static_arp_request ) + sizeof( packet_header ) );
    packet_header.packet_num = htonl( 0x01 );

    // send packet header
    result = com_socket_send( sockfd, ( u_char * ) &packet_header, sizeof( packet_header ) );
    if ( result != TRUE ) {
      MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
      com_socket_close( sockfd );
      return CLI_NG;
    }

    static_arp_request.header.length = htonl( sizeof( static_arp_request ) );
    static_arp_request.header.command_code = htonl( VHOST_STATIC_ARP_REQUEST );
    strcpy( ( char * ) &static_arp_request.header.vhost_name, vhost_name );
    cli_set_macaddress( static_arp_mac_address, ( char * ) &static_arp_request.mac_address );
    static_arp_request.ipv4_address = inet_addr( static_arp_ip_address );
    static_arp_request.mode = mode;

    // send static arp information
    result = com_socket_send( sockfd, ( u_char * ) &static_arp_request, sizeof( static_arp_request ) );
    if ( result != TRUE ) {
      MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
      com_socket_close( sockfd );
      return CLI_NG;
    }

    // receive packet header
    result = com_socket_receive( sockfd, ( u_char * ) &packet_header, sizeof( packet_header ) );
    if ( result != TRUE ) {
      MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
      com_socket_close( sockfd );
      return CLI_NG;
    }

    // receive static arp setting result
    result = com_socket_receive( sockfd, ( u_char * ) &static_arp_response, sizeof( static_arp_response ) );
    if ( result != TRUE ) {
      MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
      com_socket_close( sockfd );
      return CLI_NG;
    }

    if ( static_arp_response.result != RESULT_OK ) {
      MCLI_ERROR( ( CLI_ERROR_SET_STATIC_ARP, static_arp_response.header.vhost_name ) );
      com_socket_close( sockfd );
      return CLI_NG;
    }
    com_socket_close( sockfd );
  }

  return CLI_OK;
}


ECLI_RESULT
cli_do_arp_cache_request( char *vhost_name, u_int time ) {
  VHOST_ARP_CACHE_SET_REQUEST_BLOCK arp_cache_request;
  VHOST_ARP_CACHE_SET_ANSWER_BLOCK arp_cache_response;
  ECLI_VHOST_STATUS vhost_status;
  PACKET_HEADER packet_header;
  int sockfd;
  u_int ipv4;
  char ip_address[ IP_SIZE ] = "";
  ECLI_RESULT result;

  memset( &arp_cache_request, 0x00, sizeof( arp_cache_request ) );
  memset( &arp_cache_response, 0x00, sizeof( arp_cache_response ) );

  vhost_status = cli_get_vhost_status( vhost_name );
  if ( vhost_status == CLI_VHOST_UP ) {
    // get ip_address
    result = config_get_vhost_ipaddress( vhost_name, ip_address );
    if ( result != CLI_OK ) {
      cli_do_word_init();
      return CLI_NG;
    }
    ipv4 = htonl( inet_addr( ip_address ) );
    sockfd = com_socket_connect( ipv4, CLI_INTERFACE_PORT );
    if ( sockfd < 0 ) {
      cli_do_word_init();
      return CLI_NG;
    }

    packet_header.size = htonl( sizeof( arp_cache_request ) + sizeof( packet_header ) );
    packet_header.packet_num = htonl( 0x01 );

    // send packet header
    result = com_socket_send( sockfd, ( u_char * ) &packet_header, sizeof( packet_header ) );
    if ( result != TRUE ) {
      MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
      com_socket_close( sockfd );
      return CLI_NG;
    }

    arp_cache_request.header.length = htonl( sizeof( arp_cache_request ) );
    arp_cache_request.header.command_code = htonl( VHOST_ARP_CACHE_REQUEST );
    strcpy( ( char * ) arp_cache_request.header.vhost_name, vhost_name );
    arp_cache_request.arp_cache_time = htonl( time );

    // send arp cache information
    result = com_socket_send( sockfd, ( u_char * ) &arp_cache_request, sizeof( arp_cache_request ) );
    if ( result != TRUE ) {
      MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
      com_socket_close( sockfd );
      return CLI_NG;
    }

    // receive packet header
    result = com_socket_receive( sockfd, ( u_char * ) &packet_header, sizeof( packet_header ) );
    if ( result != TRUE ) {
      MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
      com_socket_close( sockfd );
      return CLI_NG;
    }

    // receive arp cache setting result
    result = com_socket_receive( sockfd, ( u_char * ) &arp_cache_response, sizeof( arp_cache_response ) );
    if ( result != TRUE ) {
      MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
      com_socket_close( sockfd );
      return CLI_NG;
    }

    if ( arp_cache_response.result != RESULT_OK ) {
      MCLI_ERROR( ( CLI_ERROR_VHOST_ERR ) );
      com_socket_close( sockfd );
      return CLI_NG;
    }
    com_socket_close( sockfd );
  }

  return CLI_OK;
}


ECLI_RESULT
cli_do_vhost_rawgeneration() {
  config_cmd_interface_t interface;
  ECLI_RESULT result;

  memset( &interface, 0x00, sizeof( interface ) );

  // set config parameter
  interface.head.command = CONFIG_VHOST_MODE_REQUEST;
  interface.head.set_kind = CONFIG_ADD;
  interface.command.vhost_mode.kind.add.mode = CONFIG_RAW_GENERATION_MODE;
  strcpy( interface.head.vhost_name, cli_vhost_name );

  result = cli_send_to_config( &interface );
  if ( result != CLI_OK ) {
    cli_do_word_init();
    return CLI_NG;
  }
  // check result
  if ( interface.head.result != CONFIG_OK ) {
    MCLI_ERROR( ( CLI_ERROR_CONFIG_SET_NG ) );
    cli_do_word_init();
    return CLI_NG;
  }
  // initialize word chain
  cli_do_word_init();

  return CLI_OK;
}


ECLI_RESULT
cli_do_vhost_hostemulation() {
  config_cmd_interface_t interface;
  ECLI_RESULT result;

  memset( &interface, 0x00, sizeof( interface ) );

  // set config parameter
  interface.head.command = CONFIG_VHOST_MODE_REQUEST;
  interface.head.set_kind = CONFIG_ADD;
  interface.command.vhost_mode.kind.add.mode = CONFIG_HOST_EMULATION_MODE;
  strcpy( interface.head.vhost_name, cli_vhost_name );

  result = cli_send_to_config( &interface );
  if ( result != CLI_OK ) {
    cli_do_word_init();
    return CLI_NG;
  }

  if ( interface.head.result != CONFIG_OK ) {
    MCLI_ERROR( ( CLI_ERROR_CONFIG_SET_NG ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  // initialize word chain
  cli_do_word_init();

  return CLI_OK;
}


ECLI_RESULT
cli_do_vhost_promisc() {
  config_cmd_interface_t interface;
  ECLI_RESULT result;

  memset( &interface, 0x00, sizeof( interface ) );

  // set config parameter
  interface.head.command = CONFIG_VHOST_PROMISC_REQUEST;
  interface.head.set_kind = CONFIG_ADD;
  interface.command.vhost_promisc.kind.add.promisc = CONFIG_PROMISC;
  strcpy( interface.head.vhost_name, cli_vhost_name );

  result = cli_send_to_config( &interface );
  if ( result != CLI_OK ) {
    cli_do_word_init();
    return CLI_NG;
  }

  if ( interface.head.result != CONFIG_OK ) {
    MCLI_ERROR( ( CLI_ERROR_CONFIG_SET_NG ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  // initialize word chain
  cli_do_word_init();

  return CLI_OK;
}


ECLI_RESULT
cli_do_vhost_arpcache() {
  config_cmd_interface_t interface;
  ECLI_RESULT result;

  // set config parameter
  interface.head.command = CONFIG_VHOST_ARPCACHE_REQUEST;
  interface.head.set_kind = CONFIG_ADD;
  interface.command.vhost_cache.kind.add.time = cli_arp_cache_time;
  strcpy( interface.head.vhost_name, cli_vhost_name );

  result = cli_send_to_config( &interface );
  if ( result != CLI_OK ) {
    cli_do_word_init();
    return CLI_NG;
  }

  if ( interface.head.result != CONFIG_OK ) {
    MCLI_ERROR( ( CLI_ERROR_CONFIG_SET_NG ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  result = cli_do_arp_cache_request( cli_vhost_name, cli_arp_cache_time );
  if ( result != CLI_OK ) {
    cli_do_word_init();
    return CLI_NG;
  }

  // initialize word chain
  cli_do_word_init();

  return CLI_OK;
}


ECLI_RESULT
cli_set_vhost_arpcache( void *time ) {
  if ( CLI_OK != cli_check_digit( CLI_CHECK_DIGIT, ( u_char * ) time ) ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_TIME ) );
    return CLI_NG;
  }
  cli_arp_cache_time = ( u_short ) strtoul( ( char * ) time, NULL, 0 );

  return CLI_OK;
}


ECLI_RESULT
cli_do_vhost_ipaddress() {
  config_cmd_interface_t interface;
  ECLI_RESULT result;

  memset( &interface, 0x00, sizeof( interface ) );

  // set config parameter
  interface.head.command = CONFIG_VHOST_IPADDRESS_REQUEST;
  interface.head.set_kind = CONFIG_ADD;
  strcpy( interface.command.vhost_ip_address.kind.add.ip_address, cli_ip_address );
  strcpy( interface.head.vhost_name, cli_vhost_name );

  result = cli_send_to_config( &interface );
  if ( result != CLI_OK ) {
    cli_do_word_init();
    return CLI_NG;
  }

  if ( interface.head.result != CONFIG_OK ) {
    MCLI_ERROR( ( CLI_ERROR_CONFIG_SET_NG ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  // initialize word chain
  cli_do_word_init();

  return CLI_OK;
}


ECLI_RESULT
cli_set_vhost_ipaddress( void *ip_address ) {
  if ( CLI_OK != cli_check_regexp( CLI_REGEX_IP, ( char * ) ip_address ) ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_IPADDRESS ) );
    return CLI_NG;
  }

  memset( cli_ip_address, 0x00, sizeof( cli_ip_address ) );
  memcpy( cli_ip_address, ip_address, strlen( ip_address ) );

  return CLI_OK;
}


ECLI_RESULT
cli_do_vhost_subnetmask() {
  config_cmd_interface_t interface;
  ECLI_RESULT result;

  memset( &interface, 0x00, sizeof( interface ) );

  // set config parameter
  interface.head.command = CONFIG_VHOST_MASK_REQUEST;
  interface.head.set_kind = CONFIG_ADD;
  strcpy( interface.command.vhost_mask.kind.add.mask, cli_mask );
  strcpy( interface.head.vhost_name, cli_vhost_name );

  result = cli_send_to_config( &interface );
  if ( result != CLI_OK ) {
    cli_do_word_init();
    return CLI_NG;
  }

  if ( interface.head.result != CONFIG_OK ) {
    MCLI_ERROR( ( CLI_ERROR_CONFIG_SET_NG ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  // initialize word chain
  cli_do_word_init();

  return CLI_OK;
}


ECLI_RESULT
cli_set_vhost_subnetmask( void *subnet_mask ) {
  if ( CLI_OK != cli_check_regexp( CLI_REGEX_IP, ( char * ) subnet_mask ) ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_MASK ) );
    return CLI_NG;
  }

  memset( cli_mask, 0x00, sizeof( cli_mask ) );
  memcpy( cli_mask, subnet_mask, strlen( subnet_mask ) );

  return CLI_OK;
}


ECLI_RESULT
cli_do_vhost_ether() {
  config_cmd_interface_t interface;
  ECLI_RESULT result;

  memset( &interface, 0x00, sizeof( interface ) );

  // set config parameter
  interface.head.command = CONFIG_VHOST_L2TYPE_REQUEST;
  interface.head.set_kind = CONFIG_ADD;
  interface.command.vhost_l2type.kind.add.l2type = CONFIG_L2TYPEETHER;
  strcpy( interface.head.vhost_name, cli_vhost_name );

  result = cli_send_to_config( &interface );
  if ( result != CLI_OK ) {
    cli_do_word_init();
    return CLI_NG;
  }

  if ( interface.head.result != CONFIG_OK ) {
    MCLI_ERROR( ( CLI_ERROR_CONFIG_SET_NG ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  // initialize word chain
  cli_do_word_init();

  return CLI_OK;
}


ECLI_RESULT
cli_do_vhost_controller() {
  config_cmd_interface_t interface;
  ECLI_RESULT result;

  memset( &interface, 0x00, sizeof( interface ) );

  // set config parameter
  interface.head.command = CONFIG_VHOST_CONTROLLER_REQUEST;
  interface.head.set_kind = CONFIG_ADD;
  strcpy( interface.command.vhost_controller.kind.add.controller_name, cli_controller_name );
  strcpy( interface.head.vhost_name, cli_vhost_name );

  result = cli_send_to_config( &interface );
  if ( result != CLI_OK ) {
    cli_do_word_init();
    return CLI_NG;
  }

  if ( interface.head.result != CONFIG_OK ) {
    MCLI_ERROR( ( CLI_ERROR_CONFIG_SET_NG ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  // initialize word chain
  cli_do_word_init();

  return CLI_OK;
}


ECLI_RESULT
cli_set_vhost_controller( void *controller_name ) {
  // parameter check
  if ( strlen( controller_name ) > CONTROLLER_NAME_SIZE ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_CONTROLLERNAME ) );
    return CLI_NG;
  }

  if ( CLI_OK != cli_check_digit( CLI_CHECK_LNUM, ( u_char * ) controller_name ) ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_CONTROLLERNAME ) );
    return CLI_NG;
  }

  memset( cli_controller_name, 0x00, sizeof( cli_controller_name ) );
  strcpy( cli_controller_name, controller_name );

  return CLI_OK;
}


ECLI_RESULT
cli_do_vhost_macaddress() {
  config_cmd_interface_t interface;
  ECLI_RESULT result;

  memset( &interface, 0x00, sizeof( interface ) );

  // set config parameter
  interface.head.command = CONFIG_VHOST_MACADDRESS_REQUEST;
  interface.head.set_kind = CONFIG_ADD;
  strcpy( interface.head.vhost_name, cli_vhost_name );
  strcpy( interface.command.vhost_mac_address.kind.add.mac_address, cli_mac_address );

  result = cli_send_to_config( &interface );
  if ( result != CLI_OK ) {
    cli_do_word_init();
    return CLI_NG;
  }

  if ( interface.head.result != CONFIG_OK ) {
    MCLI_ERROR( ( CLI_ERROR_CONFIG_SET_NG ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  // initialize word chain
  cli_do_word_init();

  return CLI_OK;
}


ECLI_RESULT
cli_set_vhost_macaddress( void *mac_address ) {
  if ( CLI_OK != cli_check_regexp( CLI_REGEX_MAC, ( char * ) mac_address ) ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_MACADDRESS ) );
    return CLI_NG;
  }
  memset( cli_mac_address, 0x00, sizeof( cli_mac_address ) );
  strcpy( cli_mac_address, mac_address );

  return CLI_OK;
}


ECLI_RESULT
cli_do_vhost_static_arp() {
  config_cmd_interface_t interface;
  ECLI_RESULT result;

  memset( &interface, 0x00, sizeof( interface ) );

  // set config parameter
  interface.head.command = CONFIG_VHOST_STATICARP_REQUEST;
  interface.head.set_kind = CONFIG_ADD;
  strcpy( interface.command.vhost_static_arp.kind.add.ip_address, cli_ip_address );
  strcpy( interface.command.vhost_static_arp.kind.add.mac_address, cli_mac_address );
  strcpy( interface.head.vhost_name, cli_vhost_name );

  // set configuration
  result = cli_send_to_config( &interface );
  if ( result != CLI_OK ) {
    cli_do_word_init();
    return CLI_NG;
  }

  if ( interface.head.result != CONFIG_OK ) {
    MCLI_ERROR( ( CLI_ERROR_CONFIG_SET_NG ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  // set vhost
  result = cli_do_static_arp_request( CLI_STATIC_ARP_SET, cli_vhost_name, cli_ip_address, cli_mac_address );
  if ( result != CLI_OK ) {
    cli_do_word_init();
    return CLI_NG;
  }

  // initialize word chain
  cli_do_word_init();

  return CLI_OK;
}


ECLI_RESULT
cli_do_vhost_l2type_vlan() {
  config_cmd_interface_t interface;
  ECLI_RESULT result;

  memset( &interface, 0x00, sizeof( interface ) );

  // set config parameter
  interface.head.command = CONFIG_VHOST_L2TYPE_REQUEST;
  interface.head.set_kind = CONFIG_ADD;
  interface.command.vhost_l2type.kind.add.l2type = CONFIG_L2TYPEVLAN;
  interface.command.vhost_l2type.kind.add.vlanid = cli_vlanid;
  strcpy( interface.head.vhost_name, cli_vhost_name );

  result = cli_send_to_config( &interface );
  if ( result != CLI_OK ) {
    cli_do_word_init();
    return CLI_NG;
  }

  if ( interface.head.result != CONFIG_OK ) {
    MCLI_ERROR( ( CLI_ERROR_CONFIG_SET_NG ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  // initialize word chain
  cli_do_word_init();

  return CLI_OK;
}


ECLI_RESULT
cli_set_vhost_l2type_vlan( void *vlanid ) {
  u_short vlan_id;

  if ( CLI_OK != cli_check_digit( CLI_CHECK_DIGIT, ( u_char * ) vlanid ) ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_VLANID ) );
    return CLI_NG;
  }

  vlan_id = ( u_short ) strtoul( ( char * ) vlanid, NULL, 0 );
  if ( vlan_id > CLI_VLAN_MAX ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_VLANID ) );
    return CLI_NG;
  }
  cli_vlanid = vlan_id;

  return CLI_OK;
}


ECLI_RESULT
cli_set_vhost_interface_recv( void *device ) {
  if ( strlen( device ) > NAME_SIZE ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_DEVICE ) );
    return CLI_NG;
  }

  if ( CLI_OK != cli_check_digit( CLI_CHECK_LNUM, ( u_char * ) device ) ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_DEVICE ) );
    return CLI_NG;
  }

  memset( cli_recv_device, 0x00, sizeof( cli_recv_device ) );
  memset( cli_send_device, 0x00, sizeof( cli_send_device ) );
  strcpy( cli_recv_device, device );
  strcpy( cli_send_device, device );

  return CLI_OK;
}


ECLI_RESULT
cli_do_vhost_interface_recv() {
  config_cmd_interface_t interface;
  ECLI_RESULT result;

  memset( &interface, 0x00, sizeof( interface ) );

  // set config parameter
  interface.head.command = CONFIG_VHOST_INTERFACE_REQUEST;
  interface.head.set_kind = CONFIG_ADD;
  interface.command.vhost_interface.kind.add.enable = CONFIG_DISABLE;
  strcpy( interface.command.vhost_interface.kind.add.recv_device, cli_recv_device );
  strcpy( interface.command.vhost_interface.kind.add.send_device, cli_send_device );
  strcpy( interface.head.vhost_name, cli_vhost_name );

  result = cli_send_to_config( &interface );
  if ( result != CLI_OK ) {
    cli_do_word_init();
    return CLI_NG;
  }

  if ( interface.head.result != CONFIG_OK ) {
    MCLI_ERROR( ( CLI_ERROR_CONFIG_SET_NG ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  // initialize word chain
  cli_do_word_init();

  return CLI_OK;
}


ECLI_RESULT
cli_do_vhost_interface_send() {
  config_cmd_interface_t interface;
  ECLI_RESULT result;

  memset( &interface, 0x00, sizeof( interface ) );

  // set config parameter
  interface.head.command = CONFIG_VHOST_INTERFACE_REQUEST;
  interface.head.set_kind = CONFIG_ADD;
  interface.command.vhost_interface.kind.add.enable = CONFIG_ENABLE;
  strcpy( interface.command.vhost_interface.kind.add.recv_device, cli_recv_device );
  strcpy( interface.command.vhost_interface.kind.add.send_device, cli_send_device );
  strcpy( interface.head.vhost_name, cli_vhost_name );

  result = cli_send_to_config( &interface );
  if ( result != CLI_OK ) {
    cli_do_word_init();
    return CLI_NG;
  }

  if ( interface.head.result != CONFIG_OK ) {
    MCLI_ERROR( ( CLI_ERROR_CONFIG_SET_NG ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  // initialize word chain
  cli_do_word_init();

  return CLI_OK;
}


ECLI_RESULT
cli_set_vhost_interface_send( void *device ) {
  if ( strlen( device ) > NAME_SIZE ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_DEVICE ) );
    return CLI_NG;
  }

  if ( CLI_OK != cli_check_digit( CLI_CHECK_LNUM, ( u_char * ) device ) ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, _CLI_WORD_DEVICE ) );
    return CLI_NG;
  }

  memset( cli_send_device, 0x00, sizeof( cli_send_device ) );
  strcpy( cli_send_device, device );

  return CLI_OK;
}


ECLI_RESULT
cli_do_vhost_no_mode() {
  if ( CLI_OK != cli_do_noconfig( CONFIG_VHOST_MODE_REQUEST ) ) {
    return CLI_NG;
  }

  return CLI_OK;
}


ECLI_RESULT
cli_do_vhost_no_promisc() {
  if ( CLI_OK != cli_do_noconfig( CONFIG_VHOST_PROMISC_REQUEST ) ) {
    return CLI_NG;
  }

  return CLI_OK;
}


ECLI_RESULT
cli_do_vhost_no_arpcache() {
  if ( CLI_OK != cli_do_noconfig( CONFIG_VHOST_ARPCACHE_REQUEST ) ) {
    return CLI_NG;
  }

  if ( CLI_OK != cli_do_arp_cache_request( cli_vhost_name, CLI_ARPCACHE_DEFAULT ) ) {
    return CLI_NG;
  }

  return CLI_OK;
}


ECLI_RESULT
cli_do_vhost_no_ipaddress() {
  if ( CLI_OK != cli_do_noconfig( CONFIG_VHOST_IPADDRESS_REQUEST ) ) {
    return CLI_NG;
  }

  return CLI_OK;
}


ECLI_RESULT
cli_do_vhost_no_mask() {
  if ( CLI_OK != cli_do_noconfig( CONFIG_VHOST_MASK_REQUEST ) ) {
    return CLI_NG;
  }

  return CLI_OK;
}


ECLI_RESULT
cli_do_vhost_no_l2type() {
  if ( CLI_OK != cli_do_noconfig( CONFIG_VHOST_L2TYPE_REQUEST ) ) {
    return CLI_NG;
  }

  return CLI_OK;
}


ECLI_RESULT
cli_do_vhost_no_interface() {
  if ( CLI_OK != cli_do_noconfig( CONFIG_VHOST_INTERFACE_REQUEST ) ) {
    return CLI_NG;
  }

  return CLI_OK;
}


ECLI_RESULT
cli_do_vhost_no_controller() {
  if ( CLI_OK != cli_do_noconfig( CONFIG_VHOST_CONTROLLER_REQUEST ) ) {
    return CLI_NG;
  }

  return CLI_OK;
}


ECLI_RESULT
cli_do_vhost_no_macaddress() {
  if ( CLI_OK != cli_do_noconfig( CONFIG_VHOST_MACADDRESS_REQUEST ) ) {
    return CLI_NG;
  }

  return CLI_OK;
}


ECLI_RESULT
cli_do_vhost_no_static_arp() {
  config_cmd_interface_t interface;
  int result;

  memset( &interface, 0x00, sizeof( interface ) );

  // set config parameter
  interface.head.command = CONFIG_VHOST_STATICARP_REQUEST;
  interface.head.set_kind = CONFIG_DELETE;
  strcpy( interface.command.vhost_static_arp.kind.del.ip_address, cli_ip_address );
  strcpy( interface.command.vhost_static_arp.kind.del.mac_address, cli_mac_address );
  strcpy( interface.head.vhost_name, cli_vhost_name );

  result = cli_send_to_config( &interface );
  if ( result != CLI_OK ) {
    cli_do_word_init();
    return CLI_NG;
  }

  if ( interface.head.result != CONFIG_OK ) {
    MCLI_ERROR( ( CLI_ERROR_CONFIG_DELETE_NG ) );
    return CLI_NG_EXIT_ERRORLOG;
  }

  // set vhost
  result = cli_do_static_arp_request( CLI_STATIC_ARP_DEL, cli_vhost_name, cli_ip_address, cli_mac_address );
  if ( result != CLI_OK ) {
    cli_do_word_init();
    return CLI_NG;
  }

  // initialize word chain
  cli_do_word_init();

  return CLI_OK;
}


ECLI_RESULT
cli_do_show_vhost_individual_config( FILE *fp, config_vhost_information_t *vhost_information ) {
  config_static_arp_t *static_arp_information;
  u_int static_arp_num;
  u_int static_count;
  char static_arp_string[ 128 ] = "";
  u_int print_offset = 40;

  fprintf( fp, "%s %s\n", CLI_WORD_VHOST, vhost_information->vhost_name );

  // controller
  if ( vhost_information->vhost_info.controller.enable == CONFIG_ENABLE ) {
    fprintf( fp, "  %s %s\n", CLI_WORD_CONTROLLER, vhost_information->vhost_info.controller.controller_name );
  }
  // mode
  if ( vhost_information->vhost_info.mode.enable == CONFIG_ENABLE ) {
    if ( vhost_information->vhost_info.mode.mode == CONFIG_RAW_GENERATION_MODE ) {
      fprintf( fp, "  %s %s\n", CLI_WORD_MODE, CLI_WORD_RAWGENERATION );
    }
    else {
      fprintf( fp, "  %s %s\n", CLI_WORD_MODE, CLI_WORD_HOSTEMULATION );
    }
  }
  // promisc
  if ( vhost_information->vhost_info.promisc.enable == CONFIG_ENABLE ) {
    fprintf( fp, "  %s\n", CLI_WORD_PROMISC );
  }
  // l2type
  if ( vhost_information->vhost_info.l2type.enable == CONFIG_ENABLE ) {
    if ( vhost_information->vhost_info.l2type.l2type == CONFIG_L2TYPEETHER ) {
      fprintf( fp, "  %s %s\n", CLI_WORD_L2TYPE, CLI_WORD_ETHER );
    }
    else {
      fprintf( fp, "  %s %s %d\n", CLI_WORD_L2TYPE, CLI_WORD_VLAN, vhost_information->vhost_info.l2type.vlanid );
    }
  }
  // interface
  if ( vhost_information->vhost_info.interface.enable == CONFIG_ENABLE ) {
    fprintf( fp, "  %s %s %s", CLI_WORD_INTERFACE, CLI_WORD_RECV, vhost_information->vhost_info.interface.recv_device );

    if ( vhost_information->vhost_info.interface.send_enable == CONFIG_ENABLE ) {
      fprintf( fp, " %s %s\n", CLI_WORD_SEND, vhost_information->vhost_info.interface.send_device );
    }
    else {
      fprintf( fp, "\n" );
    }
  }
  // ip_address
  if ( vhost_information->vhost_info.ip_addr.enable == CONFIG_ENABLE ) {
    fprintf( fp, "  %s %s\n", CLI_WORD_IPADDRESS, vhost_information->vhost_info.ip_addr.ip_address );
  }
  // mask
  if ( vhost_information->vhost_info.mask.enable == CONFIG_ENABLE ) {
    fprintf( fp, "  %s %s\n", CLI_WORD_MASK, vhost_information->vhost_info.mask.mask );
  }
  // mac_address
  if ( vhost_information->vhost_info.mac_addr.enable == CONFIG_ENABLE ) {
    fprintf( fp, "  %s %s\n", CLI_WORD_MACADDRESS, vhost_information->vhost_info.mac_addr.mac_address );
  }
  // arp_cache
  if ( vhost_information->vhost_info.arpcache.enable == CONFIG_ENABLE ) {
    fprintf( fp, "  %s %d\n", CLI_WORD_ARPCACHE, vhost_information->vhost_info.arpcache.time );
  }
  // static arp
  static_arp_information = config_get_static_arp_information( vhost_information->vhost_name, &static_arp_num );
  if ( static_arp_information != NULL ) {
    for ( static_count = 0; static_count < static_arp_num; static_count++ ) {
      memset( static_arp_string, '\0', sizeof( static_arp_string ) );
      sprintf( static_arp_string, "  %s %s %s %s ", CLI_WORD_STATIC, CLI_WORD_ARP, CLI_WORD_IPADDRESS,
               static_arp_information[ static_count ].ip_address );
      if ( strlen( static_arp_string ) < print_offset ) {
        memset( &static_arp_string[ strlen( static_arp_string ) ], ' ', print_offset - strlen( static_arp_string ) );
      }
      sprintf( &static_arp_string[ print_offset ], "%s %s\n", CLI_WORD_MACADDRESS, static_arp_information[ static_count ].mac_address );
      fprintf( fp, "%s", static_arp_string );
    }
    free( static_arp_information );
  }

  return CLI_OK;
}


ECLI_RESULT
cli_do_show_vhost_config() {
  config_vhost_information_t *vhost_information;
  time_t current_time;
  char current_date[ 64 ] = "";
  struct tm local_time;
  FILE *fp;

  // print format header
  current_time = time( NULL );
  localtime_r( &current_time, &local_time );
  strftime( current_date, ( strlen( current_date ) - 1 ), "%Y/%m/%d %H:%M:%S", &local_time );
  printf( "Time        :%s \n", current_date );

  vhost_information = config_get_vhost_information( cli_vhost_name );
  if ( vhost_information != NULL ) {
    fp = fopen( cli_ttyname, "w" );
    if ( fp == NULL ) {
      return CLI_NG;
    }
    fprintf( fp, "!\n" );
    cli_do_show_vhost_individual_config( fp, vhost_information );
    fclose( fp );
  }
  printf( "!\n" );
  return CLI_OK;
}
