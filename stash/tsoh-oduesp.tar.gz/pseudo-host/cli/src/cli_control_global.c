/*
 * Grobal Memorys
 *
 * Author : I.Ohkuchi
 */
#include <stdio.h>

#include "cmn.h"
#include "cli_define.h"
#include "cli_struct.h"
#include "cli_extern.h"

char cli_prompt[ 128 ] = "";
int cli_mode = CLI_ADMINMODE;
char cli_vhost_name[ NAME_SIZE ] = "";
const char **cli_command_word;
int cli_socket_fd = -1;
char cli_ttyname[ 64 ] = "";

const clictrl_cmdchain_t *cli_chain[ CLI_MODEMAX ] = { NULL, clidata_admin_chain,
                                                       clidata_config_chain,
                                                       clidata_vhost_chain };

const char *cli_word_notcompare_word[ 128 ] = { _CLI_WORD_VHOSTNAME, _CLI_WORD_MACADDRESS,
                                                _CLI_WORD_COUNT, _CLI_WORD_MASK, _CLI_WORD_ETHERTYPE, _CLI_WORD_PACKETNUM,
                                                _CLI_WORD_COS, _CLI_WORD_VLANID, _CLI_WORD_HEADWARETYPE, _CLI_WORD_LENGTH,
                                                _CLI_WORD_PROTOCOLTYPE, _CLI_WORD_OPERATIONCODE, __CLI_WORD_FILE,
                                                _CLI_WORD_IPADDRESS, _CLI_WORD_TOS, _CLI_WORD_ID, _CLI_WORD_FLAG, _CLI_WORD_OFFSET,
                                                _CLI_WORD_TTL, _CLI_WORD_PROTOCOLNUM, _CLI_WORD_PORT, _CLI_WORD_DATA,
                                                _CLI_WORD_CANCELKEY, _CLI_WORD_FILE, _CLI_WORD_CONTROLLERNAME,
                                                _CLI_WORD_TIME, _CLI_WORD_SUBNETMASK, _CLI_WORD_DEVICE,
                                                _CLI_WORD_DURATION, _CLI_WORD_OPTION, _CLI_WORD_PPS, _CLI_WORD_COUNT_LIMIT, "" };
