/*
 * CLI Interface Main function
 *
 * Author : I.Ohkuchi
 */
#define _GNU_SOURCE 1
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sched.h>

#include "cmn.h"
#include "readline/readline.h"
#include "readline/history.h"

#include "cli_define.h"
#include "cli_struct.h"
#include "cli_extern.h"

extern char **cli_do_tab_button( char *, int, int );
extern ECLI_RESULT cli_initialize_tty();
extern ECLI_RESULT cli_initialize_signal();
extern ECLI_RESULT cli_adjust_command( char ** );
extern void cli_addition_history( char * );
extern ECLI_RESULT cli_do_command( char * );

char **
cli_tabnohit_dummy() {
  return NULL;
}


void
cli_initialize_readline() {
  char filename[ 128 ] = "";

  // readline initialize
  rl_completer_quote_characters = "\"'";
  rl_attempted_completion_function = ( rl_completion_func_t * ) cli_do_tab_button;
  rl_catch_signals = 1;
  rl_ignore_completion_duplicates = 0;
  rl_inhibit_completion = 0;

  // Key Map setting
  rl_bind_key_in_map( CTRL( '@' ), ( int ( * )() ) 0, emacs_standard_keymap );
  rl_bind_key_in_map( CTRL( 'g' ), ( int ( * )() ) 0, emacs_standard_keymap );
  rl_bind_key_in_map( CTRL( 'l' ), ( int ( * )() ) 0, emacs_standard_keymap );
  rl_bind_key_in_map( CTRL( 'q' ), ( int ( * )() ) 0, emacs_standard_keymap );
  rl_bind_key_in_map( CTRL( 'r' ), ( int ( * )() ) 0, emacs_standard_keymap );
  rl_bind_key_in_map( CTRL( 's' ), ( int ( * )() ) 0, emacs_standard_keymap );
  rl_bind_key_in_map( CTRL( 'x' ), rl_unix_line_discard, emacs_standard_keymap );
  rl_bind_key_in_map( CTRL( '[' ), ( int ( * )() ) 0, emacs_standard_keymap );
  rl_bind_key_in_map( CTRL( ']' ), ( int ( * )() ) 0, emacs_standard_keymap );
  rl_bind_key_in_map( CTRL( '_' ), ( int ( * )() ) 0, emacs_standard_keymap );
  rl_bind_key_in_map( CTRL( 'g' ), ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( CTRL( 'h' ), ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( CTRL( 'i' ), ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( CTRL( 'j' ), ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( CTRL( 'm' ), ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( CTRL( 'r' ), ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( CTRL( 'y' ), ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( '[', ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( ']', ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( ' ', ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( '#', ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( '&', ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( '*', ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( '-', ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( '.', ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( '<', ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( '=', ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( '>', ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( '?', ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( '\\', ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( '_', ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( 'l', ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( 'n', ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( 'p', ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( 'q', rl_quoted_insert, emacs_meta_keymap ); 
  rl_bind_key_in_map( 'r', ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( 't', ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( 'u', ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( 'y', ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( CTRL( 'i' ), ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( CTRL( 'j' ), ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( CTRL( 'm' ), ( int ( * )() ) 0, emacs_meta_keymap );
  rl_bind_key_in_map( '*', ( int ( * )() ) 0, emacs_meta_keymap );

  // readline function initialize
  stifle_history( CLI_HISTORY_MAX );
  sprintf( filename, "%s%s", TMP_DIR, CLI_HISTORY_FILE );
  read_history( filename );
  rl_initialize();
  rl_variable_bind( "show-all-if-ambiguous", "1" );
  rl_completion_entry_function = ( rl_compentry_func_t * ) cli_tabnohit_dummy;

  return;
}


void
cli_initialize_individual() {
  pid_t pid;
  cpu_set_t cpu_set;
  int result;

  cli_initialize_signal();
  cli_initialize_tty();

  strncpy( cli_prompt, CLI_PROMPT_ADMIN, sizeof( cli_prompt ) );

  // set cpu
  pid = getpid();
  CPU_ZERO( &cpu_set );
  CPU_SET( CPU_NUMBER_CLI, &cpu_set );

  result = sched_setaffinity( pid, sizeof( cpu_set_t ), &cpu_set );
  if ( result == -1 ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
    return;
  }

  return;
}


void
cli_initialize() {
  cli_initialize_readline();
  cli_initialize_individual();
  return;
}


void
cli_do_config_file( char *filename ) {
  FILE *fp;
  char line[ 256 ];
  size_t len;

  if ( filename == NULL ) {
    return;
  }
  if ( ( fp = fopen( filename, "r" ) ) == NULL ) {
    MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
    return;
  }

  cli_mode = CLI_CONFIGMODE;
  memset( line, 0x00, sizeof( line ) );
  while ( ( fgets( line, sizeof( line ), fp ) ) != NULL ) {
    len = strlen( line );
    if ( ( line[ len - 1 ] == '\r' ) || ( line[ len - 1 ] == '\n' ) ) {
      line[ len - 1 ] = '\0';
    }
    if ( strstr( line, CLI_SAVEFILE_TIME ) != NULL ) {
      continue;
    }

    if ( CLI_OK != cli_do_special_command( line ) ) {
      continue;
    }

    if ( CLI_NG == cli_do_command( line ) ) {
      MCLI_ERROR( ( CLI_ERROR_UNKNOWN_COMMAND, line ) );
    }
    memset( line, 0x00, sizeof( line ) );
  }
  fclose( fp );
}


int
main( int argc, char *argv[] ) {
  char *line;
  int count;
  char *input_line = NULL;
  size_t size = 0;
  size_t margin = 5;

  cli_initialize();

  if ( argc >= 2 ) {
    // input command mode
    if ( strcmp( argv[ 1 ], "file" ) == 0 ) {
      cli_do_config_file( argv[ 2 ] );
    }
    else {
      count = 1;
      while ( argv[ count ] != NULL ) {
        if ( count == 1 ) {
          input_line = calloc( strlen( argv[ count ] ) + margin, sizeof( char ) );
        }
        else {
          input_line = realloc( input_line, strlen( argv[ count ] ) + size + margin );
        }

        if ( input_line == NULL ) {
          MCLI_ERROR( ( CLI_ERROR_SYSCALL, strerror( errno ) ) );
          return 1;
        }

        strcpy( &input_line[ size ], argv[ count ] );

        size += strlen( argv[ count ] ) + 1;
        strcpy( &input_line[ size - 1 ], " " );

        count++;
      }

      if ( CLI_OK != cli_do_special_command( input_line ) ) {
        return 1;
      }

      if ( CLI_NG == cli_do_command( input_line ) ) {
        MCLI_ERROR( ( CLI_ERROR_UNKNOWN_COMMAND, input_line ) );
        return 1;
      }
    }
  }
  else {
    // readline mode
    while ( ( line = readline( cli_prompt ) ) ) {
      if ( strlen( line ) != 0 ) {
        cli_control_set_alarm( line );

        if ( CLI_OK != cli_adjust_command( &line ) ) {
          cli_control_signal_alarm_init();
          continue;
        }

        if ( CLI_OK != cli_do_special_command( line ) ) {
          cli_control_signal_alarm_init();
          continue;
        }

        if ( CLI_NG == cli_do_command( line ) ) {
          MCLI_ERROR( ( CLI_ERROR_UNKNOWN_COMMAND, line ) );
          cli_control_signal_alarm_init();
          continue;
        }
        cli_addition_history( line );
      }
      cli_control_signal_alarm_init();
    }
  }

  return 0;
}
