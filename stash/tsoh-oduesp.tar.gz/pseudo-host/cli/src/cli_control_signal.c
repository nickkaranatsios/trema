#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>

#include "cmn.h"
#include "cli_define.h"
#include "cli_struct.h"
#include "cli_extern.h"

extern ECLI_RESULT cli_show_tty( const char * );
static int cli_control_alarm = CLI_FIRST;

void
cli_control_set_alarm( char *line ) {
  if ( strncmp( line, CLI_WORD_SHOW, strlen( CLI_WORD_SHOW ) ) != 0 ) {
    alarm( CLI_TIMEOUT_FIRST );
  }
  return;
}


void
cli_control_signal() {
  // check send command status
  if ( cli_send_status == CLI_SEND_STATUS_NODOING ) {
    return;
  }

  // cancel
  cli_do_admin_cancel_vhost_key( NULL );

  return;
}


void
cli_control_signal_alarm_init() {
  alarm( 0 );
  cli_control_alarm = CLI_FIRST;
  return;
}


void
cli_control_sinal_alarm() {
  if ( cli_control_alarm == CLI_FIRST ) {
    cli_control_alarm = CLI_SECOND;
    cli_show_tty( "executing" );
  }
  cli_show_tty( "." );
  alarm( 0 );
  alarm( CLI_TIMEOUT_SECOND );

  return;
}


void
cli_control_signal_null() {
  return;
}


ECLI_RESULT
cli_initialize_signal() {
  ( void ) signal( SIGINT, cli_control_signal );
  ( void ) signal( SIGHUP, cli_control_signal_null );
  ( void ) signal( SIGPIPE, cli_control_signal_null );
  ( void ) signal( SIGKILL, cli_control_signal_null );
  ( void ) signal( SIGALRM, cli_control_sinal_alarm );
  ( void ) signal( SIGTERM, cli_control_signal_null );
  ( void ) signal( SIGXCPU, cli_control_signal_null );
  ( void ) signal( SIGXFSZ, cli_control_signal_null );
  ( void ) signal( SIGVTALRM, cli_control_signal_null );
  ( void ) signal( SIGPROF, cli_control_signal_null );
  ( void ) signal( SIGUSR1, cli_control_signal_null );
  ( void ) signal( SIGUSR2, cli_control_signal_null );
  ( void ) signal( SIGQUIT, cli_control_signal_null );

  cli_control_signal_alarm_init();

  return CLI_OK;
}
