#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "cli_define.h"
#include "cli_struct.h"
#include "cli_extern.h"


ECLI_RESULT
cli_initialize_tty() {
  int result;

  result = ttyname_r( 0, cli_ttyname, sizeof( cli_ttyname ) );
  if ( result != 0x00 ) {
    return CLI_NG;
  }

  return CLI_OK;
}


ECLI_RESULT
cli_show_tty( const char *message ) {
  FILE *fp = NULL;

  fp = fopen( cli_ttyname, "w" );
  if ( fp == NULL ) {
    return CLI_NG;
  }
  fprintf( fp, "%s", message );

  fclose( fp );

  return CLI_OK;
}
