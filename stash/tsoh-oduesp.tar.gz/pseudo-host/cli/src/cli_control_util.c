#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <regex.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "cli_define.h"
#include "cli_struct.h"
#include "cli_extern.h"


ECLI_RESULT
cli_do_special_command( char *line ) {
  if ( !strncmp( CLI_EXIT_COMMAND, line, strlen( CLI_EXIT_COMMAND ) ) ) {
    if ( cli_mode == CLI_ADMINMODE ) {
      cli_mode = CLI_ADMINMODE;
      cli_command_word = clidata_admin_word;
    }
    else if ( cli_mode == CLI_CONFIGMODE ) {
      cli_mode = CLI_CONFIGMODE;
      cli_command_word = clidata_config_word;
      strncpy( cli_prompt, CLI_PROMPT_CONFIG, sizeof( cli_prompt ) );
    }
    else if ( cli_mode == CLI_VHOSTMODE ) {
      cli_mode = CLI_CONFIGMODE;
      cli_command_word = clidata_config_word;
      strncpy( cli_prompt, CLI_PROMPT_CONFIG, sizeof( cli_prompt ) );
    }
    return CLI_CONTINUE;
  }
  return CLI_OK;
}


ECLI_RESULT
cli_do_func( ECLI_RESULT ( *func )( void * ), char *data ) {
  if ( func != NULL ) {
    return ( *func )( data );
  }
  return CLI_OK;
}


ECLI_RESULT
cli_adjust_command( char **str ) {
  char *temp;
  char *temp_string;
  char *token, *re_p;
  size_t position = 0;

  temp = calloc( ( strlen( *str ) + 1 ), sizeof( char ) );
  if ( temp == NULL ) {
    return CLI_NG;
  }

  temp_string = calloc( ( strlen( *str ) + 1 ), sizeof( char ) );
  if ( temp_string == NULL ) {
    return CLI_NG;
  }

  strcpy( temp_string, *str );

  token = strtok_r( temp_string, " ", &re_p );
  while ( token != NULL ) {
    strcpy( &temp[ position ], token );
    position += strlen( token );
    temp[ position ] = ' ';
    position += 1;

    token = strtok_r( NULL, " ", &re_p );
  }
  temp[ position - 1 ] = '\0';
  memset( *str, '\0', strlen( *str ) );
  strcpy( *str, temp );
  free( temp );
  free( temp_string );

  return CLI_OK;
}


ECLI_RESULT
cli_check_digit( ECLI_CHECK_DIGITKIND kind, u_char *value ) {
  u_int count = 0, skip_count = 0;
  int result = 0;
  const char *skip_word[ 32 ] = { "_" };

  for ( count = 0; count < strlen( ( char * ) value ); count++ ) {
    if ( ( kind & CLI_CHECK_STRING ) == CLI_CHECK_STRING ) {
      result = isalpha( value[ count ] );
      if ( result == 0 ) {
        return CLI_NG;
      }
    }
    else if ( ( kind & CLI_CHECK_ASCII ) == CLI_CHECK_ASCII ) {
      result = isascii( value[ count ] );
      if ( result == 0 ) {
        return CLI_NG;
      }
    }
    else if ( ( kind & CLI_CHECK_LNUM ) == CLI_CHECK_LNUM ) {
      result = isalnum( value[ count ] );
      if ( result == 0 ) {
        while ( skip_word[ skip_count ] != NULL ) {
          if ( !strncmp( skip_word[ skip_count ], ( char * ) &value[ count ], 1 ) ) {
            break;
          }
          skip_count++;
        }
        if ( skip_word[ skip_count ] == NULL ) {
          return CLI_NG;
        }
      }
    }
    else if ( ( kind & CLI_CHECK_XDIGIT ) == CLI_CHECK_XDIGIT ) {
      if ( !strncmp( ( char * ) &value[ 0 ], "0x", strlen( "0x" ) ) == 0 ) {
        result = isxdigit( value[ count ] );
        if ( result == 0 ) {
          return CLI_NG;
        }
      }
      else {
        if ( count == 0 ) {
          count = count + 2;
        }

        result = isxdigit( value[ count ] );
        if ( result == 0 ) {
          return CLI_NG;
        }
      }
    }
    else if ( ( kind & CLI_CHECK_DIGIT ) == CLI_CHECK_DIGIT ) {
      result = isdigit( value[ count ] );
      if ( result == 0 ) {
        return CLI_NG;
      }
    }
  }

  return CLI_OK;
}


ECLI_RESULT
cli_check_variable_parameter( const char *syntax ) {
  int count = 0;
  ECLI_RESULT result = CLI_OK;

  while ( 1 ) {
    if ( strncmp( cli_word_notcompare_word[ count ], "", strlen( cli_word_notcompare_word[ count ] ) ) == 0 ) {
      break;
    }
    if ( strncmp( cli_word_notcompare_word[ count ], syntax, strlen( syntax ) ) == 0 ) {
      return CLI_NEXTCHAIN;
    }
    count++;
  }

  return result;
}


ECLI_RESULT
cli_set_name( char *name, char *set_data ) {
  if ( strlen( name ) > NAME_SIZE ) {
    MCLI_ERROR( ( CLI_ERROR_SYNTAX, "host name length error" ) );
    return CLI_NG;
  }

  strncpy( set_data, name, NAME_SIZE );

  return CLI_OK;
}


ECLI_RESULT
cli_set_macaddress( char *mac_address, char *set_data ) {
  char mac[ MAC_SIZE ];
  regex_t preg;
  size_t nmatch = 1;
  regmatch_t pmatch[ nmatch ];

  if ( strlen( mac_address ) > MAC_SIZE ) {
    return CLI_NG;
  }

  if ( regcomp( &preg, CLI_REGEX_MAC, REG_EXTENDED | REG_NEWLINE ) != 0 ) {
    return CLI_NG;
  }

  if ( regexec( &preg, mac_address, nmatch, pmatch, 0 ) != 0 ) {
    return CLI_NG;
  }
  regfree( &preg );

  sscanf( mac_address, "%02x:%02x:%02x:%02x:%02x:%02x", ( u_int * ) &mac[ 0 ], ( u_int * ) &mac[ 1 ],
                                                        ( u_int * ) &mac[ 2 ], ( u_int * ) &mac[ 3 ],
                                                        ( u_int * ) &mac[ 4 ], ( u_int * ) &mac[ 5 ] );
  set_data[ 0 ] = mac[ 0 ];
  set_data[ 1 ] = mac[ 1 ];
  set_data[ 2 ] = mac[ 2 ];
  set_data[ 3 ] = mac[ 3 ];
  set_data[ 4 ] = mac[ 4 ];
  set_data[ 5 ] = mac[ 5 ];

  return CLI_OK;
}


ECLI_RESULT
cli_set_ipaddress( char *ip_address, u_int *set_data ) {
  regex_t preg;
  size_t nmatch = 1;
  regmatch_t pmatch[ nmatch ];

  if ( strlen( ip_address ) > IP_SIZE ) {
    return CLI_NG;
  }

  if ( regcomp( &preg, CLI_REGEX_IP, REG_EXTENDED | REG_NEWLINE ) != 0 ) {
    return CLI_NG;
  }

  if ( regexec( &preg, ip_address, nmatch, pmatch, 0 ) != 0 ) {
    return CLI_NG;
  }
  regfree( &preg );

  *set_data = inet_addr( ip_address );

  return CLI_OK;
}


ECLI_RESULT
cli_check_regexp( const char *regexp, char *check_string ) {
  regex_t preg;
  size_t nmatch = 1;
  regmatch_t pmatch[ nmatch ];

  if ( regcomp( &preg, regexp, REG_EXTENDED | REG_NEWLINE ) != 0 ) {
    return CLI_NG;
  }

  if ( regexec( &preg, check_string, nmatch, pmatch, 0 ) != 0 ) {
    return CLI_NG;
  }
  regfree( &preg );

  return CLI_OK;
}
