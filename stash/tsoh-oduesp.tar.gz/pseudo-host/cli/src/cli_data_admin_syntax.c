#include <stdio.h>

#include "cmn.h"
#include "cli_define.h"
#include "cli_struct.h"
#include "cli_extern.h"

extern clictrl_cmdchain_t clidata_admin_send_vhost_chain [ 10 ] ;
extern clictrl_cmdchain_t clidata_admin_send_udp_chain[ 11 ] ;
extern clictrl_cmdchain_t clidata_admin_send_udp2_chain[ 14 ] ;
extern clictrl_cmdchain_t clidata_admin_send_ip_chain[ 19 ] ;
extern clictrl_cmdchain_t clidata_admin_send_l2type_vlan_chain[ 15 ] ;
extern clictrl_cmdchain_t clidata_admin_send_l2type_vlan2_chain[ 18 ] ;
extern clictrl_cmdchain_t clidata_admin_send_ipsrc_chain[ 2 ] ; 
extern clictrl_cmdchain_t clidata_admin_send_ipdst_chain[ 2 ]; 
extern clictrl_cmdchain_t clidata_admin_send_l2type_chain[ 3 ] ;
extern clictrl_cmdchain_t clidata_admin_send_l3type_chain [ 3 ] ;
extern clictrl_cmdchain_t clidata_admin_send_arp_chain[ 17 ] ;
extern clictrl_cmdchain_t clidata_admin_send_arp2_chain[ 20 ] ;
extern clictrl_cmdchain_t clidata_admin_send_ip2_chain[ 22 ] ;
extern clictrl_cmdchain_t clidata_admin_send_vhost2_chain [ 13 ] ;
extern clictrl_cmdchain_t clidata_admin_send_ip3_chain[ 20 ] ;
extern clictrl_cmdchain_t clidata_admin_send_arp3_chain [ 18 ] ;
extern clictrl_cmdchain_t clidata_admin_send_vhost3_chain [ 11 ] ;
extern clictrl_cmdchain_t clidata_admin_send_udp3_chain [ 12 ] ;
extern const char *clidata_admin_send_l3type[ 64 ] ; 

const char *clidata_admin_cr[ 64 ] = {
    CLI_WORD_CR,"　"
} ;

const char *clidata_admin_end[ 64 ] = {
    ""
} ;
const char *clidata_admin_word[ 256 ] = {
    CLI_WORD_SEND, CLI_WORD_START, CLI_WORD_STOP, CLI_WORD_CANCEL, 
    CLI_WORD_CONFIG, CLI_WORD_EXIT,CLI_WORD_SHOW,CLI_WORD_CLEAR,
} ;

const char *clidata_admin_send[ 64 ] = {
    _CLI_WORD_VHOSTNAME,"　"
} ;

const char *clidata_admin_cancel[ 64 ] = {
    _CLI_WORD_VHOSTNAME,"　"
} ;

const char *clidata_admin_start[ 64 ] = {
    CLI_WORD_ALL,_CLI_WORD_VHOSTNAME,
} ;

const char *clidata_admin_stop[ 64 ] = {
    CLI_WORD_ALL,_CLI_WORD_VHOSTNAME,
} ;

const char *clidata_admin_cancel_vhost[ 64 ] = {
    _CLI_WORD_CANCELKEY, "　"
} ;

const char *clidata_admin_send_vhost[ 64 ] = {
    CLI_WORD_BACKGROUND,CLI_WORD_L2TYPE,CLI_WORD_L3TYPE,CLI_WORD_UDP,CLI_WORD_PAYLOAD,
    CLI_WORD_PPS,CLI_WORD_DURATION,CLI_WORD_LENGTH,CLI_WORD_PACKETNUM,CLI_WORD_CR
} ;

const char *clidata_admin_send_vhost2[ 64 ] = {
    CLI_WORD_BACKGROUND,CLI_WORD_L2TYPE,CLI_WORD_L3TYPE,CLI_WORD_UDP,CLI_WORD_PAYLOAD,
    CLI_WORD_PPS,CLI_WORD_DURATION,CLI_WORD_LENGTH,CLI_WORD_PACKETNUM,CLI_WORD_CR,
    CLI_WORD_INCREMENT,CLI_WORD_DECREMENT,CLI_WORD_RANDOM
} ;

const char *clidata_admin_send_vhost3[ 64 ] = {
    CLI_WORD_BACKGROUND,CLI_WORD_L2TYPE,CLI_WORD_L3TYPE,CLI_WORD_UDP,CLI_WORD_PAYLOAD,
    CLI_WORD_PPS,CLI_WORD_DURATION,CLI_WORD_LENGTH,CLI_WORD_PACKETNUM,CLI_WORD_CR,
    CLI_WORD_COUNT_LIMIT
} ;

const char *clidata_admin_send_l2type_ether[ 64 ] = {
    CLI_WORD_MACSRC,CLI_WORD_MACDST,CLI_WORD_ETHERTYPE,CLI_WORD_BACKGROUND,CLI_WORD_L2TYPE,
    CLI_WORD_L3TYPE,CLI_WORD_UDP,CLI_WORD_PAYLOAD,
    CLI_WORD_PPS,CLI_WORD_DURATION,CLI_WORD_LENGTH,CLI_WORD_PACKETNUM
} ;

const char *clidata_admin_send_l2type_vlan[ 64 ] = {
    CLI_WORD_MACSRC,CLI_WORD_MACDST,CLI_WORD_ETHERTYPE,CLI_WORD_COS,CLI_WORD_VLANID,
    CLI_WORD_BACKGROUND,CLI_WORD_L2TYPE,CLI_WORD_L3TYPE,CLI_WORD_UDP,CLI_WORD_PAYLOAD,
    CLI_WORD_PPS,CLI_WORD_DURATION,CLI_WORD_LENGTH,CLI_WORD_PACKETNUM
} ;
const char *clidata_admin_send_l2type_vlan2[ 64 ] = {
    CLI_WORD_MACSRC,CLI_WORD_MACDST,CLI_WORD_ETHERTYPE,CLI_WORD_COS,CLI_WORD_VLANID,
    CLI_WORD_INCREMENT,CLI_WORD_DECREMENT,CLI_WORD_RANDOM,CLI_WORD_BACKGROUND,
    CLI_WORD_L2TYPE,CLI_WORD_L3TYPE,CLI_WORD_UDP,CLI_WORD_PAYLOAD,
    CLI_WORD_PPS,CLI_WORD_DURATION,CLI_WORD_LENGTH,CLI_WORD_PACKETNUM
} ;

const char *clidata_admin_send_l2type_vlan3[ 64 ] = {
    CLI_WORD_MACSRC,CLI_WORD_MACDST,CLI_WORD_ETHERTYPE,CLI_WORD_COS,CLI_WORD_VLANID,
    CLI_WORD_INCREMENT,CLI_WORD_DECREMENT,CLI_WORD_RANDOM,CLI_WORD_BACKGROUND,
    CLI_WORD_L2TYPE,CLI_WORD_L3TYPE,CLI_WORD_UDP,CLI_WORD_PAYLOAD,
    CLI_WORD_PPS,CLI_WORD_DURATION,CLI_WORD_LENGTH,CLI_WORD_PACKETNUM,CLI_WORD_COUNT_LIMIT
} ;

const char *cildata_admin_send_l2type[ 64 ] = {
    CLI_WORD_VLAN,CLI_WORD_ETHER
} ;

const char *clidata_admin_send_udp[ 64 ] = {
    CLI_WORD_PORTSRC,CLI_WORD_PORTDST,CLI_WORD_BACKGROUND,CLI_WORD_PAYLOAD,
    CLI_WORD_PPS,CLI_WORD_DURATION,CLI_WORD_LENGTH,CLI_WORD_PACKETNUM,
    CLI_WORD_L2TYPE,CLI_WORD_L3TYPE
} ;

const char *clidata_admin_send_udp2[ 64 ] = {
    CLI_WORD_PORTSRC,CLI_WORD_PORTDST,CLI_WORD_INCREMENT,CLI_WORD_DECREMENT,CLI_WORD_RANDOM,
    CLI_WORD_BACKGROUND,CLI_WORD_PAYLOAD,CLI_WORD_PPS,CLI_WORD_DURATION,
    CLI_WORD_LENGTH,CLI_WORD_PACKETNUM,CLI_WORD_L2TYPE,CLI_WORD_L3TYPE
} ;

const char *clidata_admin_send_udp3[ 64 ] = {
    CLI_WORD_PORTSRC,CLI_WORD_PORTDST,CLI_WORD_BACKGROUND,CLI_WORD_PAYLOAD,
    CLI_WORD_PPS,CLI_WORD_DURATION,CLI_WORD_LENGTH,CLI_WORD_PACKETNUM,CLI_WORD_COUNT_LIMIT,
    CLI_WORD_L2TYPE,CLI_WORD_L3TYPE
} ;

const char *clidata_admin_send_port[ 64 ] = {
    _CLI_WORD_PORT,"　"
} ;

const char *clidata_admin_send_l3type[ 64 ] = {
    CLI_WORD_ARP,CLI_WORD_IP
} ;

const char *clidata_admin_send_arp[ 64 ] = {
    CLI_WORD_HARDTYPE,CLI_WORD_PROTOCOLTYPE,CLI_WORD_OPERATIONCODE,CLI_WORD_MACSRC,
    CLI_WORD_MACDST,CLI_WORD_IPSRC,CLI_WORD_IPDST,CLI_WORD_BACKGROUND,CLI_WORD_L2TYPE,
    CLI_WORD_L3TYPE,CLI_WORD_UDP,CLI_WORD_PAYLOAD,
    CLI_WORD_PPS,CLI_WORD_DURATION,CLI_WORD_LENGTH,CLI_WORD_PACKETNUM
} ;

const char *clidata_admin_send_arp2[ 64 ] = {
    CLI_WORD_HARDTYPE,CLI_WORD_PROTOCOLTYPE,CLI_WORD_OPERATIONCODE,CLI_WORD_MACSRC,
    CLI_WORD_MACDST,CLI_WORD_IPSRC,CLI_WORD_IPDST,CLI_WORD_INCREMENT,CLI_WORD_DECREMENT,
    CLI_WORD_RANDOM,CLI_WORD_BACKGROUND,CLI_WORD_L2TYPE,CLI_WORD_L3TYPE,CLI_WORD_UDP,CLI_WORD_PAYLOAD,
    CLI_WORD_PPS,CLI_WORD_DURATION,CLI_WORD_LENGTH,CLI_WORD_PACKETNUM
} ;

const char *clidata_admin_send_arp3[ 64 ] = {
    CLI_WORD_HARDTYPE,CLI_WORD_PROTOCOLTYPE,CLI_WORD_OPERATIONCODE,CLI_WORD_MACSRC,
    CLI_WORD_MACDST,CLI_WORD_IPSRC,CLI_WORD_IPDST,CLI_WORD_BACKGROUND,CLI_WORD_L2TYPE,
    CLI_WORD_L3TYPE,CLI_WORD_UDP,CLI_WORD_PAYLOAD,
    CLI_WORD_PPS,CLI_WORD_DURATION,CLI_WORD_LENGTH,CLI_WORD_PACKETNUM,CLI_WORD_COUNT_LIMIT
} ;

const char *clidata_admin_send_arp_hardwaretype[ 64 ] = {
    _CLI_WORD_HEADWARETYPE,"　"
} ;

const char *clidata_admin_send_arp_protocoltype[ 64 ] = {
    _CLI_WORD_PROTOCOLTYPE, "　"
} ;

const char *clidata_admin_send_arp_operationcode[ 64 ] = {
    _CLI_WORD_OPERATIONCODE, "　"
} ;

const char *clidata_admin_send_ip[ 64 ] = {
    CLI_WORD_TOS,CLI_WORD_ID,CLI_WORD_FLAG,CLI_WORD_FLAGOFFSET,CLI_WORD_PROTOCOLNUM,
    CLI_WORD_IPSRC,CLI_WORD_IPDST,CLI_WORD_BACKGROUND,CLI_WORD_L2TYPE,CLI_WORD_L3TYPE,
    CLI_WORD_UDP,CLI_WORD_PAYLOAD,CLI_WORD_CR,CLI_WORD_OPTION,CLI_WORD_TTL,
    CLI_WORD_PPS,CLI_WORD_DURATION,CLI_WORD_LENGTH,CLI_WORD_PACKETNUM
} ;

const char *clidata_admin_send_ip2[ 64 ] = {
    CLI_WORD_TOS,CLI_WORD_ID,CLI_WORD_FLAG,CLI_WORD_FLAGOFFSET,CLI_WORD_PROTOCOLNUM,
    CLI_WORD_IPSRC,CLI_WORD_IPDST,CLI_WORD_BACKGROUND,CLI_WORD_L2TYPE,CLI_WORD_L3TYPE,
    CLI_WORD_UDP,CLI_WORD_PAYLOAD,CLI_WORD_INCREMENT,CLI_WORD_DECREMENT,CLI_WORD_RANDOM,
    CLI_WORD_PPS,CLI_WORD_DURATION,CLI_WORD_LENGTH,CLI_WORD_PACKETNUM,CLI_WORD_CR,
    CLI_WORD_OPTION,CLI_WORD_TTL
} ;

const char *clidata_admin_send_ip3[ 64 ] = {
    CLI_WORD_TOS,CLI_WORD_ID,CLI_WORD_FLAG,CLI_WORD_FLAGOFFSET,CLI_WORD_PROTOCOLNUM,
    CLI_WORD_IPSRC,CLI_WORD_IPDST,CLI_WORD_BACKGROUND,CLI_WORD_L2TYPE,CLI_WORD_L3TYPE,
    CLI_WORD_UDP,CLI_WORD_PAYLOAD,CLI_WORD_CR,CLI_WORD_OPTION,CLI_WORD_TTL,
    CLI_WORD_PPS,CLI_WORD_DURATION,CLI_WORD_LENGTH,CLI_WORD_PACKETNUM,CLI_WORD_COUNT_LIMIT
} ;


const char *clidata_admin_send_tos[ 64 ] = {
    _CLI_WORD_TOS,"　"
} ;

const char *clidata_admin_send_ttl[ 64 ] = {
    _CLI_WORD_TTL,"　"
} ;

const char *clidata_admin_send_id[ 64 ] = {
    _CLI_WORD_ID, "　"
} ;

const char *clidata_admin_send_flag[ 64 ] = {
    _CLI_WORD_FLAG,"　"
} ;

const char *clidata_admin_send_flagoffset[ 64 ] = {
    _CLI_WORD_OFFSET,"　"
} ;

const char *clidata_admin_send_protocolnum[ 64 ] = {
    _CLI_WORD_PROTOCOLTYPE,"　"
} ;

const char *clidata_admin_send_ipaddress[ 64 ] = {
    _CLI_WORD_IPADDRESS,"　"
} ;

const char *clidata_admin_send_option[ 64 ] = {
    _CLI_WORD_OPTION, "　"
} ;

const char *clidata_admin_send_mac_address[ 64 ] = {
    _CLI_WORD_MACADDRESS,"　"
} ;

const char *cildata_admin_send_ethertype[ 64 ] = {
    _CLI_WORD_ETHERTYPE,"　"
} ;

const char *clidata_admin_send_cos[ 64 ] = {
    _CLI_WORD_COS,"　"
} ;

const char *clidata_admin_send_vlanid[ 64 ] = {
    _CLI_WORD_VLANID,"　"
} ;

const char *clidata_admin_send_count[ 64 ] = {
    _CLI_WORD_COUNT,"　"
} ;

const char *clidata_admin_send_countlimit[ 64 ] = {
    _CLI_WORD_COUNT_LIMIT,"　"
} ;

const char *clidata_admin_send_mask[ 64 ] = {
    _CLI_WORD_MASK,"　"
} ;

const char *clidata_admin_send_duration[ 64 ] = {
    _CLI_WORD_DURATION,"　"
} ;

const char *clidata_admin_send_pps[ 64 ] = {
    _CLI_WORD_PPS,"　"
} ;

const char *clidata_admin_send_lenght[ 64 ] = {
    _CLI_WORD_LENGTH,"　"
} ;


/************************************************************************/
/* show command                                                         */
/************************************************************************/

const char *clidata_admin_show[ 64 ] = {
    CLI_WORD_CONFIG,CLI_WORD_VHOST,CLI_WORD_STATISTICS,CLI_WORD_ARP
} ;

const char *clidata_admin_show_stat[ 64 ] = {
    _CLI_WORD_VHOSTNAME,CLI_WORD_ALL
} ;

const char *clidata_admin_show_stat_vhostname[ 64 ] = {
    CLI_WORD_CR,_CLI_WORD_FILE,"　"
} ;

const char *clidata_admin_show_arp[ 64 ] = {
    _CLI_WORD_VHOSTNAME,CLI_WORD_ALL
} ;


/************************************************************************/
/* clear command                                                        */
/************************************************************************/
const char *clidata_admin_clear[ 64 ] = {
    CLI_WORD_ARP,CLI_WORD_STATISTICS
} ;

const char *clidata_admin_clear_arp[ 64 ] = {
    CLI_WORD_ALL,_CLI_WORD_VHOSTNAME
} ;

const char *clidata_admin_clear_stat[ 64 ] = {
    CLI_WORD_ALL,_CLI_WORD_VHOSTNAME
};

const char *clidata_admin_clear_arp_vhostname[ 64 ] = {
    CLI_WORD_CR,CLI_WORD_IPADDR
};

const char *clidata_admin_clear_arp_vhostname_ip[ 64 ] = {
    _CLI_WORD_IPADDRESS,"　"
} ;

const char *clidata_admin_clear_arp_vhostname_mac[ 64 ] = {
    CLI_WORD_MACADDR
} ;

const char *clidata_admin_clear_arp_vhostname_mac_addr[ 64 ] = {
    _CLI_WORD_MACADDRESS,"　"
} ;

const char *clidata_admin_clear_stat_vhost[ 64 ] = {
    CLI_WORD_RECV,CLI_WORD_SEND,CLI_WORD_CR
} ;


/************************************************************************/
/* send option head                                                     */
/************************************************************************/
const char *clidata_admin_send_payload[ 64 ] = {
    _CLI_WORD_DATA,"　"
} ;

clictrl_cmdchain_t clidata_admin_send_payload_increment [ 2 ] = {
    { _CLI_WORD_COUNT,      clidata_admin_send_vhost3,
                            NULL,
                            clidata_admin_send_vhost3_chain,
                            cli_set_admin_increment,
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_payload_decrement [ 2 ] = {
    { _CLI_WORD_COUNT,      clidata_admin_send_vhost3,
                            NULL,
                            clidata_admin_send_vhost3_chain,
                            cli_set_admin_decrement,
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }

} ;

clictrl_cmdchain_t clidata_admin_send_payload_random [ 2 ] = {
    { _CLI_WORD_MASK,       clidata_admin_send_vhost,
                            NULL,
                            clidata_admin_send_vhost_chain,
                            cli_set_admin_random,
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }


} ;

clictrl_cmdchain_t clidata_admin_send_payload_chain[ 2 ] = {
    { _CLI_WORD_DATA,       clidata_admin_send_vhost2,
                            NULL,
                            clidata_admin_send_vhost2_chain,
                            cli_set_admin_payload, 
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;


clictrl_cmdchain_t clidata_admin_send_pps_chain[ 2 ] = {
    { _CLI_WORD_PPS,        clidata_admin_send_vhost,
                            NULL,
                            clidata_admin_send_vhost_chain,
                            cli_set_admin_pps, 
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;


clictrl_cmdchain_t clidata_admin_send_duration_chain[ 2 ] = {
    { _CLI_WORD_DURATION,   clidata_admin_send_vhost,
                            NULL,
                            clidata_admin_send_vhost_chain,
                            cli_set_admin_duration, 
                            cli_do_send } ,
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;


clictrl_cmdchain_t clidata_admin_send_length_chain[ 2 ] = {
    { _CLI_WORD_LENGTH,     clidata_admin_send_vhost,
                            NULL,
                            clidata_admin_send_vhost_chain,
                            cli_set_admin_length, 
                            cli_do_send } ,
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

const char *clidata_admin_send_packetnum[ 64 ] = {
    _CLI_WORD_PACKETNUM,"　"
} ;

clictrl_cmdchain_t clidata_admin_send_packetnum_chain[ 2 ] = {
    { _CLI_WORD_PACKETNUM,  clidata_admin_send_vhost,
                            NULL,
                            clidata_admin_send_vhost_chain,
                            cli_set_admin_packetnum, 
                            cli_do_send } ,
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

/************************************************************************/
/* send udp head                                                        */
/************************************************************************/

clictrl_cmdchain_t clidata_admin_send_port_countlimit [ 2 ] = {
    { _CLI_WORD_COUNT_LIMIT,clidata_admin_send_udp,
                            NULL,
                            clidata_admin_send_udp_chain,
                            cli_set_admin_countlimit, 
                            cli_do_send },    
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;


clictrl_cmdchain_t clidata_admin_send_port_increment [ 2 ] = {
    { _CLI_WORD_COUNT,      clidata_admin_send_udp3,
                            NULL,
                            clidata_admin_send_udp3_chain,
                            cli_set_admin_increment, 
                            cli_do_send },    
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_port_decrement [ 2 ] = {
    { _CLI_WORD_COUNT,      clidata_admin_send_udp3,
                            NULL,
                            clidata_admin_send_udp3_chain,
                            cli_set_admin_decrement, 
                            cli_do_send },    
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_port_random [ 2 ] = {
    { _CLI_WORD_MASK,       clidata_admin_send_udp,
                            NULL,
                            clidata_admin_send_udp_chain,
                            cli_set_admin_random, 
                            cli_do_send },    
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_portsrc_chain [ 2 ] = {
    { _CLI_WORD_PORT,       clidata_admin_send_udp2,
                            NULL,
                            clidata_admin_send_udp2_chain,
                            cli_set_admin_source_port_number, 
                            cli_do_send }, 
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_portdst_chain [ 2 ] = {
    { _CLI_WORD_PORT,       clidata_admin_send_udp2,
                            NULL,
                            clidata_admin_send_udp2_chain,
                            cli_set_admin_destination_port_number, 
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_udp_chain [ 11 ] = {
    { CLI_WORD_PORTSRC,     clidata_admin_send_port,
                            NULL,
                            clidata_admin_send_portsrc_chain,
                            NULL, NULL },
    { CLI_WORD_PORTDST,     clidata_admin_send_port,
                            NULL,
                            clidata_admin_send_portdst_chain,
                            NULL, NULL },
    { CLI_WORD_BACKGROUND,  clidata_admin_send_vhost,
                            NULL,
                            clidata_admin_send_vhost_chain,
                            cli_set_admin_backgroud,
                            NULL },
    { CLI_WORD_PAYLOAD,     clidata_admin_send_payload,
                            NULL,
                            clidata_admin_send_payload_chain,
                            NULL, NULL },
    { CLI_WORD_PPS,         clidata_admin_send_pps,
                            NULL,
                            clidata_admin_send_pps_chain,
                            NULL, NULL },
    { CLI_WORD_DURATION,    clidata_admin_send_duration,
                            NULL,
                            clidata_admin_send_duration_chain,
                            NULL, NULL },
    { CLI_WORD_LENGTH,      clidata_admin_send_lenght,
                            NULL,
                            clidata_admin_send_length_chain,
                            NULL, NULL },
    { CLI_WORD_PACKETNUM,   clidata_admin_send_packetnum,
                            NULL,
                            clidata_admin_send_packetnum_chain,
                            NULL, NULL },
    { CLI_WORD_L2TYPE,      cildata_admin_send_l2type,
                            NULL,
                            clidata_admin_send_l2type_chain,
                            NULL, NULL},
    { CLI_WORD_L3TYPE,      clidata_admin_send_l3type,
                            NULL,
                            clidata_admin_send_l3type_chain,
                            NULL, NULL },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;


clictrl_cmdchain_t clidata_admin_send_udp2_chain [ 14 ] = {
    { CLI_WORD_PORTSRC,     clidata_admin_send_port,
                            NULL,
                            clidata_admin_send_ipsrc_chain,
                            NULL, NULL },
    { CLI_WORD_PORTDST,     clidata_admin_send_port,
                            NULL,
                            clidata_admin_send_portdst_chain,
                            NULL, NULL },
    { CLI_WORD_INCREMENT,   clidata_admin_send_count,
                            NULL,
                            clidata_admin_send_port_increment,
                            NULL, NULL },
    { CLI_WORD_DECREMENT,   clidata_admin_send_count,
                            NULL,
                            clidata_admin_send_port_decrement,
                            NULL, NULL },
    { CLI_WORD_RANDOM,      clidata_admin_send_mask,
                            NULL,
                            clidata_admin_send_port_random,
                            NULL, NULL },
    { CLI_WORD_BACKGROUND,  clidata_admin_send_vhost,
                            NULL,
                            clidata_admin_send_vhost_chain,
                            cli_set_admin_backgroud,
                            NULL },
    { CLI_WORD_PAYLOAD,     clidata_admin_send_payload,
                            NULL,
                            clidata_admin_send_payload_chain,
                            NULL, NULL } ,
    { CLI_WORD_PPS,         clidata_admin_send_pps,
                            NULL,
                            clidata_admin_send_pps_chain,
                            NULL, NULL },
    { CLI_WORD_DURATION,    clidata_admin_send_duration,
                            NULL,
                            clidata_admin_send_duration_chain,
                            NULL, NULL },
    { CLI_WORD_LENGTH,      clidata_admin_send_lenght,
                            NULL,
                            clidata_admin_send_length_chain,
                            NULL, NULL },
    { CLI_WORD_PACKETNUM,   clidata_admin_send_packetnum,
                            NULL,
                            clidata_admin_send_packetnum_chain,
                            NULL, NULL },
    { CLI_WORD_L2TYPE,      cildata_admin_send_l2type,
                            NULL,
                            clidata_admin_send_l2type_chain,
                            NULL, NULL},
    { CLI_WORD_L3TYPE,      clidata_admin_send_l3type,
                            NULL,
                            clidata_admin_send_l3type_chain,
                            NULL, NULL },
    { NULL,             NULL,NULL,NULL,NULL,NULL }
} ;


clictrl_cmdchain_t clidata_admin_send_udp3_chain [ 12 ] = {
    { CLI_WORD_PORTSRC,     clidata_admin_send_port,
                            NULL,
                            clidata_admin_send_portsrc_chain,
                            NULL, NULL },
    { CLI_WORD_PORTDST,     clidata_admin_send_port,
                            NULL,
                            clidata_admin_send_portdst_chain,
                            NULL, NULL },
    { CLI_WORD_BACKGROUND,  clidata_admin_send_vhost,
                            NULL,
                            clidata_admin_send_vhost_chain,
                            cli_set_admin_backgroud,
                            NULL },
    { CLI_WORD_PAYLOAD,     clidata_admin_send_payload,
                            NULL,
                            clidata_admin_send_payload_chain,
                            NULL, NULL },
    { CLI_WORD_PPS,         clidata_admin_send_pps,
                            NULL,
                            clidata_admin_send_pps_chain,
                            NULL, NULL },
    { CLI_WORD_DURATION,    clidata_admin_send_duration,
                            NULL,
                            clidata_admin_send_duration_chain,
                            NULL, NULL },
    { CLI_WORD_LENGTH,      clidata_admin_send_lenght,
                            NULL,
                            clidata_admin_send_length_chain,
                            NULL, NULL },
    { CLI_WORD_PACKETNUM,   clidata_admin_send_packetnum,
                            NULL,
                            clidata_admin_send_packetnum_chain,
                            NULL, NULL },
    { CLI_WORD_COUNT_LIMIT, clidata_admin_send_countlimit,
                            NULL,
                            clidata_admin_send_port_countlimit,
                            NULL, NULL },
    { CLI_WORD_L2TYPE,      cildata_admin_send_l2type,
                            NULL,
                            clidata_admin_send_l2type_chain,
                            NULL, NULL},
    { CLI_WORD_L3TYPE,      clidata_admin_send_l3type,
                            NULL,
                            clidata_admin_send_l3type_chain,
                            NULL, NULL },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;


/************************************************************************/
/* show command                                                         */
/************************************************************************/
clictrl_cmdchain_t clidata_admin_show_stat_vhostname_chain[ 2 ] = {
    { _CLI_WORD_FILE,       clidata_admin_cr,
                            NULL,
                            NULL,
                            cli_set_statistics_vhostname_file, 
                            cli_do_show_statistics_vhostname_file },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_show_stat_chain[ 3 ] = {
    { CLI_WORD_ALL,         clidata_admin_show_stat_vhostname,
                            NULL,
                            clidata_admin_show_stat_vhostname_chain,
                            cli_set_show_statistics_all, 
                            cli_do_show_statistics_all },
    { _CLI_WORD_VHOSTNAME,  clidata_admin_show_stat_vhostname,
                            NULL,
                            clidata_admin_show_stat_vhostname_chain,
                            cli_set_show_statistics_vhost, 
                            cli_do_show_statistics_vhostname },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_show_arp_chain[ 3 ] = {
    { CLI_WORD_ALL,         clidata_admin_cr,
                            NULL, NULL,
                            NULL, cli_do_show_arp_all },
    { _CLI_WORD_VHOSTNAME,  clidata_admin_cr,
                            NULL, NULL,
                            cli_set_admin_vhost, 
                            cli_do_show_arp_vhostname },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_show_chain[ 5 ] = {
    
    { CLI_WORD_CONFIG,      clidata_admin_cr,
                            NULL, NULL,
                            NULL, cli_do_show_config },
    { CLI_WORD_VHOST,       clidata_admin_cr,
                            NULL, NULL,
                            NULL, cli_do_show_vhost },
    { CLI_WORD_STATISTICS,  clidata_admin_show_stat,
                            NULL,
                            clidata_admin_show_stat_chain,
                            NULL, NULL },
    { CLI_WORD_ARP,         clidata_admin_show_arp,
                            NULL,
                            clidata_admin_show_arp_chain,
                            NULL, NULL },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
    
} ;

/************************************************************************/
/* clear command                                                        */
/************************************************************************/
clictrl_cmdchain_t clidata_admin_clear_stat_vhost_chain [ 3 ] = {
    { CLI_WORD_RECV,        clidata_admin_cr,
                            NULL, NULL, NULL, 
                            cli_do_clear_statistics_recv },
    { CLI_WORD_SEND,        clidata_admin_cr,
                            NULL, NULL, NULL, 
                            cli_do_clear_statistics_send },    
    { NULL,                 NULL,NULL,NULL,NULL,NULL }  
} ;

clictrl_cmdchain_t clidata_admin_clear_stat_all_chain [ 3 ] = {
    { CLI_WORD_RECV,        clidata_admin_cr,
                            NULL, NULL, NULL,
                            cli_do_clear_statistics_all_recv },
    { CLI_WORD_SEND,        clidata_admin_cr,
                            NULL, NULL, NULL,
                            cli_do_clear_statistics_all_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_clear_stat_chain [ 3 ] = {
    { CLI_WORD_ALL,         clidata_admin_clear_stat_vhost,
                            NULL,
                            clidata_admin_clear_stat_all_chain,
                            NULL, 
                            cli_do_clear_statistics_all },
    { _CLI_WORD_VHOSTNAME,  clidata_admin_clear_stat_vhost,
                            NULL,
                            clidata_admin_clear_stat_vhost_chain,
                            cli_set_admin_vhost, 
                            cli_do_clear_statistics_vhost }, 
    { NULL,                 NULL,NULL,NULL,NULL,NULL }  
} ;

// clear arp
clictrl_cmdchain_t clidata_admin_clear_arp_vhostname_mac_addr_chain[ 2 ] = { 
    { _CLI_WORD_MACADDRESS, clidata_admin_cr,
                            NULL, NULL,
                            cli_set_admin_mac_address, 
                            cli_do_clear_arp_macaddress },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_clear_arp_vhostname_mac_chain[ 2 ] = {
    { CLI_WORD_MACADDR,     clidata_admin_clear_arp_vhostname_mac_addr,
                            NULL,
                            clidata_admin_clear_arp_vhostname_mac_addr_chain,
                            NULL, NULL },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }  
}; 

clictrl_cmdchain_t clidata_admin_clear_arp_vhostname_ip_chain[ 2 ] = {
    { _CLI_WORD_IPADDRESS,  clidata_admin_clear_arp_vhostname_mac,
                            NULL,
                            clidata_admin_clear_arp_vhostname_mac_chain,
                            cli_set_admin_ip_address, NULL },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }  
} ;

clictrl_cmdchain_t clidata_admin_clear_arp_vhostname_chain[ 2 ] = {
    { CLI_WORD_IPADDR,      clidata_admin_clear_arp_vhostname_ip,
                            NULL,
                            clidata_admin_clear_arp_vhostname_ip_chain,
                            NULL, NULL },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_clear_arp_chain [ ] = {
    { CLI_WORD_ALL,         clidata_admin_cr,
                            NULL, NULL, NULL, 
                            cli_do_clear_arp_all },
    { _CLI_WORD_VHOSTNAME,  clidata_admin_clear_arp_vhostname,
                            NULL,
                            clidata_admin_clear_arp_vhostname_chain,
                            cli_set_admin_vhost, 
                            cli_do_clear_arp_vhostname },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }  
} ;

clictrl_cmdchain_t clidata_admin_clear_chain [ 3 ] = {
    { CLI_WORD_ARP,         clidata_admin_clear_arp,
                            NULL,
                            clidata_admin_clear_arp_chain,
                            NULL, NULL },
    { CLI_WORD_STATISTICS,  clidata_admin_clear_stat,
                            NULL,
                            clidata_admin_clear_stat_chain,
                            NULL, NULL },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;



/************************************************************************/
/* send command                                                         */
/************************************************************************/

clictrl_cmdchain_t clidata_admin_send_l3type_countlimit [ 2 ] = {
    { _CLI_WORD_COUNT_LIMIT,clidata_admin_send_ip,
                            NULL,
                            clidata_admin_send_ip_chain,
                            cli_set_admin_countlimit, 
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;


clictrl_cmdchain_t clidata_admin_send_l3type_increment [ 2 ] = {
    { _CLI_WORD_COUNT,      clidata_admin_send_ip3,
                            NULL,
                            clidata_admin_send_ip3_chain,
                            cli_set_admin_increment, 
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_l3type_decrement [ 2 ] = {
    { _CLI_WORD_COUNT,      clidata_admin_send_ip3,
                            NULL,
                            clidata_admin_send_ip3_chain,
                            cli_set_admin_decrement, 
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_l3type_random [ 2 ] = {
    { _CLI_WORD_MASK,       clidata_admin_send_ip,
                            NULL,
                            clidata_admin_send_ip_chain,
                            cli_set_admin_random, 
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_flag_chain [ 2 ] = {
    { _CLI_WORD_FLAG,       clidata_admin_send_ip,
                            NULL,
                            clidata_admin_send_ip_chain,
                            cli_set_admin_flag,
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_tos_chain [ 2 ] = {
    { _CLI_WORD_TOS,        clidata_admin_send_ip,
                            NULL,
                            clidata_admin_send_ip_chain,
                            cli_set_admin_tos,
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_ttl_chain [ 2 ] = {
    { _CLI_WORD_TTL,        clidata_admin_send_ip,
                            NULL,
                            clidata_admin_send_ip_chain,
                            cli_set_admin_ttl,
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;


clictrl_cmdchain_t clidata_admin_send_id_chain [ 2 ] = {
    { _CLI_WORD_ID,         clidata_admin_send_ip,
                            NULL,
                            clidata_admin_send_ip_chain,
                            cli_set_admin_id,
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_flagoffset_chain[ 2 ] = {
    { _CLI_WORD_OFFSET,     clidata_admin_send_ip,
                            NULL,
                            clidata_admin_send_ip_chain,
                            cli_set_admin_flagoffset,
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_protocolnum_chain [ 2 ] = {
    { _CLI_WORD_PROTOCOLNUM,clidata_admin_send_ip,
                            NULL,
                            clidata_admin_send_ip_chain,
                            cli_set_admin_protocolnum,
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_ipsrc_chain [ 2 ] = {
    { _CLI_WORD_IPADDRESS,  clidata_admin_send_ip2,
                            NULL,
                            clidata_admin_send_ip2_chain,
                            cli_set_admin_source_ip_address,
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_ipdst_chain [ 2 ] = {
    { _CLI_WORD_IPADDRESS,  clidata_admin_send_ip2,
                            NULL,
                            clidata_admin_send_ip2_chain,
                            cli_set_admin_destination_ip_address,
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_option_chain [ 2 ] = {
    { _CLI_WORD_OPTION,     clidata_admin_send_ip,
                            NULL,
                            clidata_admin_send_ip_chain,
                            cli_set_admin_option,
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_ip_chain[ 19 ] = {
    { CLI_WORD_TTL,         clidata_admin_send_ttl,
                            NULL,
                            clidata_admin_send_ttl_chain,
                            NULL, NULL },
    { CLI_WORD_TOS,         clidata_admin_send_tos,
                            NULL,
                            clidata_admin_send_tos_chain,
                            NULL, NULL },
    { CLI_WORD_ID,          clidata_admin_send_id,
                            NULL,
                            clidata_admin_send_id_chain,
                            NULL, NULL },
    { CLI_WORD_FLAG,        clidata_admin_send_flag,
                            NULL,
                            clidata_admin_send_flag_chain,
                            NULL, NULL },
    { CLI_WORD_FLAGOFFSET,  clidata_admin_send_flagoffset,
                            NULL,
                            clidata_admin_send_flagoffset_chain,
                            NULL, NULL },
    { CLI_WORD_PROTOCOLNUM, clidata_admin_send_protocolnum,
                            NULL,
                            clidata_admin_send_protocolnum_chain,
                            NULL, NULL },
    { CLI_WORD_IPSRC,       clidata_admin_send_ipaddress,
                            NULL,
                            clidata_admin_send_ipsrc_chain,
                            NULL, NULL },
    { CLI_WORD_IPDST,       clidata_admin_send_ipaddress,
                            NULL,
                            clidata_admin_send_ipdst_chain,
                            NULL, NULL },
    { CLI_WORD_OPTION,      clidata_admin_send_option,
                            NULL,
                            clidata_admin_send_option_chain,
                            NULL, NULL },
    { CLI_WORD_BACKGROUND,  clidata_admin_send_vhost,
                            NULL,
                            clidata_admin_send_vhost_chain,
                            cli_set_admin_backgroud,
                            cli_do_send },
    { CLI_WORD_L2TYPE,      cildata_admin_send_l2type,
                            NULL,
                            clidata_admin_send_l2type_chain,
                            NULL, NULL},
    { CLI_WORD_L3TYPE,      clidata_admin_send_l3type, 
                            NULL,
                            clidata_admin_send_l3type_chain,
                            NULL, NULL },
    { CLI_WORD_UDP,         clidata_admin_send_udp,
                            NULL,
                            clidata_admin_send_udp_chain,
                            cli_set_admin_udp, NULL } ,
    { CLI_WORD_PAYLOAD,     clidata_admin_send_payload,
                            NULL,
                            clidata_admin_send_payload_chain,
                            NULL, NULL },
    { CLI_WORD_PPS,         clidata_admin_send_pps,
                            NULL,
                            clidata_admin_send_pps_chain,
                            NULL, NULL }  ,
    { CLI_WORD_DURATION,    clidata_admin_send_duration,
                            NULL,
                            clidata_admin_send_duration_chain,
                            NULL, NULL },
    { CLI_WORD_LENGTH,      clidata_admin_send_lenght,
                            NULL,
                            clidata_admin_send_length_chain,
                            NULL, NULL }, 
    { CLI_WORD_PACKETNUM,   clidata_admin_send_packetnum,
                            NULL,
                            clidata_admin_send_packetnum_chain,
                            NULL, NULL } ,
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_ip2_chain[ 22 ] = {
    { CLI_WORD_TTL,         clidata_admin_send_ttl,
                            NULL,
                            clidata_admin_send_ttl_chain,
                            NULL, NULL },
    { CLI_WORD_TOS,         clidata_admin_send_tos,
                            NULL,
                            clidata_admin_send_tos_chain,
                            NULL, NULL },
    { CLI_WORD_ID,          clidata_admin_send_id,
                            NULL,
                            clidata_admin_send_id_chain,
                            NULL, NULL },
    { CLI_WORD_FLAG,        clidata_admin_send_flag,
                            NULL,
                            clidata_admin_send_flag_chain,
                            NULL, NULL },
    { CLI_WORD_FLAGOFFSET,  clidata_admin_send_flagoffset,
                            NULL,
                            clidata_admin_send_flagoffset_chain,
                            NULL, NULL },
    { CLI_WORD_PROTOCOLNUM, clidata_admin_send_protocolnum,
                            NULL,
                            clidata_admin_send_protocolnum_chain,
                            NULL, NULL },
    { CLI_WORD_IPSRC,       clidata_admin_send_ip,
                            NULL,
                            clidata_admin_send_ipsrc_chain,
                            NULL, NULL },
    { CLI_WORD_IPDST,       clidata_admin_send_ip,
                            NULL,
                            clidata_admin_send_ipdst_chain,
                            NULL, NULL },
    { CLI_WORD_OPTION,      clidata_admin_send_option,
                            NULL,
                            clidata_admin_send_option_chain,
                            NULL, NULL },
    { CLI_WORD_INCREMENT,   clidata_admin_send_count,
                            NULL,
                            clidata_admin_send_l3type_increment,
                            NULL, NULL },
    { CLI_WORD_DECREMENT,   clidata_admin_send_count,
                            NULL,
                            clidata_admin_send_l3type_decrement,
                            NULL, NULL },
    { CLI_WORD_RANDOM,      clidata_admin_send_mask,
                            NULL,
                            clidata_admin_send_l3type_random,
                            NULL, NULL },
    { CLI_WORD_BACKGROUND,  clidata_admin_send_vhost,
                            NULL,
                            clidata_admin_send_vhost_chain,
                            cli_set_admin_backgroud,
                            cli_do_send },
    { CLI_WORD_L2TYPE,      cildata_admin_send_l2type,
                            NULL,
                            clidata_admin_send_l2type_chain,
                            NULL, NULL} ,
    { CLI_WORD_L3TYPE,      clidata_admin_send_l3type, 
                            NULL,
                            clidata_admin_send_l3type_chain,
                            NULL, NULL } ,
    { CLI_WORD_UDP,         clidata_admin_send_udp,
                            NULL,
                            clidata_admin_send_udp_chain,
                            cli_set_admin_udp, NULL },
    { CLI_WORD_PAYLOAD,     clidata_admin_send_payload,
                            NULL,
                            clidata_admin_send_payload_chain,
                            NULL, NULL },
    { CLI_WORD_PPS,         clidata_admin_send_pps,
                            NULL,
                            clidata_admin_send_pps_chain,
                            NULL, NULL }, 
    { CLI_WORD_DURATION,    clidata_admin_send_duration,
                            NULL,
                            clidata_admin_send_duration_chain,
                            NULL, NULL }, 
    { CLI_WORD_LENGTH,      clidata_admin_send_lenght,
                            NULL,
                            clidata_admin_send_length_chain,
                            NULL, NULL },
    { CLI_WORD_PACKETNUM,   clidata_admin_send_packetnum,
                            NULL,
                            clidata_admin_send_packetnum_chain,
                            NULL, NULL },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_ip3_chain[ 20 ] = {
    { CLI_WORD_TTL,         clidata_admin_send_ttl,
                            NULL,
                            clidata_admin_send_ttl_chain,
                            NULL, NULL },
    { CLI_WORD_TOS,         clidata_admin_send_tos,
                            NULL,
                            clidata_admin_send_tos_chain,
                            NULL, NULL },
    { CLI_WORD_ID,          clidata_admin_send_id,
                            NULL,
                            clidata_admin_send_id_chain,
                            NULL, NULL },
    { CLI_WORD_FLAG,        clidata_admin_send_flag,
                            NULL,
                            clidata_admin_send_flag_chain,
                            NULL, NULL },
    { CLI_WORD_FLAGOFFSET,  clidata_admin_send_flagoffset,
                            NULL,
                            clidata_admin_send_flagoffset_chain,
                            NULL, NULL },
    { CLI_WORD_PROTOCOLNUM, clidata_admin_send_protocolnum,
                            NULL,
                            clidata_admin_send_protocolnum_chain,
                            NULL, NULL },
    { CLI_WORD_IPSRC,       clidata_admin_send_ipaddress,
                            NULL,
                            clidata_admin_send_ipsrc_chain,
                            NULL, NULL },
    { CLI_WORD_IPDST,       clidata_admin_send_ipaddress,
                            NULL,
                            clidata_admin_send_ipdst_chain,
                            NULL, NULL },
    { CLI_WORD_OPTION,      clidata_admin_send_option,
                            NULL,
                            clidata_admin_send_option_chain,
                            NULL, NULL },
    { CLI_WORD_BACKGROUND,  clidata_admin_send_vhost,
                            NULL,
                            clidata_admin_send_vhost_chain,
                            cli_set_admin_backgroud,
                            cli_do_send },
    { CLI_WORD_L2TYPE,      cildata_admin_send_l2type,
                            NULL,
                            clidata_admin_send_l2type_chain,
                            NULL, NULL} ,
    { CLI_WORD_L3TYPE,      clidata_admin_send_l3type, 
                            NULL,
                            clidata_admin_send_l3type_chain,
                            NULL, NULL } ,
    { CLI_WORD_UDP,         clidata_admin_send_udp,
                            NULL,
                            clidata_admin_send_udp_chain,
                            cli_set_admin_udp,
                            NULL },
    { CLI_WORD_PAYLOAD,     clidata_admin_send_payload,
                            NULL,
                            clidata_admin_send_payload_chain,
                            NULL, NULL },
    { CLI_WORD_PPS,         clidata_admin_send_pps,
                            NULL,
                            clidata_admin_send_pps_chain,
                            NULL, NULL },
    { CLI_WORD_DURATION,    clidata_admin_send_duration,
                            NULL,
                            clidata_admin_send_duration_chain,
                            NULL, NULL },
    { CLI_WORD_LENGTH,      clidata_admin_send_lenght,
                            NULL,
                            clidata_admin_send_length_chain,
                            NULL, NULL },
    { CLI_WORD_PACKETNUM,   clidata_admin_send_packetnum,
                            NULL,
                            clidata_admin_send_packetnum_chain,
                            NULL, NULL },
    { CLI_WORD_COUNT_LIMIT, clidata_admin_send_countlimit,
                            NULL,
                            clidata_admin_send_l3type_countlimit,
                            NULL, NULL },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_arp_hardwaretype_chain[ 2 ] = {
    { _CLI_WORD_HEADWARETYPE,clidata_admin_send_arp,
                            NULL,
                            clidata_admin_send_arp_chain,
                            cli_set_admin_hardware_type, 
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_arp_protocoltype_chain[ 2 ] = {
    { _CLI_WORD_PROTOCOLTYPE,clidata_admin_send_arp,
                            NULL,
                            clidata_admin_send_arp_chain,
                            cli_set_admin_protocol_type, 
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ; 

clictrl_cmdchain_t clidata_admin_send_arp_operationcode_chain[ 2 ] = {
    { _CLI_WORD_OPERATIONCODE,clidata_admin_send_arp,
                            NULL,
                            clidata_admin_send_arp_chain,
                            cli_set_admin_operation_code, 
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_arp_macsrc_chain[ 2 ] = {
    { _CLI_WORD_MACADDRESS, clidata_admin_send_arp2,
                            NULL,
                            clidata_admin_send_arp2_chain,
                            cli_set_admin_arp_source_mac_address, 
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_arp_macdst_chain[ 2 ] = {
    { _CLI_WORD_MACADDRESS, clidata_admin_send_arp2,
                            NULL,
                            clidata_admin_send_arp2_chain,
                            cli_set_admin_arp_destination_mac_address, 
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;


clictrl_cmdchain_t clidata_admin_send_arp_ipsrc_chain[ 2 ] = {
    { _CLI_WORD_IPADDRESS,  clidata_admin_send_arp2,
                            NULL,
                            clidata_admin_send_arp2_chain,
                            cli_set_admin_source_ip_address, 
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_arp_ipdst_chain[ 2 ] = {
    { _CLI_WORD_IPADDRESS,  clidata_admin_send_arp2,
                            NULL,
                            clidata_admin_send_arp2_chain,
                            cli_set_admin_destination_ip_address, 
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_l3type_countlimit_chain[ 2 ] = {
    { _CLI_WORD_COUNT_LIMIT,clidata_admin_send_arp,
                            NULL,
                            clidata_admin_send_arp_chain,
                            cli_set_admin_countlimit, cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_l3type_increment_chain[ 2 ] = {
    { _CLI_WORD_COUNT,      clidata_admin_send_arp3,
                            NULL,
                            clidata_admin_send_arp3_chain,
                            cli_set_admin_increment, cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_l3type_decrement_chain[ 2 ] = {
    { _CLI_WORD_COUNT,      clidata_admin_send_arp3,
                            NULL,
                            clidata_admin_send_arp3_chain,
                            cli_set_admin_decrement, cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_l3type_random_chain[ 2 ] = {
    { _CLI_WORD_MASK,       clidata_admin_send_arp2,
                            NULL,
                            clidata_admin_send_arp2_chain,
                            cli_set_admin_random, cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_arp_chain[ 17 ] = {
    { CLI_WORD_HARDTYPE,    clidata_admin_send_arp_hardwaretype,
                            NULL,
                            clidata_admin_send_arp_hardwaretype_chain, 
                            NULL, NULL },
    { CLI_WORD_PROTOCOLTYPE,clidata_admin_send_arp_protocoltype,
                            NULL,
                            clidata_admin_send_arp_protocoltype_chain,
                            NULL, NULL },
    { CLI_WORD_OPERATIONCODE,clidata_admin_send_arp_operationcode,
                            NULL,
                            clidata_admin_send_arp_operationcode_chain,
                            NULL, NULL },
    { CLI_WORD_MACSRC,      clidata_admin_send_mac_address,
                            NULL,
                            clidata_admin_send_arp_macsrc_chain,
                            NULL, NULL },
    { CLI_WORD_MACDST,      clidata_admin_send_mac_address,
                            NULL,
                            clidata_admin_send_arp_macdst_chain,
                            NULL, NULL },
    { CLI_WORD_IPSRC,       clidata_admin_send_ipaddress,
                            NULL,
                            clidata_admin_send_arp_ipsrc_chain,
                            NULL, NULL },
    { CLI_WORD_IPDST,       clidata_admin_send_ipaddress,
                            NULL,
                            clidata_admin_send_arp_ipdst_chain,
                            NULL, NULL },
    { CLI_WORD_BACKGROUND,  clidata_admin_send_vhost,
                            NULL,
                            clidata_admin_send_vhost_chain,
                            cli_set_admin_backgroud,
                            cli_do_send },
    { CLI_WORD_L2TYPE,      cildata_admin_send_l2type,
                            NULL,
                            clidata_admin_send_l2type_chain,
                            NULL, NULL},
    { CLI_WORD_L3TYPE,      clidata_admin_send_l3type, 
                            NULL,
                            clidata_admin_send_l3type_chain,
                            NULL, NULL },
    { CLI_WORD_UDP,         clidata_admin_send_udp,
                            NULL,
                            clidata_admin_send_udp_chain,
                            cli_set_admin_udp, NULL } ,
    { CLI_WORD_PAYLOAD,     clidata_admin_send_payload,
                            NULL,
                            clidata_admin_send_payload_chain,
                            NULL, NULL },
    { CLI_WORD_PPS,         clidata_admin_send_pps,
                            NULL,
                            clidata_admin_send_pps_chain,
                            NULL, NULL }, 
    { CLI_WORD_DURATION,    clidata_admin_send_duration,
                            NULL,
                            clidata_admin_send_duration_chain,
                            NULL, NULL },
    { CLI_WORD_LENGTH,      clidata_admin_send_lenght,
                            NULL,
                            clidata_admin_send_length_chain,
                            NULL, NULL },
    { CLI_WORD_PACKETNUM,   clidata_admin_send_packetnum,
                            NULL,
                            clidata_admin_send_packetnum_chain,
                            NULL, NULL }, 
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_arp2_chain[ 20 ] = {
    { CLI_WORD_HARDTYPE,    clidata_admin_send_arp_hardwaretype,
                            NULL,
                            clidata_admin_send_arp_hardwaretype_chain, 
                            NULL, NULL },
    { CLI_WORD_PROTOCOLTYPE,clidata_admin_send_arp_protocoltype,
                            NULL,
                            clidata_admin_send_arp_protocoltype_chain,
                            NULL, NULL },
    { CLI_WORD_OPERATIONCODE,clidata_admin_send_arp_operationcode,
                            NULL,
                            clidata_admin_send_arp_operationcode_chain,
                            NULL, NULL }, 
    { CLI_WORD_MACSRC,      clidata_admin_send_mac_address,
                            NULL,
                            clidata_admin_send_arp_macsrc_chain,
                            NULL, NULL },
    { CLI_WORD_MACDST,      clidata_admin_send_mac_address,
                            NULL,
                            clidata_admin_send_arp_macdst_chain,
                            NULL, NULL }, 
    { CLI_WORD_IPSRC,       clidata_admin_send_ipaddress,
                            NULL,
                            clidata_admin_send_arp_ipsrc_chain,
                            NULL, NULL }, 
    { CLI_WORD_IPDST,       clidata_admin_send_ipaddress,
                            NULL,
                            clidata_admin_send_arp_ipdst_chain,
                            NULL, NULL }, 
    { CLI_WORD_INCREMENT,   clidata_admin_send_count,
                            NULL,
                            clidata_admin_send_l3type_increment_chain,
                            NULL, NULL },
    { CLI_WORD_DECREMENT,   clidata_admin_send_count,
                            NULL,
                            clidata_admin_send_l3type_decrement_chain,
                            NULL, NULL },
    { CLI_WORD_RANDOM,      clidata_admin_send_mask,
                            NULL,
                            clidata_admin_send_l3type_random_chain,
                            NULL, NULL },
    { CLI_WORD_BACKGROUND,  clidata_admin_send_vhost,
                            NULL,
                            clidata_admin_send_vhost_chain,
                            cli_set_admin_backgroud,
                            cli_do_send },
    { CLI_WORD_L2TYPE,      cildata_admin_send_l2type,
                            NULL,
                            clidata_admin_send_l2type_chain,
                            NULL, NULL},
    { CLI_WORD_L3TYPE,      clidata_admin_send_l3type, 
                            NULL,
                            clidata_admin_send_l3type_chain,
                            NULL, NULL },
    { CLI_WORD_UDP,         clidata_admin_send_udp,
                            NULL,
                            clidata_admin_send_udp_chain,
                            cli_set_admin_udp, NULL },
    { CLI_WORD_PAYLOAD,     clidata_admin_send_payload,
                            NULL,
                            clidata_admin_send_payload_chain,
                            NULL, NULL },
    { CLI_WORD_PPS,         clidata_admin_send_pps,
                            NULL,
                            clidata_admin_send_pps_chain,
                            NULL, NULL },
    { CLI_WORD_DURATION,    clidata_admin_send_duration,
                            NULL,
                            clidata_admin_send_duration_chain,
                            NULL, NULL },
    { CLI_WORD_LENGTH,      clidata_admin_send_lenght,
                            NULL,
                            clidata_admin_send_length_chain,
                            NULL, NULL },
    { CLI_WORD_PACKETNUM,   clidata_admin_send_packetnum,
                            NULL,
                            clidata_admin_send_packetnum_chain,
                            NULL, NULL },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;


clictrl_cmdchain_t clidata_admin_send_arp3_chain[ 18 ] = {
    { CLI_WORD_HARDTYPE,    clidata_admin_send_arp_hardwaretype,
                            NULL,
                            clidata_admin_send_arp_hardwaretype_chain, 
                            NULL, NULL },
    { CLI_WORD_PROTOCOLTYPE,clidata_admin_send_arp_protocoltype,
                            NULL,
                            clidata_admin_send_arp_protocoltype_chain,
                            NULL, NULL }, 
    { CLI_WORD_OPERATIONCODE,clidata_admin_send_arp_operationcode,
                            NULL,
                            clidata_admin_send_arp_operationcode_chain,
                            NULL, NULL }, 
    { CLI_WORD_MACSRC,      clidata_admin_send_mac_address,
                            NULL,
                            clidata_admin_send_arp_macsrc_chain,
                            NULL, NULL }, 
    { CLI_WORD_MACDST,      clidata_admin_send_mac_address,
                            NULL,
                            clidata_admin_send_arp_macdst_chain,
                            NULL, NULL }, 
    { CLI_WORD_IPSRC,       clidata_admin_send_ipaddress,
                            NULL,
                            clidata_admin_send_arp_ipsrc_chain,
                            NULL, NULL },
    { CLI_WORD_IPDST,       clidata_admin_send_ipaddress,
                            NULL,
                            clidata_admin_send_arp_ipdst_chain,
                            NULL, NULL },
    { CLI_WORD_BACKGROUND,  clidata_admin_send_vhost,
                            NULL,
                            clidata_admin_send_vhost_chain,
                            cli_set_admin_backgroud,
                            cli_do_send },
    { CLI_WORD_L2TYPE,      cildata_admin_send_l2type,
                            NULL,
                            clidata_admin_send_l2type_chain,
                            NULL, NULL} ,
    { CLI_WORD_L3TYPE,      clidata_admin_send_l3type, 
                            NULL,
                            clidata_admin_send_l3type_chain,
                            NULL, NULL },
    { CLI_WORD_UDP,         clidata_admin_send_udp,
                            NULL,
                            clidata_admin_send_udp_chain,
                            cli_set_admin_udp, NULL } ,

    { CLI_WORD_PAYLOAD,     clidata_admin_send_payload,
                            NULL,
                            clidata_admin_send_payload_chain,
                            NULL, NULL },
    { CLI_WORD_PPS,         clidata_admin_send_pps,
                            NULL,
                            clidata_admin_send_pps_chain,
                            NULL, NULL }, 
    { CLI_WORD_DURATION,    clidata_admin_send_duration,
                            NULL,
                            clidata_admin_send_duration_chain,
                            NULL, NULL }, 
    { CLI_WORD_LENGTH,      clidata_admin_send_lenght,
                            NULL,
                            clidata_admin_send_length_chain,
                            NULL, NULL }, 
    { CLI_WORD_PACKETNUM,   clidata_admin_send_packetnum,
                            NULL,
                            clidata_admin_send_packetnum_chain,
                            NULL, NULL },
    { CLI_WORD_COUNT_LIMIT, clidata_admin_send_countlimit,
                            NULL,
                            clidata_admin_send_l3type_countlimit_chain,
                            NULL, NULL },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_l3type_chain [ 3 ] = {
    { CLI_WORD_IP,          clidata_admin_send_ip,
                            NULL,
                            clidata_admin_send_ip_chain,
                            cli_set_admin_l3type_ip, NULL },
    { CLI_WORD_ARP,         clidata_admin_send_arp,
                            NULL,
                            clidata_admin_send_arp_chain,
                            cli_set_admin_l3type_arp, NULL },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ; 

/************************************************************************/
/* send l2 head                                                         */
/************************************************************************/

clictrl_cmdchain_t clidata_admin_send_countlimit_chain [ 2 ] = {
    { _CLI_WORD_COUNT_LIMIT,clidata_admin_send_l2type_vlan2,
                            NULL,
                            clidata_admin_send_l2type_vlan_chain,
                            cli_set_admin_countlimit, cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;


clictrl_cmdchain_t clidata_admin_send_l2type_increment [ 2 ] = {
    { _CLI_WORD_COUNT,      clidata_admin_send_l2type_vlan3,
                            NULL,
                            clidata_admin_send_vhost3_chain,
                            cli_set_admin_increment, cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_l2type_decrement [ 2 ] = {
    { _CLI_WORD_COUNT,      clidata_admin_send_l2type_vlan3,
                            NULL,
                            clidata_admin_send_vhost3_chain,
                            cli_set_admin_decrement, cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_l2type_random [ 2 ] = {
    { _CLI_WORD_MASK,       clidata_admin_send_l2type_vlan2,
                            NULL,
                            clidata_admin_send_l2type_vlan_chain,
                            cli_set_admin_random, cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_l2type_vlan_macsrc_chain[ 2 ] = {
    { _CLI_WORD_MACADDRESS, clidata_admin_send_l2type_vlan2,
                            NULL,
                            clidata_admin_send_l2type_vlan2_chain,
                            cli_set_admin_source_mac_address,
                            cli_do_send }, 
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_l2type_vlan_macdst_chain[ 2 ] = {
    { _CLI_WORD_MACADDRESS, clidata_admin_send_l2type_vlan2,
                            NULL,
                            clidata_admin_send_l2type_vlan2_chain,
                            cli_set_admin_destination_mac_address,
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_l2type_vlan_ethertype_chain[ 2 ] = {
    { _CLI_WORD_ETHERTYPE,  clidata_admin_send_l2type_vlan2,
                            NULL,
                            clidata_admin_send_l2type_vlan2_chain,
                            cli_set_admin_ether_type,
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_l2type_vlan_cos_chain[ 2 ] = {
    { _CLI_WORD_COS,        clidata_admin_send_l2type_vlan2,
                            NULL,
                            clidata_admin_send_l2type_vlan2_chain,
                            cli_set_admin_cos,
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_l2type_vlan_vlanid_chain[ 2 ] = {
    { _CLI_WORD_VLANID,     clidata_admin_send_l2type_vlan2,
                            NULL,
                            clidata_admin_send_l2type_vlan2_chain,
                            cli_set_admin_vlanid,
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_l2type_vlan2_chain [ 18 ] = {
    { CLI_WORD_MACSRC,      clidata_admin_send_mac_address,
                            NULL,
                            clidata_admin_send_l2type_vlan_macsrc_chain,
                            NULL, NULL },
    { CLI_WORD_MACDST,      clidata_admin_send_mac_address,
                            NULL,
                            clidata_admin_send_l2type_vlan_macdst_chain,
                            NULL, NULL },
    { CLI_WORD_ETHERTYPE,   cildata_admin_send_ethertype,
                            NULL,
                            clidata_admin_send_l2type_vlan_ethertype_chain,
                            NULL, NULL },
    { CLI_WORD_COS,         clidata_admin_send_cos,
                            NULL,
                            clidata_admin_send_l2type_vlan_cos_chain,
                            NULL, NULL },
    { CLI_WORD_VLANID,      clidata_admin_send_vlanid,
                            NULL,
                            clidata_admin_send_l2type_vlan_vlanid_chain,
                            cli_set_admin_vlantype, NULL },
    { CLI_WORD_INCREMENT,   clidata_admin_send_count,
                            NULL,
                            clidata_admin_send_l2type_increment,
                            NULL, NULL },
    { CLI_WORD_DECREMENT,   clidata_admin_send_count,
                            NULL,
                            clidata_admin_send_l2type_decrement,
                            NULL, NULL },
    { CLI_WORD_RANDOM,      clidata_admin_send_mask,
                            NULL,
                            clidata_admin_send_l2type_random,
                            NULL, NULL },
    { CLI_WORD_BACKGROUND,  clidata_admin_send_vhost,
                            NULL,
                            clidata_admin_send_vhost_chain,
                            cli_set_admin_backgroud,
                            cli_do_send },
    { CLI_WORD_L2TYPE,      cildata_admin_send_l2type,
                            NULL,
                            clidata_admin_send_l2type_chain,
                            NULL, NULL},
    { CLI_WORD_L3TYPE,      clidata_admin_send_l3type, 
                            NULL,
                            clidata_admin_send_l3type_chain,
                            NULL, NULL },
    { CLI_WORD_UDP,         clidata_admin_send_udp,
                            NULL,
                            clidata_admin_send_udp_chain,
                            cli_set_admin_udp, NULL } ,
    { CLI_WORD_PAYLOAD,     clidata_admin_send_payload,
                            NULL,
                            clidata_admin_send_payload_chain,
                            NULL, NULL },
    { CLI_WORD_PPS,         clidata_admin_send_pps,
                            NULL,
                            clidata_admin_send_pps_chain,
                            NULL, NULL },
    { CLI_WORD_DURATION,    clidata_admin_send_duration,
                            NULL,
                            clidata_admin_send_duration_chain,
                            NULL, NULL },
    { CLI_WORD_LENGTH,      clidata_admin_send_lenght,
                            NULL,
                            clidata_admin_send_length_chain,
                            NULL, NULL }, 
    { CLI_WORD_PACKETNUM,   clidata_admin_send_packetnum,
                            NULL,
                            clidata_admin_send_packetnum_chain,
                            NULL, NULL },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_l2type_vlan_chain [ 15 ] = {
    { CLI_WORD_MACSRC,      clidata_admin_send_mac_address,
                            NULL,
                            clidata_admin_send_l2type_vlan_macsrc_chain,
                            NULL, NULL },
    { CLI_WORD_MACDST,      clidata_admin_send_mac_address,
                            NULL,
                            clidata_admin_send_l2type_vlan_macdst_chain,
                            NULL, NULL },
    { CLI_WORD_ETHERTYPE,   cildata_admin_send_ethertype,
                            NULL,
                            clidata_admin_send_l2type_vlan_ethertype_chain,
                            NULL, NULL },
    { CLI_WORD_COS,         clidata_admin_send_cos,
                            NULL,
                            clidata_admin_send_l2type_vlan_cos_chain,
                            NULL, NULL },
    { CLI_WORD_VLANID,      clidata_admin_send_vlanid,
                            NULL,
                            clidata_admin_send_l2type_vlan_vlanid_chain,
                            cli_set_admin_vlantype, NULL },
    { CLI_WORD_BACKGROUND,  clidata_admin_send_vhost,
                            NULL,
                            clidata_admin_send_vhost_chain,
                            cli_set_admin_backgroud,
                            cli_do_send },
    { CLI_WORD_L2TYPE,      cildata_admin_send_l2type,
                            NULL,
                            clidata_admin_send_l2type_chain,
                            NULL, NULL },
    { CLI_WORD_L3TYPE,      clidata_admin_send_l3type, 
                            NULL,
                            clidata_admin_send_l3type_chain,
                            NULL, NULL },
    { CLI_WORD_UDP,         clidata_admin_send_udp,
                            NULL,
                            clidata_admin_send_udp_chain,
                            cli_set_admin_udp, NULL } ,
    { CLI_WORD_PAYLOAD,     clidata_admin_send_payload,
                            NULL,
                            clidata_admin_send_payload_chain,
                            NULL, NULL },
    { CLI_WORD_PPS,         clidata_admin_send_pps,
                            NULL,
                            clidata_admin_send_pps_chain,
                            NULL, NULL },
    { CLI_WORD_DURATION,    clidata_admin_send_duration,
                            NULL,
                            clidata_admin_send_duration_chain,
                            NULL, NULL },
    { CLI_WORD_LENGTH,      clidata_admin_send_lenght,
                            NULL,
                            clidata_admin_send_length_chain,
                            NULL, NULL },
    { CLI_WORD_PACKETNUM,   clidata_admin_send_packetnum,
                            NULL,
                            clidata_admin_send_packetnum_chain,
                            NULL, NULL },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_l2type_ether_chain [ 11 ] = {
    { CLI_WORD_MACSRC,      clidata_admin_send_mac_address,
                            NULL,
                            clidata_admin_send_l2type_vlan_macsrc_chain,
                            NULL, NULL },
    { CLI_WORD_MACDST,      clidata_admin_send_mac_address,
                            NULL,
                            clidata_admin_send_l2type_vlan_macdst_chain,
                            NULL, NULL },
    { CLI_WORD_ETHERTYPE,   cildata_admin_send_ethertype,
                            NULL,
                            clidata_admin_send_l2type_vlan_ethertype_chain,
                            NULL, NULL },
    { CLI_WORD_L3TYPE,      clidata_admin_send_l3type,
                            NULL,
                            clidata_admin_send_l3type_chain,
                            NULL, NULL },
    { CLI_WORD_UDP,         clidata_admin_send_udp,
                            NULL,
                            clidata_admin_send_udp_chain,
                            cli_set_admin_udp, NULL },
    { CLI_WORD_PAYLOAD,     clidata_admin_send_payload,
                            NULL,
                            clidata_admin_send_payload_chain,
                            NULL, NULL },
    { CLI_WORD_PPS,         clidata_admin_send_pps,
                            NULL,
                            clidata_admin_send_pps_chain,
                            NULL, NULL },
    { CLI_WORD_DURATION,    clidata_admin_send_duration,
                            NULL,
                            clidata_admin_send_duration_chain,
                            NULL, NULL },
    { CLI_WORD_LENGTH,      clidata_admin_send_lenght,
                            NULL,
                            clidata_admin_send_length_chain,
                            NULL, NULL },
    { CLI_WORD_PACKETNUM,   clidata_admin_send_packetnum,
                            NULL,
                            clidata_admin_send_packetnum_chain,
                            NULL, NULL },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_l2type_chain [ 3 ] = {
    { CLI_WORD_VLAN,        clidata_admin_send_l2type_vlan,
                            NULL,
                            clidata_admin_send_l2type_vlan_chain,
                            cli_set_admin_l2type_vlan, NULL } ,
    { CLI_WORD_ETHER,       clidata_admin_send_l2type_ether,
                            NULL,
                            clidata_admin_send_l2type_ether_chain,
                            cli_set_admin_l2type_ether, NULL },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;


clictrl_cmdchain_t clidata_admin_cancel_key_chain [ 2 ] = {
    { _CLI_WORD_CANCELKEY,  clidata_admin_cr,
                            NULL, NULL,
                            cli_set_admin_cancel_vhost_key,
                            cli_do_admin_cancel_vhost_key },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_cancel_chain [ 2 ] = {
    { _CLI_WORD_VHOSTNAME,  clidata_admin_cancel_vhost,
                            NULL,
                            clidata_admin_cancel_key_chain,
                            cli_set_admin_vhost,
                            NULL },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_cr_chain [ 2 ] = {
    { CLI_WORD_CR,          clidata_admin_end,
                            NULL, NULL, NULL,
                            cli_do_admin_start_all },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_start_chain [ 3 ] = {
    { CLI_WORD_ALL,         clidata_admin_cr,
                            NULL,
                            clidata_admin_cr_chain,
                            NULL,
                            cli_do_admin_start_all },
    { _CLI_WORD_VHOSTNAME,  clidata_admin_cr,
                            NULL,
                            clidata_admin_cr_chain,
                            cli_set_admin_vhost,
                            cli_do_admin_start_vhost },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_stop_chain [ 3 ] = {
    { CLI_WORD_ALL,         clidata_admin_cr,
                            NULL,
                            clidata_admin_cr_chain,
                            NULL,
                            cli_do_admin_stop_all },
    { _CLI_WORD_VHOSTNAME,  clidata_admin_cr,
                            NULL,
                            clidata_admin_cr_chain,
                            cli_set_admin_vhost,
                            cli_do_admin_stop_vhost },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_vhost_chain [ 10 ] = {
    { CLI_WORD_BACKGROUND,  clidata_admin_send_vhost,
                            NULL,
                            clidata_admin_send_vhost_chain,
                            cli_set_admin_backgroud,
                            cli_do_send },
    { CLI_WORD_L2TYPE,      cildata_admin_send_l2type,
                            NULL,
                            clidata_admin_send_l2type_chain,
                            NULL, NULL},
    { CLI_WORD_L3TYPE,      clidata_admin_send_l3type, 
                            NULL,
                            clidata_admin_send_l3type_chain,
                            NULL, NULL },
    { CLI_WORD_UDP,         clidata_admin_send_udp,
                            NULL,
                            clidata_admin_send_udp_chain,
                            cli_set_admin_udp, NULL },
    { CLI_WORD_PAYLOAD,     clidata_admin_send_payload,
                            NULL,
                            clidata_admin_send_payload_chain,
                            NULL, NULL },
    { CLI_WORD_PPS,         clidata_admin_send_pps,
                            NULL,
                            clidata_admin_send_pps_chain,
                            NULL, NULL },
    { CLI_WORD_DURATION,    clidata_admin_send_duration,
                            NULL,
                            clidata_admin_send_duration_chain,
                            NULL, NULL },
    { CLI_WORD_LENGTH,      clidata_admin_send_lenght,
                            NULL,
                            clidata_admin_send_length_chain,
                            NULL, NULL },
    { CLI_WORD_PACKETNUM,   clidata_admin_send_packetnum,
                            NULL,
                            clidata_admin_send_packetnum_chain,
                            NULL, NULL }, 
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_vhost2_chain [ 13 ] = {
    { CLI_WORD_BACKGROUND,  clidata_admin_send_vhost,
                            NULL,
                            clidata_admin_send_vhost_chain,
                            cli_set_admin_backgroud,
                            cli_do_send },
    { CLI_WORD_L2TYPE,      cildata_admin_send_l2type,
                            NULL,
                            clidata_admin_send_l2type_chain,
                            NULL, NULL},
    { CLI_WORD_L3TYPE,      clidata_admin_send_l3type,
                            NULL,
                            clidata_admin_send_l3type_chain,
                            NULL, NULL },
    { CLI_WORD_UDP,         clidata_admin_send_udp,
                            NULL,
                            clidata_admin_send_udp_chain,
                            cli_set_admin_udp, NULL },
    { CLI_WORD_PAYLOAD,     clidata_admin_send_payload,
                            NULL,
                            clidata_admin_send_payload_chain,
                            NULL, NULL },
    { CLI_WORD_PPS,         clidata_admin_send_pps,
                            NULL,
                            clidata_admin_send_pps_chain,
                            NULL, NULL },
    { CLI_WORD_DURATION,    clidata_admin_send_duration,
                            NULL,
                            clidata_admin_send_duration_chain,
                            NULL, NULL },
    { CLI_WORD_LENGTH,      clidata_admin_send_lenght,
                            NULL,
                            clidata_admin_send_length_chain,
                            NULL, NULL },
    { CLI_WORD_PACKETNUM,   clidata_admin_send_packetnum,
                            NULL,
                            clidata_admin_send_packetnum_chain,
                            NULL, NULL },
    { CLI_WORD_INCREMENT,   clidata_admin_send_count,
                            NULL,
                            clidata_admin_send_payload_increment,
                            NULL, NULL },
    { CLI_WORD_DECREMENT,   clidata_admin_send_count,
                            NULL,
                            clidata_admin_send_payload_decrement,
                            NULL, NULL },
    { CLI_WORD_RANDOM,      clidata_admin_send_mask,
                            NULL,
                            clidata_admin_send_payload_random,
                            NULL,NULL },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_admin_send_vhost3_chain [ 11 ] = {
    { CLI_WORD_BACKGROUND,  clidata_admin_send_vhost,
                            NULL,
                            clidata_admin_send_vhost_chain,
                            cli_set_admin_backgroud,
                            cli_do_send },
    { CLI_WORD_L2TYPE,      cildata_admin_send_l2type,
                            NULL,
                            clidata_admin_send_l2type_chain,
                            NULL, NULL} ,
    { CLI_WORD_L3TYPE,      clidata_admin_send_l3type, 
                            NULL,
                            clidata_admin_send_l3type_chain,
                            NULL, NULL },
    { CLI_WORD_UDP,         clidata_admin_send_udp,
                            NULL,
                            clidata_admin_send_udp_chain,
                            cli_set_admin_udp, NULL },
    { CLI_WORD_PAYLOAD,     clidata_admin_send_payload,
                            NULL,
                            clidata_admin_send_payload_chain,
                            NULL, NULL },
    { CLI_WORD_PPS,         clidata_admin_send_pps,
                            NULL,
                            clidata_admin_send_pps_chain,
                            NULL, NULL }, 
    { CLI_WORD_DURATION,    clidata_admin_send_duration,
                            NULL,
                            clidata_admin_send_duration_chain,
                            NULL, NULL }, 
    { CLI_WORD_LENGTH,      clidata_admin_send_lenght,
                            NULL,
                            clidata_admin_send_length_chain,
                            NULL, NULL },
    { CLI_WORD_PACKETNUM,   clidata_admin_send_packetnum,
                            NULL,
                            clidata_admin_send_packetnum_chain,
                            NULL, NULL },
    { CLI_WORD_COUNT_LIMIT, clidata_admin_send_countlimit,
                            NULL,
                            clidata_admin_send_countlimit_chain,
                            NULL, NULL },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;


clictrl_cmdchain_t clidata_admin_send_chain [ 2 ] = {
    {_CLI_WORD_VHOSTNAME,   clidata_admin_send_vhost,
                            NULL,
                            clidata_admin_send_vhost_chain,
                            cli_set_admin_vhost,
                            cli_do_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

const clictrl_cmdchain_t clidata_admin_chain [ 9 ] = {
    { CLI_WORD_SEND,        clidata_admin_send,
                            NULL,
                            clidata_admin_send_chain,
                            cli_set_admin_send,
                            NULL },
    { CLI_WORD_CANCEL,      clidata_admin_cancel,
                            NULL,
                            clidata_admin_cancel_chain,
                            NULL, NULL },
    { CLI_WORD_START,       clidata_admin_start,
                            NULL,
                            clidata_admin_start_chain,
                            NULL, NULL },
    { CLI_WORD_STOP  ,      clidata_admin_stop,
                            NULL,
                            clidata_admin_stop_chain,
                            NULL, NULL },
    { CLI_WORD_CONFIG,      clidata_admin_cr,
                            NULL, NULL, NULL,
                            cli_do_admin_configure, },
    { CLI_WORD_EXIT,        clidata_admin_cr,
                            NULL, NULL, NULL,
                            cli_do_command_exit }, 
    { CLI_WORD_SHOW,        clidata_admin_show,
                            NULL,
                            clidata_admin_show_chain,
                            NULL, NULL },
    { CLI_WORD_CLEAR,       clidata_admin_clear,
                            NULL,
                            clidata_admin_clear_chain,
                            NULL, NULL },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

