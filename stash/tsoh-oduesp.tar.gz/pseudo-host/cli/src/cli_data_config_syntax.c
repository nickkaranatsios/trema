#include <stdio.h>

#include "cmn.h"
#include "cli_define.h"
#include "cli_struct.h"
#include "cli_extern.h"

const char *clidata_config_cr[ 64 ] = {
    CLI_WORD_CR,"　"
};

const char *clidata_config_show[ 64 ] = {
    CLI_WORD_CONFIG
} ;

const char *clidata_config_word[ 64 ] = {
    CLI_WORD_SHOW,CLI_WORD_NO,CLI_WORD_VHOST,CLI_WORD_CONTROLLER,CLI_WORD_EXIT,
    CLI_WORD_SAVE
} ;

const char *clidata_config_no[ 64 ] = {
    CLI_WORD_VHOST,CLI_WORD_CONTROLLER
};

const char *clidata_config_vhost[ 64 ] = {
    _CLI_WORD_VHOSTNAME,"　"
};

const char *clidata_config_controller[ 64 ] = {
    _CLI_WORD_CONTROLLERNAME,"　"
};

const char *clidata_config_controller_ip[ 64 ] = {
    _CLI_WORD_IPADDRESS,"　"
} ;

const char *clidata_config_no_vhost[ 64 ] = {
    _CLI_WORD_VHOSTNAME,CLI_WORD_ALL,"　"
};

const char *clidata_config_no_controller[ 64 ] = {
    CLI_WORD_ALL,_CLI_WORD_CONTROLLERNAME
};

const char *clidata_config_save[ 64 ] = {
    CLI_WORD_CR,__CLI_WORD_FILE

} ;

clictrl_cmdchain_t clidata_config_show_chain[ 2 ] = {    
    { CLI_WORD_CONFIG,      clidata_config_cr,
                            NULL, NULL,
                            NULL, cli_do_show_config },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_config_no_vhost_chain[ 3 ] = {
    { CLI_WORD_ALL,         clidata_config_cr,
                            NULL, NULL, NULL,
                            cli_do_config_no_vhost_all },

    { _CLI_WORD_VHOSTNAME,  clidata_config_cr,
                            NULL,  NULL,
                            cli_set_config_vhost,
                            cli_do_config_no_vhost }, 
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_config_no_controller_chain[ 3 ] = {
    { CLI_WORD_ALL,         clidata_config_cr,
                            NULL, NULL, NULL,
                            cli_do_config_no_controller_all },
    { _CLI_WORD_CONTROLLERNAME, clidata_config_cr,
                            NULL, NULL,
                            cli_set_config_controller,
                            cli_do_config_no_controller }, 
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_config_no_chain[ 3 ] = {
    { CLI_WORD_VHOST,       clidata_config_no_vhost,
                            NULL,
                            clidata_config_no_vhost_chain,
                            NULL, NULL },
                            
    { CLI_WORD_CONTROLLER,  clidata_config_no_controller,
                            NULL,
                            clidata_config_no_controller_chain,
                            NULL, NULL }, 
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_config_vhost_chain[ 2 ] = {
    { _CLI_WORD_VHOSTNAME,  clidata_config_cr,
                            NULL, NULL,
                            cli_set_config_vhost,
                            cli_do_config_vhost },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_config_controller_ip_chain[ 2 ] = {
    { _CLI_WORD_IPADDRESS,  clidata_config_cr,
                            NULL, NULL,
                            cli_set_config_controller_ip,
                            cli_do_config_controller },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_config_controller_chain[ 2 ] = {
    { _CLI_WORD_CONTROLLERNAME,clidata_config_controller_ip,
                            NULL,
                            clidata_config_controller_ip_chain,
                            cli_set_config_controller,
                            NULL },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_config_save_chain[ 2 ] = {

    { __CLI_WORD_FILE,      clidata_config_cr,
                            NULL, NULL,
                            cli_set_config_savefile,
                            cli_do_config_savefile },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_config_chain[ 7 ] = {
    { CLI_WORD_NO,          clidata_config_no,
                            NULL,
                            clidata_config_no_chain,
                            NULL, NULL }, 
    { CLI_WORD_VHOST,       clidata_config_vhost,
                            NULL,
                            clidata_config_vhost_chain,
                            NULL, NULL }, 
    { CLI_WORD_CONTROLLER,  clidata_config_controller,
                            NULL,
                            clidata_config_controller_chain,
                            NULL, NULL }, 
    { CLI_WORD_EXIT,        clidata_config_cr,
                            NULL, NULL, NULL,
                            cli_do_command_exit },
    { CLI_WORD_SHOW,        clidata_config_show,
                            NULL,
                            clidata_config_show_chain,
                            NULL, NULL },
    { CLI_WORD_SAVE,        clidata_config_save,
                            NULL,
                            clidata_config_save_chain,
                            NULL,
                            cli_do_config_save },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

