#include <stdio.h>

#include "cmn.h"
#include "cli_define.h"
#include "cli_struct.h"
#include "cli_extern.h"

const char *clidata_vhost_show[ 64 ] = {
    CLI_WORD_CONFIG
} ;

const char *clidata_vhost_static_arp[ 64 ] = {
    CLI_WORD_IPADDRESS
} ; 

const char *clidata_vhost_static_arp_ip[ 64 ] = {
    _CLI_WORD_IPADDRESS,"　"
} ;

const char *clidata_vhost_static_arp_ipaddr[ 64 ] = {
    CLI_WORD_MACADDRESS
} ;

const char *clidata_vhost_static_arp_mac[ 64 ] = {
    _CLI_WORD_MACADDRESS,"　"
} ;

const char *clidata_vhost_l2type_vlan[ 64 ] = {
    _CLI_WORD_VLANID,"　"
} ;

const char *clidata_vhost_interface_recv[ 64 ] = {
    _CLI_WORD_DEVICE,"　"
} ;

const char *clidata_vhost_interface_recv_send[ 64 ] = {
    CLI_WORD_SEND,CLI_WORD_CR
} ;

const char *clidata_vhost_interface_recv_send_device[ 64 ] = {
    _CLI_WORD_DEVICE,"　"
} ;

const char *clidata_vhost_word[ 64 ] = {
    CLI_WORD_SHOW,CLI_WORD_NO,CLI_WORD_MODE,CLI_WORD_PROMISC,CLI_WORD_ARPCACHE,CLI_WORD_STATIC,
    CLI_WORD_IPADDRESS,CLI_WORD_MASK,CLI_WORD_L2TYPE,CLI_WORD_INTERFACE,
    CLI_WORD_CONTROLLER,CLI_WORD_MACADDRESS,CLI_WORD_EXIT
} ;

const char *clidata_vhost_noword[ 64 ] = {
    CLI_WORD_MODE,CLI_WORD_PROMISC,CLI_WORD_ARPCACHE,CLI_WORD_STATIC,
    CLI_WORD_IPADDRESS,CLI_WORD_MASK,CLI_WORD_L2TYPE,CLI_WORD_INTERFACE,
    CLI_WORD_CONTROLLER,CLI_WORD_MACADDRESS
} ;

const char *clidata_vhost_mode [ 64 ] = {
    CLI_WORD_RAWGENERATION,CLI_WORD_HOSTEMULATION
} ;

const char *clidata_vhost_cr [ 64 ] = {
    CLI_WORD_CR,"　"
} ;

const char *clidata_vhost_arpcache[ 64 ] = {
    _CLI_WORD_TIME,"　"
} ;

const char *clidata_vhost_static[ 64 ] = {
    CLI_WORD_ARP

} ;

const char *clidata_vhost_ipaddress[ 64 ] = {
    _CLI_WORD_IPADDRESS,"　"
} ;

const char *clidata_vhost_mask [ 64 ] = {
    _CLI_WORD_SUBNETMASK, "　"
} ;

const char *clidata_vhost_l2type[ 64 ] = {
    CLI_WORD_ETHER,CLI_WORD_VLAN
} ;

const char *clidata_vhost_interface[ 64 ] = {
    CLI_WORD_RECV
} ;

const char *clidata_vhost_controller[ 64 ] = {
    _CLI_WORD_CONTROLLERNAME,"　"
} ;

const char *clidata_vhost_macaddress[ 64 ] = {
    _CLI_WORD_MACADDRESS,"　"
} ;

clictrl_cmdchain_t clidata_vhost_show_chain[ 2 ] = {
    { CLI_WORD_CONFIG,      clidata_vhost_cr,
                            NULL, NULL,
                            NULL, cli_do_show_vhost_config },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
    
} ;

clictrl_cmdchain_t clidata_vhost_mode_chain[ 3 ] = {
    { CLI_WORD_RAWGENERATION,clidata_vhost_cr,
                            NULL, NULL, NULL,
                            cli_do_vhost_rawgeneration },
    { CLI_WORD_HOSTEMULATION,clidata_vhost_cr,
                            NULL, NULL, NULL,
                            cli_do_vhost_hostemulation },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_vhost_arpcache_chain[ 2 ] = {
    { _CLI_WORD_TIME,       clidata_vhost_cr,
                            NULL, NULL,
                            cli_set_vhost_arpcache,
                            cli_do_vhost_arpcache }, 
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ; 

clictrl_cmdchain_t clidata_vhost_static_arp_mac_chain[ 2 ] = {
    { _CLI_WORD_MACADDRESS, clidata_vhost_cr,
                            NULL, NULL,
                            cli_set_vhost_macaddress,
                            cli_do_vhost_static_arp }, 
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_vhost_static_arp_ipaddr_chain[ 2 ] = {
    { CLI_WORD_MACADDRESS,  clidata_vhost_static_arp_mac,
                            NULL,
                            clidata_vhost_static_arp_mac_chain,
                            NULL, NULL }, 
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_vhost_static_arp_ip_chain[ 2 ] = {
    { _CLI_WORD_IPADDRESS,  clidata_vhost_static_arp_ipaddr,
                            NULL,
                            clidata_vhost_static_arp_ipaddr_chain,
                            cli_set_vhost_ipaddress, 
                            NULL }, 
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_vhost_static_arp_chain[ 2 ] = {
    { CLI_WORD_IPADDRESS,   clidata_vhost_static_arp_ip,
                            NULL,
                            clidata_vhost_static_arp_ip_chain,
                            NULL, NULL }, 
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_vhost_static_chain[] = {
    { CLI_WORD_ARP,         clidata_vhost_static_arp,
                            NULL,
                            clidata_vhost_static_arp_chain,
                            NULL, NULL },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_vhost_ipaddress_chain[ 2 ] = {
    { _CLI_WORD_IPADDRESS,  clidata_vhost_cr,
                            NULL, NULL,
                            cli_set_vhost_ipaddress,
                            cli_do_vhost_ipaddress },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_vhost_mask_chain[ 2 ] = {
    { _CLI_WORD_SUBNETMASK, clidata_vhost_cr,
                            NULL, NULL,
                            cli_set_vhost_subnetmask,
                            cli_do_vhost_subnetmask }, 
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_vhost_l2type_vlan_chain[ 2 ] = {
    { _CLI_WORD_VLANID,     clidata_vhost_cr,
                            NULL, NULL,
                            cli_set_vhost_l2type_vlan,
                            cli_do_vhost_l2type_vlan },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_vhost_l2type_chain[ 3 ] = {
    
    { CLI_WORD_ETHER,       clidata_vhost_cr,
                            NULL, NULL, NULL,
                            cli_do_vhost_ether },
    { CLI_WORD_VLAN,        clidata_vhost_l2type_vlan,
                            NULL,
                            clidata_vhost_l2type_vlan_chain,
                            NULL, NULL },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;


clictrl_cmdchain_t clidata_vhost_interface_recv_send_device_chain[ 2 ] = {
    { _CLI_WORD_DEVICE,     clidata_vhost_cr,
                            NULL, NULL,
                            cli_set_vhost_interface_send,
                            cli_do_vhost_interface_send },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_vhost_interface_recv_send_chain[ 2 ] = {
    { CLI_WORD_SEND,        clidata_vhost_interface_recv_send_device,
                            NULL,
                            clidata_vhost_interface_recv_send_device_chain,
                            NULL, NULL }, 
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_vhost_interface_recv_chain[ 2 ] = {
    { _CLI_WORD_DEVICE,     clidata_vhost_interface_recv_send,
                            NULL,
                            clidata_vhost_interface_recv_send_chain,
                            cli_set_vhost_interface_recv,
                            cli_do_vhost_interface_recv }, 
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;


clictrl_cmdchain_t clidata_vhost_interface_chain[ 2 ] = {
    { CLI_WORD_RECV,        clidata_vhost_interface_recv,
                            NULL,
                            clidata_vhost_interface_recv_chain,
                            NULL, NULL },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_vhsot_controller_chain[ 2 ] = {
    { _CLI_WORD_CONTROLLERNAME, clidata_vhost_cr,
                            NULL, NULL,
                            cli_set_vhost_controller,
                            cli_do_vhost_controller },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_vhost_macaddress_chain[ 2 ] = {
    { _CLI_WORD_MACADDRESS, clidata_vhost_cr,
                            NULL, NULL,
                            cli_set_vhost_macaddress,
                            cli_do_vhost_macaddress }, 
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_vhost_no_static_arp_mac_chain[ 2 ] = {
    
    { _CLI_WORD_MACADDRESS, clidata_vhost_cr,
                            NULL, NULL,
                            cli_set_vhost_macaddress,
                            cli_do_vhost_no_static_arp},  
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_vhost_no_static_arp_ipaddr_chain[ 2 ] = {
    { CLI_WORD_MACADDRESS,  clidata_vhost_static_arp_mac,
                            NULL,
                            clidata_vhost_no_static_arp_mac_chain,
                            NULL, NULL }, 
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_vhost_no_static_arp_ip_chain[ 2 ] = {
    { _CLI_WORD_IPADDRESS,  clidata_vhost_static_arp_ipaddr,
                            NULL,
                            clidata_vhost_no_static_arp_ipaddr_chain,
                            cli_set_vhost_ipaddress, 
                            NULL },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_vhost_no_static_arp_chain[ 2 ] = {
    { CLI_WORD_IPADDRESS,   clidata_vhost_static_arp_ip,
                            NULL,
                            clidata_vhost_no_static_arp_ip_chain,
                            NULL, NULL }, 
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_vhost_no_static_chain[ 2 ] = {
    { CLI_WORD_ARP,         clidata_vhost_static_arp,
                            NULL,
                            clidata_vhost_no_static_arp_chain,
                            NULL, NULL }, 
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;

clictrl_cmdchain_t clidata_vhost_no_chain[ 11 ] = {
    { CLI_WORD_MODE,        clidata_vhost_cr,
                            NULL, NULL, NULL,
                            cli_do_vhost_no_mode },
    { CLI_WORD_PROMISC,     clidata_vhost_cr,
                            NULL, NULL, NULL,
                            cli_do_vhost_no_promisc },
    { CLI_WORD_ARPCACHE,    clidata_vhost_cr,
                            NULL, NULL, NULL,
                            cli_do_vhost_no_arpcache }, 
    { CLI_WORD_STATIC,      clidata_vhost_static,
                            NULL,
                            clidata_vhost_no_static_chain,
                            NULL, NULL }, 
    { CLI_WORD_IPADDRESS,   clidata_vhost_cr,
                            NULL, NULL, NULL, 
                            cli_do_vhost_no_ipaddress },
    { CLI_WORD_MASK,        clidata_vhost_cr,
                            NULL, NULL, NULL,
                            cli_do_vhost_no_mask }, 
    { CLI_WORD_L2TYPE,      clidata_vhost_cr,
                            NULL, NULL, NULL, 
                            cli_do_vhost_no_l2type },
    { CLI_WORD_INTERFACE,   clidata_vhost_cr,
                            NULL, NULL, NULL,
                            cli_do_vhost_no_interface },
    { CLI_WORD_CONTROLLER,  clidata_vhost_cr,
                            NULL, NULL, NULL, 
                            cli_do_vhost_no_controller }, 
    { CLI_WORD_MACADDRESS,  clidata_vhost_cr,
                            NULL, NULL, NULL, 
                            cli_do_vhost_no_macaddress },
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;


clictrl_cmdchain_t clidata_vhost_chain[ 14 ] = {
    { CLI_WORD_NO,          clidata_vhost_noword,
                            NULL,
                            clidata_vhost_no_chain,
                            NULL, NULL },
    { CLI_WORD_MODE,        clidata_vhost_mode,
                            NULL,
                            clidata_vhost_mode_chain,
                            NULL, NULL },  
    { CLI_WORD_PROMISC,     clidata_vhost_cr,
                            NULL, NULL, NULL,
                            cli_do_vhost_promisc }, 
    { CLI_WORD_ARPCACHE,    clidata_vhost_arpcache,
                            NULL,
                            clidata_vhost_arpcache_chain,
                            NULL, NULL },
    { CLI_WORD_STATIC,      clidata_vhost_static,
                            NULL,
                            clidata_vhost_static_chain,
                            NULL, NULL }, 
    { CLI_WORD_IPADDRESS,   clidata_vhost_ipaddress,
                            NULL,
                            clidata_vhost_ipaddress_chain,
                            NULL, NULL },
    { CLI_WORD_MASK,        clidata_vhost_mask,
                            NULL,
                            clidata_vhost_mask_chain,
                            NULL, NULL },
    { CLI_WORD_L2TYPE,      clidata_vhost_l2type,
                            NULL,
                            clidata_vhost_l2type_chain,
                            NULL, NULL },
    { CLI_WORD_INTERFACE,   clidata_vhost_interface,
                            NULL,
                            clidata_vhost_interface_chain,
                            NULL, NULL },
    { CLI_WORD_CONTROLLER,  clidata_vhost_controller,
                            NULL,
                            clidata_vhsot_controller_chain,
                            NULL, NULL }, 
    { CLI_WORD_MACADDRESS,  clidata_vhost_macaddress,
                            NULL,
                            clidata_vhost_macaddress_chain,
                            NULL, NULL }, 
    { CLI_WORD_EXIT,        clidata_vhost_cr,
                            NULL,NULL, NULL,
                            cli_do_command_exit }, 
    { CLI_WORD_SHOW,        clidata_vhost_show,
                            NULL,
                            clidata_vhost_show_chain,
                            NULL, NULL }, 
    { NULL,                 NULL,NULL,NULL,NULL,NULL }
} ;
