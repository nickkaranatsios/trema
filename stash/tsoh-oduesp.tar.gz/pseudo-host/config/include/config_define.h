/*
 * config define header .
 *
 * Author: Isamu Ohkuchi
 */

#ifndef _CONFIG_DEFINE_H
#define _CONFIG_DEFINE_H
#include <stdio.h>
#include <stdarg.h>

/************************************************************************
 * DEFINE
 ************************************************************************/
#define CONFIG_DATABASE_LOCK_FILE                   "config_database_lock"
#define CONFIG_ERROR_PARAMETER                      "parameter error\n"

#define CONFIG_CLI_CONNECTION_MAX                   20
#define CONFIG_ALARM_TIME                           1
#define CONFIG_SELECT_TIME                          5
#define CONFIG_SELECT_MAX                           1024

/************************************************************************
 * MACRO
 ************************************************************************/
#ifdef DBG
#define MCONFIG_LOG( arg )                          ( printf( "%s:%04d  ", __FILE__, __LINE__ ), printf arg )
#define MCONFIG_ERROR( arg )                        ( printf( "%s:%04d  %s", __FILE__, __LINE__, arg ) )

#else
#define MCONFIG_LOG( arg )
#define MCONFIG_ERROR( arg )						( MLOGLIB_ERROR_PRINT( arg ) )
#endif

#endif  // _CONFIG_DEFINE_H

/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
