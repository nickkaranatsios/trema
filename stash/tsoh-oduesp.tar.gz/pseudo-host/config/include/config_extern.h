/*
 * cli extern header .
 *
 * Author: Isamu Ohkuchi
 */

#ifndef _CONFIG_EXTERN_H
#define _CONFIG_EXTERN_H
#include <sys/select.h>

extern void config_net_initialize( void );
extern void config_net_receive( void );
extern void config_lock( void  );
extern void config_unlock( void  );
extern ECONFIG_RESULT config_vhost_db( int, config_cmd_interface_t * );
extern ECONFIG_RESULT config_mode_vhost_db( int, config_cmd_interface_t * );
extern ECONFIG_RESULT config_promisc_vhost_db( int, config_cmd_interface_t * );
extern ECONFIG_RESULT config_arpcache_vhost_db( int, config_cmd_interface_t * );
extern ECONFIG_RESULT config_static_arp_vhost_db( int, config_cmd_interface_t * );
extern ECONFIG_RESULT config_ipaddress_vhost_db( int, config_cmd_interface_t * );
extern ECONFIG_RESULT config_mask_vhost_db( int, config_cmd_interface_t * );
extern ECONFIG_RESULT config_macaddress_vhost_db( int, config_cmd_interface_t * );
extern ECONFIG_RESULT config_l2type_vhost_db( int, config_cmd_interface_t * );
extern ECONFIG_RESULT config_interface_vhost_db( int, config_cmd_interface_t * );
extern ECONFIG_RESULT config_controller_vhost_db( int, config_cmd_interface_t * );
extern ECONFIG_RESULT config_get_controller_db( int, config_cmd_interface_t * );
extern ECONFIG_RESULT config_get_static_arp_db( int, config_cmd_interface_t * );
extern ECONFIG_RESULT config_get_vhost_db( int, config_cmd_interface_t * );
extern ECONFIG_RESULT config_controller_db( int, config_cmd_interface_t * );
extern ECONFIG_RESULT config_get_vhost_individual( int, config_cmd_interface_t * );
extern config_controller_detail_t *config_get_controller_information( config_cmd_interface_t * );
extern config_static_arp_t *config_get_static_arp_information( config_cmd_interface_t * );
extern config_vhost_information_t *config_get_vhost_information( config_cmd_interface_t * );
extern ECONFIG_RESULT config_get_vhost_ipaddress( int, config_cmd_interface_t * );
extern config_db_vhost_t *config_search_vhost_db( char * );
extern config_db_controller_t *config_search_controller_db( char * );
extern void config_cycle_database( void );
extern void config_set_socketfd( fd_set * );
extern void config_delete_vhost_socketfd( fd_set * );
extern config_vhost_information_t *config_get_vhost_individual_information( config_cmd_interface_t * );
extern void config_printf( char *, int, char *, ... );

#endif // _CONFIG_EXTERN_H

/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
