/*
 * cli structure header .
 *
 * Author: Isamu Ohkuchi
 */

#ifndef _CONFIG_STRUCT_H
#define _CONFIG_STRUCT_H


#include "configif.h"
#include "config_define.h"

/************************************************************************
 * Config
 ************************************************************************/

// (config)# vhost
typedef struct config_db_vhost {
  char                            vhost_name[ NAME_SIZE ];
  config_vhost_db_vhost_detail_t  vhost_db;
  void                            *front_chain;
  void                            *next_chain;
} config_db_vhost_t;

// (config)# controller
typedef struct config_db_controller {
  char                            controller_name[ CONTROLLER_NAME_SIZE + 1 ];
  char                            ip_address[ IP_SIZE + 1 ];
  int                             sockfd;
  void                            *front_chain;
  void                            *next_chain;
} config_db_controller_t;

// configuration database
typedef struct config_db {
  config_db_vhost_t               *vhost;
  config_db_controller_t          *controller;
} config_db_t;


#endif // _CONFIG_STRUCT_H

/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
