#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

#include "cmn.h"
#include "com_socket.h"
#include "configif.h"
#include "loglib.h"

#include "config_define.h"
#include "config_struct.h"
#include "config_extern.h"


ECONFIG_RESULT
config_get_controller_db( int sockfd, config_cmd_interface_t *interface ) {
  int socket_result;
  config_controller_detail_t *controller_information = NULL;
  char message[ 256 ] = "";

  // get controller information
  controller_information = config_get_controller_information( interface );

  // send response to CLI
  socket_result = com_socket_send( sockfd, ( u_char * ) interface, sizeof( config_cmd_interface_t ) );
  if ( socket_result != TRUE ) {
    snprintf( message, sizeof( message ), "%s\n", strerror( errno ) );
    MCONFIG_ERROR( ( message ) );
  }

  if ( ( controller_information != NULL ) && ( interface->command.admin_interface.command.controller.num > 0 ) ) {
    // data send
    socket_result = com_socket_send( sockfd, ( u_char * ) controller_information,
                                     sizeof( config_controller_detail_t ) * ( long unsigned int ) interface->command.admin_interface.command.controller.num );
    if ( socket_result != TRUE ) {
      snprintf( message, sizeof( message ), "%s\n", strerror( errno ) );
      MCONFIG_ERROR( ( message ) );
    }
    free( controller_information );
  }

  return CONFIG_OK;
}


ECONFIG_RESULT
config_get_static_arp_db( int sockfd, config_cmd_interface_t *interface ) {
  int socket_result;
  config_static_arp_t *static_arp_information = NULL;
  char message[ 256 ] = "";

  // get controller information
  static_arp_information = config_get_static_arp_information( interface );

  // send response to CLI
  socket_result = com_socket_send( sockfd, ( u_char * ) interface, sizeof( config_cmd_interface_t ) );
  if ( socket_result != TRUE ) {
    snprintf( message, sizeof( message ), "%s\n", strerror( errno ) );
    MCONFIG_ERROR( ( message ) );
  }

  if ( ( static_arp_information != NULL ) && ( interface->command.admin_interface.command.vhost.num > 0 ) ) {
    // data send
    socket_result = com_socket_send( sockfd, ( u_char * ) static_arp_information,
                                     sizeof( config_static_arp_t ) * ( long unsigned int ) interface->command.admin_interface.command.vhost.num );
    if ( socket_result != TRUE ) {
      snprintf( message, sizeof( message ), "%s\n", strerror( errno ) );
      MCONFIG_ERROR( ( message ) );
    }
    free( static_arp_information );
  }

  return CONFIG_OK;
}


ECONFIG_RESULT
config_get_vhost_db( int sockfd, config_cmd_interface_t *interface ) {
  int socket_result;
  config_vhost_information_t *vhost_information = NULL;
  char message[ 256 ] = "";

  // get controller information
  vhost_information = config_get_vhost_information( interface );

  // send response to CLI
  // head send
  socket_result = com_socket_send( sockfd, ( u_char * ) interface, sizeof( config_cmd_interface_t ) );
  if ( socket_result != TRUE ) {
    snprintf( message, sizeof( message ), "%s\n", strerror( errno ) );
    MCONFIG_ERROR( ( message ) );
  }

  if ( ( vhost_information != NULL ) && ( interface->command.admin_interface.command.vhost.num > 0 ) ) {
    // data send
    socket_result = com_socket_send( sockfd, ( u_char * ) vhost_information,
                                     sizeof( config_vhost_information_t ) * ( long unsigned int ) interface->command.admin_interface.command.vhost.num );
    if ( socket_result != TRUE ) {
      snprintf( message, sizeof( message ), "%s\n", strerror( errno ) );
      MCONFIG_ERROR( ( message ) );
    }
  }
  if ( vhost_information != NULL ) {
    free( vhost_information );
  }

  return CONFIG_OK;
}


ECONFIG_RESULT
config_get_vhost_individual( int sockfd, config_cmd_interface_t *interface ) {
  int socket_result;
  config_vhost_information_t *vhost_information = NULL;
  char message[ 256 ] = "";

  vhost_information = config_get_vhost_individual_information( interface );

  // send response to CLI
  // head send
  socket_result = com_socket_send( sockfd, ( u_char * ) interface, sizeof( config_cmd_interface_t ) );
  if ( socket_result != TRUE ) {
    snprintf( message, sizeof( message ), "%s\n", strerror( errno ) );
    MCONFIG_ERROR( ( message ) );
  }

  if ( vhost_information != NULL ) {
    // data send
    socket_result = com_socket_send( sockfd, ( u_char * ) vhost_information, sizeof( config_vhost_information_t ) );
    if ( socket_result != TRUE ) {
      snprintf( message, sizeof( message ), "%s\n", strerror( errno ) );
      MCONFIG_ERROR( ( message ) );
    }
    free( vhost_information );
  }

  return CONFIG_OK;
}
