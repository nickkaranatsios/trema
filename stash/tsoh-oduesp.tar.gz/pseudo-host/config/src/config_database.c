#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/file.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "configif.h"
#include "cmn.h"
#include "com_socket.h"
#include "vhost_interface.h"
#include "loglib.h"

#include "config_define.h"
#include "config_struct.h"

static config_db_t config_db;
static int config_database_lockfd;
static char config_lock_file[ 108 ];

/************************************************************************
 * Common Function
 ************************************************************************/
void
config_lock() {
  config_database_lockfd = open( config_lock_file, O_RDWR | O_CREAT, 0666 );
  flock( config_database_lockfd, LOCK_EX );
  return;
}


void
config_unlock() {
  flock( config_database_lockfd, LOCK_UN );
  close( config_database_lockfd );
  unlink( config_lock_file );
  return;
}


// database initialize
void
config_initialize_db() {
  memset( &config_db, 0x00, sizeof( config_db ) );
  sprintf( config_lock_file, "%s%s", TMP_DIR, CONFIG_DATABASE_LOCK_FILE );
  config_unlock();
  return;
}


/************************************************************************
 * cycle
 ************************************************************************/
void
config_cycle_database() {
  config_db_controller_t *search_controller_db;
  u_int ipv4;
  char message[ 256 ] = "";

  // lock database
  config_lock();

  search_controller_db = config_db.controller;
  while ( search_controller_db != NULL ) {
    if ( search_controller_db->sockfd < 0 ) {
      ipv4 = htonl( inet_addr( search_controller_db->ip_address ) );
      search_controller_db->sockfd = com_socket_connect( ipv4, MANAGER_INTERFACE_PORT );
      if ( search_controller_db->sockfd < 0 ) {
        snprintf( message, sizeof( message ), "cycle connect error( %s ).\n", strerror( errno ) );
        MCONFIG_ERROR( ( message ) );
      }
    }

    // next chain
    search_controller_db = search_controller_db->next_chain;
  }

  // unlock database
  config_unlock();

  alarm( 0 );
  alarm( CONFIG_ALARM_TIME );

  return;
}


void
config_set_socketfd( fd_set *select_fd_set ) {
  config_db_controller_t *search_controller_db;

  // lock database
  config_lock();

  search_controller_db = config_db.controller;
  while ( search_controller_db != NULL ) {
    if ( search_controller_db->sockfd > 0 ) {
      FD_SET( search_controller_db->sockfd, select_fd_set );
    }

    // next chain
    search_controller_db = search_controller_db->next_chain;
  }

  // unlock database
  config_unlock();

  return;
}


void
config_delete_vhost_socketfd( fd_set *select_fd_set ) {
  config_db_controller_t *search_controller_db;

  // lock database
  config_lock();

  search_controller_db = config_db.controller;
  while ( search_controller_db != NULL ) {
    if ( search_controller_db->sockfd >= 0 ) {
      if ( ( search_controller_db->sockfd != -1 ) && FD_ISSET( search_controller_db->sockfd, select_fd_set ) ) {
        com_socket_close( search_controller_db->sockfd );
        search_controller_db->sockfd = -1;
      }
    }

    // next chain
    search_controller_db = search_controller_db->next_chain;
  }
  // unlock database
  config_unlock();

  return;
}


/************************************************************************
 * vhost command function (config mode)
 ************************************************************************/
ECONFIG_RESULT
config_set_vhost_db( config_db_vhost_t *vhost_db ) {
  config_db_vhost_t *search_vhost_db;
  config_db_vhost_t *front_search_vhost_db;

  // lock database
  config_lock();

  search_vhost_db = config_db.vhost;
  while ( 1 ) {
    if ( search_vhost_db == NULL ) {
      config_db.vhost = vhost_db;
      break;
    }

    if ( strcmp( search_vhost_db->vhost_name, vhost_db->vhost_name ) > 0 ) {
      if ( search_vhost_db->front_chain != NULL ) {
        front_search_vhost_db = search_vhost_db->front_chain;
        front_search_vhost_db->next_chain = vhost_db;
        vhost_db->front_chain = front_search_vhost_db;
      }
      else {
        config_db.vhost = vhost_db;
      }
      search_vhost_db->front_chain = vhost_db;
      vhost_db->next_chain = search_vhost_db;
      break;
    }

    if ( search_vhost_db->next_chain == NULL ) {
      search_vhost_db->next_chain = vhost_db;
      vhost_db->front_chain = search_vhost_db;
      break;
    }
    // next chain
    search_vhost_db = search_vhost_db->next_chain;
  }

  // unlock database
  config_unlock();

  return CONFIG_OK;
}


ECONFIG_RESULT
config_delete_vhost_db( char *vhost_name ) {
  config_db_vhost_t *search_vhost_db;
  config_db_vhost_t *vhost_db;
  ECONFIG_RESULT result = CONFIG_NG;

  // lock database
  config_lock();

  search_vhost_db = config_db.vhost;
  while ( search_vhost_db != NULL ) {
    if ( strcmp( search_vhost_db->vhost_name, vhost_name ) == 0 ) {
      if ( search_vhost_db->front_chain != NULL ) {
        vhost_db = search_vhost_db->front_chain;
        vhost_db->next_chain = search_vhost_db->next_chain;

        vhost_db = search_vhost_db->next_chain;
        if ( vhost_db != NULL ) {
          vhost_db->front_chain = search_vhost_db->front_chain;
        }
        if ( search_vhost_db == config_db.vhost ) {
          config_db.vhost = NULL;
        }
      }
      else {
        vhost_db = search_vhost_db->next_chain;
        if ( vhost_db != NULL ) {
          vhost_db->front_chain = NULL;
        }
        config_db.vhost = vhost_db;
      }

      free( search_vhost_db );
      result = CONFIG_OK;
      break;
    }
    else {
      search_vhost_db = search_vhost_db->next_chain;
    }
  }

  // unlock database
  config_unlock();

  return result;
}


config_db_vhost_t *
config_search_vhost_db( char *vhost_name ) {
  config_db_vhost_t *search_vhost_db;

  // lock database
  config_lock();

  search_vhost_db = config_db.vhost;
  while ( search_vhost_db != NULL ) {
    if ( strcmp( search_vhost_db->vhost_name, vhost_name ) == 0 ) {
      // unlock database
      config_unlock();
      return search_vhost_db;
    }
    search_vhost_db = search_vhost_db->next_chain;
  }

  // unlock database
  config_unlock();

  return NULL;
}


// configure command
ECONFIG_RESULT
config_create_db_vhost( char *vhost_name ) {
  config_db_vhost_t *vhost_db;
  config_db_vhost_t *check_vhost_db;
  ECONFIG_RESULT result;

  check_vhost_db = config_search_vhost_db( vhost_name );
  if ( check_vhost_db != NULL ) {
    // vhost db don't exist
    return CONFIG_OK;
  }

  vhost_db = calloc( sizeof( config_db_vhost_t ), sizeof( char ) );
  if ( vhost_db == NULL ) {
    return CONFIG_NG;
  }
  // set vhost name
  strcpy( vhost_db->vhost_name, vhost_name );

  // set vhost database
  result = config_set_vhost_db( vhost_db );
  if ( result != CONFIG_OK ) {
    MCONFIG_ERROR( ( "config_set_ng(vhost)\n" ) );
    return CONFIG_NG;
  }

  return CONFIG_OK;
}


ECONFIG_RESULT
config_delete_db_vhost( char *vhost_name ) {
  // delete vhost database
  config_delete_vhost_db( vhost_name );

  return CONFIG_OK;
}


ECONFIG_RESULT
config_delete_all_db_vhost() {
  config_db_vhost_t *search_vhost_db;
  config_db_vhost_t *vhost_db;

  // lock database
  config_lock();

  search_vhost_db = config_db.vhost;
  while ( search_vhost_db != NULL ) {
    vhost_db = search_vhost_db;
    search_vhost_db = search_vhost_db->next_chain;
    free( vhost_db );
  }
  config_db.vhost = NULL;

  // unlock database
  config_unlock();

  return CONFIG_OK;
}


ECONFIG_RESULT
config_vhost_db( int sockfd, config_cmd_interface_t *interface ) {
  ECONFIG_RESULT result = CONFIG_NG;
  int socket_result;
  char message[ 256 ] = "";

  if ( interface->head.set_kind == CONFIG_ADD ) {
    result = config_create_db_vhost( interface->command.config_vhost.kind.add.vhost_name );
  }
  else if ( interface->head.set_kind == CONFIG_DELETE ) {
    if ( interface->command.config_vhost.kind.del.kind == CONFIG_ALL ) {
      result = config_delete_all_db_vhost();
    }
    else {
      result = config_delete_db_vhost( interface->command.config_vhost.kind.del.vhost_name );
    }
  }
  else {
    MCONFIG_ERROR( ( CONFIG_ERROR_PARAMETER ) );
    result = CONFIG_NG;
  }

  interface->head.result = result;
  interface->head.command = CONFIG_VHOST_RESPONSE;

  // send response to CLI
  socket_result = com_socket_send( sockfd, ( u_char * ) interface, sizeof( config_cmd_interface_t ) );
  if ( socket_result < 0 ) {
    snprintf( message, sizeof( message ), "%s\n", strerror( errno ) );
    MCONFIG_ERROR( ( message ) );
  }

  return CONFIG_OK;
}


/************************************************************************
 * controller command function (config mode)
 ************************************************************************/
ECONFIG_RESULT
config_set_controller_db( config_db_controller_t *controller_db ) {
  config_db_controller_t *search_controller_db;
  config_db_controller_t *front_search_controller_db;

  // lock database
  config_lock();

  search_controller_db = config_db.controller;
  while ( 1 ) {
    if ( search_controller_db == NULL ) {
      config_db.controller = controller_db;
      break;
    }

    if ( strcmp( search_controller_db->controller_name, controller_db->controller_name ) > 0 ) {
      if ( search_controller_db->front_chain != NULL ) {
        front_search_controller_db = search_controller_db->front_chain;
        front_search_controller_db->next_chain = controller_db;
        controller_db->front_chain = front_search_controller_db;
      }
      else {
        config_db.controller = controller_db;
      }
      search_controller_db->front_chain = controller_db;
      controller_db->next_chain = search_controller_db;
      break;
    }

    if ( search_controller_db->next_chain == NULL ) {
      search_controller_db->next_chain = controller_db;
      controller_db->front_chain = search_controller_db;
      break;
    }
    // next chain
    search_controller_db = search_controller_db->next_chain;
  }

  // unlock database
  config_unlock();

  return CONFIG_OK;
}


ECONFIG_RESULT
config_delete_controller_db( char *controller_name ) {
  config_db_controller_t *search_controller_db;
  config_db_controller_t *controller_db;

  // lock database
  config_lock();

  search_controller_db = config_db.controller;
  while ( search_controller_db != NULL ) {
    if ( strcmp( search_controller_db->controller_name, controller_name ) == 0 ) {
      if ( search_controller_db->front_chain != NULL ) {
        controller_db = search_controller_db->front_chain;
        controller_db->next_chain = search_controller_db->next_chain;

        controller_db = search_controller_db->next_chain;
        if ( controller_db != NULL ) {
          controller_db->front_chain = search_controller_db->front_chain;
        }
        if ( config_db.controller == search_controller_db ) {
          config_db.controller = NULL;
        }
      }
      else {
        controller_db = search_controller_db->next_chain;
        if ( controller_db != NULL ) {
          controller_db->front_chain = NULL;
        }
        config_db.controller = controller_db;
      }

      // socket close ( config - vhost socket )
      com_socket_close( search_controller_db->sockfd );

      free( search_controller_db );
      break;
    }
    else {
      search_controller_db = search_controller_db->next_chain;
    }
  }

  // unlock database
  config_unlock();

  return CONFIG_OK;
}


config_db_controller_t *
config_search_controller_db( char *controller_name ) {
  config_db_controller_t *search_controller_db;

  // lock database
  config_lock();

  search_controller_db = config_db.controller;
  while ( search_controller_db != NULL ) {
    if ( strcmp( search_controller_db->controller_name, controller_name ) == 0 ) {
      // unlock database
      config_unlock();
      return search_controller_db;
    }
    search_controller_db = search_controller_db->next_chain;
  }

  // unlock database
  config_unlock();

  return NULL;
}


ECONFIG_RESULT
config_check_duplicate_controller( char *controller_name, char *ip_address ) {
  config_db_controller_t *search_controller_db;

  // lock database
  config_lock();

  search_controller_db = config_db.controller;
  while ( search_controller_db != NULL ) {
    if ( ( strcmp( search_controller_db->ip_address, ip_address ) == 0 )
       && ( strcmp( search_controller_db->controller_name, controller_name ) != 0 ) ) {
      // unlock database
      config_unlock();
      return CONFIG_NG;
    }
    search_controller_db = search_controller_db->next_chain;
  }

  // unlock database
  config_unlock();

  return CONFIG_OK;
}


ECONFIG_RESULT
config_create_db_controller( char *controller_name, char *ip_address ) {
  config_db_controller_t *controller_db;
  ECONFIG_RESULT result;
  u_int ipv4;
  char message[ 256 ] = "";

  result = config_check_duplicate_controller( controller_name, ip_address );
  if ( result != CONFIG_OK ) {
    MCONFIG_ERROR( ( "IP ADDRESS DUPLICATE\n" ) );
    return CONFIG_DUPLICATE_NG;
  }

  controller_db = config_search_controller_db( controller_name );
  if ( controller_db != NULL ) {
    // controller_db exist.
    memset( controller_db->controller_name, 0x00, strlen( controller_db->controller_name ) + 1 );
    memset( controller_db->ip_address, 0x00, strlen( controller_db->ip_address ) + 1 );
    strcpy( controller_db->controller_name, controller_name );
    strcpy( controller_db->ip_address, ip_address );

    return CONFIG_OK;
  }

  // controller_db don't exist.
  controller_db = calloc( sizeof( config_db_controller_t ), sizeof( char ) );
  if ( controller_db == NULL ) {
    snprintf( message, sizeof( message ), "%s\n", strerror( errno ) );
    MCONFIG_ERROR( ( message ) );
    return CONFIG_NG;
  }

  strcpy( controller_db->controller_name, controller_name );
  strcpy( controller_db->ip_address, ip_address );

  result = config_set_controller_db( controller_db );
  if ( result != CONFIG_OK ) {
    MCONFIG_ERROR( ( "config_set_ng(vhost)\n" ) );
    return CONFIG_NG;
  }

  ipv4 = htonl( inet_addr( ip_address ) );
  controller_db->sockfd = com_socket_connect( ipv4, MANAGER_INTERFACE_PORT );
  if ( controller_db->sockfd < 0 ) {
    snprintf( message, sizeof( message ), "%s\n", strerror( errno ) );
    MCONFIG_ERROR( ( message ) );
    return CONFIG_OK;
  }

  return CONFIG_OK;
}


ECONFIG_RESULT
config_delete_db_controller( char *controller_name ) {
  return config_delete_controller_db( controller_name );
}


ECONFIG_RESULT
config_delete_all_db_controller() {
  config_db_controller_t *controller_db;
  config_db_controller_t *search_controller_db;

  // lock database
  config_lock();

  search_controller_db = config_db.controller;
  while ( search_controller_db != NULL ) {
    // socket close ( config - vhost socket )
    com_socket_close( search_controller_db->sockfd );

    controller_db = search_controller_db;
    search_controller_db = search_controller_db->next_chain;
    free( controller_db );
  }
  config_db.controller = NULL;

  // unlock database
  config_unlock();

  return CONFIG_OK;
}


ECONFIG_RESULT
config_controller_db( int sockfd, config_cmd_interface_t *interface ) {
  ECONFIG_RESULT result = CONFIG_NG;
  int socket_result;
  char message[ 256 ] = "";

  if ( interface->head.set_kind == CONFIG_ADD ) {
    result = config_create_db_controller( interface->command.config_controller.kind.add.controller_name,
                                          interface->command.config_controller.kind.add.ip_address );
  }
  else if ( interface->head.set_kind == CONFIG_DELETE ) {
    if ( interface->command.config_controller.kind.del.kind == CONFIG_ALL ) {
      result = config_delete_all_db_controller();
    }
    else {
      result = config_delete_db_controller( interface->command.config_controller.kind.del.controller_name );
    }
  }
  else {
    MCONFIG_ERROR( ( CONFIG_ERROR_PARAMETER ) );
    result = CONFIG_NG;
  }

  interface->head.result = result;
  interface->head.command = CONFIG_CONTROLLER_RESPONSE;

  // send response to CLI
  socket_result = com_socket_send( sockfd, ( u_char * ) interface, sizeof( config_cmd_interface_t ) );
  if ( socket_result < 0 ) {
    snprintf( message, sizeof( message ), "%s\n", strerror( errno ) );
    MCONFIG_ERROR( ( message ) );
  }

  return CONFIG_OK;
}


/************************************************************************
 * static arp command function (vhost mode)
 ************************************************************************/
config_vhost_db_static_arp_t *
config_search_static_arp_db( config_db_vhost_t *vhost_db, char *ip_address ) {
  config_vhost_db_static_arp_t *search_static_arp_db;

  search_static_arp_db = vhost_db->vhost_db.static_arp;
  while ( 1 ) {
    if ( search_static_arp_db == NULL ) {
      return NULL;
    }
    if ( strcmp( search_static_arp_db->ip_address, ip_address ) == 0 ) {
      return search_static_arp_db;
    }
    search_static_arp_db = search_static_arp_db->next_chain;
  }
}


ECONFIG_RESULT
config_set_static_arp_vhost_db( config_db_vhost_t *vhost_db, char *ip_address, char *mac_address ) {
  config_vhost_db_static_arp_t *search_static_arp_db;
  config_vhost_db_static_arp_t *front_static_arp_db;
  config_vhost_db_static_arp_t *static_arp;
  char message[ 256 ] = "";

  // lock database
  config_lock();

  search_static_arp_db = config_search_static_arp_db( vhost_db, ip_address );
  if ( search_static_arp_db != NULL ) {
    // duplicate ip_address and mac_address
    memset( search_static_arp_db->mac_address, 0x00, MAC_SIZE );
    strcpy( search_static_arp_db->mac_address, mac_address );
    config_unlock();
    return CONFIG_OK;
  }

  search_static_arp_db = vhost_db->vhost_db.static_arp;
  while ( 1 ) {
    if ( search_static_arp_db == NULL ) {
      search_static_arp_db = calloc( sizeof( config_vhost_db_static_arp_t ), sizeof( char ) );
      if ( search_static_arp_db == NULL ) {
        config_unlock();
        return CONFIG_NG;
      }

      strcpy( search_static_arp_db->ip_address, ip_address );
      strcpy( search_static_arp_db->mac_address, mac_address );

      vhost_db->vhost_db.static_arp = search_static_arp_db;
      search_static_arp_db->next_chain = NULL;
      break;
    }

    if ( strcmp( search_static_arp_db->ip_address, ip_address ) > 0 ) {
      static_arp = calloc( sizeof( config_vhost_db_static_arp_t ), sizeof( char ) );
      if ( static_arp == NULL ) {
        snprintf( message, sizeof( message ), "%s\n", strerror( errno ) );
        MCONFIG_ERROR( ( message ) );
        config_unlock();
        return CONFIG_NG;
      }
      strcpy( static_arp->ip_address, ip_address );
      strcpy( static_arp->mac_address, mac_address );

      if ( search_static_arp_db->front_chain != NULL ) {
        front_static_arp_db = search_static_arp_db->front_chain;
        front_static_arp_db->next_chain = static_arp;
        static_arp->front_chain = front_static_arp_db;
      }
      else {
        vhost_db->vhost_db.static_arp = static_arp;
      }
      search_static_arp_db->front_chain = static_arp;
      static_arp->next_chain = search_static_arp_db;

      break;
    }

    if ( search_static_arp_db->next_chain == NULL ) {
      static_arp = calloc( sizeof( config_vhost_db_static_arp_t ), sizeof( char ) );
      if ( static_arp == NULL ) {
        snprintf( message, sizeof( message ), "%s\n", strerror( errno ) );
        MCONFIG_ERROR( ( message ) );
        config_unlock();
        return CONFIG_NG;
      }
      strcpy( static_arp->ip_address, ip_address );
      strcpy( static_arp->mac_address, mac_address );

      search_static_arp_db->next_chain = static_arp;
      static_arp->front_chain = search_static_arp_db;
      break;
    }
    // next chain
    search_static_arp_db = search_static_arp_db->next_chain;
  }

  // unlock database
  config_unlock();

  return CONFIG_OK;
}


ECONFIG_RESULT
config_delete_static_arp_vhost_db( config_db_vhost_t *vhost_db, char *ip_address, char *mac_address ) {
  config_vhost_db_static_arp_t *search_static_arp_db;
  config_vhost_db_static_arp_t *static_arp_db;
  ECONFIG_RESULT result = CONFIG_NG;

  // lock database
  config_lock();

  search_static_arp_db = vhost_db->vhost_db.static_arp;
  while ( search_static_arp_db != NULL ) {
    if ( ( strcmp( search_static_arp_db->ip_address, ip_address ) == 0 ) && ( strcmp( search_static_arp_db->mac_address, mac_address ) == 0 ) ) {
      if ( search_static_arp_db->front_chain != NULL ) {
        static_arp_db = search_static_arp_db->front_chain;
        static_arp_db->next_chain = search_static_arp_db->next_chain;

        if ( search_static_arp_db->next_chain != NULL ) {
          static_arp_db = search_static_arp_db->next_chain;
          static_arp_db->front_chain = search_static_arp_db->front_chain;
        }
      }
      else {
        static_arp_db = search_static_arp_db->next_chain;
        if ( static_arp_db != NULL ) {
          static_arp_db->front_chain = NULL;
        }
        vhost_db->vhost_db.static_arp = static_arp_db;
      }

      free( search_static_arp_db );
      result = CONFIG_OK;
      break;
    }
    else {
      search_static_arp_db = search_static_arp_db->next_chain;
    }
  }

  // unlock database
  config_unlock();

  return result;
}


// static arp command
ECONFIG_RESULT
config_create_vhost_db_static_arp( char *vhost_name, char *ip_address, char *mac_address ) {
  config_db_vhost_t *vhost_db;

  vhost_db = config_search_vhost_db( vhost_name );
  if ( vhost_db == NULL ) {
    MCONFIG_ERROR( ( "config_search_ng\n" ) );
    return CONFIG_NG;
  }

  config_set_static_arp_vhost_db( vhost_db, ip_address, mac_address );

  return CONFIG_OK;
}


ECONFIG_RESULT
config_delete_vhost_db_static_arp( char *vhost_name, char *ip_address, char *mac_address ) {
  config_db_vhost_t *vhost_db;

  vhost_db = config_search_vhost_db( vhost_name );
  if ( vhost_db == NULL ) {
    MCONFIG_ERROR( ( "config_search_ng\n" ) );
    return CONFIG_NG;
  }

  config_delete_static_arp_vhost_db( vhost_db, ip_address, mac_address );

  return CONFIG_OK;
}


ECONFIG_RESULT
config_static_arp_vhost_db( int sockfd, config_cmd_interface_t *interface ) {
  ECONFIG_RESULT result;
  int socket_result;
  char message[ 256 ] = "";

  if ( interface->head.set_kind == CONFIG_ADD ) {
    result = config_create_vhost_db_static_arp( interface->head.vhost_name,
                                                interface->command.vhost_static_arp.kind.add.ip_address,
                                                interface->command.vhost_static_arp.kind.add.mac_address );
  }
  else if ( interface->head.set_kind == CONFIG_DELETE ) {
    result = config_delete_vhost_db_static_arp( interface->head.vhost_name,
                                                interface->command.vhost_static_arp.kind.del.ip_address,
                                                interface->command.vhost_static_arp.kind.del.mac_address );
  }
  else {
    MCONFIG_ERROR( ( CONFIG_ERROR_PARAMETER ) );
    result = CONFIG_NG;
  }

  interface->head.result = result;
  interface->head.command = CONFIG_VHOST_STATICARP_RESPONSE;

  // send response to CLI
  socket_result = com_socket_send( sockfd, ( u_char * ) interface, sizeof( config_cmd_interface_t ) );
  if ( socket_result < 0 ) {
    snprintf( message, sizeof( message ), "%s\n", strerror( errno ) );
    MCONFIG_ERROR( ( message ) );
  }

  return CONFIG_OK;
}


/************************************************************************
 * mode command function (vhost mode)
 ************************************************************************/
ECONFIG_RESULT
config_set_vhost_db_mode( char *vhost_name, ECONFIG_HOST_MODE mode ) {
  config_db_vhost_t *vhost_db;

  vhost_db = config_search_vhost_db( vhost_name );
  if ( vhost_db == NULL ) {
    MCONFIG_ERROR( ( "config_search_ng\n" ) );
    return CONFIG_NG;
  }

  vhost_db->vhost_db.mode.enable = CONFIG_ENABLE;
  vhost_db->vhost_db.mode.mode = mode;

  return CONFIG_OK;
}


ECONFIG_RESULT
config_delete_vhost_db_mode( char *vhost_name ) {
  config_db_vhost_t *vhost_db;

  vhost_db = config_search_vhost_db( vhost_name );
  if ( vhost_db == NULL ) {
    MCONFIG_ERROR( ( "config_search_ng\n" ) );
    return CONFIG_NG;
  }

  vhost_db->vhost_db.mode.enable = CONFIG_DISABLE;

  return CONFIG_OK;
}


ECONFIG_RESULT
config_mode_vhost_db( int sockfd, config_cmd_interface_t *interface ) {
  ECONFIG_RESULT result = CONFIG_NG;
  int socket_result;
  char message[ 256 ] = "";

  if ( interface->head.set_kind == CONFIG_ADD ) {
    result = config_set_vhost_db_mode( interface->head.vhost_name, interface->command.vhost_mode.kind.add.mode );
  }
  else if ( interface->head.set_kind == CONFIG_DELETE ) {
    result = config_delete_vhost_db_mode( interface->head.vhost_name );
  }
  else {
    MCONFIG_ERROR( ( CONFIG_ERROR_PARAMETER ) );
    result = CONFIG_NG;
  }

  interface->head.result = result;
  interface->head.command = CONFIG_VHOST_MODE_RESPONSE;

  // send response to CLI
  socket_result = com_socket_send( sockfd, ( u_char * ) interface, sizeof( config_cmd_interface_t ) );
  if ( socket_result < 0 ) {
    snprintf( message, sizeof( message ), "%s\n", strerror( errno ) );
    MCONFIG_ERROR( ( message ) );
  }

  return CONFIG_OK;
}


/************************************************************************
 * promisc command function (vhost mode)
 ************************************************************************/
ECONFIG_RESULT
config_set_vhost_db_promisc( char *vhost_name, ECONFIG_PROMISC promisc ) {
  config_db_vhost_t *vhost_db;

  vhost_db = config_search_vhost_db( vhost_name );
  if ( vhost_db == NULL ) {
    MCONFIG_ERROR( ( "config_search_ng\n" ) );
    return CONFIG_NG;
  }

  vhost_db->vhost_db.promisc.enable = CONFIG_ENABLE;
  vhost_db->vhost_db.promisc.promisc = promisc;

  return CONFIG_OK;
}


ECONFIG_RESULT
config_delete_vhost_db_promisc( char *vhost_name ) {
  config_db_vhost_t *vhost_db;

  vhost_db = config_search_vhost_db( vhost_name );
  if ( vhost_db == NULL ) {
    MCONFIG_ERROR( ( "config_search_ng\n" ) );
    return CONFIG_NG;
  }

  vhost_db->vhost_db.promisc.enable = CONFIG_DISABLE;

  return CONFIG_OK;
}


ECONFIG_RESULT
config_promisc_vhost_db( int sockfd, config_cmd_interface_t *interface ) {
  ECONFIG_RESULT result = CONFIG_NG;
  int socket_result;
  char message[ 256 ] = "";

  if ( interface->head.set_kind == CONFIG_ADD ) {
    result = config_set_vhost_db_promisc( interface->head.vhost_name, interface->command.vhost_promisc.kind.add.promisc );
  }
  else if ( interface->head.set_kind == CONFIG_DELETE ) {
    result = config_delete_vhost_db_promisc( interface->head.vhost_name );
  }
  else {
    MCONFIG_ERROR( ( CONFIG_ERROR_PARAMETER ) );
    result = CONFIG_NG;
  }

  interface->head.result = result;
  interface->head.command = CONFIG_VHOST_PROMISC_RESPONSE;

  // send response to CLI
  socket_result = com_socket_send( sockfd, ( u_char * ) interface, sizeof( config_cmd_interface_t ) );
  if ( socket_result < 0 ) {
    snprintf( message, sizeof( message ), "%s\n", strerror( errno ) );
    MCONFIG_ERROR( ( message ) );
  }

  return CONFIG_OK;
}


/************************************************************************
 * arp cache function (vhost mode)
 ************************************************************************/
ECONFIG_RESULT
config_set_vhost_db_arpcache( char *vhost_name, u_short time ) {
  config_db_vhost_t *vhost_db;

  vhost_db = config_search_vhost_db( vhost_name );
  if ( vhost_db == NULL ) {
    MCONFIG_ERROR( ( "config_search_ng\n" ) );
    return CONFIG_NG;
  }

  vhost_db->vhost_db.arpcache.enable = CONFIG_ENABLE;
  vhost_db->vhost_db.arpcache.time = time;

  return CONFIG_OK;
}


ECONFIG_RESULT
config_delete_vhost_db_arpcache( char *vhost_name ) {
  config_db_vhost_t *vhost_db;

  vhost_db = config_search_vhost_db( vhost_name );
  if ( vhost_db == NULL ) {
    MCONFIG_ERROR( ( "config_search_ng\n" ) );
    return CONFIG_NG;
  }

  vhost_db->vhost_db.arpcache.enable = CONFIG_DISABLE;

  return CONFIG_OK;
}


ECONFIG_RESULT
config_arpcache_vhost_db( int sockfd, config_cmd_interface_t *interface ) {
  ECONFIG_RESULT result = CONFIG_NG;
  int socket_result;
  char message[ 256 ] = "";

  if ( interface->head.set_kind == CONFIG_ADD ) {
    result = config_set_vhost_db_arpcache( interface->head.vhost_name, interface->command.vhost_cache.kind.add.time );
  }
  else if ( interface->head.set_kind == CONFIG_DELETE ) {
    result = config_delete_vhost_db_arpcache( interface->head.vhost_name );
  }
  else {
    MCONFIG_ERROR( ( CONFIG_ERROR_PARAMETER ) );
    result = CONFIG_NG;
  }

  interface->head.result = result;
  interface->head.command = CONFIG_VHOST_ARPCACHE_RESPONSE;

  // send response to CLI
  socket_result = com_socket_send( sockfd, ( u_char * ) interface, sizeof( config_cmd_interface_t ) );
  if ( socket_result < 0 ) {
    snprintf( message, sizeof( message ), "%s\n", strerror( errno ) );
    MCONFIG_ERROR( ( message ) );
  }

  return CONFIG_OK;
}


/************************************************************************
 * ip address function (vhost mode)
 ************************************************************************/
ECONFIG_RESULT
config_set_vhost_db_ipaddress( char *vhost_name, char *ip_address ) {
  config_db_vhost_t *vhost_db;

  vhost_db = config_search_vhost_db( vhost_name );
  if ( vhost_db == NULL ) {
    MCONFIG_ERROR( ( "config_search_ng\n" ) );
    return CONFIG_NG;
  }

  vhost_db->vhost_db.ip_addr.enable = CONFIG_ENABLE;
  strcpy( vhost_db->vhost_db.ip_addr.ip_address, ip_address );

  return CONFIG_OK;
}


ECONFIG_RESULT
config_delete_vhost_db_ipaddress( char *vhost_name ) {
  config_db_vhost_t *vhost_db;

  vhost_db = config_search_vhost_db( vhost_name );
  if ( vhost_db == NULL ) {
    MCONFIG_ERROR( ( "config_search_ng\n" ) );
    return CONFIG_NG;
  }

  vhost_db->vhost_db.ip_addr.enable = CONFIG_DISABLE;

  return CONFIG_OK;
}


ECONFIG_RESULT
config_ipaddress_vhost_db( int sockfd, config_cmd_interface_t *interface ) {
  ECONFIG_RESULT result = CONFIG_NG;
  int socket_result;
  char message[ 256 ] = "";

  if ( interface->head.set_kind == CONFIG_ADD ) {
    result = config_set_vhost_db_ipaddress( interface->head.vhost_name, interface->command.vhost_ip_address.kind.add.ip_address );
  }
  else if ( interface->head.set_kind == CONFIG_DELETE ) {
    result = config_delete_vhost_db_ipaddress( interface->head.vhost_name );
  }
  else {
    MCONFIG_ERROR( ( CONFIG_ERROR_PARAMETER ) );
    result = CONFIG_NG;
  }

  interface->head.result = result;
  interface->head.command = CONFIG_VHOST_IPADDRESS_RESPONSE;

  // send response to CLI
  socket_result = com_socket_send( sockfd, ( u_char * ) interface, sizeof( config_cmd_interface_t ) );
  if ( socket_result < 0 ) {
    snprintf( message, sizeof( message ), "%s\n", strerror( errno ) );
    MCONFIG_ERROR( ( message ) );
  }

  return CONFIG_OK;
}


/************************************************************************
 * mask function (vhost mode)
 ************************************************************************/
ECONFIG_RESULT
config_set_vhost_db_mask( char *vhost_name, char *mask ) {
  config_db_vhost_t *vhost_db;

  vhost_db = config_search_vhost_db( vhost_name );
  if ( vhost_db == NULL ) {
    MCONFIG_ERROR( ( "config_search_ng\n" ) );
    return CONFIG_NG;
  }

  vhost_db->vhost_db.mask.enable = CONFIG_ENABLE;
  strcpy( vhost_db->vhost_db.mask.mask, mask );

  return CONFIG_OK;
}


ECONFIG_RESULT
config_delete_vhost_db_mask( char *vhost_name ) {
  config_db_vhost_t *vhost_db;

  vhost_db = config_search_vhost_db( vhost_name );
  if ( vhost_db == NULL ) {
    MCONFIG_ERROR( ( "config_search_ng\n" ) );
    return CONFIG_NG;
  }

  vhost_db->vhost_db.mask.enable = CONFIG_DISABLE;

  return CONFIG_OK;
}


ECONFIG_RESULT
config_mask_vhost_db( int sockfd, config_cmd_interface_t *interface ) {
  ECONFIG_RESULT result = CONFIG_NG;
  int socket_result;
  char message[ 256 ] = "";

  if ( interface->head.set_kind == CONFIG_ADD ) {
    result = config_set_vhost_db_mask( interface->head.vhost_name, interface->command.vhost_mask.kind.add.mask );
  }
  else if ( interface->head.set_kind == CONFIG_DELETE ) {
    result = config_delete_vhost_db_mask( interface->head.vhost_name );
  }
  else {
    MCONFIG_ERROR( ( CONFIG_ERROR_PARAMETER ) );
    result = CONFIG_NG;
  }

  interface->head.result = result;
  interface->head.command = CONFIG_VHOST_MASK_RESPONSE;

  // send response to CLI
  socket_result = com_socket_send( sockfd, ( u_char * ) interface, sizeof( config_cmd_interface_t ) );
  if ( socket_result < 0 ) {
    snprintf( message, sizeof( message ), "%s\n", strerror( errno ) );
    MCONFIG_ERROR( ( message ) );
  }

  return CONFIG_OK;
}


/************************************************************************
 * mac address function (vhost mode)
 ************************************************************************/
ECONFIG_RESULT
config_set_vhost_db_macaddress( char *vhost_name, char *mac_address ) {
  config_db_vhost_t *vhost_db;

  vhost_db = config_search_vhost_db( vhost_name );
  if ( vhost_db == NULL ) {
    MCONFIG_ERROR( ( "config_search_ng\n" ) );
    return CONFIG_NG;
  }

  vhost_db->vhost_db.mac_addr.enable = CONFIG_ENABLE;
  strcpy( vhost_db->vhost_db.mac_addr.mac_address, mac_address );

  return CONFIG_OK;
}


ECONFIG_RESULT
config_delete_vhost_db_macaddress( char *vhost_name ) {
  config_db_vhost_t *vhost_db;

  vhost_db = config_search_vhost_db( vhost_name );
  if ( vhost_db == NULL ) {
    MCONFIG_ERROR( ( "config_search_ng\n" ) );
    return CONFIG_NG;
  }

  vhost_db->vhost_db.mac_addr.enable = CONFIG_DISABLE;

  return CONFIG_OK;
}


ECONFIG_RESULT
config_macaddress_vhost_db( int sockfd, config_cmd_interface_t *interface ) {
  ECONFIG_RESULT result = CONFIG_NG;
  int socket_result;
  char message[ 256 ] = "";

  if ( interface->head.set_kind == CONFIG_ADD ) {
    result = config_set_vhost_db_macaddress( interface->head.vhost_name, interface->command.vhost_mac_address.kind.add.mac_address );
  }
  else if ( interface->head.set_kind == CONFIG_DELETE ) {
    result = config_delete_vhost_db_macaddress( interface->head.vhost_name );
  }
  else {
    MCONFIG_ERROR( ( CONFIG_ERROR_PARAMETER ) );
    result = CONFIG_NG;
  }

  interface->head.result = result;
  interface->head.command = CONFIG_VHOST_MACADDRESS_RESPONSE;

  // send response to CLI
  socket_result = com_socket_send( sockfd, ( u_char * ) interface, sizeof( config_cmd_interface_t ) );
  if ( socket_result < 0 ) {
    snprintf( message, sizeof( message ), "%s\n", strerror( errno ) );
    MCONFIG_ERROR( ( message ) );
  }

  return CONFIG_OK;
}


/************************************************************************
 * l2type function (vhost mode)
 ************************************************************************/
ECONFIG_RESULT
config_set_vhost_db_l2type( char *vhost_name, ECONFIG_L2HEADTYPE l2type, u_short vlanid ) {
  config_db_vhost_t *vhost_db;

  vhost_db = config_search_vhost_db( vhost_name );
  if ( vhost_db == NULL ) {
    MCONFIG_ERROR( ( "config_search_ng\n" ) );
    return CONFIG_NG;
  }

  vhost_db->vhost_db.l2type.enable = CONFIG_ENABLE;
  vhost_db->vhost_db.l2type.l2type = l2type;
  vhost_db->vhost_db.l2type.vlanid = vlanid;

  return CONFIG_OK;
}


ECONFIG_RESULT
config_delete_vhost_db_l2type( char *vhost_name ) {
  config_db_vhost_t *vhost_db;

  vhost_db = config_search_vhost_db( vhost_name );
  if ( vhost_db == NULL ) {
    MCONFIG_ERROR( ( "config_search_ng\n" ) );
    return CONFIG_NG;
  }

  vhost_db->vhost_db.l2type.enable = CONFIG_DISABLE;

  return CONFIG_OK;
}


ECONFIG_RESULT
config_l2type_vhost_db( int sockfd, config_cmd_interface_t *interface ) {
  ECONFIG_RESULT result = CONFIG_NG;
  int socket_result;
  char message[ 256 ] = "";

  if ( interface->head.set_kind == CONFIG_ADD ) {
    result = config_set_vhost_db_l2type( interface->head.vhost_name, interface->command.vhost_l2type.kind.add.l2type,
                                         interface->command.vhost_l2type.kind.add.vlanid );
  }
  else if ( interface->head.set_kind == CONFIG_DELETE ) {
    result = config_delete_vhost_db_l2type( interface->head.vhost_name );
  }
  else {
    MCONFIG_ERROR( ( CONFIG_ERROR_PARAMETER ) );
    result = CONFIG_NG;
  }

  interface->head.result = result;
  interface->head.command = CONFIG_VHOST_L2TYPE_RESPONSE;

  // send response to CLI
  socket_result = com_socket_send( sockfd, ( u_char * ) interface, sizeof( config_cmd_interface_t ) );
  if ( socket_result < 0 ) {
    sprintf( message, "%s\n", strerror( errno ) );
    MCONFIG_ERROR( ( message ) );
  }

  return CONFIG_OK;
}


/************************************************************************
 * interface function (vhost mode)
 ************************************************************************/
ECONFIG_RESULT
config_set_vhost_db_interface( char *vhost_name, ECONFIG_ENABLE send_enable, char *send_device, char *recv_device ) {
  config_db_vhost_t *vhost_db;

  vhost_db = config_search_vhost_db( vhost_name );
  if ( vhost_db == NULL ) {
    MCONFIG_ERROR( ( "config_search_ng\n" ) );
    return CONFIG_NG;
  }

  vhost_db->vhost_db.interface.enable = CONFIG_ENABLE;
  vhost_db->vhost_db.interface.send_enable = send_enable;
  strcpy( vhost_db->vhost_db.interface.recv_device, send_device );
  strcpy( vhost_db->vhost_db.interface.send_device, recv_device );

  return CONFIG_OK;
}


ECONFIG_RESULT
config_delete_vhost_db_interface( char *vhost_name ) {
  config_db_vhost_t *vhost_db;

  vhost_db = config_search_vhost_db( vhost_name );
  if ( vhost_db == NULL ) {
    MCONFIG_ERROR( ( "config_search_ng\n" ) );
    return CONFIG_NG;
  }

  vhost_db->vhost_db.interface.enable = CONFIG_DISABLE;

  return CONFIG_OK;
}


ECONFIG_RESULT
config_interface_vhost_db( int sockfd, config_cmd_interface_t *interface ) {
  ECONFIG_RESULT result = CONFIG_NG;
  int socket_result;
  char message[ 256 ] = "";

  if ( interface->head.set_kind == CONFIG_ADD ) {
    result = config_set_vhost_db_interface( interface->head.vhost_name,
                                            interface->command.vhost_interface.kind.add.enable,
                                            interface->command.vhost_interface.kind.add.recv_device,
                                            interface->command.vhost_interface.kind.add.send_device );
  }
  else if ( interface->head.set_kind == CONFIG_DELETE ) {
    result = config_delete_vhost_db_interface( interface->head.vhost_name );
  }
  else {
    MCONFIG_ERROR( ( CONFIG_ERROR_PARAMETER ) );
    result = CONFIG_NG;
  }

  interface->head.result = result;
  interface->head.command = CONFIG_VHOST_INTERFACE_RESPONSE;

  // send response to CLI
  socket_result = com_socket_send( sockfd, ( u_char * ) interface, sizeof( config_cmd_interface_t ) );
  if ( socket_result < 0 ) {
    sprintf( message, "%s\n", strerror( errno ) );
    MCONFIG_ERROR( ( message ) );
  }

  return CONFIG_OK;
}


/************************************************************************
 * controller function (vhost mode)
 ************************************************************************/
ECONFIG_RESULT
config_set_vhost_db_controller( char *vhost_name, char *controller_name ) {
  config_db_vhost_t *vhost_db;

  vhost_db = config_search_vhost_db( vhost_name );
  if ( vhost_db == NULL ) {
    MCONFIG_ERROR( ( "config_search_ng\n" ) );
    return CONFIG_NG;
  }

  vhost_db->vhost_db.controller.enable = CONFIG_ENABLE;
  strcpy( vhost_db->vhost_db.controller.controller_name, controller_name );

  return CONFIG_OK;
}


ECONFIG_RESULT
config_delete_vhost_db_controller( char *vhost_name ) {
  config_db_vhost_t *vhost_db;

  vhost_db = config_search_vhost_db( vhost_name );
  if ( vhost_db == NULL ) {
    MCONFIG_ERROR( ( "config_search_ng\n" ) );
    return CONFIG_NG;
  }

  vhost_db->vhost_db.controller.enable = CONFIG_DISABLE;

  return CONFIG_OK;
}


ECONFIG_RESULT
config_controller_vhost_db( int sockfd, config_cmd_interface_t *interface ) {
  ECONFIG_RESULT result = CONFIG_NG;
  int socket_result;
  char message[ 256 ] = "" ;

  if ( interface->head.set_kind == CONFIG_ADD ) {
    result = config_set_vhost_db_controller( interface->head.vhost_name, interface->command.vhost_controller.kind.add.controller_name );
  }
  else if ( interface->head.set_kind == CONFIG_DELETE ) {
    result = config_delete_vhost_db_controller( interface->head.vhost_name );
  }
  else {
    MCONFIG_ERROR( ( CONFIG_ERROR_PARAMETER ) );
    result = CONFIG_NG;
  }

  interface->head.result = result;
  interface->head.command = CONFIG_VHOST_CONTROLLER_RESPONSE;

  // send response to CLI
  socket_result = com_socket_send( sockfd, ( u_char * ) interface, sizeof( config_cmd_interface_t ) );
  if ( socket_result < 0 ) {
    sprintf( message, "%s\n", strerror( errno ) );
    MCONFIG_ERROR( ( message ) );
  }

  return CONFIG_OK;
}


config_controller_detail_t *
config_get_controller_information( config_cmd_interface_t *interface ) {
  u_int count = 0;
  config_db_controller_t *search_controller_db;
  config_controller_detail_t *realloc_ptr;
  config_controller_detail_t *controller_information;

  // lock database
  config_lock();

  interface->command.admin_interface.command.controller.num = 0;
  controller_information = malloc( sizeof( config_controller_detail_t ) );
  if ( controller_information == NULL ) {
    interface->head.result = CONFIG_NG;
    config_unlock();
    return NULL;
  }

  search_controller_db = config_db.controller;
  while ( 1 ) {
    if ( search_controller_db == NULL ) {
      break;
    }

    realloc_ptr = realloc( controller_information, sizeof( config_controller_detail_t ) * ( long unsigned int ) ( count + 1 ) );
    if ( realloc_ptr == NULL ) {
      break;
    }
    controller_information = realloc_ptr;

    strcpy( controller_information[ count ].controller_name, search_controller_db->controller_name );
    strcpy( controller_information[ count ].ip_address, search_controller_db->ip_address );

    search_controller_db = search_controller_db->next_chain;
    count++;
  }

  // set response parameter
  interface->command.admin_interface.command.controller.num = count;

  // unlock database
  config_unlock();

  return controller_information;
}


config_static_arp_t *
config_get_static_arp_information( config_cmd_interface_t *interface ) {
  u_int count = 0;
  config_vhost_db_static_arp_t *search_static_arp_db;
  config_db_vhost_t *search_vhost_db;
  config_static_arp_t *realloc_ptr;
  config_static_arp_t *static_arp_information;

  // lock database
  config_lock();

  static_arp_information = malloc( sizeof( config_static_arp_t ) );
  if ( static_arp_information == NULL ) {
    interface->head.result = CONFIG_NG;
    config_unlock();
    return NULL;
  }

  search_vhost_db = config_search_vhost_db( interface->head.vhost_name );
  if ( search_vhost_db == NULL ) {
    interface->command.admin_interface.command.static_arp.num = 0;
    free( static_arp_information );
    config_unlock();
    return NULL;
  }

  search_static_arp_db = search_vhost_db->vhost_db.static_arp;
  while ( 1 ) {
    if ( search_static_arp_db == NULL ) {
      break;
    }

    realloc_ptr = realloc( static_arp_information, sizeof( config_static_arp_t ) * ( long unsigned int ) ( count + 1 ) );
    if ( realloc_ptr == NULL ) {
      break;
    }
    static_arp_information = realloc_ptr;

    strcpy( static_arp_information[ count ].ip_address, search_static_arp_db->ip_address );
    strcpy( static_arp_information[ count ].mac_address, search_static_arp_db->mac_address );

    search_static_arp_db = search_static_arp_db->next_chain;

    count++;
  }

  // set response parameter
  interface->command.admin_interface.command.static_arp.num = count;

  // unlock database
  config_unlock();

  return static_arp_information;
}


config_vhost_information_t *
config_get_vhost_information( config_cmd_interface_t *interface ) {
  u_int count = 0;
  config_db_vhost_t *search_vhost_db;
  config_vhost_information_t *realloc_ptr;
  config_vhost_information_t *vhost_infomation;

  // lock database
  config_lock();

  vhost_infomation = malloc( sizeof( config_vhost_information_t ) );
  if ( vhost_infomation == NULL ) {
    interface->head.result = CONFIG_NG;
    config_unlock();
    return NULL;
  }

  search_vhost_db = config_db.vhost;
  while ( 1 ) {
    if ( search_vhost_db == NULL ) {
      break;
    }

    realloc_ptr = realloc( vhost_infomation, sizeof( config_vhost_information_t ) * ( long unsigned int ) ( count + 1 ) );
    if ( realloc_ptr == NULL ) {
      break;
    }
    vhost_infomation = realloc_ptr;

    strcpy( vhost_infomation[ count ].vhost_name, search_vhost_db->vhost_name );
    memcpy( &vhost_infomation[ count ].vhost_info, &search_vhost_db->vhost_db, sizeof( config_vhost_db_vhost_detail_t ) );

    search_vhost_db = search_vhost_db->next_chain;
    count++;
  }

  // set response parameter
  interface->command.admin_interface.command.vhost.num = count;

  // unlock database
  config_unlock();

  return vhost_infomation;
}


config_vhost_information_t *
config_get_vhost_individual_information( config_cmd_interface_t *interface ) {
  config_db_vhost_t *search_vhost_db;
  config_vhost_information_t *vhost_infomation;

  // lock database
  config_lock();

  vhost_infomation = calloc( sizeof( config_vhost_information_t ), sizeof( char ) );
  if ( vhost_infomation == NULL ) {
    interface->command.admin_interface.command.vhost.num = 0x00;
    interface->head.result = CONFIG_NG;
    config_unlock();
    return NULL;
  }

  interface->command.admin_interface.command.vhost.num = 0x00;
  search_vhost_db = config_db.vhost;
  while ( 1 ) {
    if ( search_vhost_db == NULL ) {
      break;
    }
    if ( strcmp( interface->head.vhost_name, search_vhost_db->vhost_name ) == 0 ) {
      interface->command.admin_interface.command.vhost.num = 0x01;
      strcpy( vhost_infomation->vhost_name, search_vhost_db->vhost_name );
      memcpy( ( char * ) &vhost_infomation->vhost_info, ( char * ) &search_vhost_db->vhost_db, sizeof( config_vhost_db_vhost_detail_t ) );
      break;
    }
    search_vhost_db = search_vhost_db->next_chain;
  }

  return vhost_infomation;
}
