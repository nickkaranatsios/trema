#define _GNU_SOURCE 1
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <sched.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "cmn.h"
#include "loglib.h"

#include "config_define.h"
#include "config_struct.h"
#include "config_extern.h"


void
config_sigint() {
  config_unlock();
  exit( 1 );
  return;
}


void
config_sigalarm() {
  config_cycle_database();
  return;
}


void
config_initialize() {
  pid_t pid;
  cpu_set_t cpu_set;
  int result;
  char message[ 256 ] = "";

  ( void ) signal( SIGINT, config_sigint );
  ( void ) signal( SIGALRM, config_sigalarm );

  config_net_initialize();

  // set cpu
  pid = getpid();
  CPU_ZERO( &cpu_set );
  CPU_SET( CPU_NUMBER_CONFIG, &cpu_set );

  result = sched_setaffinity( pid, sizeof( cpu_set_t ), &cpu_set );
  if ( result == -1 ) {
    snprintf( message, sizeof( message ), "%s\n", strerror( errno ) );
    MCONFIG_ERROR( ( message ) );
    return;
  }

  alarm( 0 );
  alarm( CONFIG_ALARM_TIME );

  return;
}


void
config_print_usage() {
  printf( "usage: [-D]\n" );
  return;
}


int
config_daemonize() {
  pid_t pid, sid;
  int rc ;

  rc = chdir( ( const char * )"/" );
  if( rc != 0 ){
    return -1;
  }

  pid = fork();
  if ( pid < 0 ) {
    return -1;
  }

  if ( pid > 0 ) {
    exit( 0 );
  }

  sid = setsid();
  if ( sid < 0 ) {
    return -1;
  }

  fclose( stdin );
  fclose( stdout );
  fclose( stderr );
  umask( 0 );

  return 0;
}


int
main( int argc, char *argv[] ) {
  int opt;

  // initialize
  config_initialize();

  opt = getopt( argc, argv, "D" );
  switch ( opt ) {
  case 'D':
    if ( config_daemonize() < 0 ) {
      fprintf( stderr, "cannot daemonize.\n" );
      exit( 1 );
    }
    break;
  }
  // recv data
  config_net_receive();

  return 0;
}
