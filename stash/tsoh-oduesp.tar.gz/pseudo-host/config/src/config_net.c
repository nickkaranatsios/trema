#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <linux/un.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>

#include "cmn.h"
#include "com_socket.h"
#include "configif.h"
#include "loglib.h"

#include "config_define.h"
#include "config_struct.h"
#include "config_extern.h"

static int config_cli_sockfd;
static int config_recv_sockfd[ CONFIG_CLI_CONNECTION_MAX ];

extern ECONFIG_RESULT config_net_recv_from_cli( int );

void
config_net_set_socketfd( int sockfd ) {
  int count;

  for ( count = 0; count < CONFIG_CLI_CONNECTION_MAX; count++ ) {
    if ( config_recv_sockfd[ count ] == -1 ) {
      config_recv_sockfd[ count ] = sockfd;
      break;
    }
  }
  return;
}


void
config_net_initialize() {
  char path[ 64 ] = "";
  int count;
  char message[ 256 ] = "";

  for ( count = 0; count < CONFIG_CLI_CONNECTION_MAX; count++ ) {
    config_recv_sockfd[ count ] = -1;
  }

  sprintf( path, "%s%s", TMP_DIR, CONNECT_PATH );

  unlink( path );
  config_cli_sockfd = com_socket_unix_accept_port_create( path );
  if ( config_cli_sockfd < 0 ) {
    snprintf( message, sizeof( message ), "%s\n", strerror( errno ) );
    MCONFIG_ERROR( ( message ) );
    return;
  }

  return;
}


void
config_net_receive() {
  fd_set select_fd_set;
  int result;
  int length;
  int lp;
  int accept_sockfd;
  struct timeval select_time;
  char message[ 256 ] = "";
  struct sockaddr_un unix_sock;

  while ( 1 ) {
    FD_ZERO( &select_fd_set );
    FD_SET( config_cli_sockfd, &select_fd_set );

    config_set_socketfd( &select_fd_set );

    for ( lp = 0; lp < CONFIG_CLI_CONNECTION_MAX; lp++ ) {
      if ( config_recv_sockfd[ lp ] != -1 ) {
        FD_SET( config_recv_sockfd[ lp ], &select_fd_set );
      }
    }

    select_time.tv_sec = CONFIG_SELECT_TIME;
    select_time.tv_usec = 0;
    result = select( CONFIG_SELECT_MAX, &select_fd_set, NULL, NULL, &select_time );
    if ( result > 0 ) {
      for ( lp = 0; lp < CONFIG_CLI_CONNECTION_MAX; lp++ ) {
        if ( ( config_recv_sockfd[ lp ] != -1 ) && FD_ISSET( config_recv_sockfd[ lp ], &select_fd_set ) ) {
          result = config_net_recv_from_cli( config_recv_sockfd[ lp ] );
          if ( result != CONFIG_OK ) {
            com_socket_close( config_recv_sockfd[ lp ] );
            config_recv_sockfd[ lp ] = -1;
          }
        }
      }

      if ( ( config_cli_sockfd != -1 ) && FD_ISSET( config_cli_sockfd, &select_fd_set ) ) {
        // CLI-Config I/F
        length = sizeof( struct sockaddr_un );
        accept_sockfd = accept( config_cli_sockfd, ( struct sockaddr * ) &unix_sock, ( socklen_t * ) &length );
        if ( accept_sockfd < 0 ) {
          if ( errno == EINTR ) {
            continue;
          }
          snprintf( message, sizeof( message ), "%s\n", strerror( errno ) );
          MCONFIG_ERROR( ( message ) );
          continue;
        }
        config_net_set_socketfd( accept_sockfd );
      }

      // vhost-config connection
      config_delete_vhost_socketfd( &select_fd_set );
    }
  }

  return;
}


ECONFIG_RESULT
config_net_recv_from_cli( int recv_sockfd ) {
  int result;
  config_cmd_interface_t interface;

  memset( &interface, 0x00, sizeof( interface ) );
  result = com_socket_receive( recv_sockfd, ( u_char * ) &interface, sizeof( config_cmd_interface_t ) );
  if ( result != TRUE ) {
    // connection disconnect
    return CONFIG_NG;
  }

  MCONFIG_LOG( ( "vhost_name : %s\n", interface.head.vhost_name ) );
  switch ( interface.head.command ) {
    case CONFIG_VHOST_REQUEST:
      MCONFIG_LOG( ( "CONFIG_VHOST_REQUEST\n" ) );
      config_vhost_db( recv_sockfd, &interface );
      break;

    case CONFIG_CONTROLLER_REQUEST:
      MCONFIG_LOG( ( "CONFIG_CONTROLLER_REQUEST\n" ) );
      config_controller_db( recv_sockfd, &interface );
      break;

    case CONFIG_VHOST_MODE_REQUEST:
      MCONFIG_LOG( ( "CONFIG_VHOST_MODE_REQUEST\n" ) );
      config_mode_vhost_db( recv_sockfd, &interface );
      break;

    case CONFIG_VHOST_PROMISC_REQUEST:
      MCONFIG_LOG( ( "CONFIG_VHOST_PROMISC_REQUEST\n" ) );
      config_promisc_vhost_db( recv_sockfd, &interface );
      break;

    case CONFIG_VHOST_ARPCACHE_REQUEST:
      MCONFIG_LOG( ( "CONFIG_VHOST_ARPCACHE_REQUEST\n" ) );
      config_arpcache_vhost_db( recv_sockfd, &interface );
      break;

    case CONFIG_VHOST_STATICARP_REQUEST:
      MCONFIG_LOG( ( "CONFIG_VHOST_STATICARP_REQUEST\n" ) );
      config_static_arp_vhost_db( recv_sockfd, &interface );
      break;

    case CONFIG_VHOST_IPADDRESS_REQUEST:
      MCONFIG_LOG( ( "CONFIG_VHOST_IPADDRESS_REQUEST\n" ) );
      config_ipaddress_vhost_db( recv_sockfd, &interface );
      break;

    case CONFIG_VHOST_MASK_REQUEST:
      MCONFIG_LOG( ( "CONFIG_VHOST_MASK_REQUEST\n" ) );
      config_mask_vhost_db( recv_sockfd, &interface );
      break;

    case CONFIG_VHOST_MACADDRESS_REQUEST:
      MCONFIG_LOG( ( "CONFIG_VHOST_MACADDRESS_REQUEST\n" ) );
      config_macaddress_vhost_db( recv_sockfd, &interface );
      break;

    case CONFIG_VHOST_L2TYPE_REQUEST:
      MCONFIG_LOG( ( "CONFIG_VHOST_L2TYPE_REQUEST\n" ) );
      config_l2type_vhost_db( recv_sockfd, &interface );
      break;

    case CONFIG_VHOST_INTERFACE_REQUEST:
      MCONFIG_LOG( ( "CONFIG_VHOST_INTERFACE_REQUEST\n" ) );
      config_interface_vhost_db( recv_sockfd, &interface );
      break;

    case CONFIG_VHOST_CONTROLLER_REQUEST:
      MCONFIG_LOG( ( "CONFIG_VHOST_CONTROLLER_REQUEST\n" ) );
      config_controller_vhost_db( recv_sockfd, &interface );
      break;

    case CONFIG_GET_CONFIGURATION_VHOST:
      MCONFIG_LOG( ( "CONFIG_GET_CONFIGURATION_VHOST\n" ) );
      config_get_vhost_db( recv_sockfd, &interface );
      break;

    case CONFIG_GET_CONFIGURATION_STATIC_ARP:
      MCONFIG_LOG( ( "CONFIG_GET_CONFIGURATION_STATIC_ARP\n" ) );
      config_get_static_arp_db( recv_sockfd, &interface );
      break;

    case CONFIG_GET_CONFIGURATION_CONTROLLER:
      MCONFIG_LOG( ( "CONFIG_GET_CONFIGURATION_CONTROLLER\n" ) );
      config_get_controller_db( recv_sockfd, &interface );
      break;

    case CONFIG_GET_VHOST_IPADDRESS:
      MCONFIG_LOG( ( "CONFIG_GET_VHOST_IPADDRESS\n" ) );
      config_get_vhost_ipaddress( recv_sockfd, &interface );
      break;

    case CONFIG_GET_CONFIGURATION_VHOST_INDIVIDUAL:
      MCONFIG_LOG( ( "CONFIG_GET_CONFIGURATION_VHOST_INDIVIDUAL\n" ) );
      config_get_vhost_individual( recv_sockfd, &interface );
      break;

    default:
      MCONFIG_ERROR( ( "unknown command\n" ) );
      break;
  }

  return CONFIG_OK;
}
