#include <stdio.h>
#include <string.h>
#include <errno.h>

#include "cmn.h"
#include "configif.h"
#include "com_socket.h"
#include "loglib.h"

#include "config_define.h"
#include "config_struct.h"
#include "config_extern.h"

ECONFIG_RESULT
config_get_vhost_ipaddress( int sockfd, config_cmd_interface_t *interface ) {
  config_db_vhost_t *vhost_db;
  config_db_controller_t *controller_db;
  int socket_result;
  char message[ 256 ] = "";

  while ( 1 ) {
    vhost_db = config_search_vhost_db( interface->head.vhost_name );
    if ( vhost_db == NULL ) {
      MCONFIG_LOG( ( "config_search_vhost_db not found. \n" ) );
      interface->head.result = CONFIG_NG;
      break;
    }

    if ( vhost_db->vhost_db.controller.enable != CONFIG_ENABLE ) {
      MCONFIG_LOG( ( "controller.disable\n" ) );
      interface->head.result = CONFIG_NG;
      break;
    }

    controller_db = config_search_controller_db( vhost_db->vhost_db.controller.controller_name );
    if ( controller_db == NULL ) {
      MCONFIG_LOG( ( "config_search_controller_db not found.\n" ) );
      interface->head.result = CONFIG_NG;
      break;
    }

    strcpy( interface->command.admin_interface.command.vhost_ipaddress.ip_address, controller_db->ip_address );
    interface->head.result = CONFIG_OK;
    break;
  }

  socket_result = com_socket_send( sockfd, ( u_char * ) interface, sizeof( config_cmd_interface_t ) );
  if ( socket_result < 0 ) {
    snprintf( message, sizeof( message ), "%s\n", strerror( errno ) );
    MCONFIG_ERROR( ( message ) );
  }

  return CONFIG_OK;
}
