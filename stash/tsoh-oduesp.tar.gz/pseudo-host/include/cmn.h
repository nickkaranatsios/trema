/*
 * vhost common header .
 *
 * Author: Isamu Ohkuchi
 */

#ifndef _CMN_H
#define _CMN_H

#define u_short             unsigned short
#define u_char              unsigned char
#define u_int               unsigned int

#define TMP_DIR             "/var/tmp/"

#ifdef DBG
#define CPU_NUMBER_CLI      0
#define CPU_NUMBER_CONFIG   0
#define CPU_NUMBER_VHOST1   1
#define CPU_NUMBER_VHOST2   2
#define CPU_NUMBER_VHOST3   3
#define CPU_NUMBER_VHOST4   4
#define CPU_NUMBER_VHOST5   5
#define CPU_NUMBER_VHOST6   1
#define CPU_NUMBER_VHOST7   2
#define CPU_NUMBER_VHOST8   3
#define CPU_NUMBER_VHOST9   4
#define CPU_NUMBER_VHOST10  5
#define CPU_NUMBER_COREMAX  6

#else
#define CPU_NUMBER_CLI      0
#define CPU_NUMBER_CONFIG   0
#define CPU_NUMBER_VHOST1   1
#define CPU_NUMBER_VHOST2   2
#define CPU_NUMBER_VHOST3   3
#define CPU_NUMBER_VHOST4   4
#define CPU_NUMBER_VHOST5   5
#define CPU_NUMBER_VHOST6   6
#define CPU_NUMBER_VHOST7   7
#define CPU_NUMBER_VHOST8   8
#define CPU_NUMBER_VHOST9   9
#define CPU_NUMBER_VHOST10  10
#define CPU_NUMBER_VHOST11  11
#define CPU_NUMBER_COREMAX  12

#endif // DBG

/************************************************************************
 * MACRO
 ************************************************************************/

/* Swap bytes in 16 bit value.  */
#define M__bswap_constant_16( x ) \
  ( ( unsigned short int ) ( ( ( ( x ) >> 8 ) & 0xff ) | ( ( ( x ) & 0xff ) << 8 ) ) )

#if defined __GNUC__ && __GNUC__ >= 2
#define M__bswap_16( x )                                                     \
  ( __extension__                                                            \
    ( { register unsigned short int __v, __x = ( unsigned short int ) ( x ); \
        if ( __builtin_constant_p( __x ) ) {                                 \
          __v = M__bswap_constant_16( __x ); }                               \
        else {                                                               \
          __asm__( "rorw $8, %w0"                                            \
          : "=r" ( __v )                                                     \
          : "0" ( __x )                                                      \
          : "cc" ); }                                                        \
        __v; }                                                               \
    ) )
#else

/* This is better than nothing.  */
#define M__bswap_16( x )                                                \
  ( __extension__                                                       \
    ( { register unsigned short int __x = ( unsigned short int ) ( x ); \
        M__bswap_constant_16( __x ); }                                  \
    ) )
#endif

#ifdef __OPTIMIZE__

/* We can optimize calls to the conversion functions.  Either nothing has
   to be done or we are using directly the byte-swapping functions which
   often can be inlined.  */
#if __BYTE_ORDER == __BIG_ENDIAN

/* The host byte order is the same as network byte order,
   so these functions are all just identity.  */
#define Mntohs( x )   ( x )
#define Mhtons( x )   ( x )
#else
#if __BYTE_ORDER == __LITTLE_ENDIAN
#define Mntohs( x ) M__bswap_16( x )
#define Mhtons( x ) M__bswap_16( x )
#endif
#endif
#else
#define Mntohs( x ) ntohs( x )
#define Mhtons( x ) htons( x )
#endif


#endif // _CMN_H

/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
