/*
 * vhost packet interface .
 *
 * Author: Tomoaki Ishikawa
 */


#ifndef _COM_SOCKET_H
#define _COM_SOCKET_H

/******************************************************************************
 * define & macros                                                            *
 ******************************************************************************/
#define     FALSE       ( 0 )
#define     TRUE        ( 1 )


/******************************************************************************
 * external                                                                   *
 ******************************************************************************/
extern int com_socket_connect( u_int ipv4_address,  int port_number );
extern int com_socket_send( int socket_id, u_char *send_data, size_t send_size );
extern int com_socket_receive( int socket_fd, u_char *receive_buffer, size_t receive_size );
extern int com_socket_data_copy( int socket_fd, u_char *receive_buffer, size_t receive_size );
extern int com_socket_close( int socket_fd );
extern int com_socket_accept_port_create( int port_number );
extern int com_socket_unix_connect( char *path );
extern int com_socket_unix_accept_port_create( char *path );

#endif  // _COM_SOCKET_H

/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
