/*
 * config library header .
 *
 * Author: Isamu Ohkuchi
 */

#ifndef _CONFIG_LIB_H
#define _CONFIG_LIB_H

#include <stdio.h>

extern config_vhost_information_t *config_get_vhost_information( char * );
extern config_vhost_information_t *config_get_all_vhost_information( u_int * );
extern config_controller_detail_t *config_get_controller_information( u_int * );
extern config_static_arp_t *config_get_static_arp_information( char *, u_int * );
extern ECONFIG_RESULT config_get_vhost_ipaddress( char *, char * );


#endif  // _CONFIG_LIB_H

/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
