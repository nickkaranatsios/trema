/*
 * cli config interface header .
 *
 * Author: Isamu Ohkuchi
 */

#ifndef _CONFIGIF_H
#define _CONFIGIF_H

/************************************************************************************
 * DEFINE
 ************************************************************************************/
#define IP_SIZE                         16
#define MAC_SIZE                        18
#define NAME_SIZE                       40
#define CONTROLLER_NAME_SIZE            32
#define CONNECT_PATH                    "con.un"

#define CONFIG_TO_CLI_VHOST_MAX         5
#define CONFIG_TO_CLI_CONTROLLER_MAX    30
#define CONFIG_TO_CLI_STATICARP_MAX     30

/************************************************************************************
 * ENUM
 ************************************************************************************/
typedef enum config_command {
  // configuration command
  CONFIG_VHOST_REQUEST,                     // (config)# vhost
  CONFIG_VHOST_RESPONSE,                    // (config)# vhost
  CONFIG_CONTROLLER_REQUEST,                // (config)# controller
  CONFIG_CONTROLLER_RESPONSE,               // (config)# controller
  CONFIG_VHOST_MODE_REQUEST,                // (config-vhost)# mode
  CONFIG_VHOST_MODE_RESPONSE,               // (config-vhost)# mode
  CONFIG_VHOST_PROMISC_REQUEST,             // (config-vhost)# promisc
  CONFIG_VHOST_PROMISC_RESPONSE,            // (config-vhost)# promisc
  CONFIG_VHOST_ARPCACHE_REQUEST,            // (config-vhost)# arp_cache
  CONFIG_VHOST_ARPCACHE_RESPONSE,           // (config-vhost)# arp_cache
  CONFIG_VHOST_STATICARP_REQUEST,           // (config-vhost)# static arp
  CONFIG_VHOST_STATICARP_RESPONSE,          // (config-vhost)# static arp
  CONFIG_VHOST_IPADDRESS_REQUEST,           // (config-vhost)# ip_address
  CONFIG_VHOST_IPADDRESS_RESPONSE,          // (config-vhost)# ip_address
  CONFIG_VHOST_MASK_REQUEST,                // (config-vhost)# mask
  CONFIG_VHOST_MASK_RESPONSE,               // (config-vhost)# mask
  CONFIG_VHOST_MACADDRESS_REQUEST,          // (config-vhost)# mac_address
  CONFIG_VHOST_MACADDRESS_RESPONSE,         // (config-vhost)# mac_address
  CONFIG_VHOST_L2TYPE_REQUEST,              // (config-vhost)# l2type
  CONFIG_VHOST_L2TYPE_RESPONSE,             // (config-vhost)# l2type
  CONFIG_VHOST_INTERFACE_REQUEST,           // (config-vhost)# interface
  CONFIG_VHOST_INTERFACE_RESPONSE,          // (config-vhost)# interface
  CONFIG_VHOST_CONTROLLER_REQUEST,          // (config-vhost)# controller
  CONFIG_VHOST_CONTROLLER_RESPONSE,         // (config-vhost)# controller

  // administration command
  CONFIG_GET_CONFIGURATION_VHOST,           // show config ( vhost information )
  CONFIG_GET_CONFIGURATION_STATIC_ARP,      // show config ( static arp )
  CONFIG_GET_CONFIGURATION_CONTROLLER,      // show config ( controller information )
  CONFIG_GET_VHOST_IPADDRESS,               // get vhost ip_address

  // library
  CONFIG_GET_CONFIGURATION_VHOST_INDIVIDUAL
} ECONFIG_COMMAND;

typedef enum config_continue {
  CONFIG_CONTINUE_EXIST,                    // continue exists
  CONFIG_CONTINUE_NOT_EXIST                 // continue not exists
} ECONFIG_CONTINUE;

typedef enum config_l2headtype {
  CONFIG_L2TYPEETHER,
  CONFIG_L2TYPEVLAN
} ECONFIG_L2HEADTYPE;

typedef enum config_specified_kind {
  CONFIG_ALL,
  CONFIG_INDIVIDUAL
} ECONFIG_SPECIFIED_KIND;

typedef enum config_statistics_kind {
  CONFIG_RECEIVESEND,
  CONFIG_RECEIVE,
  CONFIG_SEND
} ECONFIG_STATISTICS_KIND;

typedef enum config_setting_kind {
  CONFIG_ADD,
  CONFIG_MODIFY,
  CONFIG_DELETE
} ECONFIG_SETTING_KIND;

typedef enum config_host_mode {
  CONFIG_RAW_GENERATION_MODE,
  CONFIG_HOST_EMULATION_MODE
} ECONFIG_HOST_MODE;

typedef enum config_promisc {
  CONFIG_PROMISC,
  CONFIG_NOPROMISC
} ECONFIG_PROMISC;

typedef enum config_enable {
  CONFIG_ENABLE = 1,
  CONFIG_DISABLE
} ECONFIG_ENABLE;

typedef enum config_result {
  CONFIG_OK,
  CONFIG_NG,
  CONFIG_DUPLICATE_NG
} ECONFIG_RESULT;


/************************************************************************************
 * STRUCT
 ************************************************************************************/
typedef struct config_common_head {
  ECONFIG_COMMAND       command;
  ECONFIG_RESULT        result;
  ECONFIG_SETTING_KIND  set_kind;
  char                  vhost_name[ NAME_SIZE ];
} config_common_head_t;

/************************************************************************************
 * configuration command
 ************************************************************************************/
// vhost
typedef struct config_vhost_add {
  char                vhost_name[ NAME_SIZE ];
} config_vhost_add_t;

typedef struct config_vhost_delete {
  ECONFIG_SPECIFIED_KIND  kind;
  char                    vhost_name[ NAME_SIZE ];
} config_vhost_delete_t;

typedef struct config_vhost {
  union vhost_kind {
    config_vhost_add_t    add;
    config_vhost_delete_t del;
  } kind;
} config_vhost_t;

// controller
typedef struct config_controller_add {
  char                    controller_name[ NAME_SIZE ];
  char                    ip_address[ IP_SIZE ];
} config_controller_add_t;

typedef struct config_controller_del {
  ECONFIG_SPECIFIED_KIND  kind;
  char                    controller_name[ NAME_SIZE ];
} config_controller_delete_t;

typedef struct config_controller {
  union controller_kind {
    config_controller_add_t     add;
    config_controller_delete_t  del;
  } kind;
} config_controller_t;

// mode
typedef struct config_mode_add {
  ECONFIG_HOST_MODE       mode;
} config_mode_add_t;

typedef struct config_mode {
  union mode_kind {
    config_mode_add_t     add;
  } kind;
} config_vhost_mode_t;

// promisc
typedef struct config_promisc_add {
  ECONFIG_PROMISC         promisc;
} config_promisc_add_t;

typedef struct config_vhost_promisc {
  union promisc_kind {
    config_promisc_add_t  add;
  } kind;
} config_vhost_promisc_t;

// arp cache
typedef struct config_vhost_arp_cache_add {
  u_short                 time;
} config_vhost_arp_cache_add_t;

typedef struct config_vhost_arp_cache {
  union vhost_arp_cache_kind {
    config_vhost_arp_cache_add_t add;
  } kind;
} config_vhost_arp_cache_t;

// static arp
typedef struct config_vhost_static_arp_add {
  char                    ip_address[ IP_SIZE ];
  char                    mac_address[ MAC_SIZE ];
} config_vhost_static_arp_add_t;

typedef struct config_vhost_static_arp_del {
  char                    ip_address[ IP_SIZE ];
  char                    mac_address[ MAC_SIZE ];
} config_vhost_static_arp_delete_t;

typedef struct config_vhost_static_arp {
  union vhost_static_arp_kind {
    config_vhost_static_arp_add_t     add;
    config_vhost_static_arp_delete_t  del;
  } kind;
} config_vhost_static_arp_t;

// ip address
typedef struct config_vhost_ip_address_add {
  char                    ip_address[ IP_SIZE ];
} config_vhost_ip_address_add_t;

typedef struct config_vhost_ip_address {
  union vhost_ip_address_kind {
    config_vhost_ip_address_add_t     add;
  } kind;
} config_vhost_ip_address_t;

// mask
typedef struct config_vhost_mask_add {
  char                    mask[ MAC_SIZE ];
} config_vhost_mask_add_t;

typedef struct config_vhost_mask {
  union vhost_mask_kind {
    config_vhost_mask_add_t           add;
  } kind;
} config_vhost_mask_t;

// mac address
typedef struct config_vhost_mac_address_add {
  char                    mac_address[ MAC_SIZE ];
} config_vhost_mac_address_add_t;

typedef struct config_vhost_mac_address {
  union vhost_mac_address_kind {
    config_vhost_mac_address_add_t    add;
  } kind;
} config_vhost_mac_address_t;

// l2type
typedef struct config_vhost_l2type_add {
  ECONFIG_L2HEADTYPE      l2type;
  u_short                 vlanid;
} config_vhost_l2type_add_t;

typedef struct config_vhost_l2type {
  union vhost_l2type_kind {
    config_vhost_l2type_add_t         add;
  } kind;
} config_vhost_l2type_t;

// interface
typedef struct config_vhost_interface_add {
  char recv_device[ NAME_SIZE ];
  ECONFIG_ENABLE          enable;
  char                    send_device[ NAME_SIZE ];
} config_vhost_interface_add_t;

typedef struct config_vhost_interface {
  union vhost_interface_kind {
    config_vhost_interface_add_t      add;
  } kind;
} config_vhost_interface_t;

// controller
typedef struct config_vhost_controller_add {
  char                    controller_name[ NAME_SIZE ];
} config_vhost_controller_add_t;

typedef struct config_vhost_controller {
  union vhost_controller_kind {
    config_vhost_controller_add_t     add;
  } kind;
} config_vhost_controller_t;

/************************************************************************************
 * CLI - CONFIG INTERFACE ( administration command)
 ************************************************************************************/
// administration head
typedef struct config_admin_head {
  int                     seq;
  ECONFIG_CONTINUE        exist;
} config_admin_head_t;


// (config-vhost)# mode
typedef struct config_vhost_db_mode {
  ECONFIG_ENABLE          enable;
  ECONFIG_HOST_MODE       mode;
} config_vhost_db_mode_t;

// (config-vhost)# promisc
typedef struct config_vhost_db_promisc {
  ECONFIG_ENABLE          enable;
  ECONFIG_PROMISC         promisc;
} config_vhost_db_promisc_t;

// (config-vhost)# arp-cache
typedef struct config_vhost_db_arpcache {
  ECONFIG_ENABLE          enable;
  u_short                 time;
} config_vhost_db_arpcache_t;

// (config-vhost)# ip_address
typedef struct config_vhost_db_ipaddress {
  ECONFIG_ENABLE          enable;
  char                    ip_address[ IP_SIZE ];
} config_vhost_db_ipaddress_t;

// (config-vhost)# mask
typedef struct config_vhost_db_mask {
  ECONFIG_ENABLE          enable;
  char                    mask[ IP_SIZE ];
} config_vhost_db_mask_t;

// (config-vhost)# mac_address
typedef struct config_vhost_db_macaddress {
  ECONFIG_ENABLE enable;
  char                    mac_address[ MAC_SIZE ];
} config_vhost_db_macaddress_t;

// (config-vhost)# l2type
typedef struct config_vhost_db_l2type {
  ECONFIG_ENABLE          enable;
  ECONFIG_L2HEADTYPE      l2type;
  u_short                 vlanid;
} config_vhost_db_l2type_t;

// (config-vhost)# interface
typedef struct config_vhost_db_interface {
  ECONFIG_ENABLE          enable;
  char                    recv_device[ NAME_SIZE + 1 ];
  ECONFIG_ENABLE          send_enable;
  char                    send_device[ NAME_SIZE + 1 ];
} config_vhost_db_interface_t;

// (config-vhost)# controller
typedef struct config_vhost_db_controller {
  ECONFIG_ENABLE          enable;
  char                    controller_name[ CONTROLLER_NAME_SIZE + 1 ];
} config_vhost_db_controller_t;

// (config-vhost)# static arp
typedef struct config_vhost_db_static_arp {
  char                    ip_address[ IP_SIZE  ];
  char                    mac_address[ MAC_SIZE  ];
  void                    *front_chain;
  void                    *next_chain;
} config_vhost_db_static_arp_t;

typedef struct config_vhost_db_vhost_detail {
  config_vhost_db_mode_t        mode;
  config_vhost_db_promisc_t     promisc;
  config_vhost_db_arpcache_t    arpcache;
  config_vhost_db_ipaddress_t   ip_addr;
  config_vhost_db_mask_t        mask;
  config_vhost_db_macaddress_t  mac_addr;
  config_vhost_db_l2type_t      l2type;
  config_vhost_db_interface_t   interface;
  config_vhost_db_controller_t  controller;
  config_vhost_db_static_arp_t  *static_arp;
} config_vhost_db_vhost_detail_t;


typedef struct config_vhost_information {
  char                            vhost_name[ NAME_SIZE ];
  config_vhost_db_vhost_detail_t  vhost_info;
} config_vhost_information_t;

// show config ( vhost information )
typedef struct config_vhost_configuration {
  u_int                       num;
  config_vhost_information_t  info[ CONFIG_TO_CLI_VHOST_MAX ];
} config_vhost_configuration_t;


// show config ( controller information )
typedef struct config_controller_detail {
  char                    controller_name[ CONTROLLER_NAME_SIZE + 1 ];
  char                    ip_address[ IP_SIZE ];
} config_controller_detail_t;

typedef struct config_controller_information {
  u_int                       num;
  config_controller_detail_t  info[ CONFIG_TO_CLI_CONTROLLER_MAX ];
} config_controller_information_t;

typedef struct config_static_arp {
  char                    ip_address[ IP_SIZE ];
  char                    mac_address[ MAC_SIZE ];
} config_static_arp_t;

typedef struct config_static_arp_information {
  u_int                   num;
} config_static_arp_information_t;

typedef struct config_vhost_ipaddress {
  char                    ip_address[ IP_SIZE ];
} config_vhost_ipaddress_t;

// CLI - CONFIG INTERFACE ( administration command)
typedef struct admin_interface {
  config_admin_head_t admin_head;
  union admin_cmd {
    config_vhost_configuration_t    vhost;
    config_controller_information_t controller;
    config_static_arp_information_t static_arp;
    config_vhost_ipaddress_t        vhost_ipaddress;
  } command;
} admin_interface_t;

// CLI - CONFIG INTERFACE
typedef struct config_interface {
  config_common_head_t head;
  union cmd {
    // configuration command
    config_vhost_t                config_vhost;
    config_controller_t           config_controller;
    config_vhost_mode_t           vhost_mode;
    config_vhost_promisc_t        vhost_promisc;
    config_vhost_arp_cache_t      vhost_cache;
    config_vhost_static_arp_t     vhost_static_arp;
    config_vhost_ip_address_t     vhost_ip_address;
    config_vhost_mask_t           vhost_mask;
    config_vhost_mac_address_t    vhost_mac_address;
    config_vhost_l2type_t         vhost_l2type;
    config_vhost_interface_t      vhost_interface;
    config_vhost_controller_t     vhost_controller;
    admin_interface_t             admin_interface;
  } command;
} config_cmd_interface_t;

#endif  // _CONFIGIF_H

/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
