
/*
 * log lib header .
 *
 * Author: Isamu Ohkuchi
 */

#ifndef _LOGLIB_H
#define _LOGLIB_H



/******************************************************************************/
/* ENUM���                                                                   */
/******************************************************************************/
enum loglib_Type {
  LOGLIB_ALL,
  LOGLIB_FILE,
  LOGLIB_STDOUT,
  LOGLIB_NONE
};

enum loglib_Kind {
  LOGLIB_PRINT,
  LOGLIB_ERR_PRINT
};

typedef enum {
  LOGLIB_ADDRESS,
  LOGLIB_OFFSET
} Eplc_liblog_dumpkind;

typedef enum {
  LOGLIB_CMDALL,
  LOGLIB_CMDFILE
} Eplc_liblog_stdkind;

typedef enum {
  LOGLIB_KEY1,
  LOGLIB_KEYMAX
} Eplc_liblog_flockkind;

/******************************************************************************
 * Define
 ******************************************************************************/
#define  LOGLIB_PARSE_KEY1                   "/"
#define  LOGLIB_PARSE_KEY1_CHAR              '/'
#define  LOGLIB_TMPSIZE                      512

#define  LOGLIB_DIR                          "/var/log"
#define  LOGLIB_LOGONDIR                     "/etc/plc"
#define  LOGLIB_TTYDIR                       "/dev/pts/"
#define  LOGLIB_SERIALTTY                    "/dev/ttyS0"
#define  LOGLIB_LOGON                        "/logon"
#define  LOGLIB_LOG_FILENAME                 "/dbglog"
#define  LOGLIB_ERRLOG_FILENAME              "/errlog"
#define  LOGLIB_OPELOG_FILENAME              "/opelog"
#define  LOGLIB_LOG_SIZE                     2000000
#define  LOGLIB_LOG_GEN                      3
#define  LOGLIB_FLOCKKEY                    "logkey1"
#define  LOGLIB_LOGDIR_STR                   "LOGDIR"
#define  LOGLIB_HOMELOGDIR_STR               "HOME_PLC_DIR"
#define  LOGLIB_LOGTYPE_STR                  "LOGTYPE"

#define MLOGLIB_PRINT( message ) \
  loglib_printf( __FILE__, __LINE__, LOGLIB_PRINT, message )
#define MLOGLIB_ERROR_PRINT( message ) \
  loglib_printf( __FILE__, __LINE__, LOGLIB_ERR_PRINT, message )

#define MLOGLIB_LOCK( A )             loglib_lock( A )
#define MLOGLIB_UNLOCK( A )           loglib_unlock( A )

/******************************************************************************
 * Extern 
 ******************************************************************************/
extern void loglib_genchk( char *logname );
extern void loglib_printf( const char *, const int, int, const char * );
extern void loglib_sigclose();

/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */


#endif // _LOGLIB_H
