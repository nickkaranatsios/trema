/*
 * vhost packet interface .
 *
 * Author: Tomoaki Ishikawa
 */


#ifndef _VHOST_PACKET_HEADER_H
#define _VHOST_PACKET_HEADER_H

#include    <net/ethernet.h>

/******************************************************************************
 * define & macros                                                            *
 ******************************************************************************/
#define     MAX_VHOST_NAME_LENGTH           32
#define     MAC_ADDRESS_LENGTH              ETH_ALEN
#define     INTERFACE_NAME_LENGTH           32
#define     MAX_OPTION_LENGTH               40

#define     SOURCE_TYPE_INCREMENT       0x01
#define     SOURCE_TYPE_DECREMENT       0x02
#define     SOURCE_TYPE_RANDOM          0x04

#define     SOURCE_CONVERT_TYPE ( SOURCE_TYPE_INCREMENT | SOURCE_TYPE_DECREMENT | SOURCE_TYPE_RANDOM )

#define     DESTINATION_TYPE_INCREMENT      0x08
#define     DESTINATION_TYPE_DECREMENT      0x10
#define     DESTINATION_TYPE_RANDOM         0x20

#define     MAC_DESTINATION_CONVERT_TYPE    ( DESTINATION_TYPE_INCREMENT | DESTINATION_TYPE_DECREMENT | DESTINATION_TYPE_RANDOM )
#define     REQUEST_NG      1

#define     REQUEST_NG      1
#define     REQUEST_OK      0

#define     VHOST_STATUS_REQUEST_ALL    0       // vhost status all get
#define     VHOST_STATUS_REQUEST_VHOST  1       // vhost status vhostname search

#if __BYTE_ORDER == __LITTLE_ENDIAN

#define     ntohll( x )   ( ( ( uint64_t ) ( ntohl( ( uint32_t ) ( ( x << 32 ) >> 32 ) ) ) << 32 ) | ( uint32_t ) ntohl( ( ( uint32_t ) ( x >> 32 ) ) ) )
#define     htonll( x )   ntohll( x )

#elif   __BYTE_ORDER == __BIG_ENDIAN

#define     ntohll( x )
#define     htonll( x )

#endif

#define     RESULT_NG       1
#define     RESULT_OK       0

#define     HOST_EMURATOR_MODE  1
#define     RAW_GENERATOR_MODE  0

#define     PACKET_TYPE_DIX     0
#define     PACKET_TYPE_8021Q   1

#define     PACKET_MODE_DEFAULT 0
#define     PACKET_MODE_PROMISC 1

#define     VHOST_STATISTICS_CLEAR_SEND     0
#define     VHOST_STATISTICS_CLEAR_RECEIVE  1
#define     VHOST_STATISTICS_CLEAR_ALL      2

#define     VHOST_STATISTICS_TYPE_SEND      0
#define     VHOST_STATISTICS_TYPE_RECEIVE   1

#define     VHOST_DYNAMIC_ARP_INDIVIDUALLY      0
#define     VHOST_DYNAMIC_ARP_CLEAR_ALL     1

#define     VHOST_STATIC_ARP_SET            0
#define     VHOST_STATIC_ARP_CLEAR          1

#define     VHOST_SEND_REQUEST_LAYER_3_TYPE_IPV4        0
#define     VHOST_SEND_REQUEST_LAYER_3_TYPE_ARP         1

#define     VHOST_PAYLOAD_NONE                  0
#define     VHOST_PAYLOAD_INCREMENT             1
#define     VHOST_PAYLOAD_DECREMENT             2
#define     VHOST_PAYLOAD_RANDOM                3
#define     VHOST_PAYLOAD_USER_DESIGNATION      4
#define     VHOST_ARP_INFORMATION_STATIC_ARP_ENTRY      0x8000

#define     VHOST_SEND_REQUEST_VLAN_ENABLE          1
#define     VHOST_SEND_REQUEST_VLAN_DISABLE         0

/******************************************************************************
 * Packet Interface Command Codes                                             *
 ******************************************************************************/
#define     VHOST_CREATE_REQUEST            0x00000001
#define     VHOST_CREATE_ANSWER             0x80000001
#define     VHOST_ARP_CACHE_REQUEST         0x00000002
#define     VHOST_ARP_CACHE_ANSWER          0x80000002
#define     VHOST_STATUS_REQUEST            0x00000003
#define     VHOST_STATUS_ANSWER             0x80000003
#define     VHOST_STOP_REQUEST              0x00000004
#define     VHOST_STOP_ANSWER               0x80000004
#define     VHOST_STATIC_ARP_REQUEST        0x00000005
#define     VHOST_STATIC_ARP_ANSWER         0x80000005
#define     VHOST_ARP_INFORMATION_REQUEST   0x00000006
#define     VHOST_ARP_INFORMATION_ANSWER    0x80000006
#define     VHOST_DYNAMIC_ARP_CLEAR_REQUEST 0x00000007
#define     VHOST_DYNAMIC_ARP_CLEAR_ANSWER  0x80000007
#define     VHOST_STATISTICS_CLEAR_REQUEST  0x00000008
#define     VHOST_STATISTICS_CLEAR_ANSWER   0x80000008
#define     VHOST_STATISTICS_GET_REQUEST    0x00000009
#define     VHOST_STATISTICS_GET_ANSWER     0x80000009
#define     VHOST_SEND_REQUEST              0x0000000A
#define     VHOST_SEND_ANSWER               0x8000000A
#define     VHOST_SEND_CANCEL_REQUEST       0x0000000B
#define     VHOST_SEND_CANCEL_ANSWER        0x8000000B
#define     VHOST_SEND_INCOMPLETEL_NOTICE   0x8000000C
#define     VHOST_SEND_RESPONCE             0x8000000D

/******************************************************************************
 * Packet Interface Structure                                                 *
 ******************************************************************************/
struct vlan_ether_header {
  u_char h_dest[ ETH_ALEN ];
  u_char h_source[ ETH_ALEN ];
  u_short h_vlan_proto;
  u_short h_vlan_TCI;
  u_short h_vlan_encapsulated_proto;
};

/******************************************************************************
 * Packet Interface Structure                                                 *
 ******************************************************************************/
typedef struct  _packet_header {
  u_int size;               // Total Size
  u_int packet_num;         // Packet Num
} PACKET_HEADER, *PACKET_HEADER_POINTER;


// Command Header
typedef struct  _command_header {
  unsigned int length;                              // command length
  unsigned int command_code;                        // command code
  u_char vhost_name[ MAX_VHOST_NAME_LENGTH ];       // vhost name
} COMMAND_PACKET_HEADER, *COMMAND_PACKET_HEADER_POINTER;

// vHost Create Request Command
typedef struct  _vhost_create_request_block {
  COMMAND_PACKET_HEADER header;
  u_int generator_mode;                                         // 0: raw genetator mode
                                                                // 1: host generator mode
  u_int ip_address;                                             // IPv4 Address
  u_int netmask;                                                // NET Mask
  u_char mac_address[ MAC_ADDRESS_LENGTH ];                     // MAC Address
  u_short l2_type;                                              // 0: DIX
                                                                // 1: 802.1Q
  u_short vlan_id;                                              // VLAN ID
  u_short promisc_mode;                                         // 0:no promisc
                                                                // 1:promisc
  u_short arp_cache_time;                                       // arp cache time
  u_short rfu;                                                  // Reserved Future Used
  char receive_interface[ INTERFACE_NAME_LENGTH ];              // receive interface name
  char send_interface[ INTERFACE_NAME_LENGTH ];                 // receive interface name
} VHOST_CREATE_REQUEST_BLOCK, *VHOST_CREATE_REQUEST_BLOCK_POINTER;

// vHost Create Answer Command
typedef struct  _vhost_create_answer_block {
  COMMAND_PACKET_HEADER header;
  u_int result;                             // 0: Complete
                                            // 1: incomplete
} VHOST_CREATE_ANSWER_BLOCK, *VHOST_CREATE_ANSWER_BLOCK_POINTER;

// vHost arp cache request Command
typedef struct  _vhost_arp_cache_set_request_block {
  COMMAND_PACKET_HEADER header;
  u_int arp_cache_time;
} VHOST_ARP_CACHE_SET_REQUEST_BLOCK, *VHOST_ARP_CACHE_SET_REQUEST_BLOCK_POINTER;

// vHost arp cache Command
typedef struct  _vhost_arp_cache_set_answer_block {
  COMMAND_PACKET_HEADER header;
  u_int result;                             // 0: Complete
                                            // 1: incomplete
} VHOST_ARP_CACHE_SET_ANSWER_BLOCK, *VHOST_ARP_CACHE_SET_ANSWER_BLOCK_POINTER;

// vHost stop request Command
typedef struct  _vhost_stop_request_block {
  COMMAND_PACKET_HEADER header;
} VHOST_STOP_REQUEST_BLOCK, *VHOST_STOP_REQUEST_BLOCK_POINTER;

// vHost stop Answer Command
typedef struct  _vhost_stop_answer_block {
  COMMAND_PACKET_HEADER header;
  u_int result;                             // 0: Complete
                                            // 1: incomplete
} VHOST_STOP_ANSWER_BLOCK, *VHOST_STOP_ANSWER_BLOCK_POINTER;

// vHost status request
typedef struct  _vhost_status_request_block {
  COMMAND_PACKET_HEADER header;
  u_int request_code;                       // 0: All
                                            // 1: vhost name search
} VHOST_STATUS_REQUEST_BLOCK, *VHOST_STATUS_REQUEST_BLOCK_POINTER;

// vHost status answer
typedef struct  _vhost_status_answer_block {
  COMMAND_PACKET_HEADER header;             // dc vhost_name
  u_int vhost_num;                          // vhost num
} VHOST_STATUS_ANSWER_BLOCK, *VHOST_STATUS_ANSWER_BLOCK_POINTER;


// vHost static arp request Command
typedef struct  _vhost_static_arp_request_block {
  COMMAND_PACKET_HEADER header;
  u_char mac_address[ MAC_ADDRESS_LENGTH ];         // MAC Address
  u_short mode;                                     // 0: SET
                                                    // 1: DELETE
  u_int ipv4_address;                               // IPv4 Address
} VHOST_STATIC_ARP_REQUEST_BLOCK, *VHOST_STATIC_ARP_REQUEST_BLOCK_POINTER;

// vHost static arp Answer Command
typedef struct  _vhost_static_arp_answer_block {
  COMMAND_PACKET_HEADER header;
  u_int result;                             // 0: Complete
                                            // 1: incomplete
} VHOST_STATIC_ARP_ANSWER_BLOCK, *VHOST_STATIC_ARP_ANSWER_BLOCK_POINTER;


// vHost arp get request Command
typedef struct  _vhost_arp_get_request_block {
  COMMAND_PACKET_HEADER header;
} VHOST_ARP_GET_REQUEST_BLOCK, *VHOST_ARP_GET_REQUEST_BLOCK_POINTER;

// vHost arp data reply Command

typedef struct  _vhost_arp_get_answer_block {
  COMMAND_PACKET_HEADER header;
  unsigned long long arp_total;             // arp total num
  unsigned long long arp_offset;            // arp offset
} VHOST_ARP_GET_ANSWER_BLOCK, *VHOST_ARP_GET_ANSWER_BLOCK_POINTER;

// vHost arp data
typedef struct  _vhost_arp_control_block {
  u_short vlan_id;                                  // VLAN ID
  u_char mac_address[ MAC_ADDRESS_LENGTH ];         // MAC Address
  u_int ipv4_address;                               // IPv4 Address
  u_int arp_expire_time;                            // arp expire time
} VHOST_ARP_CONTROL_BLOCK, *VHOST_ARP_CONTROL_BLOCK_POINTER;

// vHost dynamic arp clear request Command
typedef struct  _vhost_dynamic_arp_clear_request_block {
  COMMAND_PACKET_HEADER header;
  u_char mac_address[ MAC_ADDRESS_LENGTH ];         // MAC Address
  u_short mode;                                     // 0: individually
                                                    // 1: all
  u_int ipv4_address;                               // IPv4 Address
} VHOST_DYNAMIC_ARP_CLEAR_REQUEST_BLOCK, *VHOST_DYNAMIC_ARP_CLEAR_REQUEST_BLOCK_POINTER;

// vHost dynamic arp clear Answer Command
typedef struct  _vhost_dynamic_arp_clear_answeer_block {
  COMMAND_PACKET_HEADER header;
  u_int result;                             // 0: Complete
                                            // 1: incomplete
} VHOST_DYNAMIC_ARP_CLEAR_ANSWER_BLOCK, *VHOST_DYNAMIC_ARP_CLEAR_ANSWER_BLOCK_POINTER;

// vHost statistics clear request Command
typedef struct  _vhost_statistics_clear_request_block {
  COMMAND_PACKET_HEADER header;
  u_int type;                   // 0: send only
                                // 1: receive only
                                // 2: both
} VHOST_STATISTICS_CLEAR_REQUEST_BLOCK, *VHOST_STATISTICS_CLEAR_REQUEST_BLOCK_POINTER;

// vHost statistics clear Answer Command
typedef struct  _vhost_statistic_clear_answeer_block {
  COMMAND_PACKET_HEADER header;
  u_int result;                                 // 0: Complete
  // 1: incomplete
} VHOST_STATISTICS_CLEAR_ANSWER_BLOCK, *VHOST_STATISTICS_CLEAR_ANSWER_BLOCK_POINTER;

// send request parameters
typedef struct  _vhost_send_requset_data {
  u_int response_type;                                          // 0: Completion response
                                                                // 1: Instant response
  u_short layer_2_type;                                         // 0: DIX
                                                                // 1: 802.1Q
  u_short vlan_type;                                            // 0: disable vlan id
                                                                // 1: enable vlan id
  u_short vlan_information;                                     // VLAN ID + TCI + CoS
  u_char source_mac_address[ MAC_ADDRESS_LENGTH ];              // Source MAC Address
  u_char destination_mac_address[ MAC_ADDRESS_LENGTH ];         // Destination MAC Address
  u_short mac_type;                                             // MAC Address Type
  u_int source_mac_counut;                                      // Source MAC counter
  u_int destination_mac_counut;                                 // Destination MAC counter
  u_char source_mac_mask[ MAC_ADDRESS_LENGTH ];                 // Source MAC mask / limit
  u_char destination_mac_mask[ MAC_ADDRESS_LENGTH ];            // Destination MAC mask / limit
  u_short ether_type;                                           // ethernet type
  u_short layer_3_type;                                         // layer 3 type
  u_short hardware_type;                                        // hardware type
  u_short protocol_type;                                        // protocol type
  u_short operation_code;                                       // operation code
  u_char arp_source_mac_address[ MAC_ADDRESS_LENGTH ];          // Source MAC mask / counter
  u_char arp_destination_mac_address[ MAC_ADDRESS_LENGTH ];     // Destination MAC mask / counter
  u_short arp_mac_type;                                         // ARP MAC Address Type
  u_int arp_source_mac_count;                                   // Source MAC counter
  u_int arp_destination_mac_count;                              // Destination MAC counter
  u_char arp_source_mac_mask[ MAC_ADDRESS_LENGTH ];             // Source MAC mask / limit
  u_char arp_destination_mac_mask[ MAC_ADDRESS_LENGTH ];        // Destination MAC mask / limit
  u_int source_ip_address;                                      // Source IP address
  u_int destination_ip_address;                                 // Destination IP address
  u_short ip_type;                                              // IP type
  u_short layer_2_pad;                                          // R.F.U
  u_int source_ip_address_add_count;                            // Source IP address add count
  u_int destination_ip_address_add_count;                       // Destination IP address add count
  u_int source_ip_address_mask;                                 // Source IP address Mask/limit
  u_int destination_ip_address_mask;                            // Destination IP address Mask/limit
  u_char tos;                                                   // ToS
  u_char flags;                                                 // IP flags
  u_short id;                                                   // IP ID
  u_short flagment_offset;                                      // Flagment Offset
  u_char ttl;                                                   // TTL
  u_char protocol_number;                                       // IP protocol number
  u_short option_length;                                        // IP option length
  u_char option[ MAX_OPTION_LENGTH ];                           // option
  u_short source_port_number;                                   // UDP source port number
  u_short destination_port_number;                              // UDP destination port number
  u_short udp_type;                                             // UDP type
  u_short layer_4_pad;                                          // R.F.U
  u_short source_port_number_add_count;                         // UDP source port add counter
  u_short destination_port_number_add_count;                    // UDP destination port add counter
  u_short source_port_number_mask;                              // UDP source port mask / limit
  u_short destination_port_number_mask;                         // UDP destination port mask / limit
  u_int duration;                                               // duration
  u_int packet_par_second;                                      // PPS
  u_int packet_num;                                             // num of packet
  u_int packet_length;                                          // packet length
  u_int payload_pattern;                                        // payload pattern
  u_int payload_count;                                          // payload count( for increment/decrement )
  u_int payload_limit;                                          // payload count limit( for increment/decrement )
  u_int payload_length;                                         // payload length
  u_int payload_mask_length;                                    // payload mask length
} VHOST_SEND_REQUEST_DATA, *VHOST_SEND_REQUEST_DATA_POINTER;

// vHost send request

typedef struct  _vhost_send_request_block {
  COMMAND_PACKET_HEADER header;
  VHOST_SEND_REQUEST_DATA send_request_data;
} VHOST_SEND_REQUEST_BLOCK, *VHOST_SEND_REQUEST_BLOCK_POINTER;


// send request answer
typedef struct  _vhost_send_answer_block {
  COMMAND_PACKET_HEADER header;
  u_int send_number;                        // request number
  u_int result;                             // 0: Complete
                                            // 1: incomplete
} VHOST_SEND_ANSWER_BLOCK, *VHOST_SEND_ANSWER_BLOCK_POINTER;

// statistics request
typedef struct  _vhost_statistics_request_block {
  COMMAND_PACKET_HEADER header;
} VHOST_STATISTICS_REQUEST_BLOCK, *VHOST_STATISTICS_REQUEST_BLOCK_POINTER;

// statistics answer
typedef struct  _vhost_statistics_answer_block {
  COMMAND_PACKET_HEADER header;
  u_int statistics_all_number;
  u_int statistics_position;
} VHOST_STATISTICS_ANSWER_BLOCK, *VHOST_STATISTICS_ANSWER_BLOCK_POINTER;

typedef struct  _vhost_statistics_data {
  u_int data_length;                        // data length
  u_int packet_length;                      // packet length
  u_int ip_header_offset;                   // IP header offset
  u_int udp_header_offset;                  // UDP header offset
  u_int payload_hash;                       // payload hash(CRC16)
  u_int packet_type;                        // 0: send
                                            // 1: receive
  unsigned long long packet_data_byte;      // communication all data byte
  unsigned long long packet_number;         // communication all packet number
} VHOST_STATISTICS_DATA, *VHOST_STATISTICS_DATA_POINTER;

// vHost send cancel request Command
typedef struct  _vhost_send_cancel_request_block {
  COMMAND_PACKET_HEADER header;
  u_int cancel_number;
} VHOST_SEND_CANCEL_REQUEST_BLOCK, *VHOST_SEND_CANCEL_REQUEST_BLOCK_POINTER;

// vHost send cancel Answer Command

typedef struct  _vhost_send_cancel_answeer_block {
  COMMAND_PACKET_HEADER header;
  u_int result;                             // 0: Complete
                                            // 1: incomplete
} VHOST_SEND_CANCEL_ANSWER_BLOCK, *VHOST_SEND_CANCEL_ANSWER_BLOCK_POINTER;

// vHost send NG information Command

typedef struct  _vhost_send_ng_information_block {
  COMMAND_PACKET_HEADER header;
  u_int ipv4_address;                               // IPv4 Address
} VHOST_SEND_NG_INFORMATION_BLOCK, *VHOST_SEND_NG_INFORMATION_BLOCK_POINTER;

// vHost send response

typedef struct  _vhost_send_end_response {
  COMMAND_PACKET_HEADER header;
  u_int send_number;
} VHOST_SEND_END_RESPONSE_BLOCK, *VHOST_SEND_END_RESPONSE_BLOCK_POINTER;

#endif  // _VHOST_PACKET_HEADER_H

/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
