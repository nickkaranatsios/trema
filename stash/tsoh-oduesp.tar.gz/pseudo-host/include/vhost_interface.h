/*
 * vhost interface .
 *
 * Author: Tomoaki Ishikawa
 */

#ifndef _VHOST_INTERFACE_H
#define _VHOST_INTERFACE_H

/******************************************************************************
 * define & macros                                                            *
 ******************************************************************************/
#define     CLI_INTERFACE_PORT      15002
#define     MANAGER_INTERFACE_PORT  15003

#endif      // _VHOST_INTERFACE_H

/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
