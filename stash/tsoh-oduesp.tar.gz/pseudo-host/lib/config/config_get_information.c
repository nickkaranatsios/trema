#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

#include "cmn.h"
#include "packet.h"
#include "configif.h"
#include "com_socket.h"

config_vhost_information_t *
config_get_vhost_information( char *vhost_name ) {
  config_cmd_interface_t interface;
  char path[ 108 ] = "";
  int socket_fd;
  int result;
  config_vhost_information_t *vhost_configuration = NULL;
  config_vhost_information_t recv_vhost_information;

  memset( &recv_vhost_information, 0x00, sizeof( recv_vhost_information ) );

  sprintf( path, "%s%s", TMP_DIR, CONNECT_PATH );
  socket_fd = com_socket_unix_connect( path );
  if ( socket_fd < 0 ) {
    printf( "%s\n", strerror( errno ) );
    return NULL;
  }

  // set parameter
  interface.head.command    = CONFIG_GET_CONFIGURATION_VHOST_INDIVIDUAL;
  strcpy( interface.head.vhost_name, vhost_name );

  if ( 0 > ( result = com_socket_send( socket_fd, ( u_char * ) &interface, sizeof( interface ) ) ) ) {
    printf( "%s\n", strerror( errno ) );
    com_socket_close( socket_fd );
    return NULL;
  }

  result = com_socket_receive( socket_fd, ( u_char * ) &interface, sizeof( interface ) );
  if ( result < 0 ) {
    printf( "%s\n", strerror( errno ) );
    com_socket_close( socket_fd );
    return NULL;
  }

  if ( interface.command.admin_interface.command.vhost.num != 0x00 ) {
    vhost_configuration = calloc( sizeof( config_vhost_information_t ), sizeof( char ) );
    if ( vhost_configuration == NULL ) {
      com_socket_close( socket_fd );
      return NULL;
    }

    result = com_socket_receive( socket_fd, ( u_char * ) vhost_configuration, sizeof( config_vhost_information_t ) );
    if ( result < 0 ) {
      printf( "%s\n", strerror( errno ) );

      com_socket_close( socket_fd );
      free( vhost_configuration );

      return NULL;
    }
  }
  com_socket_close( socket_fd );

  return vhost_configuration;
}


config_vhost_information_t *
config_get_all_vhost_information( u_int *vhost_num ) {
  config_cmd_interface_t interface;
  char path[ 108 ] = "";
  int socket_fd;
  int result;
  u_int count;
  config_vhost_information_t *vhost_configuration;

  sprintf( path, "%s%s", TMP_DIR, CONNECT_PATH );
  socket_fd = com_socket_unix_connect( path );
  if ( socket_fd < 0 ) {
    printf( "%s\n", strerror( errno ) );
    return NULL;
  }

  // set parameter
  interface.head.command    = CONFIG_GET_CONFIGURATION_VHOST;

  if ( 0 > ( result = com_socket_send( socket_fd, ( u_char * ) &interface, sizeof( interface ) ) ) ) {
    printf( "%s\n", strerror( errno ) );
    com_socket_close( socket_fd );
    return NULL;
  }

  result = com_socket_receive( socket_fd, ( u_char * ) &interface, sizeof( interface ) );
  if ( result < 0 ) {
    printf( "%s\n", strerror( errno ) );
    com_socket_close( socket_fd );
    return NULL;
  }

  vhost_configuration = calloc( ( long unsigned int ) interface.command.admin_interface.command.vhost.num * sizeof( config_vhost_information_t ), sizeof( char ) );
  if ( vhost_configuration == NULL ) {
    com_socket_close( socket_fd );
    return NULL;
  }

  for ( count = 0; count < interface.command.admin_interface.command.vhost.num; count++ ) {
    result = com_socket_receive( socket_fd, ( u_char * ) &vhost_configuration[ count ], sizeof( config_vhost_information_t ) );
    if ( result < 0 ) {
      printf( "%s\n", strerror( errno ) );

      com_socket_close( socket_fd );
      free( vhost_configuration );

      return NULL;
    }
  }
  com_socket_close( socket_fd );

  *vhost_num          = interface.command.admin_interface.command.vhost.num;

  return vhost_configuration;
}


config_controller_detail_t *
config_get_controller_information( u_int *controller_num ) {
  config_cmd_interface_t interface;
  char path[ 108 ] = "";
  int socket_fd;
  int result;
  u_int count;
  config_controller_detail_t *controller_configuration;

  sprintf( path, "%s%s", TMP_DIR, CONNECT_PATH );
  socket_fd = com_socket_unix_connect( path );
  if ( socket_fd < 0 ) {
    printf( "%s\n", strerror( errno ) );
    return NULL;
  }

  // set parameter
  interface.head.command    = CONFIG_GET_CONFIGURATION_CONTROLLER;

  if ( 0 > ( result = com_socket_send( socket_fd, ( u_char * ) &interface, sizeof( interface ) ) ) ) {
    printf( "%s\n", strerror( errno ) );
    com_socket_close( socket_fd );
    return NULL;
  }

  result = com_socket_receive( socket_fd, ( u_char * ) &interface, sizeof( interface ) );
  if ( result < 0 ) {
    printf( "%s\n", strerror( errno ) );
    com_socket_close( socket_fd );
    return NULL;
  }

  controller_configuration = calloc( ( long unsigned int ) interface.command.admin_interface.command.controller.num * sizeof( config_controller_detail_t ),
    sizeof( char ) );
  if ( controller_configuration == NULL ) {
    com_socket_close( socket_fd );
    return NULL;
  }

  for ( count = 0; count < interface.command.admin_interface.command.controller.num; count++ ) {
    result = com_socket_receive( socket_fd, ( u_char * ) &controller_configuration[ count ], sizeof( config_controller_detail_t ) );
    if ( result < 0 ) {
      printf( "%s\n", strerror( errno ) );

      com_socket_close( socket_fd );
      free( controller_configuration );

      return NULL;
    }
  }
  com_socket_close( socket_fd );

  *controller_num         = interface.command.admin_interface.command.controller.num;

  return controller_configuration;
}


config_static_arp_t *
config_get_static_arp_information( char *vhost_name, u_int *static_arp_num ) {
  config_cmd_interface_t interface;
  char path[ 108 ] = "";
  int socket_fd;
  int result;
  u_int count;
  config_static_arp_t *static_arp_configuration;

  sprintf( path, "%s%s", TMP_DIR, CONNECT_PATH );
  socket_fd = com_socket_unix_connect( path );
  if ( socket_fd < 0 ) {
    printf( "%s\n", strerror( errno ) );
    return NULL;
  }

  // set parameter
  interface.head.command    = CONFIG_GET_CONFIGURATION_STATIC_ARP;
  strcpy( interface.head.vhost_name, vhost_name );

  if ( 0 > ( result = com_socket_send( socket_fd, ( u_char * ) &interface, sizeof( interface ) ) ) ) {
    printf( "%s\n", strerror( errno ) );
    com_socket_close( socket_fd );
    return NULL;
  }

  result = com_socket_receive( socket_fd, ( u_char * ) &interface, sizeof( interface ) );
  if ( result < 0 ) {
    printf( "%s\n", strerror( errno ) );
    com_socket_close( socket_fd );
    return NULL;
  }

  static_arp_configuration = calloc( ( long unsigned int ) interface.command.admin_interface.command.static_arp.num * sizeof( config_static_arp_t ), sizeof( char ) );
  if ( static_arp_configuration == NULL ) {
    com_socket_close( socket_fd );
    return NULL;
  }

  for ( count = 0; count < interface.command.admin_interface.command.static_arp.num; count++ ) {
    result = com_socket_receive( socket_fd, ( u_char * ) &static_arp_configuration[ count ], sizeof( config_static_arp_t ) );
    if ( result < 0 ) {
      printf( "%s\n", strerror( errno ) );

      com_socket_close( socket_fd );
      free( static_arp_configuration );

      return NULL;
    }
  }
  com_socket_close( socket_fd );

  *static_arp_num = interface.command.admin_interface.command.static_arp.num;

  return static_arp_configuration;
}


ECONFIG_RESULT
config_get_vhost_ipaddress( char *vhostname, char *ip_address ) {
  config_cmd_interface_t interface;
  char path[ 108 ] = "";
  int socket_fd;
  int result;

  sprintf( path, "%s%s", TMP_DIR, CONNECT_PATH );
  socket_fd = com_socket_unix_connect( path );
  if ( socket_fd < 0 ) {
    printf( "%s\n", strerror( errno ) );
    return CONFIG_NG;
  }

  interface.head.command = CONFIG_GET_VHOST_IPADDRESS;
  strcpy( interface.head.vhost_name, vhostname );

  if ( 0 > ( result = com_socket_send( socket_fd, ( u_char * ) &interface, sizeof( interface ) ) ) ) {
    printf( "%s\n", strerror( errno ) );
    com_socket_close( socket_fd );
    return CONFIG_NG;
  }

  result = com_socket_receive( socket_fd, ( u_char * ) &interface, sizeof( interface ) );
  if ( result < 0 ) {
    printf( "%s\n", strerror( errno ) );
    return CONFIG_NG;
  }
  if ( interface.head.result != CONFIG_OK ) {
    com_socket_close( socket_fd );
    return CONFIG_NG;
  }

  strcpy( ip_address, interface.command.admin_interface.command.vhost_ipaddress.ip_address );

  com_socket_close( socket_fd );

  return CONFIG_OK;
}
