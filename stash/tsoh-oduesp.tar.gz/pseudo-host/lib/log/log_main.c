#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <fcntl.h>
#include <sys/param.h>
#include <sys/sysctl.h>
#include <sys/time.h>
#include <string.h>
#include <sys/file.h>

#include "cmn.h"
#include "com_socket.h"
#include "loglib.h"

u_int   loglib_gen    = LOGLIB_LOG_GEN;
int     loglib_size   = LOGLIB_LOG_SIZE;
int     loglib_init   = 0;
int     loglib_lock_data[ LOGLIB_KEYMAX ];

void
loglib_lock( int key ) {
  char key_str[ LOGLIB_TMPSIZE ];
  int ret;

  bzero( key_str, sizeof( key_str ) );
  if ( LOGLIB_KEY1 == key ) {
    bcopy( LOGLIB_FLOCKKEY, key_str, strlen( LOGLIB_FLOCKKEY ) );
  }

  loglib_lock_data[ key ] = open( ( char * )&key_str[ 0 ], O_RDWR | O_CREAT, 0644 );
  if ( loglib_lock_data[ key ] < 0 ) {
    return;
  }

  ret = flock( loglib_lock_data[ key ], LOCK_SH );
  if ( 0 > ret ) {
    close( loglib_lock_data[ key ] );
    return;
  }

  return;
}


void
loglib_unlock( int key ) {
  char key_str[ LOGLIB_TMPSIZE ];
  int ret;

  bzero( key_str, sizeof( key_str ) );
  if ( LOGLIB_KEY1 == key ) {
    bcopy( LOGLIB_FLOCKKEY, key_str, strlen( LOGLIB_FLOCKKEY ) );
  }

  ret = flock( loglib_lock_data[ key ], LOCK_UN );
  if ( 0 > ret ) {
    close( loglib_lock_data[ key ] );
    loglib_lock_data[ key ] = 0;
    return;
  }

  close( loglib_lock_data[ key ] );

  loglib_lock_data[ key ] = 0;

  return;
}


void
loglib_sigclose() {
  int i;

  for ( i = 0; i < LOGLIB_KEYMAX; i++ ) {
    if ( loglib_lock_data[ i ] != 0 ) {
      MLOGLIB_UNLOCK( loglib_lock_data[ i ] );
      close( loglib_lock_data[ i ] );
    }
  }
  return;
}


void
loglib_local_init() {
  int i;

  loglib_init = 1;

  for ( i = 0; i < LOGLIB_KEYMAX; i++ ) {
    loglib_lock_data[ i ] = 0;
  }

  return;
}


void
loglib_genchk( char *logname ) {
  DIR *dir;
  struct dirent *dp;
  struct stat file_status;
  struct stat oldfile_status;
  static char filename[ LOGLIB_TMPSIZE ];
  static char oldfilename[ LOGLIB_TMPSIZE ];
  u_int cnt = 0, i;

  bzero( filename, sizeof( filename ) );
  strcpy( filename, logname );
  memset( &oldfile_status, 0x00, sizeof( oldfile_status ) ) ;

  if ( logname == NULL ) {
    return;
  }

  if ( stat( logname, &file_status ) == 0 ) {
    if ( loglib_size > file_status.st_size ) {
      return;
    }

    if ( ( dir = opendir( TMP_DIR ) ) != NULL ) {
      for ( dp = readdir( dir ); dp != NULL; dp = readdir( dir ) ) {
        bzero( filename, sizeof( filename ) );
        snprintf( filename, sizeof( filename ), "%s%s%s", TMP_DIR, "/", dp->d_name );
        if ( strncmp( logname, filename, strlen( TMP_DIR ) + 7 ) == 0 ) {
          cnt++;
        }
      }
      closedir( dir );
    }

    if ( cnt < loglib_gen ) {
      bzero( filename, sizeof( filename ) );
      snprintf( filename, sizeof( filename ), "%s%s", TMP_DIR, LOGLIB_LOG_FILENAME );
      if ( strncmp( logname, filename, strlen( filename ) ) == 0 ) {
        snprintf( filename, sizeof( filename ), "%s%s%d.log", TMP_DIR, LOGLIB_LOG_FILENAME, cnt - 1 );
      }
      else {
        snprintf( filename, sizeof( filename ), "%s%s%d.log", TMP_DIR, LOGLIB_ERRLOG_FILENAME, cnt - 1 );
      }
      rename( logname, filename );
    }
    else {
      bzero( filename, sizeof( filename ) );
      bzero( oldfilename, sizeof( oldfilename ) );

      if ( stat( logname, &file_status ) != -1 ) {
        bcopy( &file_status, &oldfile_status, sizeof( oldfile_status ) );
        strncpy( oldfilename, logname, strlen( logname ) );
      }

      for ( i = 1; i < cnt; i++ ) {
        bzero( &file_status, sizeof( file_status ) );
        bzero( filename, sizeof( filename ) );

        snprintf( filename, sizeof( filename ), "%s%s", TMP_DIR,LOGLIB_LOG_FILENAME );
        if ( strncmp( logname, filename, strlen( filename ) ) == 0 ) {
          snprintf( filename, sizeof( filename ), "%s%s%d.log", TMP_DIR, LOGLIB_LOG_FILENAME, i );
        }
        else {
          snprintf( filename, sizeof( filename ), "%s%s%d.log", TMP_DIR, LOGLIB_ERRLOG_FILENAME, i );
        }

        if ( stat( filename, &file_status ) != -1 ) {
          if ( oldfile_status.st_ctime > file_status.st_ctime ) {
            bcopy( &file_status, &oldfile_status, sizeof( oldfile_status ) );

            bzero( oldfilename, sizeof( oldfilename ) );
            strncpy( oldfilename, filename, strlen( filename ) );
          }
        }
      }

      unlink( oldfilename );
      rename( logname, oldfilename );
    }
  }
  return;
}


void
loglib_printf( const char *file, const int line, int kind, const char *message ) {
  FILE *fp;
  struct tm *UTCtime;
  static char buf[ LOGLIB_TMPSIZE ];
  static char filename_dbglog[ LOGLIB_TMPSIZE ];
  static char filename_errlog[ LOGLIB_TMPSIZE ];
  const char wday[ 7 ][ 4 ] = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
  char data[ LOGLIB_TMPSIZE ];
  struct timeval tp;
  struct timezone tzp;
  char logon[ LOGLIB_TMPSIZE ];
  struct stat status;
  int tmperrno;

  tmperrno = errno;

  ( void ) gettimeofday( &tp, &tzp );
  UTCtime = localtime( &tp.tv_sec );

  bzero( filename_dbglog, sizeof( filename_dbglog ) );
  bzero( filename_errlog, sizeof( filename_errlog ) );
  bzero( buf, sizeof( buf ) );
  bzero( data, sizeof( data ) );
  bzero( logon, sizeof( logon ) );

  if ( loglib_init == 0 ) {
    loglib_local_init();
  }

  snprintf( filename_dbglog, sizeof( filename_dbglog ), "%s%s%s", TMP_DIR, LOGLIB_LOG_FILENAME, ".log" );

  if ( kind == LOGLIB_ERR_PRINT ) {
    snprintf( filename_errlog, sizeof( filename_errlog ), "%s%s%s", TMP_DIR, LOGLIB_ERRLOG_FILENAME, ".log" );
    strcpy( data, "[ERROR]" );
  }

  snprintf( buf, sizeof( buf ), "%04d/%02d/%02d(%3s) %02d:%02d:%02d.%03ld %s:%d %s",
            UTCtime->tm_year + 1900, UTCtime->tm_mon + 1,
            UTCtime->tm_mday, wday[ UTCtime->tm_wday ], UTCtime->tm_hour,
            UTCtime->tm_min, UTCtime->tm_sec, tp.tv_usec / 1000,
            file, line, data );

  loglib_genchk( filename_dbglog );
  loglib_genchk( filename_errlog );

  MLOGLIB_LOCK( LOGLIB_KEY1 );

  if ( stat( logon, &status ) != -1 ) {
    fp = fopen( filename_dbglog, "a" );
    if ( fp == NULL ) {
      errno = tmperrno;
      MLOGLIB_UNLOCK( LOGLIB_KEY1 );
      return;
    }

    if ( strncmp( "\n", &message[ strlen( message ) - 1 ], 1 ) == 0 ) {
      fprintf( fp, "%s %s", buf, message );
    }
    else {
      fprintf( fp, "%s %s\n", buf, message );
    }
    fclose( fp );
    fp = NULL;
    chmod( filename_dbglog, S_IWUSR | S_IWGRP | S_IWOTH | S_IRUSR | S_IRGRP | S_IROTH );
  }
  if ( kind == LOGLIB_ERR_PRINT ) {
    fp = fopen( filename_errlog, "a" );
    if ( fp == NULL ) {
      errno = tmperrno;
      MLOGLIB_UNLOCK( LOGLIB_KEY1 );
      return;
   }
   if ( strncmp( "\n", &message[ strlen( message ) - 1 ], 1 ) == 0 ) {
    fprintf( fp, "%s %s", buf, message );
    }
    else {
      fprintf( fp, "%s %s\n", buf, message );
    }
    fclose( fp );
    chmod( filename_errlog, S_IWUSR | S_IWGRP | S_IWOTH | S_IRUSR | S_IRGRP | S_IROTH );
  }

  MLOGLIB_UNLOCK( LOGLIB_KEY1 );

  errno = tmperrno;
  return;
}

