#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>

#include <sys/socket.h>
#include <bits/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <memory.h>
#include "cmn.h"
#include "com_socket.h"

#define SOCKET_MAX_CONNECT      20
#define SOCKET_KEEPALIVE        1
#define SOCKET_KEEPIDLE         5
#define SOCKET_KEEPINTVL        5
#define SOCKET_KEEPCNT          3

// Connect
int
com_socket_connect( u_int ipv4_address, int port_number ) {
  int socket_fd;
  int rc;
  struct sockaddr_in server_address;
  int result;
  int flag;

  memset( &server_address, '\0', sizeof( server_address ) );
  server_address.sin_family = AF_INET;
  server_address.sin_port = Mhtons( ( uint16_t ) port_number );
  server_address.sin_addr.s_addr = htonl( ipv4_address );

  while ( 1 ) {
    errno = 0;
    socket_fd = socket( AF_INET, SOCK_STREAM, 0 );
    if ( socket_fd < 0 ) {
      continue;
    }

    flag = fcntl( socket_fd, F_GETFL, 0 );
    fcntl( socket_fd, F_SETFL, flag | O_NONBLOCK );

    rc = 1;
    result = setsockopt( socket_fd, SOL_SOCKET, SO_REUSEADDR, ( char * ) &rc, sizeof( int ) );
    if ( result != 0 ) {
      close( socket_fd );
      return -1;
    }
    rc = SOCKET_KEEPALIVE;
    result = setsockopt( socket_fd, SOL_SOCKET, SO_KEEPALIVE, ( char * ) &rc, sizeof( rc ) );
    if ( result != 0 ) {
      close( socket_fd );
      return -1;
    }
    rc = SOCKET_KEEPIDLE;
    result = setsockopt( socket_fd, IPPROTO_TCP, TCP_KEEPIDLE, ( char * ) &rc, sizeof( rc ) );
    if ( result != 0 ) {
      close( socket_fd );
      return -1;
    }
    rc = SOCKET_KEEPINTVL;
    result = setsockopt( socket_fd, IPPROTO_TCP, TCP_KEEPINTVL, ( char * ) &rc, sizeof( rc ) );
    if ( result != 0 ) {
      close( socket_fd );
      return -1;
    }
    rc = SOCKET_KEEPCNT;
    result = setsockopt( socket_fd, IPPROTO_TCP, TCP_KEEPCNT, ( char * ) &rc, sizeof( rc ) );
    if ( result != 0 ) {
      close( socket_fd );
      return -1;
    }
    result = connect( socket_fd, ( struct sockaddr * ) &server_address, sizeof( struct sockaddr_in ) );
    if ( result < 0 ) {
      if ( ( errno == EADDRINUSE ) || ( errno == EINTR ) ) {
        close( socket_fd );
        continue;
      }
      else if ( errno == EINPROGRESS ) {
        // non-blocking mode
        break;
      }
      close( socket_fd );
      return -1;
    }
    else if ( result == 0 ) {
      fcntl( socket_fd, F_SETFL, flag );
    }
    break;
  }
  return socket_fd;
}


// Send Data
int
com_socket_send( int socket_id, u_char *send_data, size_t send_size ) {
  size_t send_request_size = send_size;
  ssize_t send_total_size = 0;
  ssize_t rc = 0;
  u_char *next_send_pointer = send_data;

  while ( 1 ) {
    errno = 0;
    rc = send( socket_id, next_send_pointer, send_request_size, 0 );

    // send incomplete ?
    if ( rc <= 0 ) {
      if ( ( errno == EWOULDBLOCK ) || ( errno == EINTR ) ) {
        continue;
      }
      return -1;
    }

    send_total_size += rc;

    // all data send complete ?
    if ( send_total_size == ( ssize_t ) send_size ) {
      break;
    }

    next_send_pointer += rc;
    send_request_size = send_size - ( size_t ) send_total_size;
  }
  return TRUE;
}


int
com_socket_receive( int socket_fd, u_char *receive_buffer, size_t receive_size ) {
  size_t receive_request_size = receive_size;
  size_t receive_total_size = 0;
  ssize_t rc = 0;
  u_char *next_receive_pointer = receive_buffer;
  fd_set select_fd_set;

  while ( 1 ) {
    FD_ZERO( &select_fd_set );
    FD_SET( socket_fd, &select_fd_set );
    pselect( ( socket_fd + 1 ), &select_fd_set, NULL, NULL, NULL, NULL );

    errno = 0;
    rc = recv( socket_fd, next_receive_pointer, receive_request_size, 0 );

    // receive incomplete ?
    if ( rc <= 0 ) {
      if ( ( errno == EWOULDBLOCK ) || ( errno == EINTR ) ) {
        continue;
      }
      return -1;
    }

    receive_total_size += ( size_t ) rc;

    // all data receive complete ?
    if ( receive_total_size == receive_size ) {
      break;
    }
    next_receive_pointer = next_receive_pointer + rc;
    receive_request_size -= ( size_t ) rc;
  }
  return TRUE;
}


int
com_socket_data_copy( int socket_fd, u_char *receive_buffer, size_t receive_size ) {
  ssize_t rc = 0;
  fd_set select_fd_set;

  FD_ZERO( &select_fd_set );
  FD_SET( socket_fd, &select_fd_set );
  pselect( ( socket_fd + 1 ), &select_fd_set, NULL, NULL, NULL, NULL );
  while ( 1 ) {
    errno = 0;
    rc = recv( socket_fd, receive_buffer, receive_size, MSG_PEEK );

    // receive incomplete ?
    if ( rc <= 0 ) {
      if ( ( errno == EWOULDBLOCK ) || ( errno == EINTR ) ) {
        continue;
      }
      return -1;
    }
    if ( rc == ( ssize_t ) receive_size ) {
      break;
    }
  }
  return TRUE;
}


int
com_socket_close( int socket_fd ) {
  shutdown( socket_fd, SHUT_RDWR );
  close( socket_fd );
  return TRUE;
}


int
com_socket_accept_port_create( int port_number ) {
  int socket_fd;
  int rc;
  struct sockaddr_in server_address;

  memset( &server_address, '\0', sizeof( server_address ) );
  server_address.sin_family = AF_INET;
  server_address.sin_port = Mhtons( ( uint16_t ) port_number );
  server_address.sin_addr.s_addr = htonl( INADDR_ANY );

  while ( 1 ) {
    socket_fd = socket( AF_INET, SOCK_STREAM, 0 );
    if ( socket_fd < 0 ) {
      continue;
    }
    rc = 1;
    setsockopt( socket_fd, SOL_SOCKET, SO_REUSEADDR, ( char * ) &rc, sizeof( int ) );

    if ( bind( socket_fd, ( struct sockaddr * ) &server_address, sizeof( struct sockaddr_in ) ) < 0 ) {
      close( socket_fd );
      if ( errno == EADDRINUSE ) {
        continue;
      }
      return -1;
    }
    break;
  }

  if ( listen( socket_fd, SOCKET_MAX_CONNECT ) < 0 ) {
    close( socket_fd );
    return -1;
  }

  return socket_fd;
}
