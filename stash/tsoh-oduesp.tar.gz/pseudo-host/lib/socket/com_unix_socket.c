#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

#include <sys/socket.h>
#include <bits/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <memory.h>

#define SOCKET_MAX_CONNECT      20

int
com_socket_unix_connect( char *path ) {

    int socket_fd ;
    int rc ;
    struct sockaddr_un server_address;

    memset( &server_address, '\0', sizeof( server_address ) );
    server_address.sun_family = AF_UNIX ;
    strncpy( server_address.sun_path, path, strlen( path ) ) ;

    while( 1 ){
        errno = 0 ;
        socket_fd = socket( AF_UNIX, SOCK_STREAM, 0 );
        if(socket_fd < 0){
            continue ;
        }
        rc = 1 ;
        setsockopt( socket_fd, SOL_SOCKET, SO_REUSEADDR, ( char * )&rc, sizeof( int ) );
        if (connect( socket_fd, ( struct sockaddr * )&server_address, sizeof( struct sockaddr_un ) ) < 0 ){
            close( socket_fd );
            if (( errno == EADDRINUSE ) || ( errno == EINTR ) ){
                continue ;
            }
            return -1 ;
        }
        break ;
    }
    return socket_fd ;

}


int
com_socket_unix_accept_port_create( char *path ) {

    int socket_fd ;
    int rc ;
    struct sockaddr_un server_address ;

    memset( &server_address, '\0', sizeof( server_address ) );
    server_address.sun_family = AF_UNIX;
    strncpy( server_address.sun_path, path, strlen( path ) ) ;

    while( 1 ){
        socket_fd = socket( AF_UNIX, SOCK_STREAM, 0 );
        if ( socket_fd < 0 ){
            continue ;
        }
        rc = 1 ;
        setsockopt( socket_fd, SOL_SOCKET, SO_REUSEADDR, ( char * )&rc, sizeof( int ) );

        if ( bind( socket_fd, ( struct sockaddr * )&server_address, sizeof( struct sockaddr_un ) ) < 0 ){
            close( socket_fd );
            if (errno == EADDRINUSE ){
                continue ;
            }
            return -1 ;
        }
        break ;
    }

    if ( listen( socket_fd, SOCKET_MAX_CONNECT ) < 0 ) {
        close( socket_fd );
        return -1 ;
    }

    return socket_fd;
}


