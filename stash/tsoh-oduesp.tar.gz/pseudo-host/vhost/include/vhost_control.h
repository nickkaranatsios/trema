/*
 * vhost packet interface .
 *
 * Author: Tomoaki Ishikawa
 */

#ifndef _VHOST_CONTROL_H
#define _VHOST_CONTROL_H

/******************************************************************************
 * define & macros                                                            *
 ******************************************************************************/
#ifdef  LOW_MEMORY
#define     MAX_RECEIVE_BUFFER_SIZE     ( 2 * 1024 )
#define     MAX_THREADS                 10
#define     MAX_RECEIVE_POOL_SIZE       100000              // max pool buffer num
#else
#define     MAX_RECEIVE_BUFFER_SIZE     ( 9 * 1024 )
#define     MAX_THREADS                 1000
#define     MAX_RECEIVE_POOL_SIZE       700000              // max pool buffer num
#endif
#define     DESTINATION_INFORMATION_POSITION    3
#define     ARP_REQUEST_AGEOUT_TIME     2
#define     TX_QUEUE_LENGTH             100000

#define     CHAR_MAX                    255         // maxthread / 32bit
#define     STATELEN                    256
#define     VHOST_NAME_MAX              ( MAX_VHOST_NAME_LENGTH + 4 )
#define     VHOST_DEVICE_NAME_MAX       ( INTERFACE_NAME_LENGTH + 4 )
#define     ARP_HASH_MAX                0x10000
#define     STATISTICS_CONTROL_MAX      0x10000
#define     VHOST_DEVICE_MAX            4           // eth0...3
#define     SELECT_FD_MAX               1024
#define     ETHERNET_MULTICAST_BIT      0x01

#define     STATIC_ARP_ENTRY            VHOST_ARP_INFORMATION_STATIC_ARP_ENTRY
#define     TEMPORARY_REGISTRATION_ARP_ENTRY            0x4000
#define     SEND_REQUEST_ACCEPT_MAX     4
#define     NANO_SECOND                 1000000000
#define     PAYLOAD_USER_DESIGNATION    0x08
#define     VLAN_MASK                   0xFFF
#define     VHOST_WATCH_TIME            10
#define     VHOST_STATISTICS_WATCH_TIME 5000

#ifdef  DEBUG

#define     DBGPRINT( ... )   printf( __VA_ARGS__ )

#else

#define     DBGPRINT( ... )

#endif
#define nanotimeradd( a, b, result )                       \
  do {                                                     \
    ( result )->tv_sec = ( a )->tv_sec + ( b )->tv_sec;    \
    ( result )->tv_nsec = ( a )->tv_nsec + ( b )->tv_nsec; \
    if ( ( result )->tv_nsec > NANO_SECOND ) {             \
      ++( result )->tv_sec;                                \
      ( result )->tv_nsec -= NANO_SECOND;                  \
    }                                                      \
  }                                                        \
  while ( 0 )
#define nanotimersub( a, b, result )                       \
  do {                                                     \
    ( result )->tv_sec = ( a )->tv_sec - ( b )->tv_sec;    \
    ( result )->tv_nsec = ( a )->tv_nsec - ( b )->tv_nsec; \
    if ( ( result )->tv_nsec < 0 ) {                       \
      --( result )->tv_sec;                                \
      ( result )->tv_nsec += NANO_SECOND;                  \
    }                                                      \
  }                                                        \
  while ( 0 )

/******************************************************************************
 * structure                                                                  *
 ******************************************************************************/
typedef union _mac_convert {
  unsigned long long ll_mac_address;
  u_char mac_address[ MAC_ADDRESS_LENGTH + 2 ];
} UMAC_CONVERT;

typedef struct _mac_info {
  u_char mac_address[ MAC_ADDRESS_LENGTH ];                 // mac address
  u_char mask[ MAC_ADDRESS_LENGTH ];                        // random mask
  uint64_t current_no;                                      // current counter(increment/decrement)
  uint64_t add_count;                                       // random mask
} SMAC_CONTROL, *SMAC_CONTROL_POINTER;

typedef struct _ip_address_control {
  u_int ipv4_address;
  u_int ipv4_mask;
  u_int current_no;
  u_int add_count;
} IP_ADDRESS_CONTROL, *IP_ADDRESS_CONTROL_POINTER;

typedef struct _udp_port_control {
  uint32_t port_number;
  uint32_t port_number_mask;
  uint32_t current_no;
  uint32_t add_count;
} UDP_PORT_CONTROL, *UDP_PORT_CONTROL_POINTER;


typedef struct _vhost_send_ng_information_control VHOST_SEND_NG_INFORMATION_CONTROL, *VHOST_SEND_NG_INFORMATION_CONTROL_POINTER;

struct _vhost_send_ng_information_control {
  VHOST_SEND_NG_INFORMATION_CONTROL_POINTER next;
  VHOST_SEND_NG_INFORMATION_CONTROL_POINTER prev;
  VHOST_SEND_NG_INFORMATION_BLOCK ng_information;
};

typedef struct _vhost_send_ng_information_control_queue {
  VHOST_SEND_NG_INFORMATION_CONTROL_POINTER head;
  VHOST_SEND_NG_INFORMATION_CONTROL_POINTER tail;
} VHOST_SEND_NG_INFORMATION_CONTROL_QUEUE, *VHOST_SEND_NG_INFORMATION_CONTROL_QUEUE_POINTER;

typedef struct _vhost_send_requset_data_control VHOST_SEND_REQUEST_DATA_CONTROL, *VHOST_SEND_REQUEST_DATA_CONTROL_POINTER;
typedef struct _vhost_manage VHOST_MANAGE, *VHOST_MANAGE_POINTER;


// send request controls
struct _vhost_send_requset_data_control {
  VHOST_SEND_REQUEST_DATA_CONTROL_POINTER next;                 // for CLI interface
  VHOST_SEND_REQUEST_DATA_CONTROL_POINTER prev;                 // for CLI interface
  VHOST_MANAGE_POINTER vhost_manage_pointer;                    // control vhost pointer
  u_int result_socket;                                          //
  u_int send_status;                                            // 0: nothing
                                                                // 1: sending
  int stop_req;                                                 // 1:device stop request
  u_short l2_type;
  u_short vlan_information;                                     // VLAN ID + TCI + CoS
  u_int generator_mode;                                         //
  struct random_data *random_information_pointer;
  u_int response_type;                                          // 0: Completion response
                                                                // 1: Instant response
  SMAC_CONTROL source_mac_address;                              // Source MAC Address
  SMAC_CONTROL destination_mac_address;                         // Destination MAC Address
  u_short mac_type;                                             // MAC Address Type
  u_short ether_type;                                           // ethernet type
  u_short layer_3_type;                                         // layer 3 type
  u_short hardware_type;                                        // hardware type
  u_short protocol_type;                                        // protocol type
  u_short operation_code;                                       // operation code
  SMAC_CONTROL arp_source_mac_address;                          // Source MAC mask / counter
  SMAC_CONTROL arp_destination_mac_address;                     // Destination MAC mask / counter
  u_short arp_mac_type;                                         // ARP MAC Address Type
  IP_ADDRESS_CONTROL source_ip_address;                         // Source IP address
  IP_ADDRESS_CONTROL destination_ip_address;                    // Destination IP address
  u_short ip_type;                                              // IP type
  u_short pad;                                                  // R.F.U
  u_char tos;                                                   // ToS
  u_char flags;                                                 // IP flags
  u_short id;                                                   // IP ID
  u_short flagment_offset;                                      // Flagment Offset
  u_char ttl;                                                   // TTL
  u_char protocol_number;                                       // IP protocol number
  u_short option_length;                                        // IP option length
  u_char option[ MAX_OPTION_LENGTH ];                           // IP option
  UDP_PORT_CONTROL source_port_number;                          // UDP source port number
  UDP_PORT_CONTROL destination_port_number;                     // UDP destination port number
  u_short udp_type;                                             // UDP type
  u_int duration;                                               // duration
  u_int packet_par_second;                                      // PPS
  u_int packet_num;                                             // packet num
  u_int packet_length;                                          // packet length
  u_int payload_pattern;                                        // payload pattern
  u_int payload_count;                                          // payload length
  u_int payload_limit;                                          // payload limit
  u_int current_packet_num;                                     // payload count
  u_int payload_length;                                         // payload length
  u_int payload_mask_length;                                    // payload mask length
  u_char *payload_mask;                                         // payload mask pattern(user defined, random initial value)
  u_char *payload;                                              // payload
  VHOST_SEND_NG_INFORMATION_CONTROL_QUEUE send_ng_queue;        //
};

typedef struct _vhost_send_requset_data_queue_control {
  VHOST_SEND_REQUEST_DATA_CONTROL_POINTER head;
  VHOST_SEND_REQUEST_DATA_CONTROL_POINTER tail;
} VHOST_SEND_REQUEST_DATA_QUEUE_CONTROL, *VHOST_SEND_REQUEST_QUEUE_CONTROL_POINTER;

// CLI interface control
typedef struct _cli_socket_control {
  int cli_socket_fd;
  VHOST_SEND_REQUEST_DATA_QUEUE_CONTROL send_control;
} CLI_SOCKET_CONTROL, *CLI_SOCKET_CONTROL_POINTER;

typedef struct _statistics {
  u_short ether_type;
  u_short vlan_id;
  u_int ip_check_sum;
  u_int udp_check_sum;
  u_int packet_check_sum;
  int packet_bytes;
  int ip_header_offset;
  int udp_header_offset;
  unsigned long long receive_total_bytes;
  unsigned long long receive_total_packets;
  u_char packet_buffer[ MAX_RECEIVE_BUFFER_SIZE ];
} STATISTICS_INFORMATION, *STATISTICS_INFORMATION_POINTER;

typedef struct _vhost_statistics VHOST_STATISTICS, *VHOST_STATISTICS_POINTER;

struct _vhost_statistics {
  VHOST_STATISTICS_POINTER next;
  VHOST_STATISTICS_POINTER prev;
  STATISTICS_INFORMATION statistics;
};

typedef struct _vhost_statistics_control {
  VHOST_STATISTICS_POINTER head;
  VHOST_STATISTICS_POINTER tail;
} VHOST_STATISTICS_CONTROL, *VHOST_STATISTICS_CONTROL_POINTER;

// for send
typedef struct _send_buffer_control {
  VHOST_STATISTICS_POINTER send_buffer;
} SEND_BUFFER_CONTROL, *SEND_BUFFER_CONTROL_POINTER;

typedef struct _vhost_receive_buffer VHOST_RECEIVE_BUFFER, *VHOST_RECEIVE_BUFFER_POINTER;

struct _vhost_receive_buffer {
  VHOST_RECEIVE_BUFFER_POINTER next;
  VHOST_RECEIVE_BUFFER_POINTER prev;
  STATISTICS_INFORMATION statistics;
};

typedef struct _vhost_receive_buffer_control {
  VHOST_RECEIVE_BUFFER_POINTER head;
  VHOST_RECEIVE_BUFFER_POINTER tail;
} VHOST_RECEIVE_BUFFER_CONTROL, *VHOST_RECEIVE_BUFFER_CONTROL_POINTER;


typedef struct _arp_cache {
  u_short vlan_info;            // Bit 15 Static entry
                                // Bit 14 R.F.U
                                // Bit 13 R.F.U
                                // Bit 12 Valid
  u_char mac_address[ MAC_ADDRESS_LENGTH ];
  u_int ipv4_address;
  time_t ageout_time;
  time_t last_access_time;
} ARP_CACHE_TABLE, *ARP_CAHCE_TABLE_POINTER;

typedef struct _vhost_arp_table VHOST_ARP_DATA, *VHOST_ARP_DATA_POINTER;

struct _vhost_arp_table {
  VHOST_ARP_DATA_POINTER next;
  VHOST_ARP_DATA_POINTER prev;
  ARP_CACHE_TABLE arp_cache;
};


typedef struct _vhost_arp_control {
  VHOST_ARP_DATA_POINTER head;
  VHOST_ARP_DATA_POINTER tail;
} VHOST_ARP_CONTROL, *VHOST_ARP_CONTROL_POINTER;


typedef struct _vhost_control {
  u_char vhost_name[ VHOST_NAME_MAX ];
  int generator_mode;                                   // 0: raw generator mode
                                                        // 1: host emurator mode
  u_int ipv4_address;
  u_int ipv4_mask;
  u_char host_mac_address[ MAC_ADDRESS_LENGTH ];
  u_short l2_type;                                      // 0: DIX
                                                        // 1: 802.1Q
  u_short vlan_id;
  u_short promisc_mode;                                 // 0:no promisc
                                                        // 1:promisc
  u_short arp_cache_time;                               // arp cache time
  u_char send_interface[ VHOST_DEVICE_NAME_MAX ];       // sender device name
  u_char receive_interface[ VHOST_DEVICE_NAME_MAX ];    // receiver device name
} VHOST_CONTROL, *VHOST_CONTROL_POINTER;

typedef struct _device_control {
  char device_name[ VHOST_DEVICE_NAME_MAX ];
  struct ifreq ifrequest;                                       // for RAW socket
  struct sockaddr_ll socketaddress_ll;                          // for RAW socket
  int device_number;                                            // 1:device stop request
  int stop_req;                                                 // 1:device stop request
  int socket_fd;                                                // RAW socket
  int vhost_connect_nums;                                       // connect vhost nums
  VHOST_RECEIVE_BUFFER_CONTROL receive_queue;                   // receive queue
  pthread_mutex_t receiver_interface_mutex;                     // for mac entry mutex
  pthread_mutex_t receive_buffer_interface_mutex;               // for mac entry mutex
} DEVICE_CONTROL, *DEVICE_CONTROL_POINTER;


struct _vhost_manage {
  VHOST_CONTROL vhost_control;
  int socket_fd;
  struct ifreq ifrequest;                                      // for RAW socket
  int vhost_number;
  int stop_req;
  char sender_device_name[ VHOST_DEVICE_NAME_MAX ];
  struct random_data random_information;
  unsigned long long receive_statistics_packet_num;
  unsigned long long send_statistics_packet_num;
  unsigned long long arp_number;
  VHOST_ARP_CONTROL arp_control_head[ ARP_HASH_MAX ];
  VHOST_STATISTICS_CONTROL receive_statistics_control_head[ STATISTICS_CONTROL_MAX ];
  VHOST_STATISTICS_CONTROL send_statistics_control_head[ STATISTICS_CONTROL_MAX ];
  DEVICE_CONTROL_POINTER receiver_pointer;
  pthread_cond_t receiver_interface_cond;
  pthread_mutex_t receiver_interface_mutex;
  pthread_mutex_t arp_interface_mutex;
  pthread_mutex_t send_statistics_interface_mutex;
  pthread_mutex_t receive_statistics_interface_mutex;
  VHOST_SEND_REQUEST_DATA_CONTROL send_information[ SEND_REQUEST_ACCEPT_MAX ];
};


#endif      // _VHOST_CONTROL_H

/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
