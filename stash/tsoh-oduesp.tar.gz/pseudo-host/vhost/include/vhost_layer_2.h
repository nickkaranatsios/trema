/*
 * vhost L2 packet interface .
 *
 * Author: Tomoaki Ishikawa
 */


#ifndef _VHOST_LAYER2_HEADER_H
#define _VHOST_LAYER2_HEADER_H

#include "vhost_layer_3_4.h"

/******************************************************************************
 * define & macros                                                            *
 ******************************************************************************/
#define     ARP_PROTOCOL_TYPE       0x800
#define     ARP_HARDWARE_TYPE       1
#define     ARP_HARDWARE_LENGTH     MAC_ADDRESS_LENGTH
#define     ARP_PROTOCOL_LENGTH     4
#define     MINIMAM_PACKET_SIZE     64

/******************************************************************************
 * structure                                                                  *
 ******************************************************************************/

/******************************************************************************
 * external function                                                          *
 ******************************************************************************/
extern void make_mac( struct random_data *random_data, SMAC_CONTROL *mac_control, u_short mac_type, u_char *mac_write_pointer );
extern int make_vlan_header( struct random_data *random_data,
  u_char *mac_distination,
  SMAC_CONTROL *mac_source,
  u_short vid,
  u_short mac_type,
  u_short ether_type,
  u_char *write_buffer );
extern int make_ether_header( struct random_data *random_data,
  u_char *mac_distination,
  SMAC_CONTROL *mac_source,
  u_short mac_type,
  u_short ether_type,
  u_char *write_buffer );
extern size_t make_arp( u_short hard_type, u_short protocol_type, u_short operation_code, struct random_data *random_data,
  SMAC_CONTROL *mac_distination, SMAC_CONTROL *mac_source, u_short mac_type,
  IP_ADDRESS_CONTROL_POINTER source_ip_address, IP_ADDRESS_CONTROL_POINTER destination_ip_address,
  u_short ip_type, u_char *write_buffer );
extern int check_ether_header( STATISTICS_INFORMATION_POINTER read_buffer, u_short *ether_type );
extern int get_ether_header( STATISTICS_INFORMATION_POINTER read_buffer, u_short *ether_type );

#endif  // _VHOST_LAYER2_HEADER_H

/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
