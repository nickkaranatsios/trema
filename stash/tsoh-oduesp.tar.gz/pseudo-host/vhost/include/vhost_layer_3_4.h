/*
 * vhost packet interface .
 *
 * Author: Tomoaki Ishikawa
 */


#ifndef _VHOST_LAYER_3_4_HEADER_H
#define _VHOST_LAYER_3_4_HEADER_H

/******************************************************************************
 * define & macros                                                            *
 ******************************************************************************/
#define     IP_HEADER_OCTET     4
#define     INCLEMENT_MAX       256

/******************************************************************************
 * Packet Interface Command Codes                                             *
 ******************************************************************************/

/******************************************************************************
 * Packet Interface Structure                                                 *
 ******************************************************************************/

// for calculate udp checksum
typedef struct  _udp_dummy_header {
  u_int ipv4_source_address;
  u_int ipv4_destination_address;
#if __BYTE_ORDER == __LITTLE_ENDIAN
  u_char protocol_number;
  u_char pad;
#elif __BYTE_ORDER == __BIG_ENDIAN
  u_char pad;
  u_char protocol_number;
#endif
  u_short udp_length;
} UDP_DUMMY_HEADER, *UDP_DUMMY_HEADER_POINTER;

/******************************************************************************
 * external function                                                          *
 ******************************************************************************/
extern u_int make_ip_address( struct random_data *random_data, IP_ADDRESS_CONTROL_POINTER ip_address_control, u_short ip_type );
extern u_int make_ip_header( u_char tos, u_int identifier, u_short flagment, u_char ttl, u_char protocol_number,
  struct random_data *random_data, IP_ADDRESS_CONTROL_POINTER source_ip_address,
  u_int destination_ip_address, u_short ip_type,
  u_short option_length, u_char *option, u_int ip_length, u_char *write_buffer,
  STATISTICS_INFORMATION_POINTER packet_statistics, UDP_DUMMY_HEADER_POINTER dummy_header );
extern int make_udp_header( struct random_data *random_data,
  UDP_PORT_CONTROL_POINTER source_port, UDP_PORT_CONTROL_POINTER destination_port, u_short port_type,
  u_short length, u_char *write_buffer, UDP_DUMMY_HEADER_POINTER dummy_header,
  STATISTICS_INFORMATION_POINTER packet_statistics );
extern void copy_payload( u_char *write_buffer, int payload_pattern_size, u_char *payload_pattern, int size );
extern u_short make_payload( u_char *write_buffer, int *count, int type, int size,
  int count_num, int count_limit, u_char *mask, struct random_data *random_data );
extern u_short calculate_crc( u_short *buffer, u_int length );
extern u_short calculate_udp_crc( u_short *buffer, u_int length, u_short *dummy_header );
extern int check_ip_header( STATISTICS_INFORMATION_POINTER read_buffer, u_char *packet, u_short *protocol_number, u_int *ip_check_sum, u_int *udp_check_sum );

#endif  // _VHOST_LAYER_3_4_HEADER_H

/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
