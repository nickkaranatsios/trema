/*
 * vhost packet interface .
 *
 * Author: Tomoaki Ishikawa
 */

#ifndef _VHOST_SOCKET_H
#define _VHOST_SOCKET_H

/******************************************************************************
 * define & macros                                                            *
 ******************************************************************************/

/******************************************************************************
 * structure                                                                  *
 ******************************************************************************/

/******************************************************************************
 * external                                                                   *
 ******************************************************************************/
extern int vhost_create_request( VHOST_CREATE_REQUEST_BLOCK_POINTER vhost_create, u_char *result_pointer );
extern void vhost_packet_check( int socket_fd, u_char *packet, u_int packet_size );
extern int vhost_packet_receive( int socket_fd );
extern void vhost_send_complete( int socket_fd, VHOST_SEND_REQUEST_DATA_CONTROL_POINTER send_information );

#endif      // _VHOST_SOCKET_H

/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
