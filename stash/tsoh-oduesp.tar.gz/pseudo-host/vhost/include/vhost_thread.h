/*
 * vhost thread interface .
 *
 * Author: Tomoaki Ishikawa
 */


#ifndef _VHOST_THREAD_HEADER_H
#define _VHOST_THREAD_HEADER_H

/******************************************************************************
 * define & macros                                                            *
 ******************************************************************************/
#define     IP_CHECKSUM_READY       0x01
#define     UDP_CHECKSUM_READY      0x02
#define     MAX_RECEIVER_THERAD_WAIT    1

/******************************************************************************
 * Packet Interface Command Codes                                             *
 ******************************************************************************/

/******************************************************************************
 * Packet Interface Structure                                                 *
 ******************************************************************************/

/******************************************************************************
 * external function                                                          *
 ******************************************************************************/
extern VHOST_MANAGE_POINTER vhost_search_vhostname( u_char *vhost_name );
extern void vhost_receive_main( VHOST_MANAGE_POINTER vhost_manage_pointer, VHOST_STATISTICS_POINTER receive_buffer );
extern DEVICE_CONTROL_POINTER vhost_search_receiver( u_char *device_name );

extern void *vhost_receiver_main( void *args );
extern void *vhost_thread_main( void *args );
extern void *vhost_sender_main( void *args );
extern void vhost_stop( VHOST_MANAGE_POINTER vhost_manage_pointer );
extern void vhost_clear_statistics( VHOST_MANAGE_POINTER vhost_manage_pointer, int type );
extern void arp_entry_delete( VHOST_ARP_CONTROL_POINTER arp_entry_pointer, VHOST_ARP_DATA_POINTER arp_entry );
extern u_int vhost_arp_hash( u_int ipv4_address );
extern void vhost_arp_add( VHOST_ARP_CONTROL_POINTER arp_control_head, VHOST_ARP_DATA_POINTER arp_data,
  pthread_mutex_t *arp_mutex, unsigned long long *arp_entry_number,
  u_int arp_expire_time );

extern void vhost_delete_send_ng_queue( VHOST_SEND_NG_INFORMATION_CONTROL_QUEUE_POINTER send_ng_queue_pointer );


#endif  // _VHOST_THREAD_HEADER_H

/*
 * Local variables:
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * End:
 */
