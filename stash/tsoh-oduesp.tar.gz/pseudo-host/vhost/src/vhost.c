#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>
#include <netinet/tcp.h>
#include <netinet/ip.h>
#include <net/ethernet.h>
#include <sys/socket.h>
#include <netpacket/packet.h>
#include <net/if.h>
#include <string.h>
#include <pthread.h>
#include <sys/ioctl.h>
#include <sched.h>
#include <signal.h>
#include <poll.h>

#include "com_socket.h"
#include "packet.h"
#include "vhost_interface.h"
#include "vhost_control.h"
#include "vhost_layer_2.h"
#include "vhost_layer_3_4.h"
#include "vhost_socket.h"
#include "vhost_thread.h"

/******************************************************************************
 * defines                                                                    *
 ******************************************************************************/
#define     MAX_OPTIONS            3
#define     CLI_CONNECTION_MAX    16
#define     ARP_CHECK_SECOND       1
#define     ARP_CHECK_NANOSECOND   0
enum {
  EVHOST_CLI_INTERFACE_PORT,
  EVHOST_MANAGER_INTERFACE_PORT,
  EVHOST_MANAGER_DAEMONIZE,
};
#define     MANAGER_ACCEPT_SELECT_OFFSET  0
#define     CLI_ACCEPT_SELECT_OFFSET      1
#define     MANAGER_SELECT_OFFSET         2

/******************************************************************************
 * data defines                                                               *
 ******************************************************************************/
char randomStateBuffer[ MAX_THREADS ][ STATELEN ];

VHOST_MANAGE_POINTER vhost_manage;
DEVICE_CONTROL vhost_device[ VHOST_DEVICE_MAX ];

static int cli_interface_port     = CLI_INTERFACE_PORT;
static int manager_interface_port = MANAGER_INTERFACE_PORT;

struct option options[ ( MAX_OPTIONS + 1 ) ] = {
  {
    .name    = "cliport",
    .has_arg = required_argument,
    .flag    = NULL,
    .val     = EVHOST_CLI_INTERFACE_PORT
  },
  {
    .name    = "managerport",
    .has_arg = required_argument,
    .flag    = NULL,
    .val     = EVHOST_MANAGER_INTERFACE_PORT
  },
  {
    .name    = "Daemonize",
    .has_arg = no_argument,
    .flag    = NULL,
    .val     = EVHOST_MANAGER_DAEMONIZE
  },
  {
    .name    = NULL,
    .has_arg = 0,
    .flag    = NULL,
    .val     = 0
  },
};

CLI_SOCKET_CONTROL cli_socket_control[ CLI_CONNECTION_MAX ];

void
vhost_add_send_control( int socket_fd, VHOST_SEND_REQUEST_DATA_CONTROL_POINTER send_information_pointer ) {
  int lp;

  for ( lp = 0; lp < CLI_CONNECTION_MAX; lp++ ) {
    if ( cli_socket_control[ lp ].cli_socket_fd == socket_fd ) {
      if ( cli_socket_control[ lp ].send_control.head == NULL ) {
        cli_socket_control[ lp ].send_control.head = send_information_pointer;
        cli_socket_control[ lp ].send_control.tail = send_information_pointer;
        break;
      }
      else {
        cli_socket_control[ lp ].send_control.tail->next = send_information_pointer;
        send_information_pointer->prev = cli_socket_control[ lp ].send_control.tail->next;
        cli_socket_control[ lp ].send_control.tail = send_information_pointer;
        break;
      }
    }
  }
}


void
vhost_arp_expire_check( void ) {
  int lp;
  int lp2;
  int arp_cache_time;
  VHOST_ARP_DATA_POINTER search_pointer;
  time_t current_time;
  time_t expire_time_left;
  VHOST_ARP_DATA_POINTER next_search_pointer;

  time( &current_time );
  for ( lp = 0; lp < MAX_THREADS; lp++ ) {
    if ( ( vhost_manage[ lp ].vhost_control.vhost_name[ 0 ] != '\0' )
       && ( vhost_manage[ lp ].vhost_control.generator_mode == HOST_EMURATOR_MODE ) ) {
      if ( vhost_manage[ lp ].arp_number == 0 ) {
        continue;
      }

      arp_cache_time = vhost_manage[ lp ].vhost_control.arp_cache_time;
      pthread_mutex_lock( &vhost_manage[ lp ].arp_interface_mutex );

      for ( lp2 = 0; lp2 < ARP_HASH_MAX; lp2++ ) {
        search_pointer = vhost_manage[ lp ].arp_control_head[ lp2 ].head;

        while ( search_pointer != NULL ) {
          if ( ( search_pointer->arp_cache.vlan_info & STATIC_ARP_ENTRY ) == 0 ) {
            expire_time_left = current_time - search_pointer->arp_cache.last_access_time;
            if ( expire_time_left > arp_cache_time ) {
              next_search_pointer = search_pointer->next;
              arp_entry_delete( &vhost_manage[ lp ].arp_control_head[ lp2 ], search_pointer );
              search_pointer = next_search_pointer;
              vhost_manage[ lp ].arp_number -= 1;
            }
            else {
              search_pointer->arp_cache.ageout_time = arp_cache_time - expire_time_left;
              search_pointer = search_pointer->next;
            }
          }
          else {
            search_pointer = search_pointer->next;
          }
        }
      }
      pthread_mutex_unlock( &vhost_manage[ lp ].arp_interface_mutex );
    }
  }
}


void
vhost_delete_send_complete( VHOST_SEND_REQUEST_QUEUE_CONTROL_POINTER send_control_queue_pointer ) {
  VHOST_SEND_REQUEST_DATA_CONTROL_POINTER send_information_pointer;

  while ( send_control_queue_pointer->head != NULL ) {
    send_information_pointer = send_control_queue_pointer->head;
    send_information_pointer->response_type = FALSE;

    send_control_queue_pointer->head = send_information_pointer->next;
    if ( send_information_pointer->next != NULL ) {
      send_information_pointer->next->prev = send_information_pointer->prev;
    }
    if ( send_information_pointer->prev != NULL ) {
      send_information_pointer->prev->next = send_information_pointer->next;
    }
    send_information_pointer->prev = send_information_pointer->next = NULL;

    if ( send_control_queue_pointer->tail == send_information_pointer ) {
      send_control_queue_pointer->tail = NULL;
    }
  }
}


void
vhost_send_end_check( void ) {
  int lp;
  VHOST_SEND_REQUEST_DATA_CONTROL_POINTER send_information;

  for ( lp = 0; lp < CLI_CONNECTION_MAX; lp++ ) {
    if ( cli_socket_control[ lp ].send_control.head == NULL ) {
      continue;
    }
    send_information = cli_socket_control[ lp ].send_control.head;
    while ( send_information != NULL ) {
      if ( ( send_information->response_type == TRUE )
         && ( send_information->send_status == FALSE ) ) {
        vhost_send_complete( cli_socket_control[ lp ].cli_socket_fd, send_information );
        send_information->response_type = FALSE;
        if ( send_information == cli_socket_control[ lp ].send_control.head ) {
          cli_socket_control[ lp ].send_control.head = cli_socket_control[ lp ].send_control.tail = NULL;
          send_information = NULL;
        }
        else {
          if ( send_information->next != NULL ) {
            send_information->next->prev = send_information->prev;
          }
          if ( send_information->prev != NULL ) {
            send_information->prev->next = send_information->next;
          }
        }
      }
      else {
        send_information = send_information->next;
      }
    }
  }
}


void
vhost_mainloop( int cli_interface_port, int manager_interface_port ) {
  int lp;
  int cli_accept_socket_fd;
  nfds_t poll_fd_num;
  int select_result;
  int result;
  int manager_accept_socket_fd;
  int manager_socket_fd = -1;
  struct pollfd poll_fd[ SELECT_FD_MAX ];
  struct timespec select_time;

  // Create Socket(CLI)
  cli_accept_socket_fd = com_socket_accept_port_create( cli_interface_port );
  if ( cli_accept_socket_fd < 0 ) {
    printf( "CLI interface socket create error\n" );
    exit( 0 );
  }

  // Create Socket(manager)
  manager_accept_socket_fd = com_socket_accept_port_create( manager_interface_port );
  if ( manager_accept_socket_fd < 0 ) {
    printf( "CLI interface socket create error\n" );
    exit( 0 );
  }

  // main loop
  while ( 1 ) {
    memset( poll_fd, '\0', sizeof( poll_fd ) );
    poll_fd[ MANAGER_ACCEPT_SELECT_OFFSET ].fd = manager_accept_socket_fd;
    poll_fd[ MANAGER_ACCEPT_SELECT_OFFSET ].events = POLLIN | POLLERR;

    poll_fd[ CLI_ACCEPT_SELECT_OFFSET ].fd = cli_accept_socket_fd;
    poll_fd[ CLI_ACCEPT_SELECT_OFFSET ].events = POLLIN | POLLERR;

    poll_fd_num = CLI_ACCEPT_SELECT_OFFSET + 1;

    if ( manager_socket_fd != -1 ) {
      poll_fd[ MANAGER_SELECT_OFFSET ].fd = manager_socket_fd;
      poll_fd[ MANAGER_SELECT_OFFSET ].events = POLLIN | POLLERR;

      poll_fd_num += 1;
    }

    for ( lp = 0; lp < CLI_CONNECTION_MAX; lp++ ) {
      if ( cli_socket_control[ lp ].cli_socket_fd != -1 ) {
        poll_fd[ ( MANAGER_SELECT_OFFSET + ( lp + 1 ) ) ].fd = cli_socket_control[ lp ].cli_socket_fd;
        poll_fd[ ( MANAGER_SELECT_OFFSET + ( lp + 1 ) ) ].events = POLLIN | POLLERR;
        poll_fd_num += 1;
      }
    }

    select_time.tv_sec = ARP_CHECK_SECOND;
    select_time.tv_nsec = ARP_CHECK_NANOSECOND;

    select_result = ppoll( poll_fd, poll_fd_num, &select_time, NULL );
    if ( select_result > 0 ) {
      if ( manager_socket_fd != -1 ) {
        if ( poll_fd[ MANAGER_SELECT_OFFSET ].revents & POLLIN ) {
          // Data receive & data check
          result = vhost_packet_receive( manager_socket_fd );
          if ( result == FALSE ) {
            // Delete All vhost
            for ( lp = 0; lp < MAX_THREADS; lp++ ) {
              if ( vhost_manage[ lp ].vhost_control.vhost_name[ 0 ] != '\0' ) {
                vhost_stop( &vhost_manage[ lp ] );
              }
            }
            // Disconnect
            com_socket_close( manager_socket_fd );
            manager_socket_fd = -1;
          }
        }
      }
      for ( lp = 0; lp < CLI_CONNECTION_MAX; lp++ ) {
        if ( cli_socket_control[ lp ].cli_socket_fd != -1 ) {
          if ( poll_fd[ ( MANAGER_SELECT_OFFSET + ( lp + 1 ) ) ].revents & POLLIN ) {
            // Data receive & data check
            result = vhost_packet_receive( cli_socket_control[ lp ].cli_socket_fd );
            if ( result == FALSE ) {
              // Delete vhost connection
              com_socket_close( cli_socket_control[ lp ].cli_socket_fd );
              cli_socket_control[ lp ].cli_socket_fd = -1;
              vhost_delete_send_complete( &cli_socket_control[ lp ].send_control );
            }
          }
        }
      }

      if ( poll_fd[ MANAGER_ACCEPT_SELECT_OFFSET ].revents & POLLIN ) {
        // already connect?
        if ( manager_socket_fd != -1 ) {
          result = accept( manager_accept_socket_fd, NULL, NULL );
          if ( result >= 0 ) {
            com_socket_close( result );
          }
        }
        else {
          manager_socket_fd = accept( manager_accept_socket_fd, NULL, NULL );
        }
      }
      if ( poll_fd[ CLI_ACCEPT_SELECT_OFFSET ].revents & POLLIN ) {
        if ( manager_socket_fd == -1 ) {
          result = accept( cli_accept_socket_fd, NULL, NULL );
          com_socket_close( result );
        }
        else {
          result = FALSE;
          for ( lp = 0; lp < CLI_CONNECTION_MAX; lp++ ) {
            if ( cli_socket_control[ lp ].cli_socket_fd == -1 ) {
              cli_socket_control[ lp ].cli_socket_fd = accept( cli_accept_socket_fd, NULL, NULL );
              result = TRUE;
              break;
            }
          }

          // CLI connection FULL ?
          if ( result == FALSE ) {
            result = accept( cli_accept_socket_fd, NULL, NULL );
            com_socket_close( result );
          }
        }
      }
    }
    vhost_arp_expire_check();
    vhost_send_end_check();
  }
}


int
vhost_daemonize( void ) {
  pid_t pid, sid;
  int rc ;

  rc = chdir( ( const char * )"/" );
  if( rc != 0 ){
    return -1;
  }

  pid = fork();
  if ( pid < 0 ) {
    return -1;
  }

  if ( pid > 0 ) {
    exit( 0 );
  }

  sid = setsid();
  if ( sid < 0 ) {
    return -1;
  }

  fclose( stdin );
  fclose( stdout );
  fclose( stderr );

  return 0;

}


int
main( int argc, char **argv ) {
  int lp;
  int options_value;
  int daemonize = FALSE;
  int options_index;
  struct sched_param sched;

  signal( SIGPIPE, SIG_IGN );
  // option check
  while ( 1 ) {
    options_value = getopt_long( argc, argv, "c:m:D", options, &options_index );
    if ( options_value == -1 ) {
      break;
    }
    switch ( options_value ) {
      case EVHOST_CLI_INTERFACE_PORT:
        cli_interface_port = atoi( optarg );
        break;

      case EVHOST_MANAGER_INTERFACE_PORT:
        manager_interface_port = atoi( optarg );
        break;

      case 'D':
      case EVHOST_MANAGER_DAEMONIZE:
        daemonize = TRUE;
        break;
    }
  }

  if ( ( cli_interface_port == 0 ) || ( manager_interface_port == 0 ) ) {
    fprintf( stdout, "Usage : %s --cliport=cli_interface_port --managerport=manager_interface_port --daemonize\n", argv[ 0 ] );
    exit( 0 );
  }
  if ( ( daemonize == TRUE ) && ( vhost_daemonize() < 0 ) ) {
    fprintf( stderr, "[ERROR] cannot daemonize.\n" );
    exit( 1 );
  }

  for ( lp = 0; lp < CLI_CONNECTION_MAX; lp++ ) {
    cli_socket_control[ lp ].cli_socket_fd = -1;
  }
  memset( &sched, 0, sizeof( sched ) );
  sched.sched_priority = sched_get_priority_max( SCHED_FIFO );
  sched_setscheduler( 0, SCHED_FIFO, ( const struct sched_param * ) &sched.sched_priority );


  vhost_manage = calloc( MAX_THREADS, sizeof( VHOST_MANAGE ) );
  if ( vhost_manage == NULL ) {
    printf( "Not enough memory to start\n" );
    exit( 0 );
  }
  // Init Mmemory
  for ( lp = 0; lp < MAX_THREADS; lp++ ) {
    // Init Random data
    memset( &vhost_manage[ lp ].random_information, 0, sizeof( struct random_data ) );
    initstate_r( ( u_int ) time( NULL ), ( char * ) &randomStateBuffer[ lp ][ 0 ], STATELEN, &vhost_manage[ lp ].random_information );

    vhost_manage[ lp ].vhost_number = lp;

    // Initialize Mutex
    pthread_mutex_init( &vhost_manage[ lp ].receiver_interface_mutex, NULL );
    pthread_mutex_init( &vhost_manage[ lp ].arp_interface_mutex, NULL );
    pthread_mutex_init( &vhost_manage[ lp ].receive_statistics_interface_mutex, NULL );
    pthread_mutex_init( &vhost_manage[ lp ].send_statistics_interface_mutex, NULL );

    // Initialize CondSignal
    pthread_cond_init( &vhost_manage[ lp ].receiver_interface_cond, NULL );
    vhost_manage[ lp ].socket_fd = -1;
  }

  for ( lp = 0; lp < VHOST_DEVICE_MAX; lp++ ) {
    memset( &vhost_device[ lp ], '\0', sizeof( DEVICE_CONTROL ) );
    pthread_mutex_init( &vhost_device[ lp ].receiver_interface_mutex, NULL );
    pthread_mutex_init( &vhost_device[ lp ].receive_buffer_interface_mutex, NULL );
  }
  vhost_mainloop( cli_interface_port, manager_interface_port );

  return 0;
}
