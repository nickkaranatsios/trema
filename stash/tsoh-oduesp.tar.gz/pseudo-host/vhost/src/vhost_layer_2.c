#include <stdio.h>
#include <stdlib.h>
#include <netinet/tcp.h>
#include <netinet/ip.h>
#include <net/ethernet.h>
#include <net/if_arp.h>
#include <sys/socket.h>
#include <netpacket/packet.h>
#include <net/if.h>
#include <string.h>
#include "packet.h"
#include "cmn.h"
#include "vhost_control.h"
#include "vhost_layer_2.h"

typedef union _random_convert {
  uint64_t ll_mac_address;
  int32_t l_random_mac_address[ 2 ];
} URANDOM_MAC_CONVERT;

/**********************************************************************
 * L2 packet make
 **********************************************************************/
void
make_mac( struct random_data *random_data, SMAC_CONTROL_POINTER mac_control, u_short mac_type, u_char *mac_write_pointer ) {
  int lp;
  UMAC_CONVERT mac_convert;
  URANDOM_MAC_CONVERT mac_random_convert;
  uint64_t mac_address_long_long;
  uint64_t mac_address_random;
  uint64_t mac_address_mask;

  if ( mac_type == 0 ) {
    memcpy( mac_write_pointer, mac_control->mac_address, MAC_ADDRESS_LENGTH );
    return;
  }

  memset( mac_convert.mac_address, '\0', sizeof( UMAC_CONVERT ) );
  memcpy( &mac_convert.mac_address[ 2 ], mac_control->mac_address, MAC_ADDRESS_LENGTH );
  mac_address_long_long = ntohll( mac_convert.ll_mac_address );

  memset( mac_convert.mac_address, '\0', sizeof( UMAC_CONVERT ) );
  memcpy( &mac_convert.mac_address[ 2 ], mac_control->mask, MAC_ADDRESS_LENGTH );

  mac_address_mask = ntohll( mac_convert.ll_mac_address );

  if ( ( mac_type & SOURCE_TYPE_INCREMENT ) ) {
    mac_address_long_long += ( mac_control->current_no * mac_control->add_count );
  }
  else if ( ( mac_type & SOURCE_TYPE_DECREMENT ) ) {
    mac_address_long_long -= ( mac_control->current_no * mac_control->add_count );
  }
  else if ( ( mac_type & SOURCE_TYPE_RANDOM ) ) {
    // Create random MAC address
    for ( lp = 0; lp < 2; lp++ ) {
      random_r( random_data, &mac_random_convert.l_random_mac_address[ lp ] );
    }
    mac_address_random = mac_random_convert.ll_mac_address;
    mac_address_random &= ~mac_address_mask;
    mac_address_long_long &= mac_address_mask;
    mac_address_long_long |= mac_address_random;
  }

  mac_convert.ll_mac_address = htonll( mac_address_long_long );

  memcpy( mac_write_pointer, &mac_convert.mac_address[ 2 ], MAC_ADDRESS_LENGTH );

  if ( ( mac_type & ( SOURCE_TYPE_INCREMENT | SOURCE_TYPE_DECREMENT ) ) ) {
    mac_control->current_no += 1;
    if ( ( mac_address_mask != 0 ) && ( mac_control->current_no > mac_address_mask ) ) {
      mac_control->current_no = 0;
    }
  }
}


int
make_ether_header( struct random_data *random_data,
  u_char *mac_distination,
  SMAC_CONTROL_POINTER mac_source,
  u_short mac_type,
  u_short ether_type,
  u_char *write_buffer ) {
  // Make Ethernet Header
  struct ether_header *ethernet_header = ( struct ether_header * ) write_buffer;

  make_mac( random_data, mac_source, mac_type, ethernet_header->ether_shost );
  memcpy( ethernet_header->ether_dhost, mac_distination, MAC_ADDRESS_LENGTH );

  ethernet_header->ether_type = Mhtons( ether_type );
  return ( int ) sizeof( struct ether_header );
}


int
make_vlan_header( struct random_data *random_data,
  u_char *mac_distination,
  SMAC_CONTROL_POINTER mac_source,
  u_short vid,
  u_short mac_type,
  u_short ether_type,
  u_char *write_buffer ) {
  // Make Ethernet Header(802.1Q)
  struct vlan_ether_header *vlan_ethernet_header = ( struct vlan_ether_header * ) write_buffer;

  make_mac( random_data, mac_source, mac_type, vlan_ethernet_header->h_source );

  memcpy( vlan_ethernet_header->h_dest, mac_distination, MAC_ADDRESS_LENGTH );

  vlan_ethernet_header->h_vlan_proto = Mhtons( ETH_P_8021Q );
  vlan_ethernet_header->h_vlan_TCI = Mhtons( vid );
  vlan_ethernet_header->h_vlan_encapsulated_proto = Mhtons( ether_type );
  return sizeof( struct vlan_ether_header );
}


/**********************************************************************
 * packet check
 **********************************************************************/
int
check_ether_header( STATISTICS_INFORMATION_POINTER read_buffer, u_short *ether_type ) {
  int next_size;
  struct ether_header *ethernet_header = ( struct ether_header * ) read_buffer->packet_buffer;
  struct vlan_ether_header *vlan_ethernet_header = ( struct vlan_ether_header * ) read_buffer->packet_buffer;

  *ether_type = Mntohs( ethernet_header->ether_type );

  read_buffer->ip_header_offset = 0;
  read_buffer->vlan_id = 0;

  next_size = 0;
  if ( *ether_type == ETH_P_IP ) {
    read_buffer->ip_header_offset = sizeof( struct ether_header );
    next_size = sizeof( struct ether_header );
  }
  else if ( *ether_type == ETH_P_ARP ) {
    next_size = sizeof( struct ether_header );
  }
  else if ( *ether_type == ETH_P_8021Q ) {
    read_buffer->vlan_id = Mntohs( vlan_ethernet_header->h_vlan_TCI );
    *ether_type = Mntohs( vlan_ethernet_header->h_vlan_encapsulated_proto );
    if ( *ether_type == ETH_P_IP ) {
      read_buffer->ip_header_offset = sizeof( struct vlan_ether_header );
    }
    next_size = sizeof( struct vlan_ether_header );
  }
  return next_size;
}


int
get_ether_header( STATISTICS_INFORMATION_POINTER read_buffer, u_short *ether_type ) {
  int next_size;
  struct ether_header *ethernet_header = ( struct ether_header * ) read_buffer->packet_buffer;
  struct vlan_ether_header *vlan_ethernet_header = ( struct vlan_ether_header * ) read_buffer->packet_buffer;

  *ether_type = Mntohs( ethernet_header->ether_type );

  next_size = 0;
  if ( *ether_type == ETH_P_IP ) {
    next_size = sizeof( struct ether_header );
  }
  else if ( *ether_type == ETH_P_ARP ) {
    next_size = sizeof( struct ether_header );
  }
  else if ( *ether_type == ETH_P_8021Q ) {
    *ether_type = Mntohs( vlan_ethernet_header->h_vlan_encapsulated_proto );
    next_size = sizeof( struct vlan_ether_header );
  }
  return next_size;
}


/**********************************************************************
 * ARP packet make
 **********************************************************************/
size_t
make_arp( u_short hard_type,
  u_short protocol_type,
  u_short operation_code,
  struct random_data *random_data,
  SMAC_CONTROL_POINTER mac_distination,
  SMAC_CONTROL_POINTER mac_source,
  u_short mac_type,
  IP_ADDRESS_CONTROL_POINTER source_ip_address,
  IP_ADDRESS_CONTROL_POINTER destination_ip_address,
  u_short ip_type,
  u_char *write_buffer ) {
  struct arphdr *arp_header = ( struct arphdr * ) write_buffer;
  u_int ipv4_address;
  size_t size;

  arp_header->ar_hrd = Mhtons( hard_type );
  arp_header->ar_pro = Mhtons( protocol_type );
  arp_header->ar_hln = ARP_HARDWARE_LENGTH;
  arp_header->ar_pln = ARP_PROTOCOL_LENGTH;
  arp_header->ar_op = Mhtons( operation_code );

  size = sizeof( struct arphdr );
  write_buffer += sizeof( struct arphdr );

  make_mac( random_data, mac_source, mac_type, write_buffer );

  write_buffer += MAC_ADDRESS_LENGTH;
  size += MAC_ADDRESS_LENGTH;

  mac_type >>= DESTINATION_INFORMATION_POSITION;

  ipv4_address = make_ip_address( random_data, source_ip_address, ip_type );

  memcpy( write_buffer, &ipv4_address, sizeof( u_int ) );

  write_buffer += sizeof( u_int );
  size += sizeof( u_int );
  ip_type >>= DESTINATION_INFORMATION_POSITION;

  make_mac( random_data, mac_distination, mac_type, write_buffer );
  write_buffer += MAC_ADDRESS_LENGTH;
  size += MAC_ADDRESS_LENGTH;

  ipv4_address = make_ip_address( random_data, destination_ip_address, ip_type );

  memcpy( write_buffer, &ipv4_address, sizeof( u_int ) );
  size += sizeof( u_int );

  return size;
}
