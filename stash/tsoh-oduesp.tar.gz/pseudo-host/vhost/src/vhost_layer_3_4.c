#include <stdio.h>
#include <stdlib.h>
#include <netinet/udp.h>
#include <netinet/ip.h>
#include <net/ethernet.h>
#include <net/if_arp.h>
#include <sys/socket.h>
#include <netpacket/packet.h>
#include <net/if.h>
#include <string.h>
#include "packet.h"
#include "cmn.h"
#include "vhost_control.h"
#include "vhost_layer_3_4.h"

/**********************************************************************
 * L3 packet make
 **********************************************************************/
static inline u_short
make_udp_port_number( struct random_data *random_data, UDP_PORT_CONTROL_POINTER udp_port_control, u_short port_type ) {
  uint32_t port_number;
  uint32_t port_number_mask;
  uint32_t port_random;

  if ( port_type == 0 ) {
    return ( u_short ) udp_port_control->port_number;
  }
  port_number = ( uint32_t ) Mntohs( ( uint16_t ) udp_port_control->port_number );
  port_number_mask = ( uint32_t ) Mntohs( ( uint16_t ) udp_port_control->port_number_mask );

  if ( ( port_type & SOURCE_TYPE_INCREMENT ) ) {
    port_number += ( uint32_t ) ( udp_port_control->current_no * udp_port_control->add_count );
  }
  else if ( ( port_type & SOURCE_TYPE_DECREMENT ) ) {
    port_number -= ( uint32_t ) ( udp_port_control->current_no * udp_port_control->add_count );
  }
  else if ( ( port_type & SOURCE_TYPE_RANDOM ) ) {
    random_r( random_data, ( int32_t * ) &port_random );
    port_random &= ~port_number_mask;
    port_number &= port_number_mask;
    port_number |= port_random;
  }

  if ( ( port_type & ( SOURCE_TYPE_INCREMENT | SOURCE_TYPE_DECREMENT ) ) ) {
    udp_port_control->current_no += 1;
    if ( ( port_number_mask != 0 ) && ( udp_port_control->current_no > port_number_mask ) ) {
      udp_port_control->current_no = 0;
    }
  }

  return Mhtons( ( u_short ) port_number );
}


u_int
make_ip_address( struct random_data *random_data, IP_ADDRESS_CONTROL_POINTER ip_address_control, u_short ip_type ) {
  u_int ip_address;
  u_int ip_mask;
  u_int ip_random;

  if ( ip_type == 0 ) {
    return ip_address_control->ipv4_address;
  }
  ip_address = ntohl( ip_address_control->ipv4_address );
  ip_mask = ntohl( ip_address_control->ipv4_mask );

  if ( ( ip_type & SOURCE_TYPE_INCREMENT ) ) {
    ip_address += ( ip_address_control->current_no * ip_address_control->add_count );
  }
  else if ( ( ip_type & SOURCE_TYPE_DECREMENT ) ) {
    ip_address -= ( ip_address_control->current_no * ip_address_control->add_count );
  }
  else if ( ( ip_type & SOURCE_TYPE_RANDOM ) ) {
    random_r( random_data, ( int32_t * ) &ip_random );
    ip_random &= ~ip_mask;
    ip_address &= ip_mask;
    ip_address |= ip_random;
  }

  if ( ( ip_type & ( SOURCE_TYPE_INCREMENT | SOURCE_TYPE_DECREMENT ) ) ) {
    ip_address_control->current_no += 1;
    if ( ( ip_mask != 0 ) && ( ip_address_control->current_no > ip_mask ) ) {
      ip_address_control->current_no = 0;
    }
  }

  return htonl( ip_address );
}


u_int
make_ip_header( u_char tos, u_int identifier, u_short flagment, u_char ttl, u_char protocol_number, struct random_data *random_data,
                IP_ADDRESS_CONTROL_POINTER source_ip_address, u_int destination_ip_address, u_short ip_type, u_short option_length,
                u_char *option, u_int ip_length, u_char *write_buffer, STATISTICS_INFORMATION_POINTER packet_statistics, UDP_DUMMY_HEADER_POINTER dummy_header ) {
  struct iphdr *ip_header = ( struct iphdr * ) write_buffer;
  uint32_t option_length_copy;

  option_length_copy = ( uint32_t ) option_length;
  // Check option length(add padding)
  if ( ( option_length != 0 ) && ( option_length % IP_HEADER_OCTET ) ) {
    option_length_copy += ( uint32_t ) ( IP_HEADER_OCTET - ( ( uint32_t ) option_length % IP_HEADER_OCTET ) );
  }

  ip_header->ihl = ( ( ( sizeof( struct iphdr ) + option_length_copy ) / IP_HEADER_OCTET ) ) & 0xF;
  ip_header->version = IPVERSION;
  ip_header->tos = tos;
  ip_header->tot_len = Mhtons( ( uint16_t ) ip_length );
  ip_header->id = Mhtons( ( uint16_t ) identifier );
  ip_header->frag_off = Mhtons( flagment );
  ip_header->ttl = ttl;
  ip_header->protocol = protocol_number;
  ip_header->check = 0;
  ip_header->saddr = make_ip_address( random_data, source_ip_address, ip_type );
  ip_header->daddr = destination_ip_address;

  write_buffer += sizeof( struct iphdr );

  if ( option_length_copy != 0 ) {
    memcpy( write_buffer, option, option_length_copy );
  }

  packet_statistics->ip_check_sum = ( u_int ) calculate_crc( ( u_short * ) ip_header, ( u_int ) ( sizeof( struct iphdr ) + option_length ) );
  ip_header->check = ( uint16_t ) packet_statistics->ip_check_sum;

  dummy_header->ipv4_source_address = ip_header->saddr;
  dummy_header->ipv4_destination_address = ip_header->daddr;
  dummy_header->pad = 0;
  dummy_header->protocol_number = ip_header->protocol;

  return ( u_int ) ( sizeof( struct iphdr ) + option_length );
}


int
make_udp_header( struct random_data *random_data, UDP_PORT_CONTROL_POINTER source_port, UDP_PORT_CONTROL_POINTER destination_port, 
                 u_short port_type, u_short length, u_char *write_buffer, UDP_DUMMY_HEADER_POINTER dummy_header, STATISTICS_INFORMATION_POINTER packet_statistics ) {
  struct udphdr *udp_header = ( struct udphdr * ) write_buffer;

  udp_header->source = make_udp_port_number( random_data, source_port, port_type );
  port_type >>= 3;
  udp_header->dest = make_udp_port_number( random_data, destination_port, port_type );

  udp_header->len = Mhtons( length );

  dummy_header->udp_length = udp_header->len;
  udp_header->check = 0;
  packet_statistics->udp_check_sum = calculate_udp_crc( ( u_short * ) udp_header, length, ( u_short * ) dummy_header );
  udp_header->check = ( uint16_t ) packet_statistics->udp_check_sum;
  return sizeof( struct udphdr );
}


/**********************************************************************
 * PAYLOAD
 **********************************************************************/
u_short
make_payload( u_char *write_buffer, int *count, int type, int size, int count_num, int count_limit,
              u_char *mask, struct random_data *random_data ) {
  int write_position;
  int temp_count;
  int temp_add_count;
  u_char *buffer = write_buffer;
  u_int random_buffer;
  u_int random_mask;
  u_int random_include;

  if ( ( type & SOURCE_TYPE_INCREMENT ) ) {
    temp_count = buffer[ ( size - 1 ) ];
    temp_count += ( *count * count_num );
    temp_add_count = temp_count >> 8;
    buffer[ ( size - 1 ) ] = ( u_char ) temp_count;
    if ( temp_count > 0xff ) {
      for ( write_position = ( size - 2 ); write_position >= 0; write_position-- ) {
        temp_count = buffer[ write_position ];
        temp_count += temp_add_count;
        buffer[ write_position ] = ( u_char ) temp_count;
        if ( temp_count <= 0xff ) {
          break;
        }
        temp_add_count = temp_count >> 8;
      }
    }
  }
  else if ( ( type & SOURCE_TYPE_DECREMENT ) ) {
    temp_count = buffer[ ( size - 1 ) ];
    temp_count -= ( *count * count_num );
    buffer[ ( size - 1 ) ] = ( u_char ) temp_count;
    if ( temp_count < 0 ) {
      temp_add_count = ( ( temp_count * -1 ) >> 8 );
      for ( write_position = ( size - 2 ); write_position >= 0; write_position-- ) {
        temp_count = buffer[ write_position ];
        temp_count -= ( 1 + temp_add_count );
        buffer[ write_position ] = ( u_char ) temp_count;
        if ( temp_count >= 0 ) {
          break;
        }
        temp_add_count = ( ( temp_count * -1 ) >> 8 );
      }
    }
  }
  else if ( ( type & SOURCE_TYPE_RANDOM ) ) {
    if ( *count == 0 ) {
      *count += 1;
    }
    else {
      for ( write_position = 0; write_position < size; write_position += ( int ) sizeof( u_int ) ) {
        random_r( random_data, ( int32_t * ) &random_buffer );

        memcpy( &random_mask, mask, sizeof( u_int ) );
        random_mask = ntohl( random_mask );
        random_buffer &= ~random_mask;
        mask += sizeof( u_int );

        if ( ( size - write_position ) > ( int ) sizeof( u_int ) ) {
          memcpy( ( void * ) &random_include, buffer, sizeof( u_int ) );

          random_include = ntohl( random_include );

          random_include &= random_mask;
          random_include |= random_buffer;

          random_include = htonl( random_include );

          memcpy( buffer, &random_include, sizeof( u_int ) );
          buffer += sizeof( u_int );
        }
        else {
          memcpy( ( void * ) &random_include, buffer, ( size_t ) ( size - write_position ) );
          random_include = ntohl( random_include );
          random_include &= random_mask;
          random_include |= random_buffer;
          random_include = htonl( random_include );
          memcpy( buffer, &random_include, ( size_t ) ( size - write_position ) );
          buffer += ( size - write_position );
        }
      }
    }
  }
  if ( ( type & ( SOURCE_TYPE_INCREMENT | SOURCE_TYPE_DECREMENT ) ) ) {
    *count += 1;
    if ( ( count_limit != 0 ) && ( *count > count_limit ) ) {
      *count = 0;
    }
  }
  return calculate_crc( ( u_short * ) write_buffer, ( u_int ) size );
}


void
copy_payload( u_char *write_buffer, int payload_pattern_size, u_char *payload_pattern, int size ) {
  int lp;
  int copy_num;

  if ( payload_pattern_size == 0 ) {
    return;
  }

  copy_num = size / payload_pattern_size;

  for ( lp = 0; lp < copy_num; lp++ ) {
    memcpy( write_buffer, payload_pattern, ( size_t ) payload_pattern_size );
    write_buffer += payload_pattern_size;
  }
  if ( ( size % payload_pattern_size ) != 0 ) {
    memcpy( write_buffer, payload_pattern, ( size_t ) ( size % payload_pattern_size ) );
  }

  return;
}


/**********************************************************************
 * CRC
 **********************************************************************/
u_short
calculate_crc( u_short *buffer, u_int length ) {
  u_long check_sum = 0;

  while ( length > 1 ) {
    check_sum += *buffer++;
    length -= 2;
  }
  if ( length ) {
    check_sum += *( u_int8_t * ) buffer;
  }

  while ( ( check_sum & 0xffff0000 ) != 0 ) {
    check_sum = ( check_sum & 0xffff ) + ( check_sum >> 16 );  /* add overflow counts */
  }
  return ( u_short ) ~check_sum;
}


u_short
calculate_udp_crc( u_short *buffer, u_int length, u_short *dummy_header ) {
  u_long check_sum = 0;
  u_int dummy_header_length = sizeof( UDP_DUMMY_HEADER );

  while ( dummy_header_length > 1 ) {
    check_sum += *dummy_header++;
    dummy_header_length -= 2;
  }

  while ( length > 1 ) {
    check_sum += *buffer++;
    length -= 2;
  }
  if ( length ) {
    check_sum += *( u_int8_t * ) buffer;
  }

  while ( ( check_sum & 0xffff0000 ) != 0 ) {
    check_sum = ( check_sum & 0xffff ) + ( check_sum >> 16 );  /* add overflow counts */
  }
  return ( u_short ) ~check_sum;
}


/**********************************************************************
 * Packet Check
 **********************************************************************/
int
check_ip_header( STATISTICS_INFORMATION_POINTER read_buffer, u_char *packet, u_short *protocol_number,
                 u_int *ip_check_sum, u_int *udp_check_sum ) {
  struct iphdr *ip_header = ( struct iphdr * ) packet;
  struct udphdr *udp_header;
  int size;

  *ip_check_sum = 0;
  *udp_check_sum = 0;
  *protocol_number = ip_header->protocol;
  size = ( int ) ip_header->ihl * IP_HEADER_OCTET;
  *ip_check_sum = Mntohs( ip_header->check );
  if ( *protocol_number == IPPROTO_UDP ) {
    read_buffer->udp_header_offset = size + read_buffer->ip_header_offset;
    udp_header = ( struct udphdr * ) ( packet + size );
    *udp_check_sum = Mntohs( udp_header->check );
    size += ( int ) sizeof( struct udphdr );
  }

  return size;
}
