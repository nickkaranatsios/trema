#define __USE_GNU
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>
#include <netinet/tcp.h>
#include <netinet/ip.h>
#include <net/ethernet.h>
#include <string.h>
#include <pthread.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <fcntl.h>
#include <linux/if_packet.h>

#include "com_socket.h"
#include "packet.h"
#include "vhost_control.h"
#include "vhost_thread.h"
#include "vhost_layer_2.h"
#include "vhost_layer_3_4.h"
#include "cmn.h"

#include <pthread.h>
#include <sched.h>

static int vhost_num = 0;

extern VHOST_MANAGE_POINTER vhost_manage;

extern void vhost_add_send_control( int socket_fd, VHOST_SEND_REQUEST_DATA_CONTROL_POINTER send_information_pointer );

// for answer block alloc size
typedef union _answer_block_u {
  VHOST_CREATE_ANSWER_BLOCK create_answer;
  VHOST_ARP_CACHE_SET_ANSWER_BLOCK arp_cache_set_answer;
  VHOST_STOP_ANSWER_BLOCK etop_answer;
  VHOST_STATUS_ANSWER_BLOCK status_answer;
  VHOST_STATIC_ARP_ANSWER_BLOCK static_arp_answer;
  VHOST_ARP_GET_ANSWER_BLOCK arp_get_answer;
  VHOST_DYNAMIC_ARP_CLEAR_ANSWER_BLOCK dynamic_arp_clear_answer;
  VHOST_STATISTICS_CLEAR_ANSWER_BLOCK statistics_clear_anser;
  VHOST_SEND_ANSWER_BLOCK send_answer;
  VHOST_STATISTICS_ANSWER_BLOCK statistics_answer;
  VHOST_SEND_CANCEL_ANSWER_BLOCK cancel_answer;
} U_ANSWER_BLOCK;


int
vhost_make_send_socket( VHOST_MANAGE_POINTER vhost_manage_pointer ) {
  int socket_fd;
  int result;
  struct sockaddr_ll socketaddress_ll;

  // create raw socket
  socket_fd = socket( PF_PACKET, SOCK_RAW, Mhtons( ETH_P_ALL ) );
  // socket error
  if ( socket_fd < 0 ) {
    return -1;
  }

  memset( &vhost_manage_pointer->ifrequest, '\0', sizeof( struct ifreq ) );

  memcpy( vhost_manage_pointer->ifrequest.ifr_name, vhost_manage_pointer->vhost_control.send_interface, INTERFACE_NAME_LENGTH );

  result = ioctl( socket_fd, SIOCGIFINDEX, &vhost_manage_pointer->ifrequest );

  if ( result < 0 ) {
    close( socket_fd );
    return -1;
  }

  memset( &socketaddress_ll, 0x00, sizeof( struct sockaddr_ll ) );

  socketaddress_ll.sll_family = AF_PACKET;
  socketaddress_ll.sll_protocol = Mhtons( ETH_P_ALL );
  socketaddress_ll.sll_pkttype = PACKET_HOST;
  socketaddress_ll.sll_ifindex = vhost_manage_pointer->ifrequest.ifr_ifindex;
  result = bind( socket_fd, ( struct sockaddr * ) &socketaddress_ll, sizeof( struct sockaddr_ll ) );
  shutdown( socket_fd, SHUT_RD );

  if ( result < 0 ) {
    close( socket_fd );
    return -1;
  }
  vhost_manage_pointer->ifrequest.ifr_qlen = TX_QUEUE_LENGTH;
  if ( ioctl( socket_fd, SIOCSIFTXQLEN, ( void * ) &vhost_manage_pointer->ifrequest ) < 0 ) {
    return -1;
  }
  result = fcntl( socket_fd, F_SETFL, O_NONBLOCK );
  if ( result < 0 ) {
    close( socket_fd );
    return -1;
  }
  return socket_fd;
}


DEVICE_CONTROL_POINTER
vhost_create_receiver( u_char *reciever_device ) {
  int result;
  int ioctl_value;
  pthread_t pthread_control;
  u_char null_reciever_device[ VHOST_DEVICE_NAME_MAX ];
  DEVICE_CONTROL_POINTER vhost_device_control_pointer;
  cpu_set_t cpu_set;
  int socket_buffer_size;
  pthread_attr_t thread_attribute;

  // Create receiver thread
  // Get unused area
  memset( null_reciever_device, '\0', VHOST_DEVICE_NAME_MAX );
  vhost_device_control_pointer = vhost_search_receiver( null_reciever_device );

  // nothing device control area
  if ( vhost_device_control_pointer == NULL ) {
    return NULL;
  }

  // create raw socket
  vhost_device_control_pointer->socket_fd = socket( PF_PACKET, SOCK_RAW, Mhtons( ETH_P_ALL ) );
  // socket error
  if ( vhost_device_control_pointer->socket_fd < 0 ) {
    return NULL;
  }

  memset( &vhost_device_control_pointer->ifrequest, '\0', sizeof( struct ifreq ) );

  memcpy( vhost_device_control_pointer->ifrequest.ifr_name, reciever_device, INTERFACE_NAME_LENGTH );

  result = ioctl( vhost_device_control_pointer->socket_fd, SIOCGIFINDEX, &vhost_device_control_pointer->ifrequest );

  if ( result < 0 ) {
    close( vhost_device_control_pointer->socket_fd );
    return NULL;
  }

  memset( &vhost_device_control_pointer->socketaddress_ll, 0x00, sizeof( struct sockaddr_ll ) );

  // for recevei VLAN TCI
  ioctl_value = TPACKET_V2;
  setsockopt( vhost_device_control_pointer->socket_fd, SOL_PACKET, PACKET_VERSION,
    ( void * ) &ioctl_value, sizeof( ioctl_value ) );
  ioctl_value = 4; /* __be16  0x8100, __be16  h_vlan_TCI - before pg_vec has set, too */
  setsockopt( vhost_device_control_pointer->socket_fd, SOL_PACKET, PACKET_RESERVE,
    ( void * ) &ioctl_value, sizeof( ioctl_value ) );

  ioctl_value = 2;
  setsockopt( vhost_device_control_pointer->socket_fd, SOL_PACKET, PACKET_VERSION,
    ( void * ) &ioctl_value, sizeof( ioctl_value ) );
  ioctl_value = 1;
  setsockopt( vhost_device_control_pointer->socket_fd, SOL_PACKET, PACKET_AUXDATA,
    ( void * ) &ioctl_value, sizeof( ioctl_value ) );

  socket_buffer_size = ( 16 * 1024 * 1024 );
  setsockopt( vhost_device_control_pointer->socket_fd, SOL_PACKET, SO_RCVBUF,
    ( void * ) &socket_buffer_size, sizeof( socket_buffer_size ) );

  vhost_device_control_pointer->socketaddress_ll.sll_family = AF_PACKET;
  vhost_device_control_pointer->socketaddress_ll.sll_protocol = Mhtons( ETH_P_ALL );
  vhost_device_control_pointer->socketaddress_ll.sll_pkttype = PACKET_HOST;
  vhost_device_control_pointer->socketaddress_ll.sll_ifindex = vhost_device_control_pointer->ifrequest.ifr_ifindex;
  result = bind( vhost_device_control_pointer->socket_fd, ( struct sockaddr * ) &vhost_device_control_pointer->socketaddress_ll,
    sizeof( struct sockaddr_ll ) );

  shutdown( vhost_device_control_pointer->socket_fd, SHUT_WR );
  if ( result < 0 ) {
    close( vhost_device_control_pointer->socket_fd );
    return NULL;
  }
  result = fcntl( vhost_device_control_pointer->socket_fd, F_SETFL, O_NONBLOCK );
  if ( result < 0 ) {
    close( vhost_device_control_pointer->socket_fd );
    return NULL;
  }

  // thread create
  memcpy( vhost_device_control_pointer->device_name, reciever_device, INTERFACE_NAME_LENGTH );
  // wakeup vhost thread

  CPU_ZERO( &cpu_set );

  pthread_attr_init( &thread_attribute );

  CPU_SET( ( size_t ) vhost_device_control_pointer->device_number, &cpu_set );

  pthread_attr_setaffinity_np( &thread_attribute, sizeof( cpu_set ), &cpu_set );

  pthread_create( &pthread_control, &thread_attribute, vhost_receiver_main, ( void * ) vhost_device_control_pointer );

  return vhost_device_control_pointer;
}


size_t
vhost_create_request( VHOST_CREATE_REQUEST_BLOCK_POINTER vhost_create, u_char *result_pointer ) {
  int vhost_wake_num;
  pthread_t pthread_control;
  cpu_set_t cpu_set;
  pthread_attr_t thread_attribute;
  struct timespec sleep_timevalue;

  u_char vhost_name[ VHOST_NAME_MAX ];
  u_char reciever_device[ VHOST_DEVICE_NAME_MAX ];
  VHOST_CREATE_ANSWER_BLOCK_POINTER create_result = ( VHOST_CREATE_ANSWER_BLOCK_POINTER ) result_pointer;
  VHOST_MANAGE_POINTER vhost_manage_pointer;
  DEVICE_CONTROL_POINTER vhost_device_control_pointer;

  memset( vhost_name, '\0', VHOST_NAME_MAX );
  memcpy( vhost_name, vhost_create->header.vhost_name, MAX_VHOST_NAME_LENGTH );
  vhost_manage_pointer = vhost_search_vhostname( vhost_name );

  // make result header
  create_result->header.length = htonl( sizeof( VHOST_CREATE_ANSWER_BLOCK ) );
  create_result->header.command_code = htonl( VHOST_CREATE_ANSWER );
  memcpy( create_result->header.vhost_name, vhost_create->header.vhost_name, MAX_VHOST_NAME_LENGTH );

  // Duplicate check
  if ( vhost_manage_pointer != NULL ) {
    create_result->result = htonl( REQUEST_NG );
    return sizeof( VHOST_CREATE_ANSWER_BLOCK );
  }

  memset( vhost_name, '\0', VHOST_NAME_MAX );
  vhost_manage_pointer = vhost_search_vhostname( vhost_name );

  // no more vhost
  if ( vhost_manage_pointer == NULL ) {
    create_result->result = htonl( REQUEST_NG );
    return sizeof( VHOST_CREATE_ANSWER_BLOCK );
  }

  // search receiver
  memset( reciever_device, '\0', VHOST_DEVICE_NAME_MAX );
  memcpy( reciever_device, vhost_create->receive_interface, INTERFACE_NAME_LENGTH );
  vhost_device_control_pointer = vhost_search_receiver( reciever_device );

  // receiver is deactive
  if ( vhost_device_control_pointer == NULL ) {
    vhost_device_control_pointer = vhost_create_receiver( reciever_device );
  }
  if ( vhost_device_control_pointer == NULL ) {
    create_result->result = htonl( REQUEST_NG );
    return sizeof( VHOST_CREATE_ANSWER_BLOCK );
  }
  // create vhost configuration
  vhost_manage_pointer->receiver_pointer = vhost_device_control_pointer;

  pthread_mutex_lock( &vhost_manage_pointer->receiver_pointer->receiver_interface_mutex );

  vhost_wake_num = vhost_manage_pointer->receiver_pointer->vhost_connect_nums;
  pthread_mutex_unlock( &vhost_manage_pointer->receiver_pointer->receiver_interface_mutex );

  memcpy( vhost_manage_pointer->vhost_control.vhost_name,
    vhost_create->header.vhost_name, MAX_VHOST_NAME_LENGTH );

  vhost_manage_pointer->vhost_control.ipv4_address = vhost_create->ip_address;
  vhost_manage_pointer->vhost_control.ipv4_mask = vhost_create->netmask;
  memcpy( vhost_manage_pointer->vhost_control.host_mac_address, vhost_create->mac_address, MAC_ADDRESS_LENGTH );
  memcpy( vhost_manage_pointer->vhost_control.send_interface, vhost_create->send_interface, INTERFACE_NAME_LENGTH );
  memcpy( vhost_manage_pointer->vhost_control.receive_interface, vhost_create->receive_interface, INTERFACE_NAME_LENGTH );

  vhost_manage_pointer->socket_fd = vhost_make_send_socket( vhost_manage_pointer );

  vhost_manage_pointer->vhost_control.l2_type = Mntohs( vhost_create->l2_type );
  vhost_manage_pointer->vhost_control.vlan_id = Mntohs( vhost_create->vlan_id );
  vhost_manage_pointer->vhost_control.arp_cache_time = Mntohs( vhost_create->arp_cache_time );
  vhost_manage_pointer->vhost_control.generator_mode = ( int ) ntohl( vhost_create->generator_mode );
  vhost_manage_pointer->vhost_control.promisc_mode = Mntohs( vhost_create->promisc_mode );

  // add sender device
  memset( vhost_manage_pointer->sender_device_name, '\0', VHOST_DEVICE_NAME_MAX );
  memcpy( vhost_manage_pointer->sender_device_name, vhost_create->send_interface, INTERFACE_NAME_LENGTH );

  // wakeup vhost thread

  CPU_ZERO( &cpu_set );

  pthread_attr_init( &thread_attribute );

  CPU_SET( ( ( size_t ) ( vhost_manage_pointer->vhost_number % ( CPU_NUMBER_COREMAX - VHOST_DEVICE_MAX ) ) + VHOST_DEVICE_MAX ), &cpu_set );

  pthread_attr_setaffinity_np( &thread_attribute, sizeof( cpu_set ), &cpu_set );

  pthread_create( &pthread_control, &thread_attribute, vhost_thread_main, ( void * ) vhost_manage_pointer );

  // wait vhost thread wakeup
  sleep_timevalue.tv_nsec = VHOST_STATISTICS_WATCH_TIME;
  sleep_timevalue.tv_sec = 0;
  while ( 1 ) {
    if ( vhost_manage_pointer->receiver_pointer->vhost_connect_nums == ( vhost_wake_num + 1 ) ) {
      break;
    }
    nanosleep( &sleep_timevalue, NULL );
  }
  create_result->result = htonl( REQUEST_OK );

  vhost_num += 1;  // count up vhost num

  return sizeof( VHOST_CREATE_ANSWER_BLOCK );
}


void
vhost_send_my_status( VHOST_STATUS_REQUEST_BLOCK_POINTER search_requset_pointer, int socket_fd ) {
  int lp;
  u_char vhost_name[ VHOST_NAME_MAX ];
  u_char *answer_buffer;
  size_t size;
  int vhost_total_num = 0;
  PACKET_HEADER_POINTER packet_header_pointer;
  VHOST_STATUS_ANSWER_BLOCK_POINTER vhost_answer_pointer;
  u_char *vhost_name_pointer;
  VHOST_MANAGE_POINTER vhost_manage_pointer = &vhost_manage[ 0 ];

  size = sizeof( PACKET_HEADER ) + sizeof( VHOST_STATUS_ANSWER_BLOCK );
  if ( search_requset_pointer->request_code == htonl( VHOST_STATUS_REQUEST_VHOST ) ) {
    memset( vhost_name, '\0', VHOST_NAME_MAX );
    memcpy( vhost_name, search_requset_pointer->header.vhost_name, MAX_VHOST_NAME_LENGTH );
    vhost_manage_pointer = vhost_search_vhostname( vhost_name );
    if ( vhost_manage_pointer != NULL ) {
      size += MAX_VHOST_NAME_LENGTH;
      vhost_total_num = 1;
    }
  }
  else {
    size += ( size_t ) ( vhost_num * MAX_VHOST_NAME_LENGTH );
    vhost_total_num = vhost_num;
  }

  answer_buffer = calloc( 1, size );

  if ( answer_buffer == NULL ) {
    // no more memory
    return;
  }

  packet_header_pointer = ( PACKET_HEADER_POINTER ) answer_buffer;
  packet_header_pointer->size = htonl( ( u_int ) size );
  packet_header_pointer->packet_num = htonl( 1 );

  vhost_answer_pointer = ( VHOST_STATUS_ANSWER_BLOCK_POINTER ) ( ( u_char * ) answer_buffer + sizeof( PACKET_HEADER ) );
  vhost_answer_pointer->vhost_num = htonl( ( u_int ) vhost_total_num );
  vhost_answer_pointer->header.length = htonl( ( u_int ) ( sizeof( VHOST_STATUS_ANSWER_BLOCK ) + ( ( u_int ) vhost_num * MAX_VHOST_NAME_LENGTH ) ) );
  vhost_answer_pointer->header.command_code = htonl( VHOST_STATUS_ANSWER );

  vhost_name_pointer = answer_buffer + sizeof( PACKET_HEADER ) + sizeof( VHOST_STATUS_ANSWER_BLOCK );
  if ( search_requset_pointer->request_code == htonl( VHOST_STATUS_REQUEST_ALL ) ) {
    if ( vhost_total_num != 0 ) {
      for ( lp = 0; lp < MAX_THREADS; lp++, vhost_manage_pointer++ ) {
        if ( vhost_manage_pointer->vhost_control.vhost_name[ 0 ] != '\0' ) {
          memcpy( vhost_name_pointer, vhost_manage_pointer->vhost_control.vhost_name, MAX_VHOST_NAME_LENGTH );
          vhost_name_pointer += MAX_VHOST_NAME_LENGTH;
        }
      }
    }
  }
  else {
    if ( vhost_total_num != 0 ) {
      memcpy( vhost_name_pointer, vhost_manage_pointer->vhost_control.vhost_name, MAX_VHOST_NAME_LENGTH );
    }
  }

  com_socket_send( socket_fd, answer_buffer, size );
  free( answer_buffer );
}


void
vhost_send_complete( int socket_fd, VHOST_SEND_REQUEST_DATA_CONTROL_POINTER send_information ) {
  int ng_num = 0;
  VHOST_SEND_NG_INFORMATION_CONTROL_POINTER send_ng_control;
  PACKET_HEADER_POINTER packet_header_pointer;
  VHOST_SEND_NG_INFORMATION_BLOCK_POINTER send_ng_control_pointer;
  VHOST_SEND_END_RESPONSE_BLOCK_POINTER send_complete_responce_pointer;
  size_t send_size;
  u_char *result_buffer;

  send_ng_control = send_information->send_ng_queue.head;
  while ( send_ng_control != NULL ) {
    ng_num += 1;
    send_ng_control = send_ng_control->next;
  }
  send_size = sizeof( PACKET_HEADER ) + sizeof( VHOST_SEND_END_RESPONSE_BLOCK );
  if ( ng_num ) {
    send_size += ( size_t ) ng_num * sizeof( VHOST_SEND_NG_INFORMATION_BLOCK );
  }
  result_buffer = ( u_char * ) calloc( 1, send_size );

  if ( result_buffer == NULL ) {
    // no more memory
    return;
  }
  packet_header_pointer = ( PACKET_HEADER_POINTER ) result_buffer;
  packet_header_pointer->size = htonl( ( u_int ) send_size );
  packet_header_pointer->packet_num = htonl( ( u_int ) ( ng_num + 1 ) );
  send_ng_control_pointer = ( VHOST_SEND_NG_INFORMATION_BLOCK_POINTER ) ( ( u_char * ) result_buffer + sizeof( PACKET_HEADER ) );
  while ( send_information->send_ng_queue.head != NULL ) {
    send_ng_control = send_information->send_ng_queue.head;

    memcpy( send_ng_control_pointer, &send_ng_control->ng_information, sizeof( VHOST_SEND_NG_INFORMATION_BLOCK ) );

    send_ng_control_pointer->header.length = htonl( sizeof( VHOST_SEND_NG_INFORMATION_BLOCK ) );
    send_ng_control_pointer->header.command_code = htonl( VHOST_SEND_INCOMPLETEL_NOTICE );

    memcpy( send_ng_control_pointer->header.vhost_name,
            send_information->vhost_manage_pointer->vhost_control.vhost_name,
            MAX_VHOST_NAME_LENGTH );

    send_information->send_ng_queue.head = send_ng_control->next;
    if ( send_information->send_ng_queue.head == NULL ) {
      send_information->send_ng_queue.tail = NULL;
    }

    free( send_ng_control );
    send_ng_control_pointer += 1;
  }
  send_complete_responce_pointer = ( VHOST_SEND_END_RESPONSE_BLOCK_POINTER ) send_ng_control_pointer;
  send_complete_responce_pointer->header.length = htonl( sizeof( VHOST_SEND_END_RESPONSE_BLOCK ) );
  send_complete_responce_pointer->header.command_code = htonl( VHOST_SEND_RESPONCE );
  memcpy( send_complete_responce_pointer->header.vhost_name,
          send_information->vhost_manage_pointer->vhost_control.vhost_name,
          MAX_VHOST_NAME_LENGTH );

  com_socket_send( socket_fd, result_buffer, send_size );
  free( result_buffer );
}


void
vhost_send_cancel( VHOST_MANAGE_POINTER vhost_manage_pointer, int cancel_number ) {
  struct timespec sleep_timevalue;

  vhost_manage_pointer->send_information[ cancel_number ].stop_req = TRUE;

  // wait vhost thread down
  sleep_timevalue.tv_nsec = VHOST_STATISTICS_WATCH_TIME;
  sleep_timevalue.tv_sec = 0;
  while ( 1 ) {
    if ( vhost_manage_pointer->send_information[ cancel_number ].send_status == FALSE ) {
      break;
    }
    nanosleep( &sleep_timevalue, NULL );
  }
}


void
vhost_stop( VHOST_MANAGE_POINTER vhost_manage_pointer ) {
  DEVICE_CONTROL_POINTER receiver_pointer;
  int vhost_wake_num;
  int lp;

  vhost_num -= 1;
  struct timespec sleep_timevalue;

  pthread_mutex_lock( &vhost_manage_pointer->receiver_pointer->receiver_interface_mutex );

  // get receiver control vhost
  vhost_wake_num = vhost_manage_pointer->receiver_pointer->vhost_connect_nums;
  receiver_pointer = vhost_manage_pointer->receiver_pointer;

  pthread_mutex_unlock( &vhost_manage_pointer->receiver_pointer->receiver_interface_mutex );

  // vhost sending ?
  for ( lp = 0; lp < SEND_REQUEST_ACCEPT_MAX; lp++ ) {
    if ( vhost_manage_pointer->send_information[ lp ].send_status == TRUE ) {
      vhost_send_cancel( vhost_manage_pointer, lp );
    }
  }

  vhost_manage_pointer->stop_req = TRUE;
  pthread_cond_signal( &vhost_manage_pointer->receiver_interface_cond );

  // wait vhost thread down
  sleep_timevalue.tv_nsec = VHOST_STATISTICS_WATCH_TIME;
  sleep_timevalue.tv_sec = 0;
  while ( 1 ) {
    if ( receiver_pointer->vhost_connect_nums == ( vhost_wake_num - 1 ) ) {
      break;
    }
    nanosleep( &sleep_timevalue, NULL );
  }

  // my vhost only ?
  if ( receiver_pointer->vhost_connect_nums == 0 ) {
    receiver_pointer->stop_req = TRUE;
    // wait receiver thread down
    sleep_timevalue.tv_nsec = VHOST_STATISTICS_WATCH_TIME;
    sleep_timevalue.tv_sec = 0;
    while ( 1 ) {
      if ( receiver_pointer->socket_fd == -1 ) {
        break;
      }
      nanosleep( &sleep_timevalue, NULL );
    }
  }
  close( vhost_manage_pointer->socket_fd );
}


size_t
vhost_stop_request( VHOST_STOP_REQUEST_BLOCK_POINTER vhost_stop_request_block_pointer, u_char *result_pointer ) {
  u_char vhost_name[ VHOST_NAME_MAX ];
  VHOST_STOP_ANSWER_BLOCK_POINTER delete_result = ( VHOST_STOP_ANSWER_BLOCK_POINTER ) result_pointer;
  VHOST_MANAGE_POINTER vhost_manage_pointer;
  int lp;

  memset( vhost_name, '\0', VHOST_NAME_MAX );
  memcpy( vhost_name, vhost_stop_request_block_pointer->header.vhost_name, MAX_VHOST_NAME_LENGTH );

  // make result header
  delete_result->header.length = htonl( sizeof( VHOST_STOP_ANSWER_BLOCK ) );
  delete_result->header.command_code = htonl( VHOST_STOP_ANSWER );
  memcpy( delete_result->header.vhost_name, vhost_stop_request_block_pointer->header.vhost_name, MAX_VHOST_NAME_LENGTH );

  vhost_manage_pointer = vhost_search_vhostname( vhost_name );
  if ( vhost_manage_pointer == NULL ) {
    delete_result->result = htonl( REQUEST_NG );
    return sizeof( VHOST_STATUS_ANSWER_BLOCK );
  }

  // vhost sending ?
  for ( lp = 0; lp < SEND_REQUEST_ACCEPT_MAX; lp++ ) {
    if ( vhost_manage_pointer->send_information[ lp ].send_status == TRUE ) {
      delete_result->result = htonl( REQUEST_NG );
      return sizeof( VHOST_STATUS_ANSWER_BLOCK );
    }
  }
  vhost_stop( vhost_manage_pointer );
  delete_result->result = htonl( REQUEST_OK );
  return sizeof( VHOST_STATUS_ANSWER_BLOCK );
}


size_t
vhost_statistics_clear_request( VHOST_STATISTICS_CLEAR_REQUEST_BLOCK_POINTER statistics_clear_request, u_char *result_pointer ) {
  u_char vhost_name[ VHOST_NAME_MAX ];
  VHOST_STATISTICS_CLEAR_ANSWER_BLOCK_POINTER statistics_clear_result = ( VHOST_STATISTICS_CLEAR_ANSWER_BLOCK_POINTER ) result_pointer;
  VHOST_MANAGE_POINTER vhost_manage_pointer;

  memset( vhost_name, '\0', VHOST_NAME_MAX );
  memcpy( vhost_name, statistics_clear_request->header.vhost_name, MAX_VHOST_NAME_LENGTH );

  // make result header
  statistics_clear_result->header.length = htonl( sizeof( VHOST_STATISTICS_CLEAR_ANSWER_BLOCK ) );
  statistics_clear_result->header.command_code = htonl( VHOST_STATISTICS_CLEAR_ANSWER );
  memcpy( statistics_clear_result->header.vhost_name, statistics_clear_request->header.vhost_name, MAX_VHOST_NAME_LENGTH );

  vhost_manage_pointer = vhost_search_vhostname( vhost_name );
  if ( vhost_manage_pointer == NULL ) {
    statistics_clear_result->result = htonl( REQUEST_NG );
    return sizeof( VHOST_STATISTICS_CLEAR_ANSWER_BLOCK );
  }

  vhost_clear_statistics( vhost_manage_pointer, ( int ) ntohl( statistics_clear_request->type ) );
  statistics_clear_result->result = htonl( REQUEST_OK );
  return sizeof( VHOST_STATISTICS_CLEAR_ANSWER_BLOCK );
}


u_char *
vhost_statistics_result( int packet_type,
  VHOST_STATISTICS_CONTROL_POINTER statistics_control_pointer,
  u_char *result_data_offset, u_int *total_size ) {
  int lp;
  VHOST_STATISTICS_DATA statistics_answer_header;
  VHOST_STATISTICS_POINTER statistics_pointer;

  for ( lp = 0; lp < STATISTICS_CONTROL_MAX; lp++, statistics_control_pointer++ ) {
    if ( statistics_control_pointer->head != NULL ) {
      statistics_pointer = statistics_control_pointer->head;
      while ( statistics_pointer != NULL ) {
        // make &copy statistics header
        statistics_answer_header.data_length = htonl( ( ( u_int ) sizeof( VHOST_STATISTICS_DATA ) + ( u_int ) statistics_pointer->statistics.packet_bytes ) );
        statistics_answer_header.packet_length = htonl( ( u_int ) statistics_pointer->statistics.packet_bytes );
        statistics_answer_header.ip_header_offset = htonl( ( u_int ) statistics_pointer->statistics.ip_header_offset );
        statistics_answer_header.udp_header_offset = htonl( ( u_int ) statistics_pointer->statistics.udp_header_offset );
        statistics_answer_header.payload_hash = htonl( ( u_int ) statistics_pointer->statistics.packet_check_sum );

        statistics_answer_header.packet_data_byte = htonll( statistics_pointer->statistics.receive_total_bytes );
        statistics_answer_header.packet_number = htonll( statistics_pointer->statistics.receive_total_packets );
        statistics_answer_header.packet_type = htonl( ( u_int ) packet_type );

        memcpy( result_data_offset, &statistics_answer_header, sizeof( VHOST_STATISTICS_DATA ) );
        result_data_offset += sizeof( VHOST_STATISTICS_DATA );

        // copy &copy statistics header
        memcpy( result_data_offset, statistics_pointer->statistics.packet_buffer, ( size_t ) statistics_pointer->statistics.packet_bytes );
        result_data_offset += statistics_pointer->statistics.packet_bytes;

        *total_size += ( u_int ) sizeof( VHOST_STATISTICS_DATA ) + ( u_int ) statistics_pointer->statistics.packet_bytes;

        statistics_pointer = statistics_pointer->next;
      }
    }
  }
  return result_data_offset;
}


void
vhost_get_statistics_request( int socket_fd, VHOST_STATISTICS_REQUEST_BLOCK_POINTER vhost_statistics_request ) {
  size_t size;
  u_int total_packet_num;
  u_int total_packet_size;
  u_char vhost_name[ VHOST_NAME_MAX ];
  u_char *result_buffer;
  u_char *result_data_offset;
  PACKET_HEADER_POINTER packet_header;
  VHOST_MANAGE_POINTER vhost_manage_pointer;
  VHOST_STATISTICS_ANSWER_BLOCK_POINTER statistics_answer_block;

  memset( vhost_name, '\0', VHOST_NAME_MAX );
  memcpy( vhost_name, vhost_statistics_request->header.vhost_name, MAX_VHOST_NAME_LENGTH );

  vhost_manage_pointer = vhost_search_vhostname( vhost_name );

  size = sizeof( VHOST_STATISTICS_ANSWER_BLOCK ) + sizeof( PACKET_HEADER );
  if ( vhost_manage_pointer == NULL ) {
    result_buffer = ( u_char * ) calloc( 1, size );
    if ( result_buffer == NULL ) {
      // no more memory
      return;
    }
    packet_header = ( PACKET_HEADER_POINTER ) result_buffer;
    statistics_answer_block = ( VHOST_STATISTICS_ANSWER_BLOCK_POINTER ) &result_buffer[ sizeof( PACKET_HEADER ) ];
    packet_header->size = htonl( ( u_int ) size );
    packet_header->packet_num = htonl( 1 );
    memcpy( statistics_answer_block->header.vhost_name, vhost_statistics_request->header.vhost_name, MAX_VHOST_NAME_LENGTH );
    statistics_answer_block->statistics_all_number = 0;
    statistics_answer_block->statistics_position = 0;
    statistics_answer_block->header.length = htonl( sizeof( VHOST_STATISTICS_ANSWER_BLOCK ) );
    statistics_answer_block->header.command_code = htonl( VHOST_STATISTICS_GET_ANSWER );

    com_socket_send( socket_fd, result_buffer, size );
    free( result_buffer );
    return;
  }

  pthread_mutex_lock( &vhost_manage_pointer->send_statistics_interface_mutex );
  pthread_mutex_lock( &vhost_manage_pointer->receive_statistics_interface_mutex );

  total_packet_num = ( u_int ) vhost_manage_pointer->receive_statistics_packet_num + ( u_int ) vhost_manage_pointer->send_statistics_packet_num;

  size += sizeof( VHOST_STATISTICS_DATA ) * total_packet_num;

  size += MAX_RECEIVE_BUFFER_SIZE * total_packet_num;

  result_buffer = ( u_char * ) calloc( 1, size );
  if ( result_buffer == NULL ) {
    // no more memory
    pthread_mutex_unlock( &vhost_manage_pointer->receive_statistics_interface_mutex );
    pthread_mutex_unlock( &vhost_manage_pointer->send_statistics_interface_mutex );
    return;
  }

  packet_header = ( PACKET_HEADER_POINTER ) result_buffer;
  statistics_answer_block = ( VHOST_STATISTICS_ANSWER_BLOCK_POINTER ) &result_buffer[ sizeof( PACKET_HEADER ) ];

  statistics_answer_block->statistics_all_number = htonl( total_packet_num );
  statistics_answer_block->statistics_position = 0;

  total_packet_size = 0;
  result_data_offset = result_buffer + sizeof( PACKET_HEADER ) + sizeof( VHOST_STATISTICS_ANSWER_BLOCK );

  result_data_offset = vhost_statistics_result( VHOST_STATISTICS_TYPE_SEND,
    &vhost_manage_pointer->send_statistics_control_head[ 0 ],
    result_data_offset, &total_packet_size );

  result_data_offset = vhost_statistics_result( VHOST_STATISTICS_TYPE_RECEIVE,
    &vhost_manage_pointer->receive_statistics_control_head[ 0 ],
    result_data_offset, &total_packet_size );

  pthread_mutex_unlock( &vhost_manage_pointer->receive_statistics_interface_mutex );
  pthread_mutex_unlock( &vhost_manage_pointer->send_statistics_interface_mutex );

  packet_header = ( PACKET_HEADER_POINTER ) result_buffer;
  statistics_answer_block = ( VHOST_STATISTICS_ANSWER_BLOCK_POINTER ) &result_buffer[ sizeof( PACKET_HEADER ) ];

  packet_header->size = htonl( ( u_int ) total_packet_size + ( u_int ) sizeof( PACKET_HEADER ) + ( u_int ) sizeof( VHOST_STATISTICS_ANSWER_BLOCK ) );
  packet_header->packet_num = htonl( 1 );
  memcpy( statistics_answer_block->header.vhost_name, vhost_statistics_request->header.vhost_name, MAX_VHOST_NAME_LENGTH );

  statistics_answer_block->header.length = htonl( ( u_int ) sizeof( VHOST_STATISTICS_ANSWER_BLOCK ) + ( u_int ) total_packet_size );
  statistics_answer_block->header.command_code = htonl( VHOST_STATISTICS_GET_ANSWER );

  com_socket_send( socket_fd, result_buffer, total_packet_size + sizeof( PACKET_HEADER ) + sizeof( VHOST_STATISTICS_ANSWER_BLOCK ) );

  free( result_buffer );
}


size_t
vhost_arp_cache_request( VHOST_ARP_CACHE_SET_REQUEST_BLOCK_POINTER arp_cache_request, u_char *result_pointer ) {
  u_char vhost_name[ VHOST_NAME_MAX ];
  VHOST_ARP_CACHE_SET_ANSWER_BLOCK_POINTER arp_cache_set_result = ( VHOST_ARP_CACHE_SET_ANSWER_BLOCK_POINTER ) result_pointer;
  VHOST_MANAGE_POINTER vhost_manage_pointer;

  memset( vhost_name, '\0', VHOST_NAME_MAX );
  memcpy( vhost_name, arp_cache_request->header.vhost_name, MAX_VHOST_NAME_LENGTH );

  // make result header
  arp_cache_set_result->header.length = htonl( sizeof( VHOST_STATISTICS_CLEAR_ANSWER_BLOCK ) );
  arp_cache_set_result->header.command_code = htonl( VHOST_ARP_CACHE_ANSWER );
  memcpy( arp_cache_set_result->header.vhost_name, arp_cache_request->header.vhost_name, MAX_VHOST_NAME_LENGTH );

  vhost_manage_pointer = vhost_search_vhostname( vhost_name );
  if ( vhost_manage_pointer == NULL ) {
    arp_cache_set_result->result = htonl( REQUEST_NG );
    return sizeof( VHOST_ARP_CACHE_SET_ANSWER_BLOCK );
  }

  vhost_manage_pointer->vhost_control.arp_cache_time = ( u_short ) ntohl( arp_cache_request->arp_cache_time );
  arp_cache_set_result->result = htonl( REQUEST_OK );
  return sizeof( VHOST_ARP_CACHE_SET_ANSWER_BLOCK );
}


size_t
vhost_clear_dynamic_arp( VHOST_DYNAMIC_ARP_CLEAR_REQUEST_BLOCK_POINTER dynamic_arp_clear_request, u_char *result_pointer ) {
  u_int hash_value;
  int lp;
  u_char vhost_name[ VHOST_NAME_MAX ];
  VHOST_DYNAMIC_ARP_CLEAR_ANSWER_BLOCK_POINTER dynamic_arp_clear_answer = ( VHOST_DYNAMIC_ARP_CLEAR_ANSWER_BLOCK_POINTER ) result_pointer;
  VHOST_MANAGE_POINTER vhost_manage_pointer;
  VHOST_ARP_DATA_POINTER search_pointer;

  memset( vhost_name, '\0', VHOST_NAME_MAX );
  memcpy( vhost_name, dynamic_arp_clear_request->header.vhost_name, MAX_VHOST_NAME_LENGTH );

  // make result header
  dynamic_arp_clear_answer->header.length = htonl( sizeof( VHOST_DYNAMIC_ARP_CLEAR_ANSWER_BLOCK ) );
  dynamic_arp_clear_answer->header.command_code = htonl( VHOST_DYNAMIC_ARP_CLEAR_ANSWER );
  memcpy( dynamic_arp_clear_answer->header.vhost_name, dynamic_arp_clear_request->header.vhost_name, MAX_VHOST_NAME_LENGTH );

  vhost_manage_pointer = vhost_search_vhostname( vhost_name );
  if ( vhost_manage_pointer == NULL ) {
    dynamic_arp_clear_answer->result = htonl( REQUEST_NG );
    return sizeof( VHOST_DYNAMIC_ARP_CLEAR_ANSWER_BLOCK );
  }

  if ( dynamic_arp_clear_request->mode == Mhtons( VHOST_DYNAMIC_ARP_INDIVIDUALLY ) ) {
    hash_value = vhost_arp_hash( dynamic_arp_clear_request->ipv4_address );
    pthread_mutex_lock( &vhost_manage_pointer->arp_interface_mutex );
    search_pointer = vhost_manage_pointer->arp_control_head[ hash_value ].head;
    while ( search_pointer != NULL ) {
      if ( memcmp( search_pointer->arp_cache.mac_address, dynamic_arp_clear_request->mac_address, MAC_ADDRESS_LENGTH ) == 0 ) {
        if ( ( dynamic_arp_clear_request->ipv4_address == search_pointer->arp_cache.ipv4_address )
           && ( ( search_pointer->arp_cache.vlan_info & STATIC_ARP_ENTRY ) == 0 ) ) {
          arp_entry_delete( &vhost_manage_pointer->arp_control_head[ hash_value ], search_pointer );
          vhost_manage_pointer->arp_number -= 1;
          break;
        }
      }
      search_pointer = search_pointer->next;
    }

    pthread_mutex_unlock( &vhost_manage_pointer->arp_interface_mutex );
  }
  else {
    pthread_mutex_lock( &vhost_manage_pointer->arp_interface_mutex );
    for ( lp = 0; lp < ARP_HASH_MAX; lp++ ) {
      search_pointer = vhost_manage_pointer->arp_control_head[ lp ].head;
      while ( search_pointer != NULL ) {
        if ( ( search_pointer->arp_cache.vlan_info & STATIC_ARP_ENTRY ) == 0 ) {
          arp_entry_delete( &vhost_manage_pointer->arp_control_head[ lp ],
            vhost_manage_pointer->arp_control_head[ lp ].head );
          vhost_manage_pointer->arp_number -= 1;
          search_pointer = vhost_manage_pointer->arp_control_head[ lp ].head;
        }
        else {
          search_pointer = search_pointer->next;
        }
      }
    }

    pthread_mutex_unlock( &vhost_manage_pointer->arp_interface_mutex );
  }

  dynamic_arp_clear_answer->result = htonl( REQUEST_OK );
  return sizeof( VHOST_DYNAMIC_ARP_CLEAR_ANSWER_BLOCK );
}


size_t
vhost_static_arp_entry( VHOST_STATIC_ARP_REQUEST_BLOCK_POINTER static_arp_request, u_char *result_pointer ) {
  u_int hash_value;
  u_char vhost_name[ VHOST_NAME_MAX ];
  VHOST_STATIC_ARP_ANSWER_BLOCK_POINTER static_arp_answer = ( VHOST_STATIC_ARP_ANSWER_BLOCK_POINTER ) result_pointer;
  VHOST_MANAGE_POINTER vhost_manage_pointer;
  VHOST_ARP_DATA_POINTER arp_entry_pointer;

  memset( vhost_name, '\0', VHOST_NAME_MAX );
  memcpy( vhost_name, static_arp_request->header.vhost_name, MAX_VHOST_NAME_LENGTH );

  // make result header
  static_arp_answer->header.length = htonl( sizeof( VHOST_STATIC_ARP_ANSWER_BLOCK ) );
  static_arp_answer->header.command_code = htonl( VHOST_STATIC_ARP_ANSWER );

  memcpy( static_arp_answer->header.vhost_name, static_arp_request->header.vhost_name, MAX_VHOST_NAME_LENGTH );

  vhost_manage_pointer = vhost_search_vhostname( vhost_name );

  if ( vhost_manage_pointer == NULL ) {
    static_arp_answer->result = htonl( REQUEST_NG );
    return sizeof( VHOST_STATIC_ARP_ANSWER_BLOCK );
  }

  if ( static_arp_request->mode == htonl( VHOST_STATIC_ARP_SET ) ) {
    arp_entry_pointer = ( VHOST_ARP_DATA_POINTER ) calloc( 1, sizeof( VHOST_ARP_DATA ) );

    if ( arp_entry_pointer == NULL ) {
      // no more memory
      static_arp_answer->result = htonl( REQUEST_NG );
      return sizeof( VHOST_STATIC_ARP_ANSWER_BLOCK );
    }

    memcpy( arp_entry_pointer->arp_cache.mac_address, static_arp_request->mac_address, MAC_ADDRESS_LENGTH );
    arp_entry_pointer->arp_cache.ipv4_address = static_arp_request->ipv4_address;
    arp_entry_pointer->arp_cache.vlan_info = vhost_manage_pointer->vhost_control.vlan_id | STATIC_ARP_ENTRY;
    vhost_arp_add( &vhost_manage_pointer->arp_control_head[ 0 ], arp_entry_pointer,
      &vhost_manage_pointer->arp_interface_mutex, &vhost_manage_pointer->arp_number,
      0 );
  }
  // remove
  else {
    hash_value = vhost_arp_hash( static_arp_request->ipv4_address );
    pthread_mutex_lock( &vhost_manage_pointer->arp_interface_mutex );
    arp_entry_pointer = vhost_manage_pointer->arp_control_head[ hash_value ].head;
    while ( arp_entry_pointer != NULL ) {
      if ( memcmp( arp_entry_pointer->arp_cache.mac_address, static_arp_request->mac_address, MAC_ADDRESS_LENGTH ) == 0 ) {
        if ( ( static_arp_request->ipv4_address == arp_entry_pointer->arp_cache.ipv4_address )
           && ( ( arp_entry_pointer->arp_cache.vlan_info & STATIC_ARP_ENTRY ) == STATIC_ARP_ENTRY ) ) {
          arp_entry_delete( &vhost_manage_pointer->arp_control_head[ hash_value ], arp_entry_pointer );
          vhost_manage_pointer->arp_number -= 1;
          break;
        }
      }
      arp_entry_pointer = arp_entry_pointer->next;
    }

    pthread_mutex_unlock( &vhost_manage_pointer->arp_interface_mutex );
  }

  static_arp_answer->result = htonl( REQUEST_OK );
  return sizeof( VHOST_STATIC_ARP_ANSWER_BLOCK );
}


void
vhost_request_arp_data( VHOST_ARP_GET_REQUEST_BLOCK_POINTER arp_get_request, int socket_fd ) {
  u_char vhost_name[ VHOST_NAME_MAX ];
  PACKET_HEADER_POINTER packet_header;
  int lp;
  unsigned long long real_arp_counter = 0;

  VHOST_ARP_GET_ANSWER_BLOCK_POINTER arp_get_answer_pointer;
  VHOST_MANAGE_POINTER vhost_manage_pointer;
  u_char *result_buffer;
  u_char *next_write_pointer;
  VHOST_ARP_CONTROL_BLOCK vhost_arp_information;
  VHOST_ARP_DATA_POINTER vhost_current_arp_data;


  size_t total_size;

  total_size = sizeof( PACKET_HEADER ) + sizeof( VHOST_ARP_GET_ANSWER_BLOCK );

  memset( vhost_name, '\0', VHOST_NAME_MAX );
  memcpy( vhost_name, arp_get_request->header.vhost_name, MAX_VHOST_NAME_LENGTH );

  vhost_manage_pointer = vhost_search_vhostname( vhost_name );

  if ( vhost_manage_pointer == NULL ) {
    result_buffer = ( u_char * ) calloc( 1, total_size );
    if ( result_buffer == NULL ) {
      // no more memory
      return;
    }
    packet_header = ( PACKET_HEADER_POINTER ) result_buffer;
    packet_header->size = htonl( ( u_short ) total_size );
    packet_header->packet_num = htonl( 1 );
    arp_get_answer_pointer = ( VHOST_ARP_GET_ANSWER_BLOCK_POINTER ) ( ( u_char * ) result_buffer + sizeof( PACKET_HEADER ) );
    memcpy( arp_get_answer_pointer->header.vhost_name, arp_get_request->header.vhost_name, MAX_VHOST_NAME_LENGTH );

    arp_get_answer_pointer->header.command_code = htonl( VHOST_ARP_INFORMATION_ANSWER );
    arp_get_answer_pointer->arp_total = 0;
    arp_get_answer_pointer->arp_offset = 0;

    com_socket_send( socket_fd, result_buffer, total_size );
    free( result_buffer );
    return;
  }
  pthread_mutex_lock( &vhost_manage_pointer->arp_interface_mutex );
  total_size += ( size_t ) ( sizeof( VHOST_ARP_CONTROL_BLOCK ) * vhost_manage_pointer->arp_number );
  result_buffer = ( u_char * ) calloc( 1, total_size );
  if ( result_buffer == NULL ) {
    // no more memory
    pthread_mutex_unlock( &vhost_manage_pointer->arp_interface_mutex );
    return;
  }

  packet_header = ( PACKET_HEADER_POINTER ) result_buffer;
  packet_header->size = htonl( ( u_int ) total_size );
  packet_header->packet_num = htonl( 1 );
  arp_get_answer_pointer = ( VHOST_ARP_GET_ANSWER_BLOCK_POINTER ) ( ( u_char * ) result_buffer + sizeof( PACKET_HEADER ) );
  memcpy( arp_get_answer_pointer->header.vhost_name, arp_get_request->header.vhost_name, MAX_VHOST_NAME_LENGTH );

  arp_get_answer_pointer->header.command_code = htonl( VHOST_ARP_INFORMATION_ANSWER );
  arp_get_answer_pointer->arp_offset = 0;
  real_arp_counter = vhost_manage_pointer->arp_number;
  next_write_pointer = result_buffer + sizeof( PACKET_HEADER ) + sizeof( VHOST_ARP_GET_ANSWER_BLOCK );
  for ( lp = 0; lp < ARP_HASH_MAX; lp++ ) {
    if ( vhost_manage_pointer->arp_control_head[ lp ].head != NULL ) {
      vhost_current_arp_data = vhost_manage_pointer->arp_control_head[ lp ].head;
      while ( vhost_current_arp_data != NULL ) {
        if ( ( vhost_current_arp_data->arp_cache.vlan_info & TEMPORARY_REGISTRATION_ARP_ENTRY ) == TEMPORARY_REGISTRATION_ARP_ENTRY ) {
          real_arp_counter -= 1;
          vhost_current_arp_data = vhost_current_arp_data->next;
          continue;
        }
        vhost_arp_information.vlan_id = Mhtons( vhost_current_arp_data->arp_cache.vlan_info );
        vhost_arp_information.ipv4_address = vhost_current_arp_data->arp_cache.ipv4_address;
        vhost_arp_information.arp_expire_time = htonl( ( u_int ) vhost_current_arp_data->arp_cache.ageout_time );
        memcpy( &vhost_arp_information.mac_address, vhost_current_arp_data->arp_cache.mac_address, MAC_ADDRESS_LENGTH );
        memcpy( next_write_pointer, &vhost_arp_information, sizeof( vhost_arp_information ) );
        next_write_pointer += sizeof( vhost_arp_information );
        vhost_current_arp_data = vhost_current_arp_data->next;
      }
    }
  }
  total_size = sizeof( PACKET_HEADER ) + sizeof( VHOST_ARP_GET_ANSWER_BLOCK );
  total_size += ( size_t ) ( sizeof( VHOST_ARP_CONTROL_BLOCK ) * real_arp_counter );

  packet_header->size = htonl( ( u_int ) total_size );

  arp_get_answer_pointer->arp_total = htonll( real_arp_counter );
  pthread_mutex_unlock( &vhost_manage_pointer->arp_interface_mutex );
  com_socket_send( socket_fd, result_buffer, total_size );
  free( result_buffer );
}


u_int
vhost_convert_pattern( u_int payload_pattern ) {
  u_int pattern;
  u_int return_value = 0;

  pattern = htonl( payload_pattern );

  switch ( pattern ) {
    case VHOST_PAYLOAD_NONE:
      return_value = 0;
      break;

    case VHOST_PAYLOAD_INCREMENT:
    case VHOST_PAYLOAD_DECREMENT:
    case VHOST_PAYLOAD_RANDOM:
    case VHOST_PAYLOAD_USER_DESIGNATION:
      return_value = ( u_int ) ( 1 << ( pattern - 1 ) );
      break;
  }
  // unknown
  return return_value;
}


size_t
vhost_send_request( int socket_fd, VHOST_SEND_REQUEST_BLOCK_POINTER vhost_send_request, u_char *result_pointer, int *answer_count ) {
  pthread_t pthread_control;
  u_char vhost_name[ VHOST_NAME_MAX ];
  size_t result_size;
  u_int lp;
  u_int send_number;
  u_int temp_value;
  u_char *payload_pattern_pointer;
  VHOST_SEND_ANSWER_BLOCK_POINTER send_anser_request = ( VHOST_SEND_ANSWER_BLOCK_POINTER ) result_pointer;
  VHOST_SEND_END_RESPONSE_BLOCK_POINTER send_complete_request;
  VHOST_MANAGE_POINTER vhost_manage_pointer = NULL;
  VHOST_SEND_REQUEST_DATA_CONTROL_POINTER send_information_pointer = NULL;

  payload_pattern_pointer = ( u_char * ) ( ( u_char * ) vhost_send_request + sizeof( VHOST_SEND_REQUEST_BLOCK ) );

  memset( vhost_name, '\0', VHOST_NAME_MAX );
  memcpy( vhost_name, vhost_send_request->header.vhost_name, MAX_VHOST_NAME_LENGTH );

  // make result header
  send_anser_request->header.length = htonl( sizeof( VHOST_SEND_ANSWER_BLOCK ) );
  send_anser_request->header.command_code = htonl( VHOST_SEND_ANSWER );

  memcpy( send_anser_request->header.vhost_name, vhost_send_request->header.vhost_name, MAX_VHOST_NAME_LENGTH );

  vhost_manage_pointer = vhost_search_vhostname( vhost_name );
  if ( vhost_manage_pointer == NULL ) {
    *answer_count += 1;
    send_anser_request->result = htonl( REQUEST_NG );
    return sizeof( VHOST_SEND_ANSWER_BLOCK );
  }

  for ( lp = 0; lp < SEND_REQUEST_ACCEPT_MAX; lp++ ) {
    if ( ( vhost_manage_pointer->send_information[ lp ].send_status == FALSE )
       && ( vhost_manage_pointer->send_information[ lp ].response_type == FALSE ) ) {
      send_number = lp;
      send_anser_request->send_number = htonl( lp );
      send_information_pointer = &vhost_manage_pointer->send_information[ lp ];
      break;
    }
  }
  if ( send_information_pointer == NULL ) {
    *answer_count += 1;
    send_anser_request->result = htonl( REQUEST_NG );
    return sizeof( VHOST_SEND_ANSWER_BLOCK );
  }

  // clear old status
  vhost_delete_send_ng_queue( &send_information_pointer->send_ng_queue );
  memset( send_information_pointer, '\0', sizeof( VHOST_SEND_REQUEST_DATA_CONTROL ) );

  // make send control data
  send_information_pointer->response_type = ntohl( vhost_send_request->send_request_data.response_type );

  if ( send_information_pointer->response_type == FALSE ) {
    send_information_pointer->response_type = TRUE;
  }
  else {
    send_information_pointer->response_type = FALSE;
  }
  if ( vhost_manage_pointer->vhost_control.generator_mode == HOST_EMURATOR_MODE ) {
    memcpy( send_information_pointer->source_mac_address.mac_address,
      vhost_manage_pointer->vhost_control.host_mac_address, MAC_ADDRESS_LENGTH );
    memset( send_information_pointer->source_mac_address.mask, '\0', MAC_ADDRESS_LENGTH );
    send_information_pointer->source_mac_address.add_count = 0;
    send_information_pointer->source_mac_address.current_no = 0;
  }
  else {
    memcpy( send_information_pointer->source_mac_address.mac_address,
      vhost_send_request->send_request_data.source_mac_address, MAC_ADDRESS_LENGTH );
    memcpy( send_information_pointer->source_mac_address.mask,
      vhost_send_request->send_request_data.source_mac_mask, MAC_ADDRESS_LENGTH );
    send_information_pointer->source_mac_address.add_count = ntohl( vhost_send_request->send_request_data.source_mac_counut );
    send_information_pointer->source_mac_address.current_no = 0;
  }

  memcpy( send_information_pointer->destination_mac_address.mac_address,
    vhost_send_request->send_request_data.destination_mac_address, MAC_ADDRESS_LENGTH );
  memcpy( send_information_pointer->destination_mac_address.mask,
    vhost_send_request->send_request_data.destination_mac_mask, MAC_ADDRESS_LENGTH );
  send_information_pointer->destination_mac_address.add_count = ntohl( vhost_send_request->send_request_data.destination_mac_counut );
  send_information_pointer->destination_mac_address.current_no = 0;

  send_information_pointer->mac_type = Mntohs( vhost_send_request->send_request_data.mac_type );
  send_information_pointer->ether_type = Mntohs( vhost_send_request->send_request_data.ether_type );

  send_information_pointer->layer_3_type = Mntohs( vhost_send_request->send_request_data.layer_3_type );
  send_information_pointer->hardware_type = Mntohs( vhost_send_request->send_request_data.hardware_type );
  send_information_pointer->protocol_type = Mntohs( vhost_send_request->send_request_data.protocol_type );
  send_information_pointer->operation_code = Mntohs( vhost_send_request->send_request_data.operation_code );

  send_information_pointer->vhost_manage_pointer = vhost_manage_pointer;

  memcpy( send_information_pointer->arp_source_mac_address.mac_address,
    vhost_send_request->send_request_data.arp_source_mac_address, MAC_ADDRESS_LENGTH );
  memcpy( send_information_pointer->arp_source_mac_address.mask,
    vhost_send_request->send_request_data.arp_source_mac_mask, MAC_ADDRESS_LENGTH );
  send_information_pointer->arp_source_mac_address.add_count = ntohl( vhost_send_request->send_request_data.arp_source_mac_count );
  send_information_pointer->arp_source_mac_address.current_no = 0;

  memcpy( send_information_pointer->arp_destination_mac_address.mac_address,
    vhost_send_request->send_request_data.arp_destination_mac_address, MAC_ADDRESS_LENGTH );
  memcpy( send_information_pointer->arp_destination_mac_address.mask,
    vhost_send_request->send_request_data.arp_destination_mac_mask, MAC_ADDRESS_LENGTH );
  send_information_pointer->arp_destination_mac_address.add_count = ntohl( vhost_send_request->send_request_data.arp_destination_mac_count );
  send_information_pointer->arp_destination_mac_address.current_no = 0;

  send_information_pointer->arp_mac_type = Mntohs( vhost_send_request->send_request_data.arp_mac_type );

  send_information_pointer->ip_type = Mntohs( vhost_send_request->send_request_data.ip_type );
  send_information_pointer->tos = vhost_send_request->send_request_data.tos;
  send_information_pointer->flags = vhost_send_request->send_request_data.flags;
  send_information_pointer->id = Mntohs( vhost_send_request->send_request_data.id );
  send_information_pointer->flagment_offset = Mntohs( vhost_send_request->send_request_data.flagment_offset );
  send_information_pointer->ttl = vhost_send_request->send_request_data.ttl;
  send_information_pointer->protocol_number = vhost_send_request->send_request_data.protocol_number;
  send_information_pointer->option_length = Mntohs( vhost_send_request->send_request_data.option_length );
  memset( send_information_pointer->option, '\0', MAX_OPTION_LENGTH );
  memcpy( send_information_pointer->option, vhost_send_request->send_request_data.option,
    send_information_pointer->option_length );

  send_information_pointer->udp_type = Mntohs( vhost_send_request->send_request_data.udp_type );
  send_information_pointer->duration = ntohl( vhost_send_request->send_request_data.duration );
  send_information_pointer->packet_par_second = ntohl( vhost_send_request->send_request_data.packet_par_second );
  send_information_pointer->packet_length = ntohl( vhost_send_request->send_request_data.packet_length );
  send_information_pointer->packet_length -= 4;
  send_information_pointer->packet_num = ntohl( vhost_send_request->send_request_data.packet_num );
  send_information_pointer->payload_count = ntohl( vhost_send_request->send_request_data.payload_count );

  send_information_pointer->payload_pattern = vhost_convert_pattern( vhost_send_request->send_request_data.payload_pattern );
  send_information_pointer->payload_length = ntohl( vhost_send_request->send_request_data.payload_length );
  send_information_pointer->payload_length = ntohl( vhost_send_request->send_request_data.payload_length );
  send_information_pointer->payload = calloc( 1, MAX_RECEIVE_BUFFER_SIZE );
  if ( send_information_pointer->payload_length ) {
    if ( send_information_pointer->payload != NULL ) {
      copy_payload( send_information_pointer->payload,
        ( int ) send_information_pointer->payload_length, payload_pattern_pointer, MAX_RECEIVE_BUFFER_SIZE );
      if ( send_information_pointer->payload_pattern == 0 ) {
        send_information_pointer->payload_pattern = PAYLOAD_USER_DESIGNATION;
      }
    }
    payload_pattern_pointer += send_information_pointer->payload_length;
  }

  send_information_pointer->payload_mask = calloc( 1, MAX_RECEIVE_BUFFER_SIZE );
  send_information_pointer->payload_mask_length = ntohl( vhost_send_request->send_request_data.payload_mask_length );
  if ( send_information_pointer->payload_mask_length ) {
    if ( send_information_pointer->payload_mask != NULL ) {
      memcpy( send_information_pointer->payload_mask,
        payload_pattern_pointer, send_information_pointer->payload_mask_length );
    }
  }
  send_information_pointer->payload_limit = htonl( vhost_send_request->send_request_data.payload_limit );

  if ( vhost_manage_pointer->vhost_control.generator_mode == HOST_EMURATOR_MODE ) {
    send_information_pointer->source_ip_address.ipv4_address = vhost_manage_pointer->vhost_control.ipv4_address;
    send_information_pointer->source_ip_address.ipv4_mask = vhost_manage_pointer->vhost_control.ipv4_mask;
    send_information_pointer->source_ip_address.current_no = 0;
  }
  else {
    send_information_pointer->source_ip_address.ipv4_address = vhost_send_request->send_request_data.source_ip_address;
    send_information_pointer->source_ip_address.ipv4_mask = vhost_send_request->send_request_data.source_ip_address_mask;
    send_information_pointer->source_ip_address.add_count = ntohl( vhost_send_request->send_request_data.source_ip_address_add_count );
    if ( send_information_pointer->source_ip_address.add_count == 0 ) {
      send_information_pointer->source_ip_address.add_count = 1;
    }
    send_information_pointer->source_ip_address.current_no = 0;
  }

  send_information_pointer->destination_ip_address.ipv4_address = vhost_send_request->send_request_data.destination_ip_address;
  send_information_pointer->destination_ip_address.ipv4_mask = vhost_send_request->send_request_data.destination_ip_address_mask;
  send_information_pointer->destination_ip_address.add_count = ntohl( vhost_send_request->send_request_data.destination_ip_address_add_count );
  if ( send_information_pointer->destination_ip_address.add_count == 0 ) {
    send_information_pointer->destination_ip_address.add_count = 1;
  }
  send_information_pointer->destination_ip_address.current_no = 0;

  send_information_pointer->source_port_number.port_number = vhost_send_request->send_request_data.source_port_number;
  send_information_pointer->source_port_number.port_number_mask = vhost_send_request->send_request_data.source_port_number_mask;
  send_information_pointer->source_port_number.add_count = Mntohs( vhost_send_request->send_request_data.source_port_number_add_count );
  if ( send_information_pointer->source_port_number.add_count == 0 ) {
    send_information_pointer->source_port_number.add_count = 1;
  }
  send_information_pointer->source_port_number.current_no = 0;

  send_information_pointer->destination_port_number.port_number = vhost_send_request->send_request_data.destination_port_number;
  send_information_pointer->destination_port_number.port_number_mask = vhost_send_request->send_request_data.destination_port_number_mask;
  send_information_pointer->destination_port_number.add_count = Mntohs( vhost_send_request->send_request_data.destination_port_number_add_count );
  if ( send_information_pointer->destination_port_number.add_count == 0 ) {
    send_information_pointer->destination_port_number.add_count = 1;
  }
  send_information_pointer->destination_port_number.current_no = 0;

  send_information_pointer->generator_mode = ( u_short ) vhost_manage_pointer->vhost_control.generator_mode;

  if ( vhost_manage_pointer->vhost_control.generator_mode == RAW_GENERATOR_MODE ) {
    send_information_pointer->l2_type = Mhtons( vhost_send_request->send_request_data.layer_2_type );
  }
  else {
    send_information_pointer->l2_type = vhost_manage_pointer->vhost_control.l2_type;
  }

  if ( Mntohs( vhost_send_request->send_request_data.vlan_type ) == VHOST_SEND_REQUEST_VLAN_DISABLE ) {
    send_information_pointer->vlan_information = Mntohs( vhost_send_request->send_request_data.vlan_information );
    send_information_pointer->vlan_information &= ( u_short ) ~VLAN_MASK;
    temp_value = ( u_int ) send_information_pointer->vlan_information;
    temp_value |= ( vhost_manage_pointer->vhost_control.vlan_id & VLAN_MASK );
    send_information_pointer->vlan_information = ( u_short ) temp_value;
  }
  else {
    send_information_pointer->vlan_information = Mntohs( vhost_send_request->send_request_data.vlan_information );
  }

  send_information_pointer->random_information_pointer = &vhost_manage_pointer->random_information;


  if ( ( send_information_pointer->payload_length ) && ( send_information_pointer->payload == NULL ) ) {
    *answer_count += 1;
    send_anser_request->result = htonl( REQUEST_NG );
    return sizeof( VHOST_SEND_ANSWER_BLOCK );
  }

  vhost_manage_pointer->send_information[ send_number ].send_status = TRUE;

  if ( send_information_pointer->response_type == TRUE ) {
    vhost_add_send_control( socket_fd, send_information_pointer );
  }
  // create thread
  pthread_create( &pthread_control, NULL, vhost_sender_main, ( void * ) send_information_pointer );

  result_size = sizeof( VHOST_SEND_ANSWER_BLOCK );

  *answer_count += 1;
  if ( send_information_pointer->response_type == FALSE ) {
    *answer_count += 1;
    send_complete_request = ( VHOST_SEND_END_RESPONSE_BLOCK_POINTER ) ( ( u_char * ) result_pointer + sizeof( VHOST_SEND_ANSWER_BLOCK ) );
    send_complete_request->header.length = htonl( sizeof( VHOST_SEND_END_RESPONSE_BLOCK ) );
    send_complete_request->header.command_code = htonl( VHOST_SEND_RESPONCE );
    memcpy( send_complete_request->header.vhost_name, vhost_send_request->header.vhost_name, MAX_VHOST_NAME_LENGTH );
    result_size += sizeof( VHOST_SEND_END_RESPONSE_BLOCK );
    send_complete_request->send_number = send_anser_request->send_number;
  }

  return result_size;
}


size_t
vhost_send_cancel_request( VHOST_SEND_CANCEL_REQUEST_BLOCK_POINTER send_cancel_request_pointer, u_char *result_pointer ) {
  u_char vhost_name[ VHOST_NAME_MAX ];
  VHOST_SEND_CANCEL_ANSWER_BLOCK_POINTER send_cancel_answer_pointer = ( VHOST_SEND_CANCEL_ANSWER_BLOCK_POINTER ) result_pointer;
  VHOST_MANAGE_POINTER vhost_manage_pointer;
  int cancel_number;

  memset( vhost_name, '\0', VHOST_NAME_MAX );
  memcpy( vhost_name, send_cancel_request_pointer->header.vhost_name, MAX_VHOST_NAME_LENGTH );

  // make result header
  send_cancel_answer_pointer->header.length = htonl( sizeof( VHOST_SEND_CANCEL_ANSWER_BLOCK ) );
  send_cancel_answer_pointer->header.command_code = htonl( VHOST_SEND_CANCEL_ANSWER );

  memcpy( send_cancel_answer_pointer->header.vhost_name, send_cancel_request_pointer->header.vhost_name, MAX_VHOST_NAME_LENGTH );

  vhost_manage_pointer = vhost_search_vhostname( vhost_name );

  if ( vhost_manage_pointer == NULL ) {
    send_cancel_answer_pointer->result = htonl( REQUEST_NG );
    return sizeof( VHOST_SEND_CANCEL_ANSWER_BLOCK );
  }

  cancel_number = ( int ) htonl( send_cancel_request_pointer->cancel_number );
  if ( cancel_number > SEND_REQUEST_ACCEPT_MAX ) {
    send_cancel_answer_pointer->result = htonl( REQUEST_NG );
    return sizeof( VHOST_SEND_CANCEL_ANSWER_BLOCK );
  }

  if ( vhost_manage_pointer->send_information[ cancel_number ].send_status == FALSE ) {
    send_cancel_answer_pointer->result = htonl( REQUEST_NG );
    return sizeof( VHOST_SEND_CANCEL_ANSWER_BLOCK );
  }
  vhost_send_cancel( vhost_manage_pointer, cancel_number );

  send_cancel_answer_pointer->result = htonl( REQUEST_OK );
  return sizeof( VHOST_SEND_CANCEL_ANSWER_BLOCK );
}


void
vhost_packet_check( int socket_fd, u_char *packet ) {
  PACKET_HEADER_POINTER packet_header = ( PACKET_HEADER_POINTER ) packet;
  int lp;
  size_t result = 0;
  int total_length = ( int ) sizeof( PACKET_HEADER );
  size_t answer_total_length = ( int ) sizeof( PACKET_HEADER );
  int answer_count = 0;
  u_int command_code;
  int packet_num = ( int ) ntohl( packet_header->packet_num );
  COMMAND_PACKET_HEADER_POINTER command_header;
  u_char *result_buffer;

  command_header = ( COMMAND_PACKET_HEADER_POINTER ) ( ( u_char * ) packet + sizeof( PACKET_HEADER ) );

  if ( packet_num == 0 ) {
    return;
  }

  // alloc result buffer
  result_buffer = ( u_char * ) calloc( 1, ( ( sizeof( U_ANSWER_BLOCK ) * ( ( size_t ) packet_num * 2 ) ) + sizeof( PACKET_HEADER ) ) );

  for ( lp = 0; lp < packet_num; lp++ ) {
    command_code = ntohl( command_header->command_code );
    switch ( command_code ) {
      case VHOST_CREATE_REQUEST:
        // real time response
        result = vhost_create_request( ( VHOST_CREATE_REQUEST_BLOCK_POINTER ) command_header,
                                          &result_buffer[ answer_total_length ] );
        answer_count += 1;
        break;

      case VHOST_STOP_REQUEST:
        // real time response
        result = vhost_stop_request( ( VHOST_STOP_REQUEST_BLOCK_POINTER ) command_header,
                                      &result_buffer[ answer_total_length ] );
        answer_count += 1;
        break;

      case VHOST_ARP_CACHE_REQUEST:
        // real time response
        result = vhost_arp_cache_request( ( VHOST_ARP_CACHE_SET_REQUEST_BLOCK_POINTER ) command_header,
                                          &result_buffer[ answer_total_length ] );
        answer_count += 1;
        break;

      case VHOST_STATUS_REQUEST:
        // another route
        vhost_send_my_status( ( VHOST_STATUS_REQUEST_BLOCK_POINTER ) command_header, socket_fd );
        break;

      case VHOST_STATIC_ARP_REQUEST:
        // real time response
        result = vhost_static_arp_entry( ( VHOST_STATIC_ARP_REQUEST_BLOCK_POINTER ) command_header,
                                        &result_buffer[ answer_total_length ] );
        answer_count += 1;
        break;

      case VHOST_ARP_INFORMATION_REQUEST:
        // another route
        vhost_request_arp_data( ( VHOST_ARP_GET_REQUEST_BLOCK_POINTER ) command_header, socket_fd );
        break;

      case VHOST_DYNAMIC_ARP_CLEAR_REQUEST:
        // real time response
        result = vhost_clear_dynamic_arp( ( VHOST_DYNAMIC_ARP_CLEAR_REQUEST_BLOCK_POINTER ) command_header,
                                            &result_buffer[ answer_total_length ] );
        answer_count += 1;
        break;

      case VHOST_STATISTICS_CLEAR_REQUEST:
        // real time response
        result = vhost_statistics_clear_request( ( VHOST_STATISTICS_CLEAR_REQUEST_BLOCK_POINTER ) command_header,
                                                  &result_buffer[ answer_total_length ] );
        answer_count += 1;
        break;

      case VHOST_STATISTICS_GET_REQUEST:
        // another route
        vhost_get_statistics_request( socket_fd, ( VHOST_STATISTICS_REQUEST_BLOCK_POINTER ) command_header );
        break;

      case VHOST_SEND_REQUEST:
        // real time response
        result = vhost_send_request( socket_fd, ( VHOST_SEND_REQUEST_BLOCK_POINTER ) command_header,
                                      &result_buffer[ answer_total_length ], &answer_count );
        break;

      case VHOST_SEND_CANCEL_REQUEST:
        // real time response
        result = vhost_send_cancel_request( ( VHOST_SEND_CANCEL_REQUEST_BLOCK_POINTER ) command_header,
                                            &result_buffer[ answer_total_length ] );
        answer_count += 1;
        break;
    }
    answer_total_length += result;
    total_length += ( int ) ntohl( ( u_int ) command_header->length );

    command_header = ( COMMAND_PACKET_HEADER_POINTER ) ( packet + total_length );
  }
  if ( answer_count != 0 ) {
    packet_header = ( PACKET_HEADER_POINTER ) result_buffer;
    packet_header->size = htonl( ( u_int ) answer_total_length );
    packet_header->packet_num = htonl( ( u_int ) answer_count );
    com_socket_send( socket_fd, result_buffer, ( size_t ) answer_total_length );
  }
  free( result_buffer );
}


int
vhost_packet_receive( int socket_fd ) {
  u_int packet_size;
  int result;
  u_char *packet;

  result = com_socket_data_copy( socket_fd, ( u_char * ) &packet_size, sizeof( packet_size ) );
  if ( result <= 0 ) {
    return FALSE;
  }
  packet_size = ntohl( packet_size );
  packet = ( u_char * ) calloc( 1, packet_size );
  if ( packet == NULL ) {
    return FALSE;
  }
  result = com_socket_receive( socket_fd, packet, packet_size );
  if ( result <= 0 ) {
    return FALSE;
  }
  vhost_packet_check( socket_fd, packet );
  free( packet );

  return TRUE;
}
