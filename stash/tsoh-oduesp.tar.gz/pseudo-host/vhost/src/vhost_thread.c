#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <netinet/tcp.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <net/if_arp.h>
#include <net/ethernet.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <linux/if_packet.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <poll.h>

#include "packet.h"
#include "cmn.h"
#include "vhost_control.h"
#include "vhost_thread.h"
#include "vhost_layer_2.h"
#include "vhost_layer_3_4.h"
#include "com_socket.h"


extern VHOST_MANAGE_POINTER vhost_manage;
extern DEVICE_CONTROL vhost_device[ VHOST_DEVICE_MAX ];
static u_char bload_cast_mac_address[ MAC_ADDRESS_LENGTH ] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };

/******************************************************************************
 * common functions                                                           *
 ******************************************************************************/
DEVICE_CONTROL_POINTER
vhost_search_receiver( u_char *device_name ) {
  int lp;
  DEVICE_CONTROL_POINTER vhost_device_pointer = &vhost_device[ 0 ];

  for ( lp = 0; lp < VHOST_DEVICE_MAX; lp++, vhost_device_pointer++ ) {
    if ( memcmp( device_name, vhost_device_pointer->device_name, strlen( ( const char * ) device_name ) ) == 0 ) {
      if ( strlen( ( const char * ) device_name ) == strlen( ( const char * ) vhost_device_pointer->device_name ) ) {
        return vhost_device_pointer;
      }
    }
  }
  return NULL;
}


VHOST_MANAGE_POINTER
vhost_search_vhostname( u_char *vhost_name ) {
  int lp;
  VHOST_MANAGE_POINTER vhost_manage_pointer = &vhost_manage[ 0 ];

  for ( lp = 0; lp < MAX_THREADS; lp++, vhost_manage_pointer++ ) {
    if ( memcmp( vhost_name, vhost_manage_pointer->vhost_control.vhost_name, strlen( ( const char * ) vhost_name ) ) == 0 ) {
      if ( strlen( ( const char * ) vhost_name ) == strlen( ( const char * ) vhost_manage_pointer->vhost_control.vhost_name ) ) {
        return vhost_manage_pointer;
      }
    }
  }
  return NULL;
}


void
vhost_add_statistics_entry( VHOST_STATISTICS_POINTER receive_buffer,
  pthread_mutex_t *statistics_mutex,
  VHOST_STATISTICS_CONTROL_POINTER statistics_control_head,
  unsigned long long *statistics_packet_num ) {
  int crc16_data = 0;
  int crc_add_data = 0;
  int packet_check_sum = 0;
  int packet_check_sum_offset = 0;
  VHOST_STATISTICS_POINTER vhost_statistics_pointer;
  STATISTICS_INFORMATION_POINTER statistics_pointer = &receive_buffer->statistics;
  VHOST_STATISTICS_POINTER new_entry_statistics_pointer;

  packet_check_sum_offset = 0;
  if ( statistics_pointer->ip_header_offset != 0 ) {
    packet_check_sum_offset += statistics_pointer->ip_header_offset;
  }

  if ( statistics_pointer->udp_header_offset != 0 ) {
    packet_check_sum_offset = statistics_pointer->udp_header_offset;
    packet_check_sum_offset += ( int ) sizeof( struct udphdr );
  }
  if ( statistics_pointer->packet_check_sum == 0 ) {
    packet_check_sum = calculate_crc( ( u_short * ) &statistics_pointer->packet_buffer[ packet_check_sum_offset ],
      ( u_int ) ( statistics_pointer->packet_bytes - packet_check_sum_offset ) );
  }
  else {
    packet_check_sum = ( int ) statistics_pointer->packet_check_sum;
  }

  if ( statistics_pointer->ip_check_sum != 0 ) {
    crc16_data += ( int ) statistics_pointer->ip_check_sum;
    crc_add_data |= IP_CHECKSUM_READY;
  }
  if ( statistics_pointer->udp_check_sum != 0 ) {
    crc16_data += ( int ) statistics_pointer->udp_check_sum;
    crc_add_data |= UDP_CHECKSUM_READY;
  }

  // calculate position
  crc16_data += packet_check_sum;

  crc16_data %= STATISTICS_CONTROL_MAX;

  pthread_mutex_lock( statistics_mutex );
  if ( statistics_control_head[ crc16_data ].head != NULL ) {
    vhost_statistics_pointer = statistics_control_head[ crc16_data ].head;
    // full match
    while ( vhost_statistics_pointer != NULL ) {
      if ( statistics_pointer->packet_bytes == vhost_statistics_pointer->statistics.packet_bytes ) {
        if ( memcmp( vhost_statistics_pointer->statistics.packet_buffer,
            statistics_pointer->packet_buffer, ( size_t ) statistics_pointer->packet_bytes ) == 0 ) {
          vhost_statistics_pointer->statistics.receive_total_bytes += ( unsigned long long ) statistics_pointer->packet_bytes;
          vhost_statistics_pointer->statistics.receive_total_packets += 1;
          pthread_mutex_unlock( statistics_mutex );
          return;
        }
      }
      vhost_statistics_pointer = vhost_statistics_pointer->next;
    }
  }

  // Add new entry
  new_entry_statistics_pointer = calloc( 1, sizeof( VHOST_STATISTICS ) );
  if ( new_entry_statistics_pointer == NULL ) {
    return;
  }
  memcpy( new_entry_statistics_pointer, receive_buffer, sizeof( VHOST_STATISTICS ) );
  new_entry_statistics_pointer->statistics.packet_check_sum = ( u_int ) packet_check_sum;

  new_entry_statistics_pointer->statistics.receive_total_bytes = ( unsigned long long ) receive_buffer->statistics.packet_bytes;
  new_entry_statistics_pointer->statistics.receive_total_packets = 1;
  *statistics_packet_num += 1;
  if ( statistics_control_head[ crc16_data ].head == NULL ) {
    statistics_control_head[ crc16_data ].head = new_entry_statistics_pointer;
    statistics_control_head[ crc16_data ].tail = new_entry_statistics_pointer;
  }
  else {
    statistics_control_head[ crc16_data ].tail->next = new_entry_statistics_pointer;
    new_entry_statistics_pointer->prev = statistics_control_head[ crc16_data ].tail;
    statistics_control_head[ crc16_data ].tail = new_entry_statistics_pointer;
  }

  pthread_mutex_unlock( statistics_mutex );
  return;
}


u_int
vhost_arp_hash( u_int ipv4_address ) {
  u_int hash_value = ipv4_address;

  hash_value ^= ( ipv4_address >> 16 );
  hash_value ^= ( ipv4_address >> 8 );
  hash_value ^= ( ipv4_address >> 3 );
  hash_value &= ( ARP_HASH_MAX - 1 );

  return hash_value;
}


ARP_CAHCE_TABLE_POINTER
vhost_search_arp_cache( VHOST_MANAGE_POINTER vhost_manage_pointer, u_int ipv4_address ) {
  u_int hash_offset = vhost_arp_hash( ipv4_address );
  ARP_CAHCE_TABLE_POINTER arp_cache_pointer = NULL;
  VHOST_ARP_DATA_POINTER entry_arp = NULL;

  pthread_mutex_lock( &vhost_manage_pointer->arp_interface_mutex );

  if ( vhost_manage_pointer->arp_control_head[ hash_offset ].head != NULL ) {
    entry_arp = vhost_manage_pointer->arp_control_head[ hash_offset ].head;
    while ( entry_arp != NULL ) {
      if ( entry_arp->arp_cache.ipv4_address == ipv4_address ) {
        arp_cache_pointer = &entry_arp->arp_cache;
        break;
      }
      entry_arp = entry_arp->next;
    }
  }
  pthread_mutex_unlock( &vhost_manage_pointer->arp_interface_mutex );

  return arp_cache_pointer;
}


void
vhost_arp_add( VHOST_ARP_CONTROL_POINTER arp_control_head, VHOST_ARP_DATA_POINTER arp_data,
               pthread_mutex_t *arp_mutex, unsigned long long *arp_entry_number, u_int arp_expire_time ) {
  volatile u_int hash_value;

  VHOST_ARP_DATA_POINTER entry_arp;

  hash_value = vhost_arp_hash( arp_data->arp_cache.ipv4_address );
  pthread_mutex_lock( arp_mutex );

  if ( arp_control_head[ hash_value ].head != NULL ) {
    entry_arp = arp_control_head[ hash_value ].head;
    while ( entry_arp != NULL ) {
      if ( entry_arp->arp_cache.ipv4_address == arp_data->arp_cache.ipv4_address ) {
        if ( ( ( entry_arp->arp_cache.vlan_info & TEMPORARY_REGISTRATION_ARP_ENTRY ) == TEMPORARY_REGISTRATION_ARP_ENTRY )
           && ( ( arp_data->arp_cache.vlan_info & TEMPORARY_REGISTRATION_ARP_ENTRY ) == 0 ) ) {
          entry_arp->arp_cache.vlan_info &= ( u_short ) ~TEMPORARY_REGISTRATION_ARP_ENTRY;
        }
        if ( ( entry_arp->arp_cache.vlan_info & STATIC_ARP_ENTRY ) == STATIC_ARP_ENTRY ) {
          free( arp_data );
          pthread_mutex_unlock( arp_mutex );
          return;
        }
        if ( ( ( entry_arp->arp_cache.vlan_info & STATIC_ARP_ENTRY ) != STATIC_ARP_ENTRY )
           && ( ( arp_data->arp_cache.vlan_info & STATIC_ARP_ENTRY ) == STATIC_ARP_ENTRY ) ) {
          entry_arp->arp_cache.vlan_info |= STATIC_ARP_ENTRY;
        }
        if ( ( ( entry_arp->arp_cache.vlan_info & TEMPORARY_REGISTRATION_ARP_ENTRY ) != TEMPORARY_REGISTRATION_ARP_ENTRY )
           && ( ( arp_data->arp_cache.vlan_info & TEMPORARY_REGISTRATION_ARP_ENTRY ) == TEMPORARY_REGISTRATION_ARP_ENTRY ) ) {
          entry_arp->arp_cache.vlan_info |= ( u_short ) TEMPORARY_REGISTRATION_ARP_ENTRY;
          time( &entry_arp->arp_cache.last_access_time );
          free( arp_data );
          pthread_mutex_unlock( arp_mutex );
          return;
        }
        entry_arp->arp_cache.ageout_time = ( time_t )arp_expire_time;

        time( &entry_arp->arp_cache.last_access_time );
        memcpy( entry_arp->arp_cache.mac_address, arp_data->arp_cache.mac_address, MAC_ADDRESS_LENGTH );
        free( arp_data );
        pthread_mutex_unlock( arp_mutex );
        return;
      }
      entry_arp = entry_arp->next;
    }
  }

  if ( arp_data != NULL ) {
    *arp_entry_number += 1;
    time( &arp_data->arp_cache.last_access_time );
    if ( ( arp_data->arp_cache.vlan_info & TEMPORARY_REGISTRATION_ARP_ENTRY ) == TEMPORARY_REGISTRATION_ARP_ENTRY ) {
      arp_data->arp_cache.last_access_time -= ( time_t ) ( arp_expire_time - ARP_REQUEST_AGEOUT_TIME );
    }
    else {
      arp_data->arp_cache.ageout_time = ( time_t )arp_expire_time;
    }
    if ( arp_control_head[ hash_value ].head == NULL ) {
      arp_control_head[ hash_value ].head = arp_data;
      arp_control_head[ hash_value ].tail = arp_data;
    }
    else {
      arp_control_head[ hash_value ].tail->next = arp_data;
      arp_data->prev = arp_control_head[ hash_value ].tail;
      arp_control_head[ hash_value ].tail = arp_data;
    }
  }

  pthread_mutex_unlock( arp_mutex );
}


void
arp_entry_delete( VHOST_ARP_CONTROL_POINTER arp_entry_pointer, VHOST_ARP_DATA_POINTER arp_entry ) {
  if ( arp_entry == arp_entry_pointer->head ) {
    arp_entry_pointer->head = arp_entry->next;
  }
  if ( arp_entry == arp_entry_pointer->tail ) {
    arp_entry_pointer->tail = arp_entry->prev;
  }
  if ( arp_entry->next != NULL ) {
    arp_entry->next->prev = arp_entry->prev;
  }
  if ( arp_entry->prev != NULL ) {
    arp_entry->prev->next = arp_entry->next;
  }
  free( arp_entry );
}


/******************************************************************************
 * vhost  functions                                                           *
 ******************************************************************************/
void
vhost_arp_reply_check( VHOST_MANAGE_POINTER vhost_manage_pointer, VHOST_STATISTICS_POINTER receive_buffer, int ether_size ) {
  VHOST_ARP_DATA_POINTER arp_data;
  SMAC_CONTROL destination_mac_address;
  IP_ADDRESS_CONTROL destination_ipv4_address;
  u_char *arp_data_pointer;
  STATISTICS_INFORMATION_POINTER statistics_pointer = &receive_buffer->statistics;

  arp_data = ( VHOST_ARP_DATA_POINTER ) calloc( 1, sizeof( VHOST_ARP_DATA ) );
  if ( arp_data == NULL ) {
    // no more memory
    return;
  }

  // broadcast?
  // my host ?
  if ( memcmp( statistics_pointer->packet_buffer, vhost_manage_pointer->vhost_control.host_mac_address, MAC_ADDRESS_LENGTH ) != 0 ) {
    free( arp_data );
    return;
  }

  arp_data_pointer = &statistics_pointer->packet_buffer[ ether_size + ( int ) sizeof( struct arphdr ) ];
  memcpy( arp_data->arp_cache.mac_address, arp_data_pointer, MAC_ADDRESS_LENGTH );
  arp_data_pointer += MAC_ADDRESS_LENGTH;

  memcpy( &arp_data->arp_cache.ipv4_address, arp_data_pointer, sizeof( u_int ) );
  arp_data_pointer += sizeof( u_int );

  memcpy( destination_mac_address.mac_address, arp_data_pointer, MAC_ADDRESS_LENGTH );
  arp_data_pointer += MAC_ADDRESS_LENGTH;

  memcpy( &destination_ipv4_address.ipv4_address, arp_data_pointer, sizeof( u_int ) );

  if ( destination_ipv4_address.ipv4_address != vhost_manage_pointer->vhost_control.ipv4_address ) {
    free( arp_data );
    return;
  }

  // add arp entry
  vhost_arp_add( &vhost_manage_pointer->arp_control_head[ 0 ], arp_data,
    &vhost_manage_pointer->arp_interface_mutex,
    &vhost_manage_pointer->arp_number,
    vhost_manage_pointer->vhost_control.arp_cache_time );
}


void
vhost_arp_request_check( int socket_fd, VHOST_MANAGE_POINTER vhost_manage_pointer,
  VHOST_STATISTICS_POINTER receive_buffer, int ether_size ) {
  VHOST_ARP_DATA_POINTER arp_data;
  SMAC_CONTROL destination_mac_address;
  SMAC_CONTROL source_mac_address;
  IP_ADDRESS_CONTROL destination_ipv4_address;
  IP_ADDRESS_CONTROL source_ipv4_address;
  u_char mac_address[ MAC_ADDRESS_LENGTH ];
  u_char *arp_data_pointer;
  size_t size;
  u_int ipv4_mask;

  STATISTICS_INFORMATION_POINTER statistics_pointer = &receive_buffer->statistics;
  VHOST_STATISTICS_POINTER arp_send_pointer;

  arp_data = ( VHOST_ARP_DATA_POINTER ) calloc( 1, sizeof( VHOST_ARP_DATA ) );
  if ( arp_data == NULL ) {
    // no more memory
    return;
  }

  // broadcast?
  if ( memcmp( statistics_pointer->packet_buffer, bload_cast_mac_address, MAC_ADDRESS_LENGTH ) != 0 ) {
    // my host ?
    if ( memcmp( statistics_pointer->packet_buffer, vhost_manage_pointer->vhost_control.host_mac_address, MAC_ADDRESS_LENGTH ) != 0 ) {
      free( arp_data );
      return;
    }
  }

  arp_data_pointer = &statistics_pointer->packet_buffer[ ether_size + ( int ) sizeof( struct arphdr ) ];
  memcpy( arp_data->arp_cache.mac_address, arp_data_pointer, MAC_ADDRESS_LENGTH );
  memcpy( source_mac_address.mac_address, arp_data_pointer, MAC_ADDRESS_LENGTH );

  arp_data_pointer += MAC_ADDRESS_LENGTH;

  memcpy( &arp_data->arp_cache.ipv4_address, arp_data_pointer, sizeof( u_int ) );
  arp_data_pointer += sizeof( u_int );

  memcpy( destination_mac_address.mac_address, arp_data_pointer, MAC_ADDRESS_LENGTH );
  arp_data_pointer += MAC_ADDRESS_LENGTH;

  memcpy( &destination_ipv4_address.ipv4_address, arp_data_pointer, sizeof( u_int ) );
  source_ipv4_address.ipv4_address = arp_data->arp_cache.ipv4_address;

  ipv4_mask = vhost_manage_pointer->vhost_control.ipv4_mask;

  if ( ( source_ipv4_address.ipv4_address & ipv4_mask ) != ( vhost_manage_pointer->vhost_control.ipv4_address & ipv4_mask ) ) {
    free( arp_data );
    return;
  }
  if ( destination_ipv4_address.ipv4_address != vhost_manage_pointer->vhost_control.ipv4_address ) {
    free( arp_data );
    return;
  }

  memset( mac_address, '\0', MAC_ADDRESS_LENGTH );
  memcpy( mac_address, arp_data->arp_cache.mac_address, MAC_ADDRESS_LENGTH );
  // add arp entry
  vhost_arp_add( &vhost_manage_pointer->arp_control_head[ 0 ], arp_data,
    &vhost_manage_pointer->arp_interface_mutex,
    &vhost_manage_pointer->arp_number,
    vhost_manage_pointer->vhost_control.arp_cache_time );

  // make arp reply
  arp_send_pointer = ( VHOST_STATISTICS_POINTER ) calloc( 1, sizeof( VHOST_STATISTICS ) );
  if ( arp_send_pointer == NULL ) {
    // no more memory
    return;
  }

  memcpy( &destination_mac_address.mac_address[ 0 ], &vhost_manage_pointer->vhost_control.host_mac_address[ 0 ], MAC_ADDRESS_LENGTH );

  if ( vhost_manage_pointer->vhost_control.l2_type == PACKET_TYPE_8021Q ) {
    size = ( size_t ) make_vlan_header( NULL, mac_address, &destination_mac_address,
      vhost_manage_pointer->vhost_control.vlan_id, 0, ETH_P_ARP, arp_send_pointer->statistics.packet_buffer );
  }
  else {
    size = ( size_t ) make_ether_header( NULL, mac_address, &destination_mac_address, 0,
      ETH_P_ARP, arp_send_pointer->statistics.packet_buffer );
  }
  size += ( size_t ) make_arp( ARP_HARDWARE_TYPE, ARP_PROTOCOL_TYPE, ARPOP_REPLY, NULL,
    &source_mac_address, &destination_mac_address, 0,
    &destination_ipv4_address, &source_ipv4_address, 0,
    &arp_send_pointer->statistics.packet_buffer[ size ] );

  send( socket_fd, arp_send_pointer->statistics.packet_buffer, MINIMAM_PACKET_SIZE, 0 );

  arp_send_pointer->statistics.packet_bytes = MINIMAM_PACKET_SIZE;
  vhost_add_statistics_entry( arp_send_pointer,
    &vhost_manage_pointer->send_statistics_interface_mutex,
    &vhost_manage_pointer->send_statistics_control_head[ 0 ],
    &vhost_manage_pointer->send_statistics_packet_num );
  free( arp_send_pointer );
}


void
vhost_receive_main( VHOST_MANAGE_POINTER vhost_manage_pointer, VHOST_STATISTICS_POINTER receive_buffer ) {
  struct arphdr *arp_header;
  int ether_size;
  u_short ether_type;
  int operation_code;
  struct ether_header *ethernet_header;

  VHOST_CONTROL_POINTER vhost_control_pointer = &vhost_manage_pointer->vhost_control;
  STATISTICS_INFORMATION_POINTER statistics_pointer = &receive_buffer->statistics;

  ether_size = get_ether_header( statistics_pointer, &ether_type );

  if ( vhost_manage_pointer->vhost_control.promisc_mode == FALSE ) {
    if ( vhost_control_pointer->l2_type == PACKET_TYPE_8021Q ) {
      if ( ( statistics_pointer->vlan_id & 0xFFF ) != vhost_control_pointer->vlan_id ) {
        return;
      }
    }
    else {
      if ( ether_size != sizeof( struct ether_header ) ) {
        return;
      }
    }
  }
  if ( vhost_control_pointer->generator_mode == HOST_EMURATOR_MODE ) {
    // Nothing IP ?
    if ( statistics_pointer->ip_header_offset == 0 ) {
      if ( statistics_pointer->ether_type == ETH_P_ARP ) {
        arp_header = ( struct arphdr * ) &statistics_pointer->packet_buffer[ ether_size ];
        operation_code = Mntohs( arp_header->ar_op );
        ethernet_header = ( struct ether_header * ) statistics_pointer->packet_buffer;

        if ( ( arp_header->ar_hln != MAC_ADDRESS_LENGTH ) || ( arp_header->ar_pln != ARP_PROTOCOL_LENGTH ) ) {
          vhost_add_statistics_entry( receive_buffer,
            &vhost_manage_pointer->receive_statistics_interface_mutex,
            vhost_manage_pointer->receive_statistics_control_head,
            &vhost_manage_pointer->receive_statistics_packet_num );
          return;
        }
        if ( memcmp( vhost_manage_pointer->vhost_control.host_mac_address,
            ethernet_header->ether_shost, MAC_ADDRESS_LENGTH ) == 0 ) {
          return;
        }

        if ( vhost_control_pointer->l2_type == PACKET_TYPE_8021Q ) {
          // 802.1q size ?
          if ( ether_size == sizeof( struct vlan_ether_header ) ) {
            // match vlan id?
            if ( ( statistics_pointer->vlan_id & 0xFFF ) == vhost_control_pointer->vlan_id ) {
              if ( operation_code == ARPOP_REQUEST ) {
                vhost_arp_request_check( vhost_manage_pointer->socket_fd,
                  vhost_manage_pointer, receive_buffer, ether_size );
              }
              else if( operation_code == ARPOP_REPLY ) {
                vhost_arp_reply_check( vhost_manage_pointer, receive_buffer, ether_size );
              }
            }
          }
        }
        else if ( vhost_control_pointer->l2_type == PACKET_TYPE_DIX ) {
          // dix size ?
          if ( ether_size == sizeof( struct ether_header ) ) {
            if ( operation_code == ARPOP_REQUEST ) {
              vhost_arp_request_check( vhost_manage_pointer->socket_fd,
                vhost_manage_pointer, receive_buffer, ether_size );
            }
            else if( operation_code == ARPOP_REPLY ) {
              vhost_arp_reply_check( vhost_manage_pointer, receive_buffer, ether_size );
            }
          }
        }
      }
    }
  }

  vhost_add_statistics_entry( receive_buffer,
    &vhost_manage_pointer->receive_statistics_interface_mutex,
    vhost_manage_pointer->receive_statistics_control_head,
    &vhost_manage_pointer->receive_statistics_packet_num );
}


void
vhost_delete_statistics( VHOST_STATISTICS_CONTROL_POINTER control_queue_pointer, pthread_mutex_t *mutex ) {
  int lp;
  VHOST_STATISTICS_POINTER current_pointer;
  VHOST_STATISTICS_POINTER next_pointer;

  pthread_mutex_lock( mutex );

  for ( lp = 0; lp < STATISTICS_CONTROL_MAX; lp++, control_queue_pointer++ ) {
    if ( control_queue_pointer->head != NULL ) {
      current_pointer = control_queue_pointer->head;
      while ( current_pointer != NULL ) {
        control_queue_pointer->head = current_pointer->next;
        if ( control_queue_pointer->tail == current_pointer ) {
          control_queue_pointer->tail = current_pointer->prev;
        }
        if ( control_queue_pointer->head == current_pointer ) {
          control_queue_pointer->head = current_pointer->next;
        }

        next_pointer = current_pointer->next;
        if ( next_pointer != NULL ) {
          next_pointer->prev = NULL;
        }
        free( current_pointer );
        current_pointer = next_pointer;
      }
    }
  }
  pthread_mutex_unlock( mutex );
}


void
vhost_clear_statistics( VHOST_MANAGE_POINTER vhost_manage_pointer, int type ) {
  switch ( type ) {
    case VHOST_STATISTICS_CLEAR_SEND:
      vhost_manage_pointer->send_statistics_packet_num = 0;
      vhost_delete_statistics( &vhost_manage_pointer->send_statistics_control_head[ 0 ],
        &vhost_manage_pointer->send_statistics_interface_mutex );
      break;

    case VHOST_STATISTICS_CLEAR_RECEIVE:
      vhost_manage_pointer->receive_statistics_packet_num = 0;
      vhost_delete_statistics( &vhost_manage_pointer->receive_statistics_control_head[ 0 ],
        &vhost_manage_pointer->receive_statistics_interface_mutex );
      break;

    case VHOST_STATISTICS_CLEAR_ALL:
      vhost_delete_statistics( &vhost_manage_pointer->send_statistics_control_head[ 0 ],
        &vhost_manage_pointer->send_statistics_interface_mutex );
      vhost_delete_statistics( &vhost_manage_pointer->receive_statistics_control_head[ 0 ],
        &vhost_manage_pointer->receive_statistics_interface_mutex );
      vhost_manage_pointer->receive_statistics_packet_num = 0;
      vhost_manage_pointer->send_statistics_packet_num = 0;
      break;
  }
}


void
vhost_thread_exit( VHOST_MANAGE_POINTER vhost_manage_pointer ) {
  int lp;

  vhost_manage_pointer->stop_req = FALSE;

  // thread exit
  pthread_mutex_lock( &vhost_manage_pointer->receiver_pointer->receiver_interface_mutex );
  vhost_manage_pointer->receiver_pointer->vhost_connect_nums -= 1;
  pthread_mutex_unlock( &vhost_manage_pointer->receiver_pointer->receiver_interface_mutex );

  memset( &vhost_manage_pointer->vhost_control, '\0', sizeof( VHOST_CONTROL ) );
  memset( vhost_manage_pointer->sender_device_name, '\0', sizeof( VHOST_DEVICE_NAME_MAX ) );
  vhost_manage_pointer->receiver_pointer = NULL;

  // delete statistics entry
  vhost_clear_statistics( vhost_manage_pointer, VHOST_STATISTICS_CLEAR_ALL );

  // delete arp entry
  pthread_mutex_lock( &vhost_manage_pointer->arp_interface_mutex );
  vhost_manage_pointer->arp_number = 0;
  for ( lp = 0; lp < ARP_HASH_MAX; lp++ ) {
    while ( vhost_manage_pointer->arp_control_head[ lp ].head != NULL ) {
      arp_entry_delete( &vhost_manage_pointer->arp_control_head[ lp ],
        vhost_manage_pointer->arp_control_head[ lp ].head );
    }
  }

  pthread_mutex_unlock( &vhost_manage_pointer->arp_interface_mutex );
  pthread_exit( ( void * ) NULL );
}


void *
vhost_thread_main( void *args ) {
  VHOST_MANAGE_POINTER vhost_manage_pointer = ( VHOST_MANAGE_POINTER ) args;
  VHOST_RECEIVE_BUFFER_POINTER receiver_head;
  VHOST_STATISTICS_POINTER receive_statistics_pointer;
  struct timespec request;
  int next_offset;
  u_short protocol_number;

  pthread_detach( pthread_self() );

  // thread initialize
  pthread_mutex_lock( &vhost_manage_pointer->receiver_pointer->receiver_interface_mutex );
  receiver_head = vhost_manage_pointer->receiver_pointer->receive_queue.head;
  vhost_manage_pointer->receiver_pointer->vhost_connect_nums += 1;

  pthread_mutex_unlock( &vhost_manage_pointer->receiver_pointer->receiver_interface_mutex );

  receive_statistics_pointer = ( VHOST_STATISTICS_POINTER ) calloc( 1, sizeof( VHOST_STATISTICS ) );
  if ( receive_statistics_pointer == NULL ) {
    // no more memory
    vhost_thread_exit( vhost_manage_pointer );
  }
  while ( 1 ) {
    if ( vhost_manage_pointer->stop_req == TRUE ) {
      break;
    }

    request.tv_sec = 0;
    request.tv_nsec = VHOST_WATCH_TIME;

    nanosleep( &request, NULL );

    while ( receiver_head != vhost_manage_pointer->receiver_pointer->receive_queue.head ) {
      if ( ( ( receiver_head->statistics.packet_buffer[ 0 ] & ETHERNET_MULTICAST_BIT ) == ETHERNET_MULTICAST_BIT )
         || ( memcmp( vhost_manage_pointer->vhost_control.host_mac_address,
            receiver_head->statistics.packet_buffer, MAC_ADDRESS_LENGTH ) == 0 )
         || ( vhost_manage_pointer->vhost_control.promisc_mode == TRUE ) ) {
        memmove( &receive_statistics_pointer->statistics, &receiver_head->statistics, sizeof( STATISTICS_INFORMATION ) );

        // Check IP
        next_offset = check_ether_header( &receive_statistics_pointer->statistics,
          &receive_statistics_pointer->statistics.ether_type );

        // Check UDP
        if ( receive_statistics_pointer->statistics.ether_type == ETH_P_IP ) {
          ( void ) check_ip_header( &receive_statistics_pointer->statistics,
            &receive_statistics_pointer->statistics.packet_buffer[ next_offset ],
            &protocol_number, &receive_statistics_pointer->statistics.ip_check_sum,
            &receive_statistics_pointer->statistics.udp_check_sum );
        }

        vhost_receive_main( vhost_manage_pointer, receive_statistics_pointer );
      }
      receiver_head = receiver_head->next;
    }
  }
  free( receive_statistics_pointer );
  vhost_thread_exit( vhost_manage_pointer );

  return NULL;
}


/******************************************************************************
 * receiver functions                                                         *
 ******************************************************************************/
void
vhost_add_vlan_tci( struct msghdr *message_pointer, struct iovec *iovbec_pointer, u_char *buffer_pointer, int *packet_length ) {
  struct tpacket_auxdata *aux_data_pointer;
  u_int length;
  u_int copy;
  u_short *ptr;
  struct cmsghdr *current_message_pointer;

  for ( current_message_pointer = CMSG_FIRSTHDR( message_pointer ); current_message_pointer;
    current_message_pointer = CMSG_NXTHDR( message_pointer, current_message_pointer ) ) {
    if ( ( current_message_pointer->cmsg_len < CMSG_LEN( sizeof( struct tpacket_auxdata ) ) )
       || ( current_message_pointer->cmsg_level != SOL_PACKET ) || ( current_message_pointer->cmsg_type != PACKET_AUXDATA ) ) {
      continue;
    }

    aux_data_pointer = ( struct tpacket_auxdata * ) CMSG_DATA( current_message_pointer );
    if ( aux_data_pointer->tp_vlan_tci == 0 ) {
      continue;
    }

    length = ( u_int ) * packet_length > ( u_int ) iovbec_pointer->iov_len ? ( u_int ) iovbec_pointer->iov_len : ( u_int ) * packet_length;
    copy = length - 2 * ETH_ALEN;
    memmove( buffer_pointer + ( 2 * ETH_ALEN ) + 4,
      buffer_pointer + ( 2 * ETH_ALEN ), copy );

    ptr = ( unsigned short * ) ( ( unsigned char * ) iovbec_pointer->iov_base + 2 * ETH_ALEN );

    if ( length >= 2 * ETH_ALEN + 2 ) {
      *( ptr++ ) = Mhtons( ETH_P_8021Q );
    }

    if ( length >= 2 * ETH_ALEN + 4 ) {
      *( ptr++ ) = Mhtons( aux_data_pointer->tp_vlan_tci );
    }

    *packet_length += 4;
  }
}


void
vhost_receiver_exit( DEVICE_CONTROL_POINTER receiver_control ) {
  VHOST_RECEIVE_BUFFER_POINTER control;

  memset( receiver_control->device_name, '\0', VHOST_DEVICE_NAME_MAX );
  receiver_control->stop_req = FALSE;

  // cutting ring
  receiver_control->receive_queue.tail->next = NULL;

  // delete ring
  while ( receiver_control->receive_queue.head != NULL ) {
    control = receiver_control->receive_queue.head;
    receiver_control->receive_queue.head = control->next;
    if ( receiver_control->receive_queue.tail == control ) {
      receiver_control->receive_queue.tail = control->next;
    }
    free( control );
  }

  receiver_control->ifrequest.ifr_flags &= ~( IFF_PROMISC | IFF_ALLMULTI );
  ioctl( receiver_control->socket_fd, SIOCSIFFLAGS, &receiver_control->ifrequest );
  close( receiver_control->socket_fd );
  receiver_control->socket_fd = -1;

  pthread_exit( ( void * ) NULL );
}


void *
vhost_receiver_main( void *args ) {
  DEVICE_CONTROL_POINTER receiver_control = ( DEVICE_CONTROL_POINTER ) args;
  struct pollfd poll_fd;
  struct timespec select_time;
  int result;
  int lp;
  VHOST_RECEIVE_BUFFER_POINTER current_pointer;
  struct sockaddr_ll receive_socket_addr_ll;
  struct msghdr message;
  struct iovec iovec_buffer;

  union {
    struct cmsghdr cmessage;
    char buffer[ CMSG_SPACE( sizeof( struct tpacket_auxdata ) ) ];
  }
  cmessage_buffer;

  pthread_detach( pthread_self() );

  // initialize receive buffer pool ;
  for ( lp = 0; lp < MAX_RECEIVE_POOL_SIZE; lp++ ) {
    current_pointer = ( VHOST_RECEIVE_BUFFER_POINTER ) calloc( 1, sizeof( VHOST_RECEIVE_BUFFER ) );
    if ( current_pointer == NULL ) {
      vhost_receiver_exit( receiver_control );
    }
    if ( receiver_control->receive_queue.head == NULL ) {
      receiver_control->receive_queue.head = current_pointer;
      receiver_control->receive_queue.tail = current_pointer;
    }
    else {
      receiver_control->receive_queue.tail->next = current_pointer;
      current_pointer->prev = receiver_control->receive_queue.tail;
      receiver_control->receive_queue.tail = current_pointer;
    }
  }
  // make ring
  receiver_control->receive_queue.tail->next = receiver_control->receive_queue.head;
  receiver_control->receive_queue.head->prev = receiver_control->receive_queue.tail;
  if ( ioctl( receiver_control->socket_fd, SIOCGIFFLAGS, &receiver_control->ifrequest ) != 0 ) {
    return NULL;
  }
  receiver_control->ifrequest.ifr_flags |= ( IFF_PROMISC | IFF_ALLMULTI );
  if ( ioctl( receiver_control->socket_fd, SIOCSIFFLAGS, &receiver_control->ifrequest ) != 0 ) {
    return NULL;
  }

  message.msg_name = &receive_socket_addr_ll;
  message.msg_namelen = sizeof( receive_socket_addr_ll );
  message.msg_iov = &iovec_buffer;
  message.msg_iovlen = 1;
  message.msg_control = &cmessage_buffer;
  message.msg_controllen = sizeof( cmessage_buffer );
  message.msg_flags = 0;
  //
  memset( &poll_fd, '\0', sizeof( struct pollfd ) );
  poll_fd.fd = receiver_control->socket_fd;
  poll_fd.events = POLLIN | POLLERR;
  while ( 1 ) {
    select_time.tv_sec = MAX_RECEIVER_THERAD_WAIT;
    select_time.tv_nsec = 0;
    result = ppoll( &poll_fd, 1, &select_time, NULL );
    if ( receiver_control->stop_req == TRUE ) {
      break;
    }
    // get event
    if ( result <= 0 ) {
      continue;
    }
    while ( 1 ) {
      current_pointer = receiver_control->receive_queue.head;

      iovec_buffer.iov_len = MAX_RECEIVE_BUFFER_SIZE;
      iovec_buffer.iov_base = current_pointer->statistics.packet_buffer;

      current_pointer->statistics.packet_bytes = ( int ) recvmsg( receiver_control->socket_fd, &message, MSG_TRUNC );
      if ( current_pointer->statistics.packet_bytes <= 0 ) {
        break;
      }
      vhost_add_vlan_tci( &message, &iovec_buffer, current_pointer->statistics.packet_buffer,
        &current_pointer->statistics.packet_bytes );
      receiver_control->receive_queue.head = current_pointer->next;
      current_pointer = receiver_control->receive_queue.tail;
      receiver_control->receive_queue.tail = receiver_control->receive_queue.tail->next;
    }
  }

  // clear data
  vhost_receiver_exit( receiver_control );

  return NULL;
}


/******************************************************************************
 * sender functions                                                           *
 ******************************************************************************/
void
vhost_add_send_ng_message_entry( VHOST_SEND_NG_INFORMATION_CONTROL_QUEUE_POINTER send_ng_queue_pointer, u_int ipv4_address ) {
  VHOST_SEND_NG_INFORMATION_CONTROL_POINTER send_ng_control_pointer;

  send_ng_control_pointer = ( VHOST_SEND_NG_INFORMATION_CONTROL_POINTER ) calloc( 1, sizeof( VHOST_SEND_NG_INFORMATION_CONTROL ) );
  if ( send_ng_control_pointer == NULL ) {
    // no more memory
    return;
  }

  send_ng_control_pointer->ng_information.ipv4_address = ipv4_address;

  if ( send_ng_queue_pointer->head == NULL ) {
    send_ng_queue_pointer->head = send_ng_queue_pointer->tail = send_ng_control_pointer;
  }
  else {
    send_ng_queue_pointer->tail->next = send_ng_control_pointer;
    send_ng_control_pointer->prev = send_ng_queue_pointer->tail;
    send_ng_queue_pointer->tail = send_ng_control_pointer;
  }
}


void
vhost_arp_request_send( VHOST_MANAGE_POINTER vhost_manage_pointer, u_int destination_ip_address ) {
  size_t size;
  VHOST_STATISTICS_POINTER send_buffer;
  SMAC_CONTROL arp_distination_mac_address;
  SMAC_CONTROL source_mac_address;
  IP_ADDRESS_CONTROL arp_source_ip_address;
  IP_ADDRESS_CONTROL arp_distination_ip_address;
  VHOST_ARP_DATA_POINTER arp_data;


  send_buffer = ( VHOST_STATISTICS_POINTER ) calloc( 1, sizeof( VHOST_STATISTICS ) );
  if ( send_buffer == NULL ) {
    return;
  }
  arp_source_ip_address.ipv4_address = vhost_manage_pointer->vhost_control.ipv4_address;
  arp_source_ip_address.ipv4_mask = vhost_manage_pointer->vhost_control.ipv4_mask;
  arp_source_ip_address.current_no = 0;

  arp_distination_ip_address.ipv4_address = destination_ip_address;
  arp_distination_ip_address.ipv4_mask = 0;
  arp_distination_ip_address.current_no = 0;

  memset( arp_distination_mac_address.mac_address, 0xff, MAC_ADDRESS_LENGTH );
  memset( arp_distination_mac_address.mask, '\0', MAC_ADDRESS_LENGTH );
  arp_distination_mac_address.current_no = 0;

  memcpy( source_mac_address.mac_address, vhost_manage_pointer->vhost_control.host_mac_address, MAC_ADDRESS_LENGTH );
  memset( source_mac_address.mask, '\0', MAC_ADDRESS_LENGTH );
  source_mac_address.current_no = 0;

  if ( vhost_manage_pointer->vhost_control.l2_type == PACKET_TYPE_8021Q ) {
    size = ( size_t ) make_vlan_header( NULL, arp_distination_mac_address.mac_address, &source_mac_address,
      ( u_short ) vhost_manage_pointer->vhost_control.vlan_id, 0, ETH_P_ARP,
      send_buffer->statistics.packet_buffer );
  }
  else {
    size = ( size_t ) make_ether_header( NULL, arp_distination_mac_address.mac_address, &source_mac_address, 0,
      ETH_P_ARP, send_buffer->statistics.packet_buffer );
  }
  memset( arp_distination_mac_address.mac_address, '\0', MAC_ADDRESS_LENGTH );

  size += make_arp( ARP_HARDWARE_TYPE, ARP_PROTOCOL_TYPE, ARPOP_REQUEST, NULL, &arp_distination_mac_address, &source_mac_address,
    0, &arp_source_ip_address, &arp_distination_ip_address, 0,
    &send_buffer->statistics.packet_buffer[ size ] );

  send( vhost_manage_pointer->socket_fd, send_buffer->statistics.packet_buffer, MINIMAM_PACKET_SIZE, 0 );
  send_buffer->statistics.packet_bytes = MINIMAM_PACKET_SIZE;

  vhost_add_statistics_entry( send_buffer,
    &vhost_manage_pointer->send_statistics_interface_mutex,
    &vhost_manage_pointer->send_statistics_control_head[ 0 ],
    &vhost_manage_pointer->send_statistics_packet_num );

  free( send_buffer );
  // add arp entry
  arp_data = ( VHOST_ARP_DATA_POINTER ) calloc( 1, sizeof( VHOST_ARP_DATA ) );
  if ( arp_data == NULL ) {
    // no more memory
    return;
  }
  // temporary registration arp
  arp_data->arp_cache.ipv4_address = destination_ip_address;
  arp_data->arp_cache.vlan_info = TEMPORARY_REGISTRATION_ARP_ENTRY;

  vhost_arp_add( &vhost_manage_pointer->arp_control_head[ 0 ], arp_data,
    &vhost_manage_pointer->arp_interface_mutex,
    &vhost_manage_pointer->arp_number,
    vhost_manage_pointer->vhost_control.arp_cache_time );
}


void
vhost_create_payload( VHOST_SEND_REQUEST_DATA_CONTROL_POINTER send_control_pointer,
                      VHOST_STATISTICS_POINTER send_buffer, u_int send_length ) {
  if ( send_control_pointer->packet_length > send_length ) {
    if ( send_control_pointer->payload_pattern != 0 ) {
      copy_payload( ( send_buffer->statistics.packet_buffer + send_length ),
        ( int ) send_control_pointer->payload_length,
        send_control_pointer->payload,
        ( int ) ( send_control_pointer->packet_length - send_length ) );

      send_buffer->statistics.packet_check_sum
        = make_payload( ( send_buffer->statistics.packet_buffer + send_length ),
        ( int * ) &send_control_pointer->current_packet_num,
        ( int ) send_control_pointer->payload_pattern,
        ( int ) ( send_control_pointer->packet_length - send_length ),
        ( int ) send_control_pointer->payload_count,
        ( int ) send_control_pointer->payload_limit,
        send_control_pointer->payload_mask,
        send_control_pointer->random_information_pointer );
    }
    else {
      send_buffer->statistics.packet_check_sum
        = calculate_crc( ( u_short * ) ( send_buffer->statistics.packet_buffer + send_length ),
        ( send_control_pointer->packet_length - send_length ) );
    }
  }
}


int
vhost_raw_genarator_send( VHOST_SEND_REQUEST_DATA_CONTROL_POINTER send_control_pointer,
                          VHOST_STATISTICS_POINTER send_buffer ) {
  u_int destination_ip_address;
  u_char destination_mac_address[ MAC_ADDRESS_LENGTH ];
  UDP_DUMMY_HEADER udp_dummy_header;
  int send_length;

  make_mac( send_control_pointer->random_information_pointer,
    &send_control_pointer->destination_mac_address,
    ( send_control_pointer->mac_type >> DESTINATION_INFORMATION_POSITION ),
    destination_mac_address );

  if ( send_control_pointer->l2_type == PACKET_TYPE_8021Q ) {
    send_length = make_vlan_header( send_control_pointer->random_information_pointer,
      destination_mac_address,
      &send_control_pointer->source_mac_address,
      send_control_pointer->vlan_information,
      send_control_pointer->mac_type,
      send_control_pointer->ether_type,
      send_buffer->statistics.packet_buffer );
  }
  else {
    send_length = make_ether_header( send_control_pointer->random_information_pointer,
      destination_mac_address,
      &send_control_pointer->source_mac_address,
      send_control_pointer->mac_type,
      send_control_pointer->ether_type,
      send_buffer->statistics.packet_buffer );
  }
  if ( send_control_pointer->layer_3_type == VHOST_SEND_REQUEST_LAYER_3_TYPE_IPV4 ) {
    destination_ip_address = make_ip_address( send_control_pointer->random_information_pointer,
      &send_control_pointer->destination_ip_address,
      ( send_control_pointer->ip_type >> DESTINATION_INFORMATION_POSITION ) );

    send_buffer->statistics.ip_header_offset = send_length;
    send_length += ( int ) make_ip_header( send_control_pointer->tos,
      send_control_pointer->id,
      ( u_short ) ( send_control_pointer->flagment_offset | ( ( send_control_pointer->flags & 0xF ) << 12 ) ),
      send_control_pointer->ttl,
      send_control_pointer->protocol_number,
      send_control_pointer->random_information_pointer,
      &send_control_pointer->source_ip_address,
      destination_ip_address,
      send_control_pointer->ip_type,
      send_control_pointer->option_length,
      send_control_pointer->option,
      ( send_control_pointer->packet_length - ( u_int ) send_length ),
      ( send_buffer->statistics.packet_buffer + ( u_int ) send_length ),
      &send_buffer->statistics, &udp_dummy_header );

    if ( send_control_pointer->protocol_number == IPPROTO_UDP ) {
      send_buffer->statistics.udp_header_offset = send_length;
      send_length += make_udp_header( send_control_pointer->random_information_pointer,
        &send_control_pointer->source_port_number,
        &send_control_pointer->destination_port_number,
        send_control_pointer->udp_type,
        ( u_short ) ( send_control_pointer->packet_length - ( u_int ) send_length ),
        ( send_buffer->statistics.packet_buffer + ( u_int ) send_length ),
        &udp_dummy_header,
        &send_buffer->statistics );
    }
  }
  else {
    send_length += ( int ) make_arp( send_control_pointer->hardware_type,
      send_control_pointer->protocol_type,
      send_control_pointer->operation_code,
      send_control_pointer->random_information_pointer,
      &send_control_pointer->arp_destination_mac_address,
      &send_control_pointer->arp_source_mac_address,
      send_control_pointer->arp_mac_type,
      &send_control_pointer->source_ip_address,
      &send_control_pointer->destination_ip_address,
      send_control_pointer->ip_type,
      &send_buffer->statistics.packet_buffer[ send_length ] );
  }
  vhost_create_payload( send_control_pointer, send_buffer, ( u_int ) send_length );

  return TRUE;
}


int
vhost_host_emuration_send( VHOST_SEND_REQUEST_DATA_CONTROL_POINTER send_control_pointer, VHOST_MANAGE_POINTER vhost_manage_pointer,
                           VHOST_STATISTICS_POINTER send_buffer ) {
  u_int destination_ip_address;
  u_char destination_mac_address[ MAC_ADDRESS_LENGTH ];
  UDP_DUMMY_HEADER udp_dummy_header;
  int send_length;
  struct timespec request;
  ARP_CAHCE_TABLE_POINTER arp_cache_pointer;

  destination_ip_address = make_ip_address( send_control_pointer->random_information_pointer,
    &send_control_pointer->destination_ip_address,
    ( send_control_pointer->ip_type >> DESTINATION_INFORMATION_POSITION ) );

  arp_cache_pointer = vhost_search_arp_cache( vhost_manage_pointer, destination_ip_address );
  if ( arp_cache_pointer == NULL ) {
    if ( ( destination_ip_address & vhost_manage_pointer->vhost_control.ipv4_mask )
      != ( vhost_manage_pointer->vhost_control.ipv4_address & vhost_manage_pointer->vhost_control.ipv4_mask ) ) {
      vhost_add_send_ng_message_entry( &send_control_pointer->send_ng_queue, destination_ip_address );
      return FALSE ;
    }
    // arp request
    vhost_arp_request_send( vhost_manage_pointer, destination_ip_address );

    // wait arp reply or  arp timeout
    while( (arp_cache_pointer = vhost_search_arp_cache( vhost_manage_pointer, destination_ip_address ) ) != NULL ){
      if ( send_control_pointer->stop_req == TRUE ) {
        vhost_add_send_ng_message_entry( &send_control_pointer->send_ng_queue, destination_ip_address );
        return FALSE;
      }
      if ( ( arp_cache_pointer->vlan_info & TEMPORARY_REGISTRATION_ARP_ENTRY ) != TEMPORARY_REGISTRATION_ARP_ENTRY ) {
        memcpy( destination_mac_address, arp_cache_pointer->mac_address, MAC_ADDRESS_LENGTH );
        break ;
      }
      request.tv_sec = 0;
      request.tv_nsec = VHOST_WATCH_TIME;
      nanosleep( &request, NULL );
    }
    // add send ng queue
    if( arp_cache_pointer == NULL ){
      vhost_add_send_ng_message_entry( &send_control_pointer->send_ng_queue, destination_ip_address );
      return FALSE;
    }
  }
  else {
    if ( ( arp_cache_pointer->ageout_time <= ARP_REQUEST_AGEOUT_TIME ) 
      && ( ( arp_cache_pointer->vlan_info & TEMPORARY_REGISTRATION_ARP_ENTRY ) != TEMPORARY_REGISTRATION_ARP_ENTRY ) ) {
      vhost_arp_request_send( vhost_manage_pointer, destination_ip_address );
    }
    memcpy( destination_mac_address, arp_cache_pointer->mac_address, MAC_ADDRESS_LENGTH );
  }

  if ( vhost_manage_pointer->vhost_control.l2_type == PACKET_TYPE_8021Q ) {
    send_length = make_vlan_header( send_control_pointer->random_information_pointer,
      destination_mac_address,
      &send_control_pointer->source_mac_address,
      send_control_pointer->vlan_information,
      send_control_pointer->mac_type,
      send_control_pointer->ether_type,
      send_buffer->statistics.packet_buffer );
    send_buffer->statistics.ip_header_offset = send_length;
  }
  else {
    send_length = make_ether_header( send_control_pointer->random_information_pointer,
      destination_mac_address,
      &send_control_pointer->source_mac_address,
      send_control_pointer->mac_type,
      send_control_pointer->ether_type,
      send_buffer->statistics.packet_buffer );

    send_buffer->statistics.ip_header_offset = send_length;
  }

  send_length += ( int ) make_ip_header( send_control_pointer->tos,
    send_control_pointer->id,
    ( u_short ) ( send_control_pointer->flagment_offset | ( ( send_control_pointer->flags & 0xF ) << 12 ) ),
    send_control_pointer->ttl,
    send_control_pointer->protocol_number,
    send_control_pointer->random_information_pointer,
    &send_control_pointer->source_ip_address,
    arp_cache_pointer->ipv4_address,
    send_control_pointer->ip_type,
    send_control_pointer->option_length,
    send_control_pointer->option,
    ( send_control_pointer->packet_length - ( u_int ) send_length ),
    ( send_buffer->statistics.packet_buffer + ( u_int ) send_length ),
    &send_buffer->statistics, &udp_dummy_header );

  if ( send_control_pointer->protocol_number == IPPROTO_UDP ) {
    send_buffer->statistics.udp_header_offset = send_length;
    send_length += make_udp_header( send_control_pointer->random_information_pointer,
      &send_control_pointer->source_port_number,
      &send_control_pointer->destination_port_number,
      send_control_pointer->udp_type,
      ( u_short ) ( send_control_pointer->packet_length - ( u_int ) send_length ),
      ( send_buffer->statistics.packet_buffer + ( u_int ) send_length ),
      &udp_dummy_header,
      &send_buffer->statistics );
  }

  vhost_create_payload( send_control_pointer, send_buffer, ( u_int ) send_length );

  return TRUE;
}


void
vhost_delete_send_ng_queue( VHOST_SEND_NG_INFORMATION_CONTROL_QUEUE_POINTER send_ng_queue_pointer ) {
                            VHOST_SEND_NG_INFORMATION_CONTROL_POINTER send_ng_control;

  while ( send_ng_queue_pointer->head != NULL ) {
    send_ng_control = send_ng_queue_pointer->head;
    send_ng_queue_pointer->head = send_ng_control->next;
    free( send_ng_control );
  }

  send_ng_queue_pointer->tail = NULL;
}


void
vhost_sender_exit( VHOST_SEND_REQUEST_DATA_CONTROL_POINTER send_control_pointer ) {
  if ( send_control_pointer->response_type == FALSE ) {
    vhost_delete_send_ng_queue( &send_control_pointer->send_ng_queue );
  }

  if ( send_control_pointer->payload != NULL ) {
    free( send_control_pointer->payload );
  }

  if ( send_control_pointer->payload_mask != NULL ) {
    free( send_control_pointer->payload_mask );
  }
  send_control_pointer->payload = NULL;
  send_control_pointer->send_status = FALSE;
  send_control_pointer->stop_req = FALSE;

  pthread_exit( ( void * ) NULL );
}


void *
vhost_sender_main( void *args ) {
  VHOST_SEND_REQUEST_DATA_CONTROL_POINTER send_control_pointer = ( VHOST_SEND_REQUEST_DATA_CONTROL_POINTER ) args;
  VHOST_MANAGE_POINTER vhost_manage_pointer;
  u_int send_num;
  u_int rc;
  u_int current_send_num;
  int send_request;
  struct timespec start_timevalue;
  struct timespec stop_timevalue;
  struct timespec sub_timevalue;
  struct timespec sleep_timevalue;
  VHOST_STATISTICS_POINTER send_buffer;

  pthread_detach( pthread_self() );

  vhost_manage_pointer = send_control_pointer->vhost_manage_pointer;

  if ( send_control_pointer->duration != 0 ) {
    send_num = send_control_pointer->packet_par_second * send_control_pointer->duration;
  }
  else {
    send_num = send_control_pointer->packet_num;
  }

  send_buffer = ( VHOST_STATISTICS_POINTER ) calloc( 1, sizeof( VHOST_STATISTICS ) );
  if ( send_buffer == NULL ) {
    vhost_sender_exit( send_control_pointer );
  }

  clock_gettime( CLOCK_REALTIME, &start_timevalue );
  for ( current_send_num = 0; current_send_num < send_num; current_send_num++ ) {
    if ( send_control_pointer->stop_req == TRUE ) {
      break;
    }
    memset( send_buffer, '\0', sizeof( VHOST_STATISTICS ) );
    // Make Send Data
    if ( send_control_pointer->generator_mode == HOST_EMURATOR_MODE ) {
      send_request = vhost_host_emuration_send( send_control_pointer, vhost_manage_pointer, send_buffer );
    }
    else {
      send_request = vhost_raw_genarator_send( send_control_pointer, send_buffer );
    }
    if ( send_request == TRUE ) {
      do {
        rc = ( u_int ) send( vhost_manage_pointer->socket_fd, send_buffer->statistics.packet_buffer,
          send_control_pointer->packet_length, 0 );
      } while ( rc != send_control_pointer->packet_length );

      send_buffer->statistics.packet_bytes = ( int ) send_control_pointer->packet_length;
      vhost_add_statistics_entry( send_buffer,
        &vhost_manage_pointer->send_statistics_interface_mutex,
        &vhost_manage_pointer->send_statistics_control_head[ 0 ],
        &vhost_manage_pointer->send_statistics_packet_num );
    }

    if ( ( current_send_num != 0 ) && ( ( current_send_num % send_control_pointer->packet_par_second ) == 0 ) ) {
      clock_gettime( CLOCK_REALTIME, &stop_timevalue );
      nanotimersub( &stop_timevalue, &start_timevalue, &sub_timevalue );
      sub_timevalue.tv_nsec = ( NANO_SECOND - sub_timevalue.tv_nsec );
      nanotimeradd( &stop_timevalue, &sub_timevalue, &sleep_timevalue );

      clock_nanosleep( CLOCK_REALTIME, TIMER_ABSTIME, ( const struct timespec * ) &sleep_timevalue, NULL );
      clock_gettime( CLOCK_REALTIME, &start_timevalue );
    }
  }
  clock_gettime( CLOCK_REALTIME, &stop_timevalue );

  free( send_buffer );
  vhost_sender_exit( send_control_pointer );

  return NULL;
}
